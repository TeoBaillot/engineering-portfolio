-- Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2018.2 (lin64) Build 2258646 Thu Jun 14 20:02:38 MDT 2018
-- Date        : Wed Dec 17 16:21:10 2025
-- Host        : PCII-REF running 64-bit Ubuntu 22.04.5 LTS
-- Command     : write_vhdl -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ zed_lenet_cnn_1_0_stub.vhdl
-- Design      : zed_lenet_cnn_1_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7z020clg484-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  Port ( 
    ap_clk : in STD_LOGIC;
    ap_rst_n : in STD_LOGIC;
    ap_start : in STD_LOGIC;
    ap_done : out STD_LOGIC;
    ap_idle : out STD_LOGIC;
    ap_ready : out STD_LOGIC;
    input_r_Clk_A : out STD_LOGIC;
    input_r_Rst_A : out STD_LOGIC;
    input_r_EN_A : out STD_LOGIC;
    input_r_WEN_A : out STD_LOGIC_VECTOR ( 3 downto 0 );
    input_r_Addr_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    input_r_Din_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    input_r_Dout_A : in STD_LOGIC_VECTOR ( 31 downto 0 );
    conv1_kernel_Clk_A : out STD_LOGIC;
    conv1_kernel_Rst_A : out STD_LOGIC;
    conv1_kernel_EN_A : out STD_LOGIC;
    conv1_kernel_WEN_A : out STD_LOGIC_VECTOR ( 3 downto 0 );
    conv1_kernel_Addr_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    conv1_kernel_Din_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    conv1_kernel_Dout_A : in STD_LOGIC_VECTOR ( 31 downto 0 );
    conv1_bias_Clk_A : out STD_LOGIC;
    conv1_bias_Rst_A : out STD_LOGIC;
    conv1_bias_EN_A : out STD_LOGIC;
    conv1_bias_WEN_A : out STD_LOGIC_VECTOR ( 3 downto 0 );
    conv1_bias_Addr_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    conv1_bias_Din_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    conv1_bias_Dout_A : in STD_LOGIC_VECTOR ( 31 downto 0 );
    conv2_bias_Clk_A : out STD_LOGIC;
    conv2_bias_Rst_A : out STD_LOGIC;
    conv2_bias_EN_A : out STD_LOGIC;
    conv2_bias_WEN_A : out STD_LOGIC_VECTOR ( 3 downto 0 );
    conv2_bias_Addr_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    conv2_bias_Din_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    conv2_bias_Dout_A : in STD_LOGIC_VECTOR ( 31 downto 0 );
    fc1_bias_Clk_A : out STD_LOGIC;
    fc1_bias_Rst_A : out STD_LOGIC;
    fc1_bias_EN_A : out STD_LOGIC;
    fc1_bias_WEN_A : out STD_LOGIC_VECTOR ( 3 downto 0 );
    fc1_bias_Addr_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    fc1_bias_Din_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    fc1_bias_Dout_A : in STD_LOGIC_VECTOR ( 31 downto 0 );
    fc2_kernel_Clk_A : out STD_LOGIC;
    fc2_kernel_Rst_A : out STD_LOGIC;
    fc2_kernel_EN_A : out STD_LOGIC;
    fc2_kernel_WEN_A : out STD_LOGIC_VECTOR ( 3 downto 0 );
    fc2_kernel_Addr_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    fc2_kernel_Din_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    fc2_kernel_Dout_A : in STD_LOGIC_VECTOR ( 31 downto 0 );
    fc2_bias_Clk_A : out STD_LOGIC;
    fc2_bias_Rst_A : out STD_LOGIC;
    fc2_bias_EN_A : out STD_LOGIC;
    fc2_bias_WEN_A : out STD_LOGIC_VECTOR ( 3 downto 0 );
    fc2_bias_Addr_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    fc2_bias_Din_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    fc2_bias_Dout_A : in STD_LOGIC_VECTOR ( 31 downto 0 );
    output_r_Clk_A : out STD_LOGIC;
    output_r_Rst_A : out STD_LOGIC;
    output_r_EN_A : out STD_LOGIC;
    output_r_WEN_A : out STD_LOGIC_VECTOR ( 3 downto 0 );
    output_r_Addr_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    output_r_Din_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    output_r_Dout_A : in STD_LOGIC_VECTOR ( 31 downto 0 )
  );

end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture stub of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "ap_clk,ap_rst_n,ap_start,ap_done,ap_idle,ap_ready,input_r_Clk_A,input_r_Rst_A,input_r_EN_A,input_r_WEN_A[3:0],input_r_Addr_A[31:0],input_r_Din_A[31:0],input_r_Dout_A[31:0],conv1_kernel_Clk_A,conv1_kernel_Rst_A,conv1_kernel_EN_A,conv1_kernel_WEN_A[3:0],conv1_kernel_Addr_A[31:0],conv1_kernel_Din_A[31:0],conv1_kernel_Dout_A[31:0],conv1_bias_Clk_A,conv1_bias_Rst_A,conv1_bias_EN_A,conv1_bias_WEN_A[3:0],conv1_bias_Addr_A[31:0],conv1_bias_Din_A[31:0],conv1_bias_Dout_A[31:0],conv2_bias_Clk_A,conv2_bias_Rst_A,conv2_bias_EN_A,conv2_bias_WEN_A[3:0],conv2_bias_Addr_A[31:0],conv2_bias_Din_A[31:0],conv2_bias_Dout_A[31:0],fc1_bias_Clk_A,fc1_bias_Rst_A,fc1_bias_EN_A,fc1_bias_WEN_A[3:0],fc1_bias_Addr_A[31:0],fc1_bias_Din_A[31:0],fc1_bias_Dout_A[31:0],fc2_kernel_Clk_A,fc2_kernel_Rst_A,fc2_kernel_EN_A,fc2_kernel_WEN_A[3:0],fc2_kernel_Addr_A[31:0],fc2_kernel_Din_A[31:0],fc2_kernel_Dout_A[31:0],fc2_bias_Clk_A,fc2_bias_Rst_A,fc2_bias_EN_A,fc2_bias_WEN_A[3:0],fc2_bias_Addr_A[31:0],fc2_bias_Din_A[31:0],fc2_bias_Dout_A[31:0],output_r_Clk_A,output_r_Rst_A,output_r_EN_A,output_r_WEN_A[3:0],output_r_Addr_A[31:0],output_r_Din_A[31:0],output_r_Dout_A[31:0]";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "a0_lenet_cnn,Vivado 2018.2";
begin
end;
