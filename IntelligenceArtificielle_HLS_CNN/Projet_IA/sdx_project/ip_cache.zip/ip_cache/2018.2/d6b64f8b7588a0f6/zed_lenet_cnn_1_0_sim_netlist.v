// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2018.2 (lin64) Build 2258646 Thu Jun 14 20:02:38 MDT 2018
// Date        : Wed Dec 17 16:21:10 2025
// Host        : PCII-REF running 64-bit Ubuntu 22.04.5 LTS
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ zed_lenet_cnn_1_0_sim_netlist.v
// Design      : zed_lenet_cnn_1_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg484-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv1_28x28x1_5x5x20
   (\ap_CS_fsm_reg[2]_0 ,
    output_r_Rst_A,
    bias_Addr_A,
    grp_Conv1_28x28x1_5x5x20_fu_74_ap_start_reg_reg,
    input_r_Addr_A,
    conv1_bias_EN_A,
    conv1_kernel_Addr_A,
    conv1_kernel_EN_A,
    grp_Conv1_28x28x1_5x5x20_fu_74_ap_start_reg,
    Q,
    grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg,
    ap_rst_n,
    ap_start,
    \ap_CS_fsm_reg[0]_0 ,
    ap_clk);
  output \ap_CS_fsm_reg[2]_0 ;
  output output_r_Rst_A;
  output [4:0]bias_Addr_A;
  output grp_Conv1_28x28x1_5x5x20_fu_74_ap_start_reg_reg;
  output [10:0]input_r_Addr_A;
  output conv1_bias_EN_A;
  output [9:0]conv1_kernel_Addr_A;
  output conv1_kernel_EN_A;
  input grp_Conv1_28x28x1_5x5x20_fu_74_ap_start_reg;
  input [1:0]Q;
  input grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg;
  input ap_rst_n;
  input ap_start;
  input [0:0]\ap_CS_fsm_reg[0]_0 ;
  input ap_clk;

  wire [2:0]B;
  wire [4:3]B__0;
  wire [1:0]Q;
  wire \ap_CS_fsm[2]_i_1__4_n_4 ;
  wire \ap_CS_fsm[9]_i_1__0_n_4 ;
  wire ap_CS_fsm_pp0_stage0;
  wire ap_CS_fsm_pp0_stage1;
  wire ap_CS_fsm_pp0_stage10;
  wire ap_CS_fsm_pp0_stage11;
  wire ap_CS_fsm_pp0_stage12;
  wire ap_CS_fsm_pp0_stage13;
  wire ap_CS_fsm_pp0_stage14;
  wire ap_CS_fsm_pp0_stage15;
  wire ap_CS_fsm_pp0_stage16;
  wire ap_CS_fsm_pp0_stage17;
  wire ap_CS_fsm_pp0_stage18;
  wire ap_CS_fsm_pp0_stage19;
  wire ap_CS_fsm_pp0_stage2;
  wire ap_CS_fsm_pp0_stage20;
  wire ap_CS_fsm_pp0_stage21;
  wire ap_CS_fsm_pp0_stage22;
  wire ap_CS_fsm_pp0_stage23;
  wire ap_CS_fsm_pp0_stage24;
  wire ap_CS_fsm_pp0_stage3;
  wire ap_CS_fsm_pp0_stage4;
  wire ap_CS_fsm_pp0_stage5;
  wire ap_CS_fsm_pp0_stage6;
  wire ap_CS_fsm_pp0_stage7;
  wire ap_CS_fsm_pp0_stage8;
  wire ap_CS_fsm_pp0_stage9;
  wire [0:0]\ap_CS_fsm_reg[0]_0 ;
  wire \ap_CS_fsm_reg[2]_0 ;
  wire \ap_CS_fsm_reg_n_4_[0] ;
  wire [26:0]ap_NS_fsm;
  wire ap_NS_fsm133_out;
  wire ap_clk;
  wire ap_enable_reg_pp0_iter0;
  wire ap_enable_reg_pp0_iter0_i_1_n_4;
  wire ap_enable_reg_pp0_iter12;
  wire ap_enable_reg_pp0_iter1_i_1_n_4;
  wire ap_enable_reg_pp0_iter1_reg_n_4;
  wire [4:2]ap_phi_mux_filter_index_phi_fu_591_p4;
  wire ap_phi_mux_indvar_flatten2_phi_fu_580_p42;
  wire [4:0]ap_phi_mux_x_phi_fu_624_p4;
  wire [4:0]ap_phi_mux_y_phi_fu_613_p4;
  wire ap_rst_n;
  wire ap_start;
  wire [4:0]bias_Addr_A;
  wire conv1_bias_EN_A;
  wire [9:0]conv1_kernel_Addr_A;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_11_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_12_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_13_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_15_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_16_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_17_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_18_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_19_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_1_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_20_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_21_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_22_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_23_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_24_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_25_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_26_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_27_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_28_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_29_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_2_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_30_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_31_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_32_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_33_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_34_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_35_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_36_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_37_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_3_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_4_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_5_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_6_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_7_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_8_n_4 ;
  wire \conv1_kernel_Addr_A[10]_INST_0_i_9_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_10_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_11_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_12_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_13_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_14_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_15_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_16_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_17_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_18_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_19_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_1_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_20_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_23_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_24_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_25_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_26_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_27_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_28_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_29_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_2_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_30_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_31_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_32_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_33_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_34_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_35_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_36_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_37_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_38_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_39_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_3_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_40_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_41_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_42_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_43_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_44_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_45_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_4_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_5_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_6_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_7_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_8_n_4 ;
  wire \conv1_kernel_Addr_A[11]_INST_0_i_9_n_4 ;
  wire \conv1_kernel_Addr_A[2]_INST_0_i_10_n_4 ;
  wire \conv1_kernel_Addr_A[2]_INST_0_i_1_n_4 ;
  wire \conv1_kernel_Addr_A[2]_INST_0_i_2_n_4 ;
  wire \conv1_kernel_Addr_A[2]_INST_0_i_3_n_4 ;
  wire \conv1_kernel_Addr_A[2]_INST_0_i_4_n_4 ;
  wire \conv1_kernel_Addr_A[2]_INST_0_i_5_n_4 ;
  wire \conv1_kernel_Addr_A[2]_INST_0_i_8_n_4 ;
  wire \conv1_kernel_Addr_A[2]_INST_0_i_9_n_4 ;
  wire \conv1_kernel_Addr_A[3]_INST_0_i_11_n_4 ;
  wire \conv1_kernel_Addr_A[3]_INST_0_i_12_n_4 ;
  wire \conv1_kernel_Addr_A[3]_INST_0_i_1_n_4 ;
  wire \conv1_kernel_Addr_A[3]_INST_0_i_2_n_4 ;
  wire \conv1_kernel_Addr_A[3]_INST_0_i_3_n_4 ;
  wire \conv1_kernel_Addr_A[3]_INST_0_i_4_n_4 ;
  wire \conv1_kernel_Addr_A[3]_INST_0_i_5_n_4 ;
  wire \conv1_kernel_Addr_A[3]_INST_0_i_6_n_4 ;
  wire \conv1_kernel_Addr_A[3]_INST_0_i_7_n_4 ;
  wire \conv1_kernel_Addr_A[4]_INST_0_i_10_n_4 ;
  wire \conv1_kernel_Addr_A[4]_INST_0_i_11_n_4 ;
  wire \conv1_kernel_Addr_A[4]_INST_0_i_1_n_4 ;
  wire \conv1_kernel_Addr_A[4]_INST_0_i_2_n_4 ;
  wire \conv1_kernel_Addr_A[4]_INST_0_i_3_n_4 ;
  wire \conv1_kernel_Addr_A[4]_INST_0_i_4_n_4 ;
  wire \conv1_kernel_Addr_A[4]_INST_0_i_5_n_4 ;
  wire \conv1_kernel_Addr_A[4]_INST_0_i_6_n_4 ;
  wire \conv1_kernel_Addr_A[4]_INST_0_i_7_n_4 ;
  wire \conv1_kernel_Addr_A[4]_INST_0_i_8_n_4 ;
  wire \conv1_kernel_Addr_A[4]_INST_0_i_9_n_4 ;
  wire \conv1_kernel_Addr_A[5]_INST_0_i_10_n_4 ;
  wire \conv1_kernel_Addr_A[5]_INST_0_i_11_n_4 ;
  wire \conv1_kernel_Addr_A[5]_INST_0_i_13_n_4 ;
  wire \conv1_kernel_Addr_A[5]_INST_0_i_14_n_4 ;
  wire \conv1_kernel_Addr_A[5]_INST_0_i_19_n_4 ;
  wire \conv1_kernel_Addr_A[5]_INST_0_i_1_n_4 ;
  wire \conv1_kernel_Addr_A[5]_INST_0_i_2_n_4 ;
  wire \conv1_kernel_Addr_A[5]_INST_0_i_3_n_4 ;
  wire \conv1_kernel_Addr_A[5]_INST_0_i_5_n_4 ;
  wire \conv1_kernel_Addr_A[5]_INST_0_i_6_n_4 ;
  wire \conv1_kernel_Addr_A[5]_INST_0_i_7_n_4 ;
  wire \conv1_kernel_Addr_A[5]_INST_0_i_8_n_4 ;
  wire \conv1_kernel_Addr_A[5]_INST_0_i_9_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_10_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_11_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_12_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_14_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_15_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_16_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_17_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_18_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_19_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_1_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_20_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_21_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_22_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_23_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_24_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_25_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_26_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_27_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_2_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_3_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_5_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_6_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_7_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_8_n_4 ;
  wire \conv1_kernel_Addr_A[6]_INST_0_i_9_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_10_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_11_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_12_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_13_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_14_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_15_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_16_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_17_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_18_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_19_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_1_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_20_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_21_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_22_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_23_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_24_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_25_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_26_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_27_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_28_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_29_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_2_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_30_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_31_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_32_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_33_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_34_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_3_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_4_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_5_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_6_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_7_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_8_n_4 ;
  wire \conv1_kernel_Addr_A[7]_INST_0_i_9_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_10_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_11_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_12_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_13_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_15_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_16_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_17_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_18_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_19_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_1_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_20_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_21_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_22_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_23_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_24_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_25_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_26_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_27_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_28_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_29_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_2_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_30_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_31_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_32_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_33_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_34_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_35_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_3_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_4_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_5_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_6_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_7_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_8_n_4 ;
  wire \conv1_kernel_Addr_A[8]_INST_0_i_9_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_10_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_11_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_12_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_13_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_14_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_15_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_16_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_17_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_18_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_19_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_1_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_20_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_21_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_22_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_23_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_24_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_25_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_26_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_27_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_28_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_29_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_2_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_30_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_31_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_32_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_33_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_3_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_4_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_5_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_6_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_7_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_8_n_4 ;
  wire \conv1_kernel_Addr_A[9]_INST_0_i_9_n_4 ;
  wire conv1_kernel_EN_A;
  wire conv1_kernel_EN_A_INST_0_i_1_n_4;
  wire conv1_kernel_EN_A_INST_0_i_2_n_4;
  wire conv1_kernel_EN_A_INST_0_i_3_n_4;
  wire conv1_kernel_EN_A_INST_0_i_4_n_4;
  wire conv1_kernel_EN_A_INST_0_i_5_n_4;
  wire conv1_kernel_EN_A_INST_0_i_6_n_4;
  wire [10:2]data10;
  wire [10:2]data11;
  wire [10:2]data12;
  wire [10:2]data13;
  wire [10:2]data14;
  wire [10:2]data15;
  wire [10:2]data16;
  wire [10:2]data17;
  wire [10:1]data18;
  wire [10:2]data19;
  wire [10:1]data20;
  wire [10:2]data21;
  wire [10:1]data22;
  wire [10:3]data23;
  wire [10:1]data24;
  wire [10:2]data6;
  wire [10:1]data7;
  wire [10:2]data8;
  wire [10:2]data9;
  wire exitcond_flatten2_fu_663_p2;
  wire \exitcond_flatten2_reg_2688[0]_i_1_n_4 ;
  wire \exitcond_flatten2_reg_2688_reg_n_4_[0] ;
  wire exitcond_flatten_fu_681_p2;
  wire filter_index_reg_587;
  wire \filter_index_reg_587_reg_n_4_[0] ;
  wire \filter_index_reg_587_reg_n_4_[1] ;
  wire \filter_index_reg_587_reg_n_4_[2] ;
  wire \filter_index_reg_587_reg_n_4_[3] ;
  wire \filter_index_reg_587_reg_n_4_[4] ;
  wire grp_Conv1_28x28x1_5x5x20_fu_74_ap_ready;
  wire grp_Conv1_28x28x1_5x5x20_fu_74_ap_start_reg;
  wire grp_Conv1_28x28x1_5x5x20_fu_74_ap_start_reg_reg;
  wire grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg;
  wire [13:0]indvar_flatten2_reg_576;
  wire \indvar_flatten2_reg_576[13]_i_2_n_4 ;
  wire indvar_flatten_next2_reg_26920;
  wire \indvar_flatten_next2_reg_2692[0]_i_3_n_4 ;
  wire \indvar_flatten_next2_reg_2692[0]_i_4_n_4 ;
  wire \indvar_flatten_next2_reg_2692[0]_i_5_n_4 ;
  wire \indvar_flatten_next2_reg_2692[0]_i_6_n_4 ;
  wire \indvar_flatten_next2_reg_2692[12]_i_2_n_4 ;
  wire \indvar_flatten_next2_reg_2692[12]_i_3_n_4 ;
  wire \indvar_flatten_next2_reg_2692[4]_i_2_n_4 ;
  wire \indvar_flatten_next2_reg_2692[4]_i_3_n_4 ;
  wire \indvar_flatten_next2_reg_2692[4]_i_4_n_4 ;
  wire \indvar_flatten_next2_reg_2692[4]_i_5_n_4 ;
  wire \indvar_flatten_next2_reg_2692[8]_i_2_n_4 ;
  wire \indvar_flatten_next2_reg_2692[8]_i_3_n_4 ;
  wire \indvar_flatten_next2_reg_2692[8]_i_4_n_4 ;
  wire \indvar_flatten_next2_reg_2692[8]_i_5_n_4 ;
  wire [13:0]indvar_flatten_next2_reg_2692_reg;
  wire \indvar_flatten_next2_reg_2692_reg[0]_i_2_n_10 ;
  wire \indvar_flatten_next2_reg_2692_reg[0]_i_2_n_11 ;
  wire \indvar_flatten_next2_reg_2692_reg[0]_i_2_n_4 ;
  wire \indvar_flatten_next2_reg_2692_reg[0]_i_2_n_5 ;
  wire \indvar_flatten_next2_reg_2692_reg[0]_i_2_n_6 ;
  wire \indvar_flatten_next2_reg_2692_reg[0]_i_2_n_7 ;
  wire \indvar_flatten_next2_reg_2692_reg[0]_i_2_n_8 ;
  wire \indvar_flatten_next2_reg_2692_reg[0]_i_2_n_9 ;
  wire \indvar_flatten_next2_reg_2692_reg[12]_i_1_n_10 ;
  wire \indvar_flatten_next2_reg_2692_reg[12]_i_1_n_11 ;
  wire \indvar_flatten_next2_reg_2692_reg[12]_i_1_n_7 ;
  wire \indvar_flatten_next2_reg_2692_reg[4]_i_1_n_10 ;
  wire \indvar_flatten_next2_reg_2692_reg[4]_i_1_n_11 ;
  wire \indvar_flatten_next2_reg_2692_reg[4]_i_1_n_4 ;
  wire \indvar_flatten_next2_reg_2692_reg[4]_i_1_n_5 ;
  wire \indvar_flatten_next2_reg_2692_reg[4]_i_1_n_6 ;
  wire \indvar_flatten_next2_reg_2692_reg[4]_i_1_n_7 ;
  wire \indvar_flatten_next2_reg_2692_reg[4]_i_1_n_8 ;
  wire \indvar_flatten_next2_reg_2692_reg[4]_i_1_n_9 ;
  wire \indvar_flatten_next2_reg_2692_reg[8]_i_1_n_10 ;
  wire \indvar_flatten_next2_reg_2692_reg[8]_i_1_n_11 ;
  wire \indvar_flatten_next2_reg_2692_reg[8]_i_1_n_4 ;
  wire \indvar_flatten_next2_reg_2692_reg[8]_i_1_n_5 ;
  wire \indvar_flatten_next2_reg_2692_reg[8]_i_1_n_6 ;
  wire \indvar_flatten_next2_reg_2692_reg[8]_i_1_n_7 ;
  wire \indvar_flatten_next2_reg_2692_reg[8]_i_1_n_8 ;
  wire \indvar_flatten_next2_reg_2692_reg[8]_i_1_n_9 ;
  wire [9:0]indvar_flatten_next_reg_2776;
  wire \indvar_flatten_next_reg_2776[0]_i_1_n_4 ;
  wire \indvar_flatten_next_reg_2776[2]_i_2_n_4 ;
  wire \indvar_flatten_next_reg_2776[3]_i_2_n_4 ;
  wire \indvar_flatten_next_reg_2776[4]_i_2_n_4 ;
  wire \indvar_flatten_next_reg_2776[5]_i_2_n_4 ;
  wire \indvar_flatten_next_reg_2776[6]_i_2_n_4 ;
  wire \indvar_flatten_next_reg_2776[7]_i_2_n_4 ;
  wire \indvar_flatten_next_reg_2776[9]_i_1_n_4 ;
  wire \indvar_flatten_next_reg_2776[9]_i_3_n_4 ;
  wire \indvar_flatten_next_reg_2776[9]_i_4_n_4 ;
  wire \indvar_flatten_next_reg_2776[9]_i_5_n_4 ;
  wire [9:1]indvar_flatten_op_fu_847_p2;
  wire [9:0]indvar_flatten_reg_598;
  wire [10:0]input_r_Addr_A;
  wire \input_r_Addr_A[10]_INST_0_i_10_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_11_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_12_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_13_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_14_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_15_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_16_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_17_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_18_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_19_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_1_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_20_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_21_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_21_n_5 ;
  wire \input_r_Addr_A[10]_INST_0_i_21_n_6 ;
  wire \input_r_Addr_A[10]_INST_0_i_21_n_7 ;
  wire \input_r_Addr_A[10]_INST_0_i_22_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_22_n_5 ;
  wire \input_r_Addr_A[10]_INST_0_i_22_n_6 ;
  wire \input_r_Addr_A[10]_INST_0_i_22_n_7 ;
  wire \input_r_Addr_A[10]_INST_0_i_23_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_23_n_5 ;
  wire \input_r_Addr_A[10]_INST_0_i_23_n_6 ;
  wire \input_r_Addr_A[10]_INST_0_i_23_n_7 ;
  wire \input_r_Addr_A[10]_INST_0_i_24_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_24_n_5 ;
  wire \input_r_Addr_A[10]_INST_0_i_24_n_6 ;
  wire \input_r_Addr_A[10]_INST_0_i_24_n_7 ;
  wire \input_r_Addr_A[10]_INST_0_i_25_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_26_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_27_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_28_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_29_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_2_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_30_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_31_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_32_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_33_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_34_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_35_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_36_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_37_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_38_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_39_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_3_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_40_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_41_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_42_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_43_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_44_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_4_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_5_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_6_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_7_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_7_n_5 ;
  wire \input_r_Addr_A[10]_INST_0_i_7_n_6 ;
  wire \input_r_Addr_A[10]_INST_0_i_7_n_7 ;
  wire \input_r_Addr_A[10]_INST_0_i_8_n_4 ;
  wire \input_r_Addr_A[10]_INST_0_i_9_n_4 ;
  wire \input_r_Addr_A[11]_INST_0_i_10_n_4 ;
  wire \input_r_Addr_A[11]_INST_0_i_11_n_4 ;
  wire \input_r_Addr_A[11]_INST_0_i_1_n_4 ;
  wire \input_r_Addr_A[11]_INST_0_i_2_n_4 ;
  wire \input_r_Addr_A[11]_INST_0_i_3_n_4 ;
  wire \input_r_Addr_A[11]_INST_0_i_4_n_4 ;
  wire \input_r_Addr_A[11]_INST_0_i_5_n_4 ;
  wire \input_r_Addr_A[11]_INST_0_i_6_n_4 ;
  wire \input_r_Addr_A[11]_INST_0_i_7_n_4 ;
  wire \input_r_Addr_A[11]_INST_0_i_8_n_4 ;
  wire \input_r_Addr_A[11]_INST_0_i_9_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_10_n_5 ;
  wire \input_r_Addr_A[12]_INST_0_i_10_n_6 ;
  wire \input_r_Addr_A[12]_INST_0_i_10_n_7 ;
  wire \input_r_Addr_A[12]_INST_0_i_12_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_13_n_7 ;
  wire \input_r_Addr_A[12]_INST_0_i_14_n_5 ;
  wire \input_r_Addr_A[12]_INST_0_i_14_n_6 ;
  wire \input_r_Addr_A[12]_INST_0_i_14_n_7 ;
  wire \input_r_Addr_A[12]_INST_0_i_15_n_5 ;
  wire \input_r_Addr_A[12]_INST_0_i_15_n_6 ;
  wire \input_r_Addr_A[12]_INST_0_i_15_n_7 ;
  wire \input_r_Addr_A[12]_INST_0_i_19_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_1_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_20_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_21_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_22_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_23_n_5 ;
  wire \input_r_Addr_A[12]_INST_0_i_23_n_6 ;
  wire \input_r_Addr_A[12]_INST_0_i_23_n_7 ;
  wire \input_r_Addr_A[12]_INST_0_i_24_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_25_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_26_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_27_n_5 ;
  wire \input_r_Addr_A[12]_INST_0_i_27_n_6 ;
  wire \input_r_Addr_A[12]_INST_0_i_27_n_7 ;
  wire \input_r_Addr_A[12]_INST_0_i_28_n_5 ;
  wire \input_r_Addr_A[12]_INST_0_i_28_n_6 ;
  wire \input_r_Addr_A[12]_INST_0_i_28_n_7 ;
  wire \input_r_Addr_A[12]_INST_0_i_29_n_5 ;
  wire \input_r_Addr_A[12]_INST_0_i_29_n_6 ;
  wire \input_r_Addr_A[12]_INST_0_i_29_n_7 ;
  wire \input_r_Addr_A[12]_INST_0_i_2_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_33_n_5 ;
  wire \input_r_Addr_A[12]_INST_0_i_33_n_6 ;
  wire \input_r_Addr_A[12]_INST_0_i_33_n_7 ;
  wire \input_r_Addr_A[12]_INST_0_i_34_n_5 ;
  wire \input_r_Addr_A[12]_INST_0_i_34_n_6 ;
  wire \input_r_Addr_A[12]_INST_0_i_34_n_7 ;
  wire \input_r_Addr_A[12]_INST_0_i_35_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_36_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_37_n_5 ;
  wire \input_r_Addr_A[12]_INST_0_i_37_n_6 ;
  wire \input_r_Addr_A[12]_INST_0_i_37_n_7 ;
  wire \input_r_Addr_A[12]_INST_0_i_38_n_5 ;
  wire \input_r_Addr_A[12]_INST_0_i_38_n_6 ;
  wire \input_r_Addr_A[12]_INST_0_i_38_n_7 ;
  wire \input_r_Addr_A[12]_INST_0_i_39_n_7 ;
  wire \input_r_Addr_A[12]_INST_0_i_3_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_42_n_7 ;
  wire \input_r_Addr_A[12]_INST_0_i_44_n_7 ;
  wire \input_r_Addr_A[12]_INST_0_i_45_n_5 ;
  wire \input_r_Addr_A[12]_INST_0_i_45_n_6 ;
  wire \input_r_Addr_A[12]_INST_0_i_45_n_7 ;
  wire \input_r_Addr_A[12]_INST_0_i_47_n_7 ;
  wire \input_r_Addr_A[12]_INST_0_i_48_n_5 ;
  wire \input_r_Addr_A[12]_INST_0_i_48_n_6 ;
  wire \input_r_Addr_A[12]_INST_0_i_48_n_7 ;
  wire \input_r_Addr_A[12]_INST_0_i_49_n_5 ;
  wire \input_r_Addr_A[12]_INST_0_i_49_n_6 ;
  wire \input_r_Addr_A[12]_INST_0_i_49_n_7 ;
  wire \input_r_Addr_A[12]_INST_0_i_4_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_50_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_51_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_52_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_53_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_54_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_5_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_6_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_7_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_8_n_4 ;
  wire \input_r_Addr_A[12]_INST_0_i_9_n_4 ;
  wire \input_r_Addr_A[2]_INST_0_i_10_n_4 ;
  wire \input_r_Addr_A[2]_INST_0_i_1_n_4 ;
  wire \input_r_Addr_A[2]_INST_0_i_2_n_4 ;
  wire \input_r_Addr_A[2]_INST_0_i_3_n_4 ;
  wire \input_r_Addr_A[2]_INST_0_i_4_n_4 ;
  wire \input_r_Addr_A[2]_INST_0_i_5_n_4 ;
  wire \input_r_Addr_A[2]_INST_0_i_6_n_4 ;
  wire \input_r_Addr_A[2]_INST_0_i_7_n_4 ;
  wire \input_r_Addr_A[2]_INST_0_i_8_n_4 ;
  wire \input_r_Addr_A[2]_INST_0_i_9_n_4 ;
  wire \input_r_Addr_A[3]_INST_0_i_10_n_4 ;
  wire \input_r_Addr_A[3]_INST_0_i_11_n_4 ;
  wire \input_r_Addr_A[3]_INST_0_i_1_n_4 ;
  wire \input_r_Addr_A[3]_INST_0_i_2_n_4 ;
  wire \input_r_Addr_A[3]_INST_0_i_3_n_4 ;
  wire \input_r_Addr_A[3]_INST_0_i_4_n_4 ;
  wire \input_r_Addr_A[3]_INST_0_i_5_n_4 ;
  wire \input_r_Addr_A[3]_INST_0_i_6_n_4 ;
  wire \input_r_Addr_A[3]_INST_0_i_7_n_4 ;
  wire \input_r_Addr_A[3]_INST_0_i_8_n_4 ;
  wire \input_r_Addr_A[3]_INST_0_i_9_n_4 ;
  wire \input_r_Addr_A[4]_INST_0_i_11_n_4 ;
  wire \input_r_Addr_A[4]_INST_0_i_12_n_4 ;
  wire \input_r_Addr_A[4]_INST_0_i_14_n_4 ;
  wire \input_r_Addr_A[4]_INST_0_i_14_n_5 ;
  wire \input_r_Addr_A[4]_INST_0_i_14_n_6 ;
  wire \input_r_Addr_A[4]_INST_0_i_14_n_7 ;
  wire \input_r_Addr_A[4]_INST_0_i_18_n_4 ;
  wire \input_r_Addr_A[4]_INST_0_i_19_n_4 ;
  wire \input_r_Addr_A[4]_INST_0_i_1_n_4 ;
  wire \input_r_Addr_A[4]_INST_0_i_20_n_4 ;
  wire \input_r_Addr_A[4]_INST_0_i_21_n_4 ;
  wire \input_r_Addr_A[4]_INST_0_i_22_n_4 ;
  wire \input_r_Addr_A[4]_INST_0_i_23_n_4 ;
  wire \input_r_Addr_A[4]_INST_0_i_24_n_4 ;
  wire \input_r_Addr_A[4]_INST_0_i_2_n_4 ;
  wire \input_r_Addr_A[4]_INST_0_i_3_n_4 ;
  wire \input_r_Addr_A[4]_INST_0_i_4_n_4 ;
  wire \input_r_Addr_A[4]_INST_0_i_5_n_4 ;
  wire \input_r_Addr_A[4]_INST_0_i_6_n_4 ;
  wire \input_r_Addr_A[4]_INST_0_i_7_n_4 ;
  wire \input_r_Addr_A[4]_INST_0_i_8_n_4 ;
  wire \input_r_Addr_A[5]_INST_0_i_10_n_4 ;
  wire \input_r_Addr_A[5]_INST_0_i_11_n_4 ;
  wire \input_r_Addr_A[5]_INST_0_i_1_n_4 ;
  wire \input_r_Addr_A[5]_INST_0_i_2_n_4 ;
  wire \input_r_Addr_A[5]_INST_0_i_3_n_4 ;
  wire \input_r_Addr_A[5]_INST_0_i_4_n_4 ;
  wire \input_r_Addr_A[5]_INST_0_i_5_n_4 ;
  wire \input_r_Addr_A[5]_INST_0_i_6_n_4 ;
  wire \input_r_Addr_A[5]_INST_0_i_7_n_4 ;
  wire \input_r_Addr_A[5]_INST_0_i_8_n_4 ;
  wire \input_r_Addr_A[5]_INST_0_i_9_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_10_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_11_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_12_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_13_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_14_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_15_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_16_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_16_n_5 ;
  wire \input_r_Addr_A[6]_INST_0_i_16_n_6 ;
  wire \input_r_Addr_A[6]_INST_0_i_16_n_7 ;
  wire \input_r_Addr_A[6]_INST_0_i_17_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_17_n_5 ;
  wire \input_r_Addr_A[6]_INST_0_i_17_n_6 ;
  wire \input_r_Addr_A[6]_INST_0_i_17_n_7 ;
  wire \input_r_Addr_A[6]_INST_0_i_18_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_18_n_5 ;
  wire \input_r_Addr_A[6]_INST_0_i_18_n_6 ;
  wire \input_r_Addr_A[6]_INST_0_i_18_n_7 ;
  wire \input_r_Addr_A[6]_INST_0_i_19_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_1_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_20_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_21_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_22_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_23_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_24_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_25_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_26_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_27_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_28_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_29_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_2_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_30_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_3_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_4_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_5_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_6_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_7_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_7_n_5 ;
  wire \input_r_Addr_A[6]_INST_0_i_7_n_6 ;
  wire \input_r_Addr_A[6]_INST_0_i_7_n_7 ;
  wire \input_r_Addr_A[6]_INST_0_i_8_n_4 ;
  wire \input_r_Addr_A[6]_INST_0_i_9_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_10_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_11_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_12_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_13_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_13_n_5 ;
  wire \input_r_Addr_A[7]_INST_0_i_13_n_6 ;
  wire \input_r_Addr_A[7]_INST_0_i_13_n_7 ;
  wire \input_r_Addr_A[7]_INST_0_i_14_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_15_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_16_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_16_n_5 ;
  wire \input_r_Addr_A[7]_INST_0_i_16_n_6 ;
  wire \input_r_Addr_A[7]_INST_0_i_16_n_7 ;
  wire \input_r_Addr_A[7]_INST_0_i_17_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_17_n_5 ;
  wire \input_r_Addr_A[7]_INST_0_i_17_n_6 ;
  wire \input_r_Addr_A[7]_INST_0_i_17_n_7 ;
  wire \input_r_Addr_A[7]_INST_0_i_18_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_18_n_5 ;
  wire \input_r_Addr_A[7]_INST_0_i_18_n_6 ;
  wire \input_r_Addr_A[7]_INST_0_i_18_n_7 ;
  wire \input_r_Addr_A[7]_INST_0_i_19_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_1_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_20_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_22_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_22_n_5 ;
  wire \input_r_Addr_A[7]_INST_0_i_22_n_6 ;
  wire \input_r_Addr_A[7]_INST_0_i_22_n_7 ;
  wire \input_r_Addr_A[7]_INST_0_i_23_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_23_n_5 ;
  wire \input_r_Addr_A[7]_INST_0_i_23_n_6 ;
  wire \input_r_Addr_A[7]_INST_0_i_23_n_7 ;
  wire \input_r_Addr_A[7]_INST_0_i_24_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_25_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_27_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_28_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_2_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_30_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_30_n_5 ;
  wire \input_r_Addr_A[7]_INST_0_i_30_n_6 ;
  wire \input_r_Addr_A[7]_INST_0_i_30_n_7 ;
  wire \input_r_Addr_A[7]_INST_0_i_31_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_31_n_5 ;
  wire \input_r_Addr_A[7]_INST_0_i_31_n_6 ;
  wire \input_r_Addr_A[7]_INST_0_i_31_n_7 ;
  wire \input_r_Addr_A[7]_INST_0_i_32_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_32_n_5 ;
  wire \input_r_Addr_A[7]_INST_0_i_32_n_6 ;
  wire \input_r_Addr_A[7]_INST_0_i_32_n_7 ;
  wire \input_r_Addr_A[7]_INST_0_i_33_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_33_n_5 ;
  wire \input_r_Addr_A[7]_INST_0_i_33_n_6 ;
  wire \input_r_Addr_A[7]_INST_0_i_33_n_7 ;
  wire \input_r_Addr_A[7]_INST_0_i_34_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_35_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_36_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_37_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_37_n_5 ;
  wire \input_r_Addr_A[7]_INST_0_i_37_n_6 ;
  wire \input_r_Addr_A[7]_INST_0_i_37_n_7 ;
  wire \input_r_Addr_A[7]_INST_0_i_38_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_39_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_3_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_41_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_42_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_44_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_45_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_47_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_48_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_4_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_50_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_51_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_53_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_54_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_55_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_56_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_57_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_59_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_5_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_60_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_61_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_62_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_63_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_64_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_65_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_66_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_67_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_6_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_6_n_5 ;
  wire \input_r_Addr_A[7]_INST_0_i_6_n_6 ;
  wire \input_r_Addr_A[7]_INST_0_i_6_n_7 ;
  wire \input_r_Addr_A[7]_INST_0_i_7_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_8_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_8_n_5 ;
  wire \input_r_Addr_A[7]_INST_0_i_8_n_6 ;
  wire \input_r_Addr_A[7]_INST_0_i_8_n_7 ;
  wire \input_r_Addr_A[7]_INST_0_i_9_n_4 ;
  wire \input_r_Addr_A[7]_INST_0_i_9_n_5 ;
  wire \input_r_Addr_A[7]_INST_0_i_9_n_6 ;
  wire \input_r_Addr_A[7]_INST_0_i_9_n_7 ;
  wire \input_r_Addr_A[8]_INST_0_i_10_n_4 ;
  wire \input_r_Addr_A[8]_INST_0_i_11_n_4 ;
  wire \input_r_Addr_A[8]_INST_0_i_1_n_4 ;
  wire \input_r_Addr_A[8]_INST_0_i_2_n_4 ;
  wire \input_r_Addr_A[8]_INST_0_i_3_n_4 ;
  wire \input_r_Addr_A[8]_INST_0_i_4_n_4 ;
  wire \input_r_Addr_A[8]_INST_0_i_5_n_4 ;
  wire \input_r_Addr_A[8]_INST_0_i_6_n_4 ;
  wire \input_r_Addr_A[8]_INST_0_i_7_n_4 ;
  wire \input_r_Addr_A[8]_INST_0_i_8_n_4 ;
  wire \input_r_Addr_A[8]_INST_0_i_9_n_4 ;
  wire \input_r_Addr_A[9]_INST_0_i_10_n_4 ;
  wire \input_r_Addr_A[9]_INST_0_i_11_n_4 ;
  wire \input_r_Addr_A[9]_INST_0_i_1_n_4 ;
  wire \input_r_Addr_A[9]_INST_0_i_2_n_4 ;
  wire \input_r_Addr_A[9]_INST_0_i_3_n_4 ;
  wire \input_r_Addr_A[9]_INST_0_i_4_n_4 ;
  wire \input_r_Addr_A[9]_INST_0_i_5_n_4 ;
  wire \input_r_Addr_A[9]_INST_0_i_6_n_4 ;
  wire \input_r_Addr_A[9]_INST_0_i_7_n_4 ;
  wire \input_r_Addr_A[9]_INST_0_i_8_n_4 ;
  wire \input_r_Addr_A[9]_INST_0_i_9_n_4 ;
  wire output_r_Rst_A;
  wire p_0_in28_out;
  wire [9:5]p_shl10_cast_fu_1237_p1;
  wire [9:6]p_shl6_cast_fu_878_p1;
  wire reg_6311041_out;
  wire reg_6311242_out;
  wire reg_6311343_out;
  wire reg_6311444_out;
  wire reg_6311545_out;
  wire reg_6311646_out;
  wire reg_6311747_out;
  wire reg_6311848_out;
  wire reg_6311949_out;
  wire reg_6312050_out;
  wire reg_6312151_out;
  wire reg_6312252_out;
  wire reg_6312353_out;
  wire reg_6312454_out;
  wire reg_63125;
  wire reg_6312555_out;
  wire reg_631435_out;
  wire reg_631536_out;
  wire reg_631637_out;
  wire reg_631738_out;
  wire reg_631839_out;
  wire reg_631940_out;
  wire [10:2]tmp_103_fu_2000_p2;
  wire [10:0]tmp_103_reg_3416;
  wire \tmp_103_reg_3416[5]_i_2_n_4 ;
  wire \tmp_103_reg_3416[5]_i_3_n_4 ;
  wire \tmp_103_reg_3416[5]_i_4_n_4 ;
  wire \tmp_103_reg_3416_reg[10]_i_1_n_5 ;
  wire \tmp_103_reg_3416_reg[10]_i_1_n_6 ;
  wire \tmp_103_reg_3416_reg[10]_i_1_n_7 ;
  wire \tmp_103_reg_3416_reg[5]_i_1_n_4 ;
  wire \tmp_103_reg_3416_reg[5]_i_1_n_5 ;
  wire \tmp_103_reg_3416_reg[5]_i_1_n_6 ;
  wire \tmp_103_reg_3416_reg[5]_i_1_n_7 ;
  wire [10:2]tmp_109_fu_2013_p2;
  wire [10:0]tmp_109_reg_3426;
  wire \tmp_109_reg_3426[5]_i_2_n_4 ;
  wire \tmp_109_reg_3426[5]_i_3_n_4 ;
  wire \tmp_109_reg_3426[5]_i_4_n_4 ;
  wire \tmp_109_reg_3426_reg[10]_i_1_n_5 ;
  wire \tmp_109_reg_3426_reg[10]_i_1_n_6 ;
  wire \tmp_109_reg_3426_reg[10]_i_1_n_7 ;
  wire \tmp_109_reg_3426_reg[5]_i_1_n_4 ;
  wire \tmp_109_reg_3426_reg[5]_i_1_n_5 ;
  wire \tmp_109_reg_3426_reg[5]_i_1_n_6 ;
  wire \tmp_109_reg_3426_reg[5]_i_1_n_7 ;
  wire [10:2]tmp_113_fu_2017_p2;
  wire [10:2]tmp_113_reg_3431;
  wire \tmp_113_reg_3431[5]_i_2_n_4 ;
  wire \tmp_113_reg_3431[5]_i_3_n_4 ;
  wire \tmp_113_reg_3431[5]_i_4_n_4 ;
  wire \tmp_113_reg_3431_reg[10]_i_1_n_5 ;
  wire \tmp_113_reg_3431_reg[10]_i_1_n_6 ;
  wire \tmp_113_reg_3431_reg[10]_i_1_n_7 ;
  wire \tmp_113_reg_3431_reg[5]_i_1_n_4 ;
  wire \tmp_113_reg_3431_reg[5]_i_1_n_5 ;
  wire \tmp_113_reg_3431_reg[5]_i_1_n_6 ;
  wire \tmp_113_reg_3431_reg[5]_i_1_n_7 ;
  wire [10:2]tmp_114_fu_2021_p2;
  wire [10:0]tmp_114_reg_3436;
  wire \tmp_114_reg_3436[10]_i_1_n_4 ;
  wire \tmp_114_reg_3436[5]_i_2_n_4 ;
  wire \tmp_114_reg_3436[5]_i_3_n_4 ;
  wire \tmp_114_reg_3436[5]_i_4_n_4 ;
  wire \tmp_114_reg_3436_reg[10]_i_2_n_5 ;
  wire \tmp_114_reg_3436_reg[10]_i_2_n_6 ;
  wire \tmp_114_reg_3436_reg[10]_i_2_n_7 ;
  wire \tmp_114_reg_3436_reg[5]_i_1_n_4 ;
  wire \tmp_114_reg_3436_reg[5]_i_1_n_5 ;
  wire \tmp_114_reg_3436_reg[5]_i_1_n_6 ;
  wire \tmp_114_reg_3436_reg[5]_i_1_n_7 ;
  wire [10:2]tmp_118_fu_2025_p2;
  wire [10:0]tmp_118_reg_3441;
  wire \tmp_118_reg_3441[5]_i_2_n_4 ;
  wire \tmp_118_reg_3441[5]_i_3_n_4 ;
  wire \tmp_118_reg_3441[5]_i_4_n_4 ;
  wire \tmp_118_reg_3441_reg[10]_i_1_n_5 ;
  wire \tmp_118_reg_3441_reg[10]_i_1_n_6 ;
  wire \tmp_118_reg_3441_reg[10]_i_1_n_7 ;
  wire \tmp_118_reg_3441_reg[5]_i_1_n_4 ;
  wire \tmp_118_reg_3441_reg[5]_i_1_n_5 ;
  wire \tmp_118_reg_3441_reg[5]_i_1_n_6 ;
  wire \tmp_118_reg_3441_reg[5]_i_1_n_7 ;
  wire [10:2]tmp_123_fu_2029_p2;
  wire [10:0]tmp_123_reg_3446;
  wire \tmp_123_reg_3446[5]_i_2_n_4 ;
  wire \tmp_123_reg_3446[5]_i_3_n_4 ;
  wire \tmp_123_reg_3446[5]_i_4_n_4 ;
  wire \tmp_123_reg_3446_reg[10]_i_1_n_5 ;
  wire \tmp_123_reg_3446_reg[10]_i_1_n_6 ;
  wire \tmp_123_reg_3446_reg[10]_i_1_n_7 ;
  wire \tmp_123_reg_3446_reg[5]_i_1_n_4 ;
  wire \tmp_123_reg_3446_reg[5]_i_1_n_5 ;
  wire \tmp_123_reg_3446_reg[5]_i_1_n_6 ;
  wire \tmp_123_reg_3446_reg[5]_i_1_n_7 ;
  wire [4:1]tmp_37_1_cast_mid2_fu_797_p3;
  wire tmp_37_1_cast_mid2_reg_2752;
  wire \tmp_37_1_cast_mid2_reg_2752[4]_i_2_n_4 ;
  wire \tmp_37_1_cast_mid2_reg_2752[4]_i_3_n_4 ;
  wire [4:1]tmp_37_2_cast_mid2_fu_811_p3;
  wire [4:1]tmp_37_2_cast_mid2_reg_2758;
  wire \tmp_37_2_cast_mid2_reg_2758[4]_i_2_n_4 ;
  wire \tmp_37_2_cast_mid2_reg_2758[4]_i_3_n_4 ;
  wire [4:0]tmp_37_3_cast_mid2_fu_825_p3;
  wire [4:0]tmp_37_3_cast_mid2_reg_2764;
  wire \tmp_37_3_cast_mid2_reg_2764[3]_i_2_n_4 ;
  wire \tmp_37_3_cast_mid2_reg_2764[4]_i_2_n_4 ;
  wire [4:0]tmp_37_4_cast_mid2_fu_839_p3;
  wire [4:0]tmp_37_4_cast_mid2_reg_2770;
  wire \tmp_37_4_cast_mid2_reg_2770[4]_i_3_n_4 ;
  wire [4:0]tmp_39_0_1_cast_cast_fu_1029_p1;
  wire \tmp_39_0_1_cast_cast_reg_2871[4]_i_1_n_4 ;
  wire [4:0]tmp_39_0_1_cast_cast_reg_2871_reg__0;
  wire [4:0]tmp_39_0_2_cast_cast_reg_2794;
  wire \tmp_39_0_2_cast_cast_reg_2794[4]_i_1_n_4 ;
  wire [4:1]tmp_39_0_2_fu_899_p2;
  wire [4:0]tmp_39_0_3_cast_cast_reg_2917_reg__0;
  wire [4:1]tmp_39_0_3_fu_1115_p2;
  wire \tmp_39_0_4_cast_cast_reg_2812[4]_i_1_n_4 ;
  wire [4:0]tmp_39_0_4_cast_cast_reg_2812_reg__0;
  wire [4:2]tmp_39_0_4_fu_929_p2;
  wire [9:9]tmp_66_cast_fu_1435_p1;
  wire [9:9]tmp_68_cast_fu_1559_p1;
  wire \tmp_6_cast_reg_2838[4]_i_1_n_4 ;
  wire [4:0]tmp_6_cast_reg_2838_reg__0;
  wire [3:3]tmp_80_cast_fu_2081_p1;
  wire [3:3]tmp_81_cast_fu_2129_p1;
  wire [3:3]tmp_82_cast_fu_2181_p1;
  wire [3:3]tmp_83_cast_fu_2229_p1;
  wire [6:5]tmp_83_fu_1252_p2;
  wire \tmp_83_reg_2990[3]_i_1_n_4 ;
  wire \tmp_83_reg_2990[4]_i_1_n_4 ;
  wire \tmp_83_reg_2990[7]_i_1_n_4 ;
  wire \tmp_83_reg_2990[8]_i_1_n_4 ;
  wire \tmp_83_reg_2990[9]_i_1_n_4 ;
  wire \tmp_83_reg_2990[9]_i_2_n_4 ;
  wire [7:0]tmp_83_reg_2990_reg__0;
  wire [3:3]tmp_84_cast_fu_2295_p1;
  wire [8:3]tmp_85_cast_fu_2384_p1;
  wire [8:8]tmp_87_cast_fu_1174_p1;
  wire [6:5]tmp_89_fu_893_p2;
  wire \tmp_89_reg_2786[3]_i_1_n_4 ;
  wire \tmp_89_reg_2786[4]_i_1_n_4 ;
  wire \tmp_89_reg_2786[7]_i_1_n_4 ;
  wire \tmp_89_reg_2786[8]_i_1_n_4 ;
  wire \tmp_89_reg_2786[9]_i_1_n_4 ;
  wire \tmp_89_reg_2786_reg_n_4_[2] ;
  wire \tmp_89_reg_2786_reg_n_4_[3] ;
  wire \tmp_89_reg_2786_reg_n_4_[4] ;
  wire \tmp_89_reg_2786_reg_n_4_[5] ;
  wire \tmp_89_reg_2786_reg_n_4_[6] ;
  wire \tmp_89_reg_2786_reg_n_4_[7] ;
  wire \tmp_89_reg_2786_reg_n_4_[8] ;
  wire \tmp_89_reg_2786_reg_n_4_[9] ;
  wire [6:5]tmp_92_fu_980_p2;
  wire \tmp_92_reg_2830[3]_i_1_n_4 ;
  wire \tmp_92_reg_2830[4]_i_1_n_4 ;
  wire \tmp_92_reg_2830[7]_i_1_n_4 ;
  wire \tmp_92_reg_2830[8]_i_1_n_4 ;
  wire \tmp_92_reg_2830[9]_i_1_n_4 ;
  wire [7:0]tmp_92_reg_2830_reg__0;
  wire [6:5]tmp_95_fu_1917_p2;
  wire \tmp_95_reg_3368[3]_i_1_n_4 ;
  wire \tmp_95_reg_3368[4]_i_1_n_4 ;
  wire \tmp_95_reg_3368[7]_i_1_n_4 ;
  wire \tmp_95_reg_3368[8]_i_1_n_4 ;
  wire \tmp_95_reg_3368[9]_i_1_n_4 ;
  wire \tmp_95_reg_3368[9]_i_2_n_4 ;
  wire [7:0]tmp_95_reg_3368_reg__0;
  wire [6:5]tmp_98_fu_1109_p2;
  wire [9:2]tmp_98_reg_2909;
  wire \tmp_98_reg_2909[3]_i_1_n_4 ;
  wire \tmp_98_reg_2909[4]_i_1_n_4 ;
  wire \tmp_98_reg_2909[7]_i_1_n_4 ;
  wire \tmp_98_reg_2909[8]_i_1_n_4 ;
  wire \tmp_98_reg_2909[9]_i_1_n_4 ;
  wire \tmp_98_reg_2909[9]_i_2_n_4 ;
  wire [9:3]tmp_fu_707_p2;
  wire [4:0]tmp_mid2_72_fu_783_p3;
  wire \tmp_mid2_v_reg_2697[1]_i_3_n_4 ;
  wire \tmp_mid2_v_reg_2697[1]_i_4_n_4 ;
  wire \tmp_mid2_v_reg_2697[1]_i_5_n_4 ;
  wire \tmp_mid2_v_reg_2697[1]_i_6_n_4 ;
  wire \tmp_mid2_v_reg_2697[1]_i_7_n_4 ;
  wire \tmp_mid2_v_reg_2697[1]_i_8_n_4 ;
  wire \tmp_mid2_v_reg_2697[4]_i_10_n_4 ;
  wire \tmp_mid2_v_reg_2697[4]_i_11_n_4 ;
  wire \tmp_mid2_v_reg_2697[4]_i_12_n_4 ;
  wire \tmp_mid2_v_reg_2697[4]_i_1_n_4 ;
  wire \tmp_mid2_v_reg_2697[4]_i_3_n_4 ;
  wire \tmp_mid2_v_reg_2697[4]_i_4_n_4 ;
  wire \tmp_mid2_v_reg_2697[4]_i_5_n_4 ;
  wire \tmp_mid2_v_reg_2697[4]_i_6_n_4 ;
  wire \tmp_mid2_v_reg_2697[4]_i_8_n_4 ;
  wire [9:0]tmp_reg_2705;
  wire \tmp_reg_2705[6]_i_2_n_4 ;
  wire \tmp_reg_2705[6]_i_3_n_4 ;
  wire \tmp_reg_2705[6]_i_4_n_4 ;
  wire \tmp_reg_2705[6]_i_5_n_4 ;
  wire \tmp_reg_2705[6]_i_6_n_4 ;
  wire \tmp_reg_2705[6]_i_7_n_4 ;
  wire \tmp_reg_2705[6]_i_8_n_4 ;
  wire \tmp_reg_2705[9]_i_2_n_4 ;
  wire \tmp_reg_2705[9]_i_3_n_4 ;
  wire \tmp_reg_2705[9]_i_4_n_4 ;
  wire \tmp_reg_2705[9]_i_5_n_4 ;
  wire \tmp_reg_2705[9]_i_6_n_4 ;
  wire \tmp_reg_2705_reg[6]_i_1_n_4 ;
  wire \tmp_reg_2705_reg[6]_i_1_n_5 ;
  wire \tmp_reg_2705_reg[6]_i_1_n_6 ;
  wire \tmp_reg_2705_reg[6]_i_1_n_7 ;
  wire \tmp_reg_2705_reg[9]_i_1_n_6 ;
  wire \tmp_reg_2705_reg[9]_i_1_n_7 ;
  wire [4:0]x_4_reg_2866;
  wire \x_4_reg_2866[4]_i_1_n_4 ;
  wire x_mid2_reg_2734;
  wire \x_mid2_reg_2734[4]_i_2_n_4 ;
  wire \x_mid2_reg_2734[4]_i_5_n_4 ;
  wire \x_mid2_reg_2734[4]_i_6_n_4 ;
  wire \x_mid2_reg_2734_reg_n_4_[0] ;
  wire \x_mid2_reg_2734_reg_n_4_[1] ;
  wire \x_mid2_reg_2734_reg_n_4_[2] ;
  wire \x_mid2_reg_2734_reg_n_4_[3] ;
  wire \x_mid2_reg_2734_reg_n_4_[4] ;
  wire [4:0]x_reg_620;
  wire xlnx_opt_;
  wire xlnx_opt__12;
  wire xlnx_opt__15;
  wire xlnx_opt__3;
  wire xlnx_opt__6;
  wire xlnx_opt__9;
  wire [4:0]y_mid_fu_687_p3;
  wire [4:0]y_reg_609;
  wire [3:1]NLW_CARRY4_CO_UNCONNECTED;
  wire [3:1]NLW_CARRY4_DI_UNCONNECTED;
  wire [3:0]NLW_CARRY4_O_UNCONNECTED;
  wire [3:1]NLW_CARRY4_S_UNCONNECTED;
  wire [3:1]NLW_CARRY4_1_CO_UNCONNECTED;
  wire [3:1]NLW_CARRY4_1_DI_UNCONNECTED;
  wire [3:0]NLW_CARRY4_1_O_UNCONNECTED;
  wire [3:1]NLW_CARRY4_1_S_UNCONNECTED;
  wire [3:1]NLW_CARRY4_2_CO_UNCONNECTED;
  wire [3:1]NLW_CARRY4_2_DI_UNCONNECTED;
  wire [3:0]NLW_CARRY4_2_O_UNCONNECTED;
  wire [3:1]NLW_CARRY4_2_S_UNCONNECTED;
  wire [3:1]NLW_CARRY4_3_CO_UNCONNECTED;
  wire [3:1]NLW_CARRY4_3_DI_UNCONNECTED;
  wire [3:0]NLW_CARRY4_3_O_UNCONNECTED;
  wire [3:1]NLW_CARRY4_3_S_UNCONNECTED;
  wire [3:1]NLW_CARRY4_4_CO_UNCONNECTED;
  wire [3:1]NLW_CARRY4_4_DI_UNCONNECTED;
  wire [3:0]NLW_CARRY4_4_O_UNCONNECTED;
  wire [3:1]NLW_CARRY4_4_S_UNCONNECTED;
  wire [3:1]NLW_CARRY4_5_CO_UNCONNECTED;
  wire [3:1]NLW_CARRY4_5_DI_UNCONNECTED;
  wire [3:0]NLW_CARRY4_5_O_UNCONNECTED;
  wire [3:1]NLW_CARRY4_5_S_UNCONNECTED;
  wire [3:1]\NLW_indvar_flatten_next2_reg_2692_reg[12]_i_1_CO_UNCONNECTED ;
  wire [3:2]\NLW_indvar_flatten_next2_reg_2692_reg[12]_i_1_O_UNCONNECTED ;
  wire [3:1]\NLW_input_r_Addr_A[12]_INST_0_i_13_CO_UNCONNECTED ;
  wire [3:2]\NLW_input_r_Addr_A[12]_INST_0_i_13_O_UNCONNECTED ;
  wire [3:1]\NLW_input_r_Addr_A[12]_INST_0_i_39_CO_UNCONNECTED ;
  wire [3:2]\NLW_input_r_Addr_A[12]_INST_0_i_39_O_UNCONNECTED ;
  wire [3:1]\NLW_input_r_Addr_A[12]_INST_0_i_42_CO_UNCONNECTED ;
  wire [3:2]\NLW_input_r_Addr_A[12]_INST_0_i_42_O_UNCONNECTED ;
  wire [3:1]\NLW_input_r_Addr_A[12]_INST_0_i_44_CO_UNCONNECTED ;
  wire [3:2]\NLW_input_r_Addr_A[12]_INST_0_i_44_O_UNCONNECTED ;
  wire [3:1]\NLW_input_r_Addr_A[12]_INST_0_i_47_CO_UNCONNECTED ;
  wire [3:2]\NLW_input_r_Addr_A[12]_INST_0_i_47_O_UNCONNECTED ;
  wire [0:0]\NLW_input_r_Addr_A[4]_INST_0_i_14_O_UNCONNECTED ;
  wire [0:0]\NLW_input_r_Addr_A[7]_INST_0_i_13_O_UNCONNECTED ;
  wire [0:0]\NLW_input_r_Addr_A[7]_INST_0_i_16_O_UNCONNECTED ;
  wire [0:0]\NLW_input_r_Addr_A[7]_INST_0_i_17_O_UNCONNECTED ;
  wire [0:0]\NLW_input_r_Addr_A[7]_INST_0_i_18_O_UNCONNECTED ;
  wire [0:0]\NLW_input_r_Addr_A[7]_INST_0_i_22_O_UNCONNECTED ;
  wire [0:0]\NLW_input_r_Addr_A[7]_INST_0_i_23_O_UNCONNECTED ;
  wire [0:0]\NLW_input_r_Addr_A[7]_INST_0_i_30_O_UNCONNECTED ;
  wire [0:0]\NLW_input_r_Addr_A[7]_INST_0_i_31_O_UNCONNECTED ;
  wire [0:0]\NLW_input_r_Addr_A[7]_INST_0_i_32_O_UNCONNECTED ;
  wire [0:0]\NLW_input_r_Addr_A[7]_INST_0_i_33_O_UNCONNECTED ;
  wire [0:0]\NLW_input_r_Addr_A[7]_INST_0_i_37_O_UNCONNECTED ;
  wire [0:0]\NLW_input_r_Addr_A[7]_INST_0_i_6_O_UNCONNECTED ;
  wire [0:0]\NLW_input_r_Addr_A[7]_INST_0_i_8_O_UNCONNECTED ;
  wire [0:0]\NLW_input_r_Addr_A[7]_INST_0_i_9_O_UNCONNECTED ;
  wire [0:0]\NLW_tmp_103_reg_3416_reg[5]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_tmp_109_reg_3426_reg[5]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_tmp_113_reg_3431_reg[5]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_tmp_114_reg_3436_reg[5]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_tmp_118_reg_3441_reg[5]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_tmp_123_reg_3446_reg[5]_i_1_O_UNCONNECTED ;
  wire [3:2]\NLW_tmp_reg_2705_reg[9]_i_1_CO_UNCONNECTED ;
  wire [3:3]\NLW_tmp_reg_2705_reg[9]_i_1_O_UNCONNECTED ;

  CARRY4 CARRY4
       (.CI(xlnx_opt_),
        .CO({NLW_CARRY4_CO_UNCONNECTED[3:1],tmp_103_fu_2000_p2[10]}),
        .CYINIT(1'b0),
        .DI({NLW_CARRY4_DI_UNCONNECTED[3:1],1'b0}),
        .O(NLW_CARRY4_O_UNCONNECTED[3:0]),
        .S({NLW_CARRY4_S_UNCONNECTED[3:1],1'b1}));
  CARRY4 CARRY4_1
       (.CI(xlnx_opt__3),
        .CO({NLW_CARRY4_1_CO_UNCONNECTED[3:1],tmp_109_fu_2013_p2[10]}),
        .CYINIT(1'b0),
        .DI({NLW_CARRY4_1_DI_UNCONNECTED[3:1],1'b0}),
        .O(NLW_CARRY4_1_O_UNCONNECTED[3:0]),
        .S({NLW_CARRY4_1_S_UNCONNECTED[3:1],1'b1}));
  CARRY4 CARRY4_2
       (.CI(xlnx_opt__6),
        .CO({NLW_CARRY4_2_CO_UNCONNECTED[3:1],tmp_113_fu_2017_p2[10]}),
        .CYINIT(1'b0),
        .DI({NLW_CARRY4_2_DI_UNCONNECTED[3:1],1'b0}),
        .O(NLW_CARRY4_2_O_UNCONNECTED[3:0]),
        .S({NLW_CARRY4_2_S_UNCONNECTED[3:1],1'b1}));
  CARRY4 CARRY4_3
       (.CI(xlnx_opt__9),
        .CO({NLW_CARRY4_3_CO_UNCONNECTED[3:1],tmp_114_fu_2021_p2[10]}),
        .CYINIT(1'b0),
        .DI({NLW_CARRY4_3_DI_UNCONNECTED[3:1],1'b0}),
        .O(NLW_CARRY4_3_O_UNCONNECTED[3:0]),
        .S({NLW_CARRY4_3_S_UNCONNECTED[3:1],1'b1}));
  CARRY4 CARRY4_4
       (.CI(xlnx_opt__12),
        .CO({NLW_CARRY4_4_CO_UNCONNECTED[3:1],tmp_118_fu_2025_p2[10]}),
        .CYINIT(1'b0),
        .DI({NLW_CARRY4_4_DI_UNCONNECTED[3:1],1'b0}),
        .O(NLW_CARRY4_4_O_UNCONNECTED[3:0]),
        .S({NLW_CARRY4_4_S_UNCONNECTED[3:1],1'b1}));
  CARRY4 CARRY4_5
       (.CI(xlnx_opt__15),
        .CO({NLW_CARRY4_5_CO_UNCONNECTED[3:1],tmp_123_fu_2029_p2[10]}),
        .CYINIT(1'b0),
        .DI({NLW_CARRY4_5_DI_UNCONNECTED[3:1],1'b0}),
        .O(NLW_CARRY4_5_O_UNCONNECTED[3:0]),
        .S({NLW_CARRY4_5_S_UNCONNECTED[3:1],1'b1}));
  (* SOFT_HLUTNM = "soft_lutpair39" *) 
  LUT3 #(
    .INIT(8'hAE)) 
    \ap_CS_fsm[0]_i_1 
       (.I0(grp_Conv1_28x28x1_5x5x20_fu_74_ap_ready),
        .I1(\ap_CS_fsm_reg_n_4_[0] ),
        .I2(grp_Conv1_28x28x1_5x5x20_fu_74_ap_start_reg),
        .O(ap_NS_fsm[0]));
  (* SOFT_HLUTNM = "soft_lutpair61" *) 
  LUT3 #(
    .INIT(8'hEA)) 
    \ap_CS_fsm[1]_i_1 
       (.I0(ap_CS_fsm_pp0_stage24),
        .I1(\ap_CS_fsm_reg_n_4_[0] ),
        .I2(grp_Conv1_28x28x1_5x5x20_fu_74_ap_start_reg),
        .O(ap_NS_fsm[1]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT5 #(
    .INIT(32'h03800080)) 
    \ap_CS_fsm[26]_i_1 
       (.I0(exitcond_flatten2_fu_663_p2),
        .I1(ap_CS_fsm_pp0_stage0),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_enable_reg_pp0_iter1_reg_n_4),
        .I4(ap_CS_fsm_pp0_stage7),
        .O(ap_NS_fsm[26]));
  LUT4 #(
    .INIT(16'h0001)) 
    \ap_CS_fsm[26]_i_2 
       (.I0(\tmp_mid2_v_reg_2697[4]_i_6_n_4 ),
        .I1(\tmp_mid2_v_reg_2697[4]_i_5_n_4 ),
        .I2(\tmp_mid2_v_reg_2697[4]_i_4_n_4 ),
        .I3(\tmp_mid2_v_reg_2697[4]_i_3_n_4 ),
        .O(exitcond_flatten2_fu_663_p2));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT4 #(
    .INIT(16'hA2AA)) 
    \ap_CS_fsm[2]_i_1__4 
       (.I0(ap_CS_fsm_pp0_stage0),
        .I1(ap_enable_reg_pp0_iter0),
        .I2(ap_enable_reg_pp0_iter1_reg_n_4),
        .I3(exitcond_flatten2_fu_663_p2),
        .O(\ap_CS_fsm[2]_i_1__4_n_4 ));
  LUT6 #(
    .INIT(64'h4545FFFF454545FF)) 
    \ap_CS_fsm[2]_i_3 
       (.I0(grp_Conv1_28x28x1_5x5x20_fu_74_ap_ready),
        .I1(grp_Conv1_28x28x1_5x5x20_fu_74_ap_start_reg),
        .I2(\ap_CS_fsm_reg_n_4_[0] ),
        .I3(Q[0]),
        .I4(Q[1]),
        .I5(grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg),
        .O(\ap_CS_fsm_reg[2]_0 ));
  (* SOFT_HLUTNM = "soft_lutpair54" *) 
  LUT3 #(
    .INIT(8'hB0)) 
    \ap_CS_fsm[9]_i_1__0 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage7),
        .O(\ap_CS_fsm[9]_i_1__0_n_4 ));
  (* FSM_ENCODING = "none" *) 
  FDSE #(
    .INIT(1'b1)) 
    \ap_CS_fsm_reg[0] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[0]),
        .Q(\ap_CS_fsm_reg_n_4_[0] ),
        .S(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[10] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage8),
        .Q(ap_CS_fsm_pp0_stage9),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[11] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage9),
        .Q(ap_CS_fsm_pp0_stage10),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[12] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage10),
        .Q(ap_CS_fsm_pp0_stage11),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[13] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage11),
        .Q(ap_CS_fsm_pp0_stage12),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[14] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage12),
        .Q(ap_CS_fsm_pp0_stage13),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[15] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage13),
        .Q(ap_CS_fsm_pp0_stage14),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[16] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage14),
        .Q(ap_CS_fsm_pp0_stage15),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[17] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage15),
        .Q(ap_CS_fsm_pp0_stage16),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[18] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage16),
        .Q(ap_CS_fsm_pp0_stage17),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[19] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage17),
        .Q(ap_CS_fsm_pp0_stage18),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[1] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[1]),
        .Q(ap_CS_fsm_pp0_stage0),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[20] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage18),
        .Q(ap_CS_fsm_pp0_stage19),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[21] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage19),
        .Q(ap_CS_fsm_pp0_stage20),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[22] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage20),
        .Q(ap_CS_fsm_pp0_stage21),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[23] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage21),
        .Q(ap_CS_fsm_pp0_stage22),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[24] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage22),
        .Q(ap_CS_fsm_pp0_stage23),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[25] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage23),
        .Q(ap_CS_fsm_pp0_stage24),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[26] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[26]),
        .Q(grp_Conv1_28x28x1_5x5x20_fu_74_ap_ready),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[2] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\ap_CS_fsm[2]_i_1__4_n_4 ),
        .Q(ap_CS_fsm_pp0_stage1),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[3] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage1),
        .Q(ap_CS_fsm_pp0_stage2),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[4] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage2),
        .Q(ap_CS_fsm_pp0_stage3),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[5] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage3),
        .Q(ap_CS_fsm_pp0_stage4),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[6] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage4),
        .Q(ap_CS_fsm_pp0_stage5),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[7] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage5),
        .Q(ap_CS_fsm_pp0_stage6),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[8] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_pp0_stage6),
        .Q(ap_CS_fsm_pp0_stage7),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[9] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\ap_CS_fsm[9]_i_1__0_n_4 ),
        .Q(ap_CS_fsm_pp0_stage8),
        .R(output_r_Rst_A));
  LUT6 #(
    .INIT(64'h0000EA00EA00EA00)) 
    ap_enable_reg_pp0_iter0_i_1
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(\ap_CS_fsm_reg_n_4_[0] ),
        .I2(grp_Conv1_28x28x1_5x5x20_fu_74_ap_start_reg),
        .I3(ap_rst_n),
        .I4(exitcond_flatten2_fu_663_p2),
        .I5(ap_CS_fsm_pp0_stage0),
        .O(ap_enable_reg_pp0_iter0_i_1_n_4));
  FDRE #(
    .INIT(1'b0)) 
    ap_enable_reg_pp0_iter0_reg
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_enable_reg_pp0_iter0_i_1_n_4),
        .Q(ap_enable_reg_pp0_iter0),
        .R(1'b0));
  LUT6 #(
    .INIT(64'h000000A0C0C000A0)) 
    ap_enable_reg_pp0_iter1_i_1
       (.I0(ap_enable_reg_pp0_iter1_reg_n_4),
        .I1(ap_enable_reg_pp0_iter0),
        .I2(ap_rst_n),
        .I3(ap_NS_fsm133_out),
        .I4(ap_enable_reg_pp0_iter12),
        .I5(exitcond_flatten2_fu_663_p2),
        .O(ap_enable_reg_pp0_iter1_i_1_n_4));
  (* SOFT_HLUTNM = "soft_lutpair61" *) 
  LUT2 #(
    .INIT(4'h8)) 
    ap_enable_reg_pp0_iter1_i_2
       (.I0(\ap_CS_fsm_reg_n_4_[0] ),
        .I1(grp_Conv1_28x28x1_5x5x20_fu_74_ap_start_reg),
        .O(ap_NS_fsm133_out));
  (* SOFT_HLUTNM = "soft_lutpair83" *) 
  LUT2 #(
    .INIT(4'hE)) 
    ap_enable_reg_pp0_iter1_i_3
       (.I0(ap_CS_fsm_pp0_stage24),
        .I1(ap_CS_fsm_pp0_stage7),
        .O(ap_enable_reg_pp0_iter12));
  FDRE #(
    .INIT(1'b0)) 
    ap_enable_reg_pp0_iter1_reg
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_enable_reg_pp0_iter1_i_1_n_4),
        .Q(ap_enable_reg_pp0_iter1_reg_n_4),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair85" *) 
  LUT2 #(
    .INIT(4'h8)) 
    conv1_bias_EN_A_INST_0
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage9),
        .O(conv1_bias_EN_A));
  LUT6 #(
    .INIT(64'hFFFFFFFF23232322)) 
    \conv1_kernel_Addr_A[10]_INST_0 
       (.I0(\conv1_kernel_Addr_A[10]_INST_0_i_1_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .I3(\conv1_kernel_Addr_A[10]_INST_0_i_2_n_4 ),
        .I4(\conv1_kernel_Addr_A[10]_INST_0_i_3_n_4 ),
        .I5(\conv1_kernel_Addr_A[10]_INST_0_i_4_n_4 ),
        .O(conv1_kernel_Addr_A[8]));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_1 
       (.I0(\conv1_kernel_Addr_A[10]_INST_0_i_5_n_4 ),
        .I1(\conv1_kernel_Addr_A[10]_INST_0_i_6_n_4 ),
        .I2(\conv1_kernel_Addr_A[10]_INST_0_i_7_n_4 ),
        .I3(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .I4(\conv1_kernel_Addr_A[10]_INST_0_i_8_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_7_n_4 ),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_1_n_4 ));
  LUT6 #(
    .INIT(64'h57FFFFFFA8000000)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_10 
       (.I0(tmp_reg_2705[6]),
        .I1(tmp_reg_2705[3]),
        .I2(tmp_reg_2705[4]),
        .I3(tmp_reg_2705[5]),
        .I4(tmp_reg_2705[7]),
        .I5(tmp_reg_2705[8]),
        .O(tmp_87_cast_fu_1174_p1));
  LUT6 #(
    .INIT(64'h000F0F0002080208)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_11 
       (.I0(reg_631637_out),
        .I1(\conv1_kernel_Addr_A[10]_INST_0_i_25_n_4 ),
        .I2(reg_631839_out),
        .I3(tmp_reg_2705[8]),
        .I4(\conv1_kernel_Addr_A[10]_INST_0_i_26_n_4 ),
        .I5(reg_631738_out),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_11_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_12 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[5]),
        .I2(\conv1_kernel_Addr_A[10]_INST_0_i_27_n_4 ),
        .I3(tmp_reg_2705[4]),
        .I4(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_12_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_13 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[5]),
        .I2(\conv1_kernel_Addr_A[10]_INST_0_i_28_n_4 ),
        .I3(tmp_reg_2705[4]),
        .I4(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_13_n_4 ));
  LUT6 #(
    .INIT(64'h57FFFFFFA8000000)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_14 
       (.I0(tmp_reg_2705[6]),
        .I1(\conv1_kernel_Addr_A[10]_INST_0_i_29_n_4 ),
        .I2(tmp_reg_2705[4]),
        .I3(tmp_reg_2705[5]),
        .I4(tmp_reg_2705[7]),
        .I5(tmp_reg_2705[8]),
        .O(tmp_85_cast_fu_2384_p1[8]));
  LUT6 #(
    .INIT(64'h0072FF72FFD800D8)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_15 
       (.I0(reg_6312252_out),
        .I1(\conv1_kernel_Addr_A[10]_INST_0_i_30_n_4 ),
        .I2(\conv1_kernel_Addr_A[10]_INST_0_i_31_n_4 ),
        .I3(reg_6312353_out),
        .I4(\conv1_kernel_Addr_A[11]_INST_0_i_36_n_4 ),
        .I5(tmp_reg_2705[8]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_15_n_4 ));
  LUT6 #(
    .INIT(64'h0072FF72FFD800D8)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_16 
       (.I0(reg_63125),
        .I1(\conv1_kernel_Addr_A[11]_INST_0_i_39_n_4 ),
        .I2(\conv1_kernel_Addr_A[10]_INST_0_i_32_n_4 ),
        .I3(reg_6312555_out),
        .I4(\conv1_kernel_Addr_A[10]_INST_0_i_33_n_4 ),
        .I5(tmp_reg_2705[8]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_16_n_4 ));
  LUT6 #(
    .INIT(64'h6AAA000000000000)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_17 
       (.I0(tmp_reg_2705[8]),
        .I1(tmp_reg_2705[7]),
        .I2(\conv1_kernel_Addr_A[8]_INST_0_i_22_n_4 ),
        .I3(tmp_reg_2705[6]),
        .I4(ap_CS_fsm_pp0_stage16),
        .I5(ap_enable_reg_pp0_iter0),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_17_n_4 ));
  LUT6 #(
    .INIT(64'h8880000000000000)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_18 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[5]),
        .I2(\conv1_kernel_Addr_A[10]_INST_0_i_34_n_4 ),
        .I3(tmp_reg_2705[3]),
        .I4(tmp_reg_2705[4]),
        .I5(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_18_n_4 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_19 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[5]),
        .I2(tmp_reg_2705[3]),
        .I3(tmp_reg_2705[2]),
        .I4(tmp_reg_2705[4]),
        .I5(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_19_n_4 ));
  LUT6 #(
    .INIT(64'h3333300022222222)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_2 
       (.I0(\conv1_kernel_Addr_A[10]_INST_0_i_9_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .I2(tmp_87_cast_fu_1174_p1),
        .I3(reg_631839_out),
        .I4(\conv1_kernel_Addr_A[10]_INST_0_i_11_n_4 ),
        .I5(\input_r_Addr_A[4]_INST_0_i_12_n_4 ),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_2_n_4 ));
  LUT6 #(
    .INIT(64'h6AAA000000000000)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_20 
       (.I0(tmp_reg_2705[8]),
        .I1(tmp_reg_2705[7]),
        .I2(\conv1_kernel_Addr_A[11]_INST_0_i_41_n_4 ),
        .I3(tmp_reg_2705[6]),
        .I4(ap_CS_fsm_pp0_stage10),
        .I5(ap_enable_reg_pp0_iter0),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_20_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair31" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_21 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[5]),
        .I2(\conv1_kernel_Addr_A[10]_INST_0_i_35_n_4 ),
        .I3(tmp_reg_2705[4]),
        .I4(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_21_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_22 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[5]),
        .I2(tmp_reg_2705[3]),
        .I3(tmp_reg_2705[4]),
        .I4(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_22_n_4 ));
  LUT6 #(
    .INIT(64'h00002A8000000000)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_23 
       (.I0(ap_CS_fsm_pp0_stage13),
        .I1(\conv1_kernel_Addr_A[11]_INST_0_i_40_n_4 ),
        .I2(tmp_reg_2705[7]),
        .I3(tmp_reg_2705[8]),
        .I4(ap_CS_fsm_pp0_stage14),
        .I5(ap_enable_reg_pp0_iter0),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_23_n_4 ));
  LUT6 #(
    .INIT(64'h8880000000000000)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_24 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[5]),
        .I2(\conv1_kernel_Addr_A[10]_INST_0_i_36_n_4 ),
        .I3(tmp_reg_2705[3]),
        .I4(tmp_reg_2705[4]),
        .I5(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_24_n_4 ));
  LUT6 #(
    .INIT(64'h8880000000000000)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_25 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[5]),
        .I2(\conv1_kernel_Addr_A[10]_INST_0_i_37_n_4 ),
        .I3(tmp_reg_2705[3]),
        .I4(tmp_reg_2705[4]),
        .I5(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_25_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair32" *) 
  LUT5 #(
    .INIT(32'h88800000)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_26 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[5]),
        .I2(tmp_reg_2705[4]),
        .I3(\conv1_kernel_Addr_A[6]_INST_0_i_23_n_4 ),
        .I4(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_26_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair65" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_27 
       (.I0(tmp_reg_2705[3]),
        .I1(tmp_reg_2705[1]),
        .I2(tmp_reg_2705[2]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_27_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair41" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_28 
       (.I0(tmp_reg_2705[3]),
        .I1(tmp_reg_2705[1]),
        .I2(tmp_reg_2705[0]),
        .I3(tmp_reg_2705[2]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_28_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair60" *) 
  LUT3 #(
    .INIT(8'hA8)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_29 
       (.I0(tmp_reg_2705[3]),
        .I1(tmp_reg_2705[2]),
        .I2(tmp_reg_2705[1]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_29_n_4 ));
  LUT6 #(
    .INIT(64'h665A665A66AA6600)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_3 
       (.I0(tmp_reg_2705[8]),
        .I1(\conv1_kernel_Addr_A[10]_INST_0_i_12_n_4 ),
        .I2(\conv1_kernel_Addr_A[10]_INST_0_i_13_n_4 ),
        .I3(conv1_bias_EN_A),
        .I4(reg_631940_out),
        .I5(reg_6311041_out),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_3_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT5 #(
    .INIT(32'h88800000)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_30 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[5]),
        .I2(tmp_reg_2705[4]),
        .I3(\conv1_kernel_Addr_A[10]_INST_0_i_28_n_4 ),
        .I4(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_30_n_4 ));
  LUT6 #(
    .INIT(64'h6AAAAAAA00000000)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_31 
       (.I0(tmp_reg_2705[8]),
        .I1(tmp_reg_2705[7]),
        .I2(tmp_reg_2705[5]),
        .I3(tmp_reg_2705[4]),
        .I4(tmp_reg_2705[6]),
        .I5(reg_6312151_out),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_31_n_4 ));
  LUT6 #(
    .INIT(64'h6AAA000000000000)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_32 
       (.I0(tmp_reg_2705[8]),
        .I1(tmp_reg_2705[7]),
        .I2(\conv1_kernel_Addr_A[11]_INST_0_i_45_n_4 ),
        .I3(tmp_reg_2705[6]),
        .I4(ap_CS_fsm_pp0_stage22),
        .I5(ap_enable_reg_pp0_iter0),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_32_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair31" *) 
  LUT5 #(
    .INIT(32'h88800000)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_33 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[5]),
        .I2(tmp_reg_2705[4]),
        .I3(\conv1_kernel_Addr_A[10]_INST_0_i_35_n_4 ),
        .I4(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_33_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair67" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_34 
       (.I0(tmp_reg_2705[1]),
        .I1(tmp_reg_2705[0]),
        .I2(tmp_reg_2705[2]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_34_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair46" *) 
  LUT4 #(
    .INIT(16'hA888)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_35 
       (.I0(tmp_reg_2705[3]),
        .I1(tmp_reg_2705[2]),
        .I2(tmp_reg_2705[1]),
        .I3(tmp_reg_2705[0]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_35_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair75" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_36 
       (.I0(tmp_reg_2705[2]),
        .I1(tmp_reg_2705[1]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_36_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair67" *) 
  LUT3 #(
    .INIT(8'hA8)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_37 
       (.I0(tmp_reg_2705[2]),
        .I1(tmp_reg_2705[1]),
        .I2(tmp_reg_2705[0]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_37_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_4 
       (.I0(tmp_85_cast_fu_2384_p1[8]),
        .I1(\conv1_kernel_Addr_A[10]_INST_0_i_15_n_4 ),
        .I2(\conv1_kernel_Addr_A[10]_INST_0_i_16_n_4 ),
        .I3(ap_phi_mux_indvar_flatten2_phi_fu_580_p42),
        .I4(\conv1_kernel_Addr_A[11]_INST_0_i_13_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_24_n_4 ),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_4_n_4 ));
  LUT6 #(
    .INIT(64'h0072FF72FFD800D8)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_5 
       (.I0(reg_6311949_out),
        .I1(\conv1_kernel_Addr_A[11]_INST_0_i_25_n_4 ),
        .I2(\conv1_kernel_Addr_A[10]_INST_0_i_17_n_4 ),
        .I3(reg_6312050_out),
        .I4(\conv1_kernel_Addr_A[10]_INST_0_i_18_n_4 ),
        .I5(tmp_reg_2705[8]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_5_n_4 ));
  LUT6 #(
    .INIT(64'h0072FF72FFD800D8)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_6 
       (.I0(reg_6311343_out),
        .I1(\conv1_kernel_Addr_A[10]_INST_0_i_19_n_4 ),
        .I2(\conv1_kernel_Addr_A[10]_INST_0_i_20_n_4 ),
        .I3(reg_6311444_out),
        .I4(\conv1_kernel_Addr_A[10]_INST_0_i_21_n_4 ),
        .I5(tmp_reg_2705[8]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_6_n_4 ));
  LUT6 #(
    .INIT(64'h00F2FFF2FFF800F8)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_7 
       (.I0(reg_6311646_out),
        .I1(\conv1_kernel_Addr_A[10]_INST_0_i_22_n_4 ),
        .I2(\conv1_kernel_Addr_A[10]_INST_0_i_23_n_4 ),
        .I3(reg_6311747_out),
        .I4(\conv1_kernel_Addr_A[11]_INST_0_i_20_n_4 ),
        .I5(tmp_reg_2705[8]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_7_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT4 #(
    .INIT(16'hFE00)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_8 
       (.I0(ap_CS_fsm_pp0_stage11),
        .I1(ap_CS_fsm_pp0_stage10),
        .I2(ap_CS_fsm_pp0_stage12),
        .I3(ap_enable_reg_pp0_iter0),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_8_n_4 ));
  LUT6 #(
    .INIT(64'h0027FF27FFD800D8)) 
    \conv1_kernel_Addr_A[10]_INST_0_i_9 
       (.I0(reg_631435_out),
        .I1(\conv1_kernel_Addr_A[11]_INST_0_i_30_n_4 ),
        .I2(\conv1_kernel_Addr_A[11]_INST_0_i_29_n_4 ),
        .I3(reg_631536_out),
        .I4(\conv1_kernel_Addr_A[10]_INST_0_i_24_n_4 ),
        .I5(tmp_reg_2705[8]),
        .O(\conv1_kernel_Addr_A[10]_INST_0_i_9_n_4 ));
  LUT6 #(
    .INIT(64'hFFD8FFD8FFD800D8)) 
    \conv1_kernel_Addr_A[11]_INST_0 
       (.I0(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .I1(\conv1_kernel_Addr_A[11]_INST_0_i_1_n_4 ),
        .I2(\conv1_kernel_Addr_A[11]_INST_0_i_2_n_4 ),
        .I3(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I4(\conv1_kernel_Addr_A[11]_INST_0_i_3_n_4 ),
        .I5(\conv1_kernel_Addr_A[11]_INST_0_i_4_n_4 ),
        .O(conv1_kernel_Addr_A[9]));
  LUT6 #(
    .INIT(64'hFFD8FFD8FFD800D8)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_1 
       (.I0(\input_r_Addr_A[12]_INST_0_i_7_n_4 ),
        .I1(\conv1_kernel_Addr_A[11]_INST_0_i_5_n_4 ),
        .I2(\conv1_kernel_Addr_A[11]_INST_0_i_6_n_4 ),
        .I3(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .I4(\conv1_kernel_Addr_A[11]_INST_0_i_7_n_4 ),
        .I5(\conv1_kernel_Addr_A[11]_INST_0_i_8_n_4 ),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_1_n_4 ));
  LUT6 #(
    .INIT(64'h0330303012301230)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_10 
       (.I0(\conv1_kernel_Addr_A[11]_INST_0_i_29_n_4 ),
        .I1(reg_631536_out),
        .I2(tmp_reg_2705[9]),
        .I3(tmp_reg_2705[8]),
        .I4(\conv1_kernel_Addr_A[11]_INST_0_i_30_n_4 ),
        .I5(reg_631435_out),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_10_n_4 ));
  LUT6 #(
    .INIT(64'h6AAA000000000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_11 
       (.I0(tmp_reg_2705[9]),
        .I1(tmp_reg_2705[8]),
        .I2(\conv1_kernel_Addr_A[11]_INST_0_i_31_n_4 ),
        .I3(tmp_reg_2705[7]),
        .I4(ap_CS_fsm_pp0_stage3),
        .I5(ap_enable_reg_pp0_iter0),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_11_n_4 ));
  LUT6 #(
    .INIT(64'h665A665A66AA6600)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_12 
       (.I0(tmp_reg_2705[9]),
        .I1(\conv1_kernel_Addr_A[11]_INST_0_i_32_n_4 ),
        .I2(\conv1_kernel_Addr_A[11]_INST_0_i_33_n_4 ),
        .I3(conv1_bias_EN_A),
        .I4(reg_631940_out),
        .I5(reg_6311041_out),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_12_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT4 #(
    .INIT(16'hF0E0)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_13 
       (.I0(ap_CS_fsm_pp0_stage20),
        .I1(ap_CS_fsm_pp0_stage19),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage21),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_13_n_4 ));
  LUT6 #(
    .INIT(64'h0EFEFEFEFE0E0E0E)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_14 
       (.I0(\conv1_kernel_Addr_A[11]_INST_0_i_34_n_4 ),
        .I1(\conv1_kernel_Addr_A[11]_INST_0_i_35_n_4 ),
        .I2(reg_6312353_out),
        .I3(\conv1_kernel_Addr_A[11]_INST_0_i_36_n_4 ),
        .I4(tmp_reg_2705[8]),
        .I5(tmp_reg_2705[9]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_14_n_4 ));
  LUT6 #(
    .INIT(64'h6AAAAAAA00000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_15 
       (.I0(tmp_reg_2705[9]),
        .I1(tmp_reg_2705[8]),
        .I2(tmp_reg_2705[6]),
        .I3(\conv1_kernel_Addr_A[11]_INST_0_i_37_n_4 ),
        .I4(tmp_reg_2705[7]),
        .I5(reg_6312555_out),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_15_n_4 ));
  LUT6 #(
    .INIT(64'h0330303022222222)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_16 
       (.I0(\conv1_kernel_Addr_A[11]_INST_0_i_38_n_4 ),
        .I1(reg_6312555_out),
        .I2(tmp_reg_2705[9]),
        .I3(tmp_reg_2705[8]),
        .I4(\conv1_kernel_Addr_A[11]_INST_0_i_39_n_4 ),
        .I5(reg_63125),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_16_n_4 ));
  LUT6 #(
    .INIT(64'hAAAAA80000000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_17 
       (.I0(tmp_reg_2705[6]),
        .I1(tmp_reg_2705[1]),
        .I2(tmp_reg_2705[2]),
        .I3(tmp_reg_2705[3]),
        .I4(tmp_reg_2705[4]),
        .I5(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_17_n_4 ));
  LUT6 #(
    .INIT(64'h00002A8000000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_18 
       (.I0(ap_CS_fsm_pp0_stage14),
        .I1(\conv1_kernel_Addr_A[10]_INST_0_i_22_n_4 ),
        .I2(tmp_reg_2705[8]),
        .I3(tmp_reg_2705[9]),
        .I4(ap_CS_fsm_pp0_stage15),
        .I5(ap_enable_reg_pp0_iter0),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_18_n_4 ));
  LUT6 #(
    .INIT(64'h000000002AAA8000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_19 
       (.I0(reg_6311545_out),
        .I1(tmp_reg_2705[7]),
        .I2(\conv1_kernel_Addr_A[11]_INST_0_i_40_n_4 ),
        .I3(tmp_reg_2705[8]),
        .I4(tmp_reg_2705[9]),
        .I5(reg_6311646_out),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_19_n_4 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF0D0D0D08)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_2 
       (.I0(\input_r_Addr_A[4]_INST_0_i_12_n_4 ),
        .I1(\conv1_kernel_Addr_A[11]_INST_0_i_9_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .I3(\conv1_kernel_Addr_A[11]_INST_0_i_10_n_4 ),
        .I4(\conv1_kernel_Addr_A[11]_INST_0_i_11_n_4 ),
        .I5(\conv1_kernel_Addr_A[11]_INST_0_i_12_n_4 ),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_2_n_4 ));
  LUT6 #(
    .INIT(64'h8880000000000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_20 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[5]),
        .I2(tmp_reg_2705[2]),
        .I3(tmp_reg_2705[3]),
        .I4(tmp_reg_2705[4]),
        .I5(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_20_n_4 ));
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_21 
       (.I0(tmp_reg_2705[7]),
        .I1(\conv1_kernel_Addr_A[8]_INST_0_i_19_n_4 ),
        .I2(tmp_reg_2705[6]),
        .I3(tmp_reg_2705[8]),
        .I4(tmp_reg_2705[9]),
        .O(tmp_68_cast_fu_1559_p1));
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_22 
       (.I0(tmp_reg_2705[7]),
        .I1(\conv1_kernel_Addr_A[11]_INST_0_i_41_n_4 ),
        .I2(tmp_reg_2705[6]),
        .I3(tmp_reg_2705[8]),
        .I4(tmp_reg_2705[9]),
        .O(tmp_66_cast_fu_1435_p1));
  LUT6 #(
    .INIT(64'h00002A8000000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_23 
       (.I0(ap_CS_fsm_pp0_stage11),
        .I1(\conv1_kernel_Addr_A[10]_INST_0_i_19_n_4 ),
        .I2(tmp_reg_2705[8]),
        .I3(tmp_reg_2705[9]),
        .I4(ap_CS_fsm_pp0_stage12),
        .I5(ap_enable_reg_pp0_iter0),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_23_n_4 ));
  LUT6 #(
    .INIT(64'h6AAAAAAA00000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_24 
       (.I0(tmp_reg_2705[9]),
        .I1(tmp_reg_2705[8]),
        .I2(tmp_reg_2705[6]),
        .I3(\conv1_kernel_Addr_A[8]_INST_0_i_22_n_4 ),
        .I4(tmp_reg_2705[7]),
        .I5(reg_6311848_out),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_24_n_4 ));
  LUT6 #(
    .INIT(64'h8880000000000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_25 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[5]),
        .I2(\conv1_kernel_Addr_A[11]_INST_0_i_42_n_4 ),
        .I3(tmp_reg_2705[3]),
        .I4(tmp_reg_2705[4]),
        .I5(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_25_n_4 ));
  LUT6 #(
    .INIT(64'h8880000000000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_26 
       (.I0(tmp_reg_2705[8]),
        .I1(tmp_reg_2705[6]),
        .I2(\conv1_kernel_Addr_A[6]_INST_0_i_23_n_4 ),
        .I3(tmp_reg_2705[4]),
        .I4(tmp_reg_2705[5]),
        .I5(tmp_reg_2705[7]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_26_n_4 ));
  LUT6 #(
    .INIT(64'h6AAAAAAA00000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_27 
       (.I0(tmp_reg_2705[9]),
        .I1(tmp_reg_2705[8]),
        .I2(tmp_reg_2705[6]),
        .I3(\conv1_kernel_Addr_A[8]_INST_0_i_24_n_4 ),
        .I4(tmp_reg_2705[7]),
        .I5(reg_631637_out),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_27_n_4 ));
  LUT6 #(
    .INIT(64'h8880000000000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_28 
       (.I0(tmp_reg_2705[8]),
        .I1(tmp_reg_2705[6]),
        .I2(tmp_reg_2705[3]),
        .I3(tmp_reg_2705[4]),
        .I4(tmp_reg_2705[5]),
        .I5(tmp_reg_2705[7]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_28_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair32" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_29 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[5]),
        .I2(\conv1_kernel_Addr_A[6]_INST_0_i_23_n_4 ),
        .I3(tmp_reg_2705[4]),
        .I4(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_29_n_4 ));
  LUT6 #(
    .INIT(64'h0F0F0F0008080808)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_3 
       (.I0(\conv1_kernel_Addr_A[11]_INST_0_i_13_n_4 ),
        .I1(\conv1_kernel_Addr_A[11]_INST_0_i_14_n_4 ),
        .I2(ap_phi_mux_indvar_flatten2_phi_fu_580_p42),
        .I3(\conv1_kernel_Addr_A[11]_INST_0_i_15_n_4 ),
        .I4(\conv1_kernel_Addr_A[11]_INST_0_i_16_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_24_n_4 ),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_3_n_4 ));
  LUT6 #(
    .INIT(64'h8880000000000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_30 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[5]),
        .I2(\conv1_kernel_Addr_A[11]_INST_0_i_43_n_4 ),
        .I3(tmp_reg_2705[3]),
        .I4(tmp_reg_2705[4]),
        .I5(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_30_n_4 ));
  LUT6 #(
    .INIT(64'h8880808000000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_31 
       (.I0(tmp_reg_2705[6]),
        .I1(tmp_reg_2705[4]),
        .I2(tmp_reg_2705[3]),
        .I3(tmp_reg_2705[2]),
        .I4(tmp_reg_2705[1]),
        .I5(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_31_n_4 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_32 
       (.I0(tmp_reg_2705[8]),
        .I1(tmp_reg_2705[6]),
        .I2(tmp_reg_2705[4]),
        .I3(\conv1_kernel_Addr_A[10]_INST_0_i_27_n_4 ),
        .I4(tmp_reg_2705[5]),
        .I5(tmp_reg_2705[7]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_32_n_4 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_33 
       (.I0(tmp_reg_2705[8]),
        .I1(tmp_reg_2705[6]),
        .I2(tmp_reg_2705[4]),
        .I3(\conv1_kernel_Addr_A[10]_INST_0_i_28_n_4 ),
        .I4(tmp_reg_2705[5]),
        .I5(tmp_reg_2705[7]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_33_n_4 ));
  LUT6 #(
    .INIT(64'h6AAAAAAA00000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_34 
       (.I0(tmp_reg_2705[9]),
        .I1(tmp_reg_2705[8]),
        .I2(tmp_reg_2705[6]),
        .I3(\conv1_kernel_Addr_A[8]_INST_0_i_31_n_4 ),
        .I4(tmp_reg_2705[7]),
        .I5(reg_6312252_out),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_34_n_4 ));
  LUT6 #(
    .INIT(64'h00002A8000000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_35 
       (.I0(ap_CS_fsm_pp0_stage19),
        .I1(\conv1_kernel_Addr_A[11]_INST_0_i_44_n_4 ),
        .I2(tmp_reg_2705[8]),
        .I3(tmp_reg_2705[9]),
        .I4(ap_CS_fsm_pp0_stage20),
        .I5(ap_enable_reg_pp0_iter0),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_35_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT5 #(
    .INIT(32'h88800000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_36 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[5]),
        .I2(tmp_reg_2705[4]),
        .I3(\conv1_kernel_Addr_A[10]_INST_0_i_27_n_4 ),
        .I4(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_36_n_4 ));
  LUT6 #(
    .INIT(64'hA8A8A888A888A888)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_37 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[4]),
        .I2(tmp_reg_2705[3]),
        .I3(tmp_reg_2705[2]),
        .I4(tmp_reg_2705[1]),
        .I5(tmp_reg_2705[0]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_37_n_4 ));
  LUT6 #(
    .INIT(64'h6AAAAAAA00000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_38 
       (.I0(tmp_reg_2705[9]),
        .I1(tmp_reg_2705[8]),
        .I2(tmp_reg_2705[6]),
        .I3(\conv1_kernel_Addr_A[11]_INST_0_i_45_n_4 ),
        .I4(tmp_reg_2705[7]),
        .I5(reg_6312454_out),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_38_n_4 ));
  LUT6 #(
    .INIT(64'h8880808000000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_39 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[5]),
        .I2(tmp_reg_2705[4]),
        .I3(tmp_reg_2705[3]),
        .I4(tmp_reg_2705[2]),
        .I5(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_39_n_4 ));
  LUT6 #(
    .INIT(64'h7F80000000000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_4 
       (.I0(tmp_reg_2705[7]),
        .I1(\conv1_kernel_Addr_A[11]_INST_0_i_17_n_4 ),
        .I2(tmp_reg_2705[8]),
        .I3(tmp_reg_2705[9]),
        .I4(ap_enable_reg_pp0_iter1_reg_n_4),
        .I5(ap_CS_fsm_pp0_stage0),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_4_n_4 ));
  LUT6 #(
    .INIT(64'h8880000000000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_40 
       (.I0(tmp_reg_2705[6]),
        .I1(tmp_reg_2705[4]),
        .I2(tmp_reg_2705[1]),
        .I3(tmp_reg_2705[2]),
        .I4(tmp_reg_2705[3]),
        .I5(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_40_n_4 ));
  LUT6 #(
    .INIT(64'h8880000000000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_41 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[3]),
        .I2(tmp_reg_2705[0]),
        .I3(tmp_reg_2705[1]),
        .I4(tmp_reg_2705[2]),
        .I5(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_41_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair75" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_42 
       (.I0(tmp_reg_2705[1]),
        .I1(tmp_reg_2705[2]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_42_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair64" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_43 
       (.I0(tmp_reg_2705[2]),
        .I1(tmp_reg_2705[0]),
        .I2(tmp_reg_2705[1]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_43_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_44 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[5]),
        .I2(tmp_reg_2705[4]),
        .I3(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_44_n_4 ));
  LUT6 #(
    .INIT(64'hA8A8A88888888888)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_45 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[4]),
        .I2(tmp_reg_2705[3]),
        .I3(tmp_reg_2705[0]),
        .I4(tmp_reg_2705[1]),
        .I5(tmp_reg_2705[2]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_45_n_4 ));
  LUT6 #(
    .INIT(64'hAEFEFEFEFEAEAEAE)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_5 
       (.I0(\conv1_kernel_Addr_A[11]_INST_0_i_18_n_4 ),
        .I1(\conv1_kernel_Addr_A[11]_INST_0_i_19_n_4 ),
        .I2(reg_6311747_out),
        .I3(\conv1_kernel_Addr_A[11]_INST_0_i_20_n_4 ),
        .I4(tmp_reg_2705[8]),
        .I5(tmp_reg_2705[9]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_5_n_4 ));
  LUT6 #(
    .INIT(64'hFAF0FAF0FAFCFA00)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_6 
       (.I0(tmp_68_cast_fu_1559_p1),
        .I1(tmp_66_cast_fu_1435_p1),
        .I2(\conv1_kernel_Addr_A[11]_INST_0_i_23_n_4 ),
        .I3(reg_6311444_out),
        .I4(reg_6311242_out),
        .I5(reg_6311343_out),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_6_n_4 ));
  LUT6 #(
    .INIT(64'h0330303022222222)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_7 
       (.I0(\conv1_kernel_Addr_A[11]_INST_0_i_24_n_4 ),
        .I1(reg_6312050_out),
        .I2(tmp_reg_2705[9]),
        .I3(tmp_reg_2705[8]),
        .I4(\conv1_kernel_Addr_A[11]_INST_0_i_25_n_4 ),
        .I5(reg_6311949_out),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_7_n_4 ));
  LUT6 #(
    .INIT(64'h6AAAAAAA00000000)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_8 
       (.I0(tmp_reg_2705[9]),
        .I1(tmp_reg_2705[8]),
        .I2(tmp_reg_2705[6]),
        .I3(\conv1_kernel_Addr_A[8]_INST_0_i_8_n_4 ),
        .I4(tmp_reg_2705[7]),
        .I5(reg_6312050_out),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_8_n_4 ));
  LUT6 #(
    .INIT(64'h0072FF72FFD800D8)) 
    \conv1_kernel_Addr_A[11]_INST_0_i_9 
       (.I0(reg_631738_out),
        .I1(\conv1_kernel_Addr_A[11]_INST_0_i_26_n_4 ),
        .I2(\conv1_kernel_Addr_A[11]_INST_0_i_27_n_4 ),
        .I3(reg_631839_out),
        .I4(\conv1_kernel_Addr_A[11]_INST_0_i_28_n_4 ),
        .I5(tmp_reg_2705[9]),
        .O(\conv1_kernel_Addr_A[11]_INST_0_i_9_n_4 ));
  LUT5 #(
    .INIT(32'hFFD800D8)) 
    \conv1_kernel_Addr_A[2]_INST_0 
       (.I0(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .I1(\conv1_kernel_Addr_A[2]_INST_0_i_1_n_4 ),
        .I2(\conv1_kernel_Addr_A[2]_INST_0_i_2_n_4 ),
        .I3(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I4(\conv1_kernel_Addr_A[2]_INST_0_i_3_n_4 ),
        .O(conv1_kernel_Addr_A[0]));
  LUT6 #(
    .INIT(64'hAAEEAAAAFFBAAAAA)) 
    \conv1_kernel_Addr_A[2]_INST_0_i_1 
       (.I0(\conv1_kernel_Addr_A[2]_INST_0_i_4_n_4 ),
        .I1(ap_CS_fsm_pp0_stage17),
        .I2(ap_CS_fsm_pp0_stage16),
        .I3(ap_CS_fsm_pp0_stage18),
        .I4(ap_enable_reg_pp0_iter0),
        .I5(tmp_reg_2705[0]),
        .O(\conv1_kernel_Addr_A[2]_INST_0_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'h84848480)) 
    \conv1_kernel_Addr_A[2]_INST_0_i_10 
       (.I0(tmp_reg_2705[0]),
        .I1(ap_enable_reg_pp0_iter0),
        .I2(ap_CS_fsm_pp0_stage6),
        .I3(ap_CS_fsm_pp0_stage4),
        .I4(ap_CS_fsm_pp0_stage5),
        .O(\conv1_kernel_Addr_A[2]_INST_0_i_10_n_4 ));
  LUT6 #(
    .INIT(64'hFFBAAAAAAAEEAAAA)) 
    \conv1_kernel_Addr_A[2]_INST_0_i_2 
       (.I0(\conv1_kernel_Addr_A[2]_INST_0_i_5_n_4 ),
        .I1(ap_CS_fsm_pp0_stage8),
        .I2(ap_CS_fsm_pp0_stage7),
        .I3(ap_CS_fsm_pp0_stage9),
        .I4(ap_enable_reg_pp0_iter0),
        .I5(tmp_reg_2705[0]),
        .O(\conv1_kernel_Addr_A[2]_INST_0_i_2_n_4 ));
  LUT6 #(
    .INIT(64'hFFFF0B0A0000F5F4)) 
    \conv1_kernel_Addr_A[2]_INST_0_i_3 
       (.I0(reg_63125),
        .I1(reg_6312454_out),
        .I2(reg_6312555_out),
        .I3(\conv1_kernel_Addr_A[2]_INST_0_i_8_n_4 ),
        .I4(ap_phi_mux_indvar_flatten2_phi_fu_580_p42),
        .I5(tmp_reg_2705[0]),
        .O(\conv1_kernel_Addr_A[2]_INST_0_i_3_n_4 ));
  LUT6 #(
    .INIT(64'h3030303030303022)) 
    \conv1_kernel_Addr_A[2]_INST_0_i_4 
       (.I0(\conv1_kernel_Addr_A[2]_INST_0_i_9_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .I2(tmp_reg_2705[0]),
        .I3(reg_6311747_out),
        .I4(reg_6311545_out),
        .I5(reg_6311646_out),
        .O(\conv1_kernel_Addr_A[2]_INST_0_i_4_n_4 ));
  LUT5 #(
    .INIT(32'h00FF0009)) 
    \conv1_kernel_Addr_A[2]_INST_0_i_5 
       (.I0(tmp_reg_2705[0]),
        .I1(reg_631536_out),
        .I2(\input_r_Addr_A[4]_INST_0_i_12_n_4 ),
        .I3(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .I4(\conv1_kernel_Addr_A[2]_INST_0_i_10_n_4 ),
        .O(\conv1_kernel_Addr_A[2]_INST_0_i_5_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair72" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \conv1_kernel_Addr_A[2]_INST_0_i_6 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage23),
        .O(reg_63125));
  (* SOFT_HLUTNM = "soft_lutpair73" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \conv1_kernel_Addr_A[2]_INST_0_i_7 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage22),
        .O(reg_6312454_out));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT5 #(
    .INIT(32'h9090A080)) 
    \conv1_kernel_Addr_A[2]_INST_0_i_8 
       (.I0(tmp_reg_2705[0]),
        .I1(ap_CS_fsm_pp0_stage21),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage19),
        .I4(ap_CS_fsm_pp0_stage20),
        .O(\conv1_kernel_Addr_A[2]_INST_0_i_8_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT5 #(
    .INIT(32'h48484440)) 
    \conv1_kernel_Addr_A[2]_INST_0_i_9 
       (.I0(tmp_reg_2705[0]),
        .I1(ap_enable_reg_pp0_iter0),
        .I2(ap_CS_fsm_pp0_stage12),
        .I3(ap_CS_fsm_pp0_stage10),
        .I4(ap_CS_fsm_pp0_stage11),
        .O(\conv1_kernel_Addr_A[2]_INST_0_i_9_n_4 ));
  LUT6 #(
    .INIT(64'hAAAAEEEAEEEEEEEA)) 
    \conv1_kernel_Addr_A[3]_INST_0 
       (.I0(\conv1_kernel_Addr_A[3]_INST_0_i_1_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I2(\conv1_kernel_Addr_A[3]_INST_0_i_2_n_4 ),
        .I3(\conv1_kernel_Addr_A[3]_INST_0_i_3_n_4 ),
        .I4(ap_phi_mux_indvar_flatten2_phi_fu_580_p42),
        .I5(tmp_reg_2705[1]),
        .O(conv1_kernel_Addr_A[1]));
  LUT6 #(
    .INIT(64'h00FF000000FE00FE)) 
    \conv1_kernel_Addr_A[3]_INST_0_i_1 
       (.I0(\conv1_kernel_Addr_A[3]_INST_0_i_4_n_4 ),
        .I1(\conv1_kernel_Addr_A[3]_INST_0_i_5_n_4 ),
        .I2(\conv1_kernel_Addr_A[3]_INST_0_i_6_n_4 ),
        .I3(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I4(\conv1_kernel_Addr_A[3]_INST_0_i_7_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .O(\conv1_kernel_Addr_A[3]_INST_0_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair81" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \conv1_kernel_Addr_A[3]_INST_0_i_10 
       (.I0(ap_CS_fsm_pp0_stage21),
        .I1(ap_enable_reg_pp0_iter0),
        .O(reg_6312353_out));
  LUT6 #(
    .INIT(64'h3030303030033022)) 
    \conv1_kernel_Addr_A[3]_INST_0_i_11 
       (.I0(\conv1_kernel_Addr_A[3]_INST_0_i_12_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .I2(tmp_reg_2705[1]),
        .I3(reg_6311747_out),
        .I4(reg_6311545_out),
        .I5(reg_6311646_out),
        .O(\conv1_kernel_Addr_A[3]_INST_0_i_11_n_4 ));
  LUT6 #(
    .INIT(64'h60A060A060906000)) 
    \conv1_kernel_Addr_A[3]_INST_0_i_12 
       (.I0(tmp_reg_2705[1]),
        .I1(tmp_reg_2705[0]),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage12),
        .I4(ap_CS_fsm_pp0_stage10),
        .I5(ap_CS_fsm_pp0_stage11),
        .O(\conv1_kernel_Addr_A[3]_INST_0_i_12_n_4 ));
  LUT6 #(
    .INIT(64'h60A060A060906000)) 
    \conv1_kernel_Addr_A[3]_INST_0_i_2 
       (.I0(tmp_reg_2705[1]),
        .I1(tmp_reg_2705[0]),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage24),
        .I4(ap_CS_fsm_pp0_stage22),
        .I5(ap_CS_fsm_pp0_stage23),
        .O(\conv1_kernel_Addr_A[3]_INST_0_i_2_n_4 ));
  LUT6 #(
    .INIT(64'h00000000040EFAF0)) 
    \conv1_kernel_Addr_A[3]_INST_0_i_3 
       (.I0(reg_6312252_out),
        .I1(reg_6312151_out),
        .I2(reg_6312353_out),
        .I3(tmp_reg_2705[0]),
        .I4(tmp_reg_2705[1]),
        .I5(\input_r_Addr_A[12]_INST_0_i_24_n_4 ),
        .O(\conv1_kernel_Addr_A[3]_INST_0_i_3_n_4 ));
  LUT6 #(
    .INIT(64'h5060506050A05000)) 
    \conv1_kernel_Addr_A[3]_INST_0_i_4 
       (.I0(tmp_reg_2705[1]),
        .I1(tmp_reg_2705[0]),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage9),
        .I4(ap_CS_fsm_pp0_stage7),
        .I5(ap_CS_fsm_pp0_stage8),
        .O(\conv1_kernel_Addr_A[3]_INST_0_i_4_n_4 ));
  LUT6 #(
    .INIT(64'h0000000000551441)) 
    \conv1_kernel_Addr_A[3]_INST_0_i_5 
       (.I0(\input_r_Addr_A[4]_INST_0_i_12_n_4 ),
        .I1(reg_631435_out),
        .I2(tmp_reg_2705[0]),
        .I3(tmp_reg_2705[1]),
        .I4(reg_631536_out),
        .I5(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .O(\conv1_kernel_Addr_A[3]_INST_0_i_5_n_4 ));
  LUT6 #(
    .INIT(64'h00000000FEF0000E)) 
    \conv1_kernel_Addr_A[3]_INST_0_i_6 
       (.I0(reg_631738_out),
        .I1(reg_631637_out),
        .I2(reg_631839_out),
        .I3(tmp_reg_2705[0]),
        .I4(tmp_reg_2705[1]),
        .I5(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .O(\conv1_kernel_Addr_A[3]_INST_0_i_6_n_4 ));
  LUT6 #(
    .INIT(64'hFFAAAABAAAFEFFEE)) 
    \conv1_kernel_Addr_A[3]_INST_0_i_7 
       (.I0(\conv1_kernel_Addr_A[3]_INST_0_i_11_n_4 ),
        .I1(reg_6311949_out),
        .I2(reg_6311848_out),
        .I3(reg_6312050_out),
        .I4(tmp_reg_2705[0]),
        .I5(tmp_reg_2705[1]),
        .O(\conv1_kernel_Addr_A[3]_INST_0_i_7_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair82" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \conv1_kernel_Addr_A[3]_INST_0_i_8 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage20),
        .O(reg_6312252_out));
  (* SOFT_HLUTNM = "soft_lutpair84" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \conv1_kernel_Addr_A[3]_INST_0_i_9 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage19),
        .O(reg_6312151_out));
  LUT5 #(
    .INIT(32'hFFD800D8)) 
    \conv1_kernel_Addr_A[4]_INST_0 
       (.I0(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .I1(\conv1_kernel_Addr_A[4]_INST_0_i_1_n_4 ),
        .I2(\conv1_kernel_Addr_A[4]_INST_0_i_2_n_4 ),
        .I3(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I4(\conv1_kernel_Addr_A[4]_INST_0_i_3_n_4 ),
        .O(conv1_kernel_Addr_A[2]));
  LUT5 #(
    .INIT(32'hFFFF2322)) 
    \conv1_kernel_Addr_A[4]_INST_0_i_1 
       (.I0(\conv1_kernel_Addr_A[4]_INST_0_i_4_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_7_n_4 ),
        .I3(\conv1_kernel_Addr_A[4]_INST_0_i_5_n_4 ),
        .I4(\conv1_kernel_Addr_A[4]_INST_0_i_6_n_4 ),
        .O(\conv1_kernel_Addr_A[4]_INST_0_i_1_n_4 ));
  LUT6 #(
    .INIT(64'h9555955595569500)) 
    \conv1_kernel_Addr_A[4]_INST_0_i_10 
       (.I0(tmp_reg_2705[2]),
        .I1(tmp_reg_2705[1]),
        .I2(tmp_reg_2705[0]),
        .I3(reg_6312555_out),
        .I4(reg_6312454_out),
        .I5(reg_63125),
        .O(\conv1_kernel_Addr_A[4]_INST_0_i_10_n_4 ));
  LUT6 #(
    .INIT(64'h666A666A66AA6600)) 
    \conv1_kernel_Addr_A[4]_INST_0_i_11 
       (.I0(tmp_reg_2705[2]),
        .I1(tmp_reg_2705[1]),
        .I2(tmp_reg_2705[0]),
        .I3(reg_6312353_out),
        .I4(reg_6312151_out),
        .I5(reg_6312252_out),
        .O(\conv1_kernel_Addr_A[4]_INST_0_i_11_n_4 ));
  LUT5 #(
    .INIT(32'hFFFF2322)) 
    \conv1_kernel_Addr_A[4]_INST_0_i_2 
       (.I0(\conv1_kernel_Addr_A[4]_INST_0_i_7_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .I2(\input_r_Addr_A[4]_INST_0_i_12_n_4 ),
        .I3(\conv1_kernel_Addr_A[4]_INST_0_i_8_n_4 ),
        .I4(\conv1_kernel_Addr_A[4]_INST_0_i_9_n_4 ),
        .O(\conv1_kernel_Addr_A[4]_INST_0_i_2_n_4 ));
  LUT6 #(
    .INIT(64'hFFBA00BA00BAFFBA)) 
    \conv1_kernel_Addr_A[4]_INST_0_i_3 
       (.I0(\conv1_kernel_Addr_A[4]_INST_0_i_10_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_24_n_4 ),
        .I2(\conv1_kernel_Addr_A[4]_INST_0_i_11_n_4 ),
        .I3(ap_phi_mux_indvar_flatten2_phi_fu_580_p42),
        .I4(tmp_reg_2705[2]),
        .I5(tmp_reg_2705[1]),
        .O(\conv1_kernel_Addr_A[4]_INST_0_i_3_n_4 ));
  LUT6 #(
    .INIT(64'h50A050A050905000)) 
    \conv1_kernel_Addr_A[4]_INST_0_i_4 
       (.I0(tmp_reg_2705[2]),
        .I1(tmp_reg_2705[1]),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage15),
        .I4(ap_CS_fsm_pp0_stage13),
        .I5(ap_CS_fsm_pp0_stage14),
        .O(\conv1_kernel_Addr_A[4]_INST_0_i_4_n_4 ));
  LUT6 #(
    .INIT(64'h9555955595569500)) 
    \conv1_kernel_Addr_A[4]_INST_0_i_5 
       (.I0(tmp_reg_2705[2]),
        .I1(tmp_reg_2705[1]),
        .I2(tmp_reg_2705[0]),
        .I3(reg_6311444_out),
        .I4(reg_6311242_out),
        .I5(reg_6311343_out),
        .O(\conv1_kernel_Addr_A[4]_INST_0_i_5_n_4 ));
  LUT6 #(
    .INIT(64'hA9A5A9A5A995A900)) 
    \conv1_kernel_Addr_A[4]_INST_0_i_6 
       (.I0(tmp_reg_2705[2]),
        .I1(tmp_reg_2705[0]),
        .I2(tmp_reg_2705[1]),
        .I3(reg_6312050_out),
        .I4(reg_6311848_out),
        .I5(reg_6311949_out),
        .O(\conv1_kernel_Addr_A[4]_INST_0_i_6_n_4 ));
  LUT6 #(
    .INIT(64'hAAA9AAA9AA56AA00)) 
    \conv1_kernel_Addr_A[4]_INST_0_i_7 
       (.I0(tmp_reg_2705[2]),
        .I1(tmp_reg_2705[0]),
        .I2(tmp_reg_2705[1]),
        .I3(reg_631839_out),
        .I4(reg_631637_out),
        .I5(reg_631738_out),
        .O(\conv1_kernel_Addr_A[4]_INST_0_i_7_n_4 ));
  LUT6 #(
    .INIT(64'h0F7FFCECF0800313)) 
    \conv1_kernel_Addr_A[4]_INST_0_i_8 
       (.I0(ap_CS_fsm_pp0_stage2),
        .I1(tmp_reg_2705[0]),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage3),
        .I4(tmp_reg_2705[1]),
        .I5(tmp_reg_2705[2]),
        .O(\conv1_kernel_Addr_A[4]_INST_0_i_8_n_4 ));
  LUT6 #(
    .INIT(64'h666A666A66AA6600)) 
    \conv1_kernel_Addr_A[4]_INST_0_i_9 
       (.I0(tmp_reg_2705[2]),
        .I1(tmp_reg_2705[1]),
        .I2(tmp_reg_2705[0]),
        .I3(conv1_bias_EN_A),
        .I4(reg_631940_out),
        .I5(reg_6311041_out),
        .O(\conv1_kernel_Addr_A[4]_INST_0_i_9_n_4 ));
  LUT6 #(
    .INIT(64'hFEFEFE0EFE0EFE0E)) 
    \conv1_kernel_Addr_A[5]_INST_0 
       (.I0(\conv1_kernel_Addr_A[5]_INST_0_i_1_n_4 ),
        .I1(\conv1_kernel_Addr_A[5]_INST_0_i_2_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I3(\conv1_kernel_Addr_A[5]_INST_0_i_3_n_4 ),
        .I4(ap_phi_mux_indvar_flatten2_phi_fu_580_p42),
        .I5(tmp_85_cast_fu_2384_p1[3]),
        .O(conv1_kernel_Addr_A[3]));
  LUT6 #(
    .INIT(64'hAAFFAAAE00000000)) 
    \conv1_kernel_Addr_A[5]_INST_0_i_1 
       (.I0(\conv1_kernel_Addr_A[5]_INST_0_i_5_n_4 ),
        .I1(\conv1_kernel_Addr_A[5]_INST_0_i_6_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_7_n_4 ),
        .I3(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .I4(\conv1_kernel_Addr_A[5]_INST_0_i_7_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .O(\conv1_kernel_Addr_A[5]_INST_0_i_1_n_4 ));
  LUT6 #(
    .INIT(64'h5556555655955500)) 
    \conv1_kernel_Addr_A[5]_INST_0_i_10 
       (.I0(tmp_reg_2705[3]),
        .I1(\conv1_kernel_Addr_A[5]_INST_0_i_19_n_4 ),
        .I2(tmp_reg_2705[2]),
        .I3(reg_631839_out),
        .I4(reg_631637_out),
        .I5(reg_631738_out),
        .O(\conv1_kernel_Addr_A[5]_INST_0_i_10_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \conv1_kernel_Addr_A[5]_INST_0_i_11 
       (.I0(tmp_81_cast_fu_2129_p1),
        .I1(tmp_reg_2705[3]),
        .I2(tmp_80_cast_fu_2081_p1),
        .I3(reg_6312353_out),
        .I4(reg_6312151_out),
        .I5(reg_6312252_out),
        .O(\conv1_kernel_Addr_A[5]_INST_0_i_11_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair49" *) 
  LUT4 #(
    .INIT(16'h15EA)) 
    \conv1_kernel_Addr_A[5]_INST_0_i_12 
       (.I0(tmp_reg_2705[2]),
        .I1(tmp_reg_2705[1]),
        .I2(tmp_reg_2705[0]),
        .I3(tmp_reg_2705[3]),
        .O(tmp_84_cast_fu_2295_p1));
  LUT6 #(
    .INIT(64'h000F0F0008080808)) 
    \conv1_kernel_Addr_A[5]_INST_0_i_13 
       (.I0(reg_6312454_out),
        .I1(tmp_82_cast_fu_2181_p1),
        .I2(reg_6312555_out),
        .I3(tmp_reg_2705[3]),
        .I4(tmp_reg_2705[2]),
        .I5(reg_63125),
        .O(\conv1_kernel_Addr_A[5]_INST_0_i_13_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair44" *) 
  LUT4 #(
    .INIT(16'h01FE)) 
    \conv1_kernel_Addr_A[5]_INST_0_i_14 
       (.I0(tmp_reg_2705[2]),
        .I1(tmp_reg_2705[0]),
        .I2(tmp_reg_2705[1]),
        .I3(tmp_reg_2705[3]),
        .O(\conv1_kernel_Addr_A[5]_INST_0_i_14_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair41" *) 
  LUT4 #(
    .INIT(16'h1FE0)) 
    \conv1_kernel_Addr_A[5]_INST_0_i_15 
       (.I0(tmp_reg_2705[0]),
        .I1(tmp_reg_2705[1]),
        .I2(tmp_reg_2705[2]),
        .I3(tmp_reg_2705[3]),
        .O(tmp_82_cast_fu_2181_p1));
  LUT2 #(
    .INIT(4'h6)) 
    \conv1_kernel_Addr_A[5]_INST_0_i_16 
       (.I0(tmp_reg_2705[2]),
        .I1(tmp_reg_2705[3]),
        .O(tmp_83_cast_fu_2229_p1));
  (* SOFT_HLUTNM = "soft_lutpair65" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \conv1_kernel_Addr_A[5]_INST_0_i_17 
       (.I0(tmp_reg_2705[1]),
        .I1(tmp_reg_2705[2]),
        .I2(tmp_reg_2705[3]),
        .O(tmp_81_cast_fu_2129_p1));
  (* SOFT_HLUTNM = "soft_lutpair44" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \conv1_kernel_Addr_A[5]_INST_0_i_18 
       (.I0(tmp_reg_2705[1]),
        .I1(tmp_reg_2705[0]),
        .I2(tmp_reg_2705[2]),
        .I3(tmp_reg_2705[3]),
        .O(tmp_80_cast_fu_2081_p1));
  LUT2 #(
    .INIT(4'hE)) 
    \conv1_kernel_Addr_A[5]_INST_0_i_19 
       (.I0(tmp_reg_2705[0]),
        .I1(tmp_reg_2705[1]),
        .O(\conv1_kernel_Addr_A[5]_INST_0_i_19_n_4 ));
  LUT6 #(
    .INIT(64'h00000000AAFFAAAE)) 
    \conv1_kernel_Addr_A[5]_INST_0_i_2 
       (.I0(\conv1_kernel_Addr_A[5]_INST_0_i_8_n_4 ),
        .I1(\conv1_kernel_Addr_A[5]_INST_0_i_9_n_4 ),
        .I2(\input_r_Addr_A[4]_INST_0_i_12_n_4 ),
        .I3(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .I4(\conv1_kernel_Addr_A[5]_INST_0_i_10_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .O(\conv1_kernel_Addr_A[5]_INST_0_i_2_n_4 ));
  LUT6 #(
    .INIT(64'h3333300022222222)) 
    \conv1_kernel_Addr_A[5]_INST_0_i_3 
       (.I0(\conv1_kernel_Addr_A[5]_INST_0_i_11_n_4 ),
        .I1(ap_phi_mux_indvar_flatten2_phi_fu_580_p42),
        .I2(tmp_84_cast_fu_2295_p1),
        .I3(reg_6312555_out),
        .I4(\conv1_kernel_Addr_A[5]_INST_0_i_13_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_24_n_4 ),
        .O(\conv1_kernel_Addr_A[5]_INST_0_i_3_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair59" *) 
  LUT3 #(
    .INIT(8'h1E)) 
    \conv1_kernel_Addr_A[5]_INST_0_i_4 
       (.I0(tmp_reg_2705[2]),
        .I1(tmp_reg_2705[1]),
        .I2(tmp_reg_2705[3]),
        .O(tmp_85_cast_fu_2384_p1[3]));
  LUT6 #(
    .INIT(64'h550F550F55335500)) 
    \conv1_kernel_Addr_A[5]_INST_0_i_5 
       (.I0(\conv1_kernel_Addr_A[5]_INST_0_i_14_n_4 ),
        .I1(tmp_84_cast_fu_2295_p1),
        .I2(tmp_85_cast_fu_2384_p1[3]),
        .I3(reg_6312050_out),
        .I4(reg_6311848_out),
        .I5(reg_6311949_out),
        .O(\conv1_kernel_Addr_A[5]_INST_0_i_5_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \conv1_kernel_Addr_A[5]_INST_0_i_6 
       (.I0(tmp_84_cast_fu_2295_p1),
        .I1(tmp_82_cast_fu_2181_p1),
        .I2(tmp_83_cast_fu_2229_p1),
        .I3(reg_6311444_out),
        .I4(reg_6311242_out),
        .I5(reg_6311343_out),
        .O(\conv1_kernel_Addr_A[5]_INST_0_i_6_n_4 ));
  LUT6 #(
    .INIT(64'h9955995599569900)) 
    \conv1_kernel_Addr_A[5]_INST_0_i_7 
       (.I0(tmp_reg_2705[3]),
        .I1(tmp_reg_2705[2]),
        .I2(tmp_reg_2705[1]),
        .I3(reg_6311747_out),
        .I4(reg_6311545_out),
        .I5(reg_6311646_out),
        .O(\conv1_kernel_Addr_A[5]_INST_0_i_7_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \conv1_kernel_Addr_A[5]_INST_0_i_8 
       (.I0(tmp_81_cast_fu_2129_p1),
        .I1(tmp_reg_2705[3]),
        .I2(tmp_80_cast_fu_2081_p1),
        .I3(conv1_bias_EN_A),
        .I4(reg_631940_out),
        .I5(reg_6311041_out),
        .O(\conv1_kernel_Addr_A[5]_INST_0_i_8_n_4 ));
  LUT6 #(
    .INIT(64'hF0000FFF80017FFE)) 
    \conv1_kernel_Addr_A[5]_INST_0_i_9 
       (.I0(tmp_reg_2705[0]),
        .I1(reg_631435_out),
        .I2(tmp_reg_2705[1]),
        .I3(tmp_reg_2705[2]),
        .I4(tmp_reg_2705[3]),
        .I5(reg_631536_out),
        .O(\conv1_kernel_Addr_A[5]_INST_0_i_9_n_4 ));
  LUT6 #(
    .INIT(64'hFE0EFE0EFEFEFE0E)) 
    \conv1_kernel_Addr_A[6]_INST_0 
       (.I0(\conv1_kernel_Addr_A[6]_INST_0_i_1_n_4 ),
        .I1(\conv1_kernel_Addr_A[6]_INST_0_i_2_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I3(\conv1_kernel_Addr_A[6]_INST_0_i_3_n_4 ),
        .I4(ap_phi_mux_indvar_flatten2_phi_fu_580_p42),
        .I5(\conv1_kernel_Addr_A[6]_INST_0_i_5_n_4 ),
        .O(conv1_kernel_Addr_A[4]));
  LUT6 #(
    .INIT(64'hBB88B8B800000000)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_1 
       (.I0(\conv1_kernel_Addr_A[6]_INST_0_i_6_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .I2(\conv1_kernel_Addr_A[6]_INST_0_i_7_n_4 ),
        .I3(\conv1_kernel_Addr_A[6]_INST_0_i_8_n_4 ),
        .I4(\input_r_Addr_A[12]_INST_0_i_7_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_1_n_4 ));
  LUT6 #(
    .INIT(64'h0027FF27FFD800D8)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_10 
       (.I0(reg_631435_out),
        .I1(\conv1_kernel_Addr_A[6]_INST_0_i_22_n_4 ),
        .I2(\conv1_kernel_Addr_A[6]_INST_0_i_23_n_4 ),
        .I3(reg_631536_out),
        .I4(\conv1_kernel_Addr_A[6]_INST_0_i_24_n_4 ),
        .I5(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_10_n_4 ));
  LUT6 #(
    .INIT(64'hFF0000FFB8B87474)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_11 
       (.I0(\conv1_kernel_Addr_A[6]_INST_0_i_23_n_4 ),
        .I1(reg_631738_out),
        .I2(\conv1_kernel_Addr_A[6]_INST_0_i_25_n_4 ),
        .I3(tmp_reg_2705[3]),
        .I4(tmp_reg_2705[4]),
        .I5(reg_631839_out),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_11_n_4 ));
  LUT6 #(
    .INIT(64'h99A599A599559900)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_12 
       (.I0(tmp_reg_2705[4]),
        .I1(\conv1_kernel_Addr_A[10]_INST_0_i_27_n_4 ),
        .I2(\conv1_kernel_Addr_A[10]_INST_0_i_28_n_4 ),
        .I3(reg_6312353_out),
        .I4(reg_6312151_out),
        .I5(reg_6312252_out),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_12_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair74" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_13 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage24),
        .O(reg_6312555_out));
  (* SOFT_HLUTNM = "soft_lutpair37" *) 
  LUT5 #(
    .INIT(32'h07FFF800)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_14 
       (.I0(tmp_reg_2705[0]),
        .I1(tmp_reg_2705[1]),
        .I2(tmp_reg_2705[2]),
        .I3(tmp_reg_2705[3]),
        .I4(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_14_n_4 ));
  LUT6 #(
    .INIT(64'h0F08000400080F04)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_15 
       (.I0(\conv1_kernel_Addr_A[6]_INST_0_i_26_n_4 ),
        .I1(reg_6312454_out),
        .I2(reg_6312555_out),
        .I3(reg_63125),
        .I4(tmp_reg_2705[4]),
        .I5(\conv1_kernel_Addr_A[6]_INST_0_i_27_n_4 ),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_15_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair59" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_16 
       (.I0(tmp_reg_2705[2]),
        .I1(tmp_reg_2705[1]),
        .I2(tmp_reg_2705[3]),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_16_n_4 ));
  LUT6 #(
    .INIT(64'h5555566600000000)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_17 
       (.I0(tmp_reg_2705[4]),
        .I1(tmp_reg_2705[2]),
        .I2(tmp_reg_2705[1]),
        .I3(tmp_reg_2705[0]),
        .I4(tmp_reg_2705[3]),
        .I5(reg_6311848_out),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_17_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair46" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_18 
       (.I0(tmp_reg_2705[2]),
        .I1(tmp_reg_2705[0]),
        .I2(tmp_reg_2705[1]),
        .I3(tmp_reg_2705[3]),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_18_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair37" *) 
  LUT5 #(
    .INIT(32'h57FFA800)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_19 
       (.I0(tmp_reg_2705[2]),
        .I1(tmp_reg_2705[1]),
        .I2(tmp_reg_2705[0]),
        .I3(tmp_reg_2705[3]),
        .I4(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_19_n_4 ));
  LUT6 #(
    .INIT(64'h00000000AFAAAEAE)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_2 
       (.I0(\conv1_kernel_Addr_A[6]_INST_0_i_9_n_4 ),
        .I1(\conv1_kernel_Addr_A[6]_INST_0_i_10_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .I3(\conv1_kernel_Addr_A[6]_INST_0_i_11_n_4 ),
        .I4(\input_r_Addr_A[4]_INST_0_i_12_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_2_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair68" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_20 
       (.I0(tmp_reg_2705[2]),
        .I1(tmp_reg_2705[3]),
        .I2(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_20_n_4 ));
  LUT6 #(
    .INIT(64'h666A000000000000)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_21 
       (.I0(tmp_reg_2705[4]),
        .I1(tmp_reg_2705[3]),
        .I2(tmp_reg_2705[2]),
        .I3(tmp_reg_2705[1]),
        .I4(ap_CS_fsm_pp0_stage13),
        .I5(ap_enable_reg_pp0_iter0),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_21_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair40" *) 
  LUT4 #(
    .INIT(16'hFF80)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_22 
       (.I0(tmp_reg_2705[1]),
        .I1(tmp_reg_2705[0]),
        .I2(tmp_reg_2705[2]),
        .I3(tmp_reg_2705[3]),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_22_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair49" *) 
  LUT4 #(
    .INIT(16'hAAA8)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_23 
       (.I0(tmp_reg_2705[3]),
        .I1(tmp_reg_2705[2]),
        .I2(tmp_reg_2705[0]),
        .I3(tmp_reg_2705[1]),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_23_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair60" *) 
  LUT3 #(
    .INIT(8'hF8)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_24 
       (.I0(tmp_reg_2705[1]),
        .I1(tmp_reg_2705[2]),
        .I2(tmp_reg_2705[3]),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_24_n_4 ));
  LUT6 #(
    .INIT(64'h555556AA00000000)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_25 
       (.I0(tmp_reg_2705[4]),
        .I1(tmp_reg_2705[0]),
        .I2(tmp_reg_2705[1]),
        .I3(tmp_reg_2705[2]),
        .I4(tmp_reg_2705[3]),
        .I5(reg_631637_out),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_25_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair40" *) 
  LUT4 #(
    .INIT(16'hA800)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_26 
       (.I0(tmp_reg_2705[3]),
        .I1(tmp_reg_2705[0]),
        .I2(tmp_reg_2705[1]),
        .I3(tmp_reg_2705[2]),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_26_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair68" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_27 
       (.I0(tmp_reg_2705[3]),
        .I1(tmp_reg_2705[2]),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_27_n_4 ));
  LUT6 #(
    .INIT(64'h3333003022222222)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_3 
       (.I0(\conv1_kernel_Addr_A[6]_INST_0_i_12_n_4 ),
        .I1(ap_phi_mux_indvar_flatten2_phi_fu_580_p42),
        .I2(reg_6312555_out),
        .I3(\conv1_kernel_Addr_A[6]_INST_0_i_14_n_4 ),
        .I4(\conv1_kernel_Addr_A[6]_INST_0_i_15_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_24_n_4 ),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_3_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_4 
       (.I0(ap_CS_fsm_pp0_stage0),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .O(ap_phi_mux_indvar_flatten2_phi_fu_580_p42));
  (* SOFT_HLUTNM = "soft_lutpair55" *) 
  LUT4 #(
    .INIT(16'h1FE0)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_5 
       (.I0(tmp_reg_2705[1]),
        .I1(tmp_reg_2705[2]),
        .I2(tmp_reg_2705[3]),
        .I3(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_5_n_4 ));
  LUT6 #(
    .INIT(64'h0072FF72FFD800D8)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_6 
       (.I0(reg_6311949_out),
        .I1(\conv1_kernel_Addr_A[6]_INST_0_i_16_n_4 ),
        .I2(\conv1_kernel_Addr_A[6]_INST_0_i_17_n_4 ),
        .I3(reg_6312050_out),
        .I4(\conv1_kernel_Addr_A[6]_INST_0_i_18_n_4 ),
        .I5(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_6_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_7 
       (.I0(\conv1_kernel_Addr_A[6]_INST_0_i_14_n_4 ),
        .I1(\conv1_kernel_Addr_A[6]_INST_0_i_19_n_4 ),
        .I2(\conv1_kernel_Addr_A[6]_INST_0_i_20_n_4 ),
        .I3(reg_6311444_out),
        .I4(reg_6311242_out),
        .I5(reg_6311343_out),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_7_n_4 ));
  LUT6 #(
    .INIT(64'h040E04FEFEF4FE04)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_8 
       (.I0(reg_6311646_out),
        .I1(\conv1_kernel_Addr_A[6]_INST_0_i_21_n_4 ),
        .I2(reg_6311747_out),
        .I3(tmp_reg_2705[3]),
        .I4(tmp_reg_2705[2]),
        .I5(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_8_n_4 ));
  LUT6 #(
    .INIT(64'h665A665A66AA6600)) 
    \conv1_kernel_Addr_A[6]_INST_0_i_9 
       (.I0(tmp_reg_2705[4]),
        .I1(\conv1_kernel_Addr_A[10]_INST_0_i_27_n_4 ),
        .I2(\conv1_kernel_Addr_A[10]_INST_0_i_28_n_4 ),
        .I3(conv1_bias_EN_A),
        .I4(reg_631940_out),
        .I5(reg_6311041_out),
        .O(\conv1_kernel_Addr_A[6]_INST_0_i_9_n_4 ));
  LUT4 #(
    .INIT(16'hFE0E)) 
    \conv1_kernel_Addr_A[7]_INST_0 
       (.I0(\conv1_kernel_Addr_A[7]_INST_0_i_1_n_4 ),
        .I1(\conv1_kernel_Addr_A[7]_INST_0_i_2_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I3(\conv1_kernel_Addr_A[7]_INST_0_i_3_n_4 ),
        .O(conv1_kernel_Addr_A[5]));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_1 
       (.I0(\conv1_kernel_Addr_A[7]_INST_0_i_4_n_4 ),
        .I1(\conv1_kernel_Addr_A[7]_INST_0_i_5_n_4 ),
        .I2(\conv1_kernel_Addr_A[7]_INST_0_i_6_n_4 ),
        .I3(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .I4(\conv1_kernel_Addr_A[10]_INST_0_i_8_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_7_n_4 ),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_1_n_4 ));
  LUT6 #(
    .INIT(64'h00F2FFF2FFF800F8)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_10 
       (.I0(reg_63125),
        .I1(\conv1_kernel_Addr_A[7]_INST_0_i_28_n_4 ),
        .I2(\conv1_kernel_Addr_A[7]_INST_0_i_29_n_4 ),
        .I3(reg_6312555_out),
        .I4(\conv1_kernel_Addr_A[7]_INST_0_i_30_n_4 ),
        .I5(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_10_n_4 ));
  LUT6 #(
    .INIT(64'hFFFF560000000000)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_11 
       (.I0(tmp_reg_2705[5]),
        .I1(\conv1_kernel_Addr_A[10]_INST_0_i_27_n_4 ),
        .I2(tmp_reg_2705[4]),
        .I3(reg_6312353_out),
        .I4(\conv1_kernel_Addr_A[7]_INST_0_i_31_n_4 ),
        .I5(\conv1_kernel_Addr_A[11]_INST_0_i_13_n_4 ),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_11_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair42" *) 
  LUT4 #(
    .INIT(16'hFFE0)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_12 
       (.I0(tmp_reg_2705[1]),
        .I1(tmp_reg_2705[2]),
        .I2(tmp_reg_2705[3]),
        .I3(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_12_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT4 #(
    .INIT(16'hAAA8)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_13 
       (.I0(tmp_reg_2705[4]),
        .I1(tmp_reg_2705[3]),
        .I2(tmp_reg_2705[1]),
        .I3(tmp_reg_2705[2]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_13_n_4 ));
  LUT6 #(
    .INIT(64'h666A000000000000)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_14 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[4]),
        .I2(tmp_reg_2705[3]),
        .I3(\conv1_kernel_Addr_A[7]_INST_0_i_32_n_4 ),
        .I4(ap_CS_fsm_pp0_stage16),
        .I5(ap_enable_reg_pp0_iter0),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_14_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT5 #(
    .INIT(32'hAAAAAAA8)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_15 
       (.I0(tmp_reg_2705[4]),
        .I1(tmp_reg_2705[3]),
        .I2(tmp_reg_2705[1]),
        .I3(tmp_reg_2705[0]),
        .I4(tmp_reg_2705[2]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_15_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair56" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_16 
       (.I0(tmp_reg_2705[4]),
        .I1(tmp_reg_2705[2]),
        .I2(tmp_reg_2705[3]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_16_n_4 ));
  LUT6 #(
    .INIT(64'h00002A8000000000)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_17 
       (.I0(ap_CS_fsm_pp0_stage10),
        .I1(\conv1_kernel_Addr_A[6]_INST_0_i_26_n_4 ),
        .I2(tmp_reg_2705[4]),
        .I3(tmp_reg_2705[5]),
        .I4(ap_CS_fsm_pp0_stage11),
        .I5(ap_enable_reg_pp0_iter0),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_17_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT5 #(
    .INIT(32'hAA800000)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_18 
       (.I0(tmp_reg_2705[4]),
        .I1(tmp_reg_2705[0]),
        .I2(tmp_reg_2705[1]),
        .I3(tmp_reg_2705[2]),
        .I4(tmp_reg_2705[3]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_18_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair35" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_19 
       (.I0(tmp_reg_2705[4]),
        .I1(tmp_reg_2705[3]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_19_n_4 ));
  LUT6 #(
    .INIT(64'h00000000AFAAAEAE)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_2 
       (.I0(\conv1_kernel_Addr_A[7]_INST_0_i_7_n_4 ),
        .I1(\conv1_kernel_Addr_A[7]_INST_0_i_8_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .I3(\conv1_kernel_Addr_A[7]_INST_0_i_9_n_4 ),
        .I4(\input_r_Addr_A[4]_INST_0_i_12_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_2_n_4 ));
  LUT6 #(
    .INIT(64'h666AAAAA00000000)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_20 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[4]),
        .I2(tmp_reg_2705[1]),
        .I3(tmp_reg_2705[2]),
        .I4(tmp_reg_2705[3]),
        .I5(reg_6311545_out),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_20_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair66" *) 
  LUT3 #(
    .INIT(8'hA8)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_21 
       (.I0(tmp_reg_2705[4]),
        .I1(tmp_reg_2705[3]),
        .I2(tmp_reg_2705[2]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_21_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair55" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_22 
       (.I0(tmp_reg_2705[4]),
        .I1(tmp_reg_2705[2]),
        .I2(tmp_reg_2705[1]),
        .I3(tmp_reg_2705[3]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_22_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_23 
       (.I0(tmp_reg_2705[4]),
        .I1(tmp_reg_2705[2]),
        .I2(tmp_reg_2705[0]),
        .I3(tmp_reg_2705[1]),
        .I4(tmp_reg_2705[3]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_23_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT5 #(
    .INIT(32'hA8888888)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_24 
       (.I0(tmp_reg_2705[4]),
        .I1(tmp_reg_2705[3]),
        .I2(tmp_reg_2705[2]),
        .I3(tmp_reg_2705[0]),
        .I4(tmp_reg_2705[1]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_24_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair38" *) 
  LUT5 #(
    .INIT(32'hAAA80000)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_25 
       (.I0(tmp_reg_2705[4]),
        .I1(tmp_reg_2705[1]),
        .I2(tmp_reg_2705[0]),
        .I3(tmp_reg_2705[2]),
        .I4(tmp_reg_2705[3]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_25_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair42" *) 
  LUT4 #(
    .INIT(16'hA888)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_26 
       (.I0(tmp_reg_2705[4]),
        .I1(tmp_reg_2705[3]),
        .I2(tmp_reg_2705[2]),
        .I3(tmp_reg_2705[1]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_26_n_4 ));
  LUT6 #(
    .INIT(64'h000F0F0002080208)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_27 
       (.I0(reg_631637_out),
        .I1(\conv1_kernel_Addr_A[7]_INST_0_i_33_n_4 ),
        .I2(reg_631839_out),
        .I3(tmp_reg_2705[5]),
        .I4(\conv1_kernel_Addr_A[7]_INST_0_i_34_n_4 ),
        .I5(reg_631738_out),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_27_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair66" *) 
  LUT3 #(
    .INIT(8'hF8)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_28 
       (.I0(tmp_reg_2705[2]),
        .I1(tmp_reg_2705[3]),
        .I2(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_28_n_4 ));
  LUT6 #(
    .INIT(64'h000002A800000000)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_29 
       (.I0(ap_CS_fsm_pp0_stage22),
        .I1(tmp_reg_2705[4]),
        .I2(\conv1_kernel_Addr_A[6]_INST_0_i_26_n_4 ),
        .I3(tmp_reg_2705[5]),
        .I4(ap_CS_fsm_pp0_stage23),
        .I5(ap_enable_reg_pp0_iter0),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_29_n_4 ));
  LUT6 #(
    .INIT(64'h00D8FFD8FFD800D8)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_3 
       (.I0(\input_r_Addr_A[12]_INST_0_i_24_n_4 ),
        .I1(\conv1_kernel_Addr_A[7]_INST_0_i_10_n_4 ),
        .I2(\conv1_kernel_Addr_A[7]_INST_0_i_11_n_4 ),
        .I3(ap_phi_mux_indvar_flatten2_phi_fu_580_p42),
        .I4(tmp_reg_2705[5]),
        .I5(\conv1_kernel_Addr_A[7]_INST_0_i_12_n_4 ),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_3_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair34" *) 
  LUT5 #(
    .INIT(32'hFFFFF800)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_30 
       (.I0(tmp_reg_2705[0]),
        .I1(tmp_reg_2705[1]),
        .I2(tmp_reg_2705[2]),
        .I3(tmp_reg_2705[3]),
        .I4(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_30_n_4 ));
  LUT6 #(
    .INIT(64'h0303033002022020)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_31 
       (.I0(reg_6312151_out),
        .I1(reg_6312353_out),
        .I2(tmp_reg_2705[5]),
        .I3(\conv1_kernel_Addr_A[10]_INST_0_i_28_n_4 ),
        .I4(tmp_reg_2705[4]),
        .I5(reg_6312252_out),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_31_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair64" *) 
  LUT3 #(
    .INIT(8'hF8)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_32 
       (.I0(tmp_reg_2705[0]),
        .I1(tmp_reg_2705[1]),
        .I2(tmp_reg_2705[2]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_32_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair34" *) 
  LUT5 #(
    .INIT(32'hA8A8A888)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_33 
       (.I0(tmp_reg_2705[4]),
        .I1(tmp_reg_2705[3]),
        .I2(tmp_reg_2705[2]),
        .I3(tmp_reg_2705[1]),
        .I4(tmp_reg_2705[0]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_33_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair38" *) 
  LUT5 #(
    .INIT(32'hFFFFFE00)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_34 
       (.I0(tmp_reg_2705[1]),
        .I1(tmp_reg_2705[0]),
        .I2(tmp_reg_2705[2]),
        .I3(tmp_reg_2705[3]),
        .I4(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_34_n_4 ));
  LUT6 #(
    .INIT(64'h0072FF72FFD800D8)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_4 
       (.I0(reg_6311949_out),
        .I1(\conv1_kernel_Addr_A[7]_INST_0_i_13_n_4 ),
        .I2(\conv1_kernel_Addr_A[7]_INST_0_i_14_n_4 ),
        .I3(reg_6312050_out),
        .I4(\conv1_kernel_Addr_A[7]_INST_0_i_15_n_4 ),
        .I5(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_4_n_4 ));
  LUT6 #(
    .INIT(64'h00F2FFF2FFF800F8)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_5 
       (.I0(reg_6311343_out),
        .I1(\conv1_kernel_Addr_A[7]_INST_0_i_16_n_4 ),
        .I2(\conv1_kernel_Addr_A[7]_INST_0_i_17_n_4 ),
        .I3(reg_6311444_out),
        .I4(\conv1_kernel_Addr_A[7]_INST_0_i_18_n_4 ),
        .I5(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_5_n_4 ));
  LUT6 #(
    .INIT(64'h0072FF72FFD800D8)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_6 
       (.I0(reg_6311646_out),
        .I1(\conv1_kernel_Addr_A[7]_INST_0_i_19_n_4 ),
        .I2(\conv1_kernel_Addr_A[7]_INST_0_i_20_n_4 ),
        .I3(reg_6311747_out),
        .I4(\conv1_kernel_Addr_A[7]_INST_0_i_21_n_4 ),
        .I5(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_6_n_4 ));
  LUT6 #(
    .INIT(64'h665A665A66AA6600)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_7 
       (.I0(tmp_reg_2705[5]),
        .I1(\conv1_kernel_Addr_A[7]_INST_0_i_22_n_4 ),
        .I2(\conv1_kernel_Addr_A[7]_INST_0_i_23_n_4 ),
        .I3(conv1_bias_EN_A),
        .I4(reg_631940_out),
        .I5(reg_6311041_out),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_7_n_4 ));
  LUT6 #(
    .INIT(64'h0027FF27FFD800D8)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_8 
       (.I0(reg_631435_out),
        .I1(\conv1_kernel_Addr_A[7]_INST_0_i_24_n_4 ),
        .I2(\conv1_kernel_Addr_A[7]_INST_0_i_25_n_4 ),
        .I3(reg_631536_out),
        .I4(\conv1_kernel_Addr_A[7]_INST_0_i_26_n_4 ),
        .I5(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_8_n_4 ));
  LUT6 #(
    .INIT(64'hAAAAAAEAEAEAEAAA)) 
    \conv1_kernel_Addr_A[7]_INST_0_i_9 
       (.I0(\conv1_kernel_Addr_A[7]_INST_0_i_27_n_4 ),
        .I1(ap_enable_reg_pp0_iter0),
        .I2(ap_CS_fsm_pp0_stage6),
        .I3(tmp_reg_2705[4]),
        .I4(tmp_reg_2705[3]),
        .I5(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[7]_INST_0_i_9_n_4 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF00FD00A8)) 
    \conv1_kernel_Addr_A[8]_INST_0 
       (.I0(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .I1(\conv1_kernel_Addr_A[8]_INST_0_i_1_n_4 ),
        .I2(\conv1_kernel_Addr_A[8]_INST_0_i_2_n_4 ),
        .I3(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I4(\conv1_kernel_Addr_A[8]_INST_0_i_3_n_4 ),
        .I5(\conv1_kernel_Addr_A[8]_INST_0_i_4_n_4 ),
        .O(conv1_kernel_Addr_A[6]));
  LUT6 #(
    .INIT(64'h0F0F0F0008080808)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_1 
       (.I0(\conv1_kernel_Addr_A[10]_INST_0_i_8_n_4 ),
        .I1(\conv1_kernel_Addr_A[8]_INST_0_i_5_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .I3(\conv1_kernel_Addr_A[8]_INST_0_i_6_n_4 ),
        .I4(\conv1_kernel_Addr_A[8]_INST_0_i_7_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_7_n_4 ),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_1_n_4 ));
  LUT6 #(
    .INIT(64'h000F0F0002080208)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_10 
       (.I0(reg_631637_out),
        .I1(\conv1_kernel_Addr_A[8]_INST_0_i_24_n_4 ),
        .I2(reg_631839_out),
        .I3(tmp_reg_2705[6]),
        .I4(\conv1_kernel_Addr_A[8]_INST_0_i_25_n_4 ),
        .I5(reg_631738_out),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_10_n_4 ));
  LUT6 #(
    .INIT(64'h666A000000000000)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_11 
       (.I0(tmp_reg_2705[6]),
        .I1(tmp_reg_2705[5]),
        .I2(tmp_reg_2705[4]),
        .I3(tmp_reg_2705[3]),
        .I4(ap_CS_fsm_pp0_stage6),
        .I5(ap_enable_reg_pp0_iter0),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_11_n_4 ));
  LUT6 #(
    .INIT(64'h0027FF27FFD800D8)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_12 
       (.I0(reg_631435_out),
        .I1(\conv1_kernel_Addr_A[8]_INST_0_i_26_n_4 ),
        .I2(\conv1_kernel_Addr_A[8]_INST_0_i_27_n_4 ),
        .I3(reg_631536_out),
        .I4(\conv1_kernel_Addr_A[8]_INST_0_i_28_n_4 ),
        .I5(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_12_n_4 ));
  LUT6 #(
    .INIT(64'h665A665A66AA6600)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_13 
       (.I0(tmp_reg_2705[6]),
        .I1(\conv1_kernel_Addr_A[8]_INST_0_i_29_n_4 ),
        .I2(\conv1_kernel_Addr_A[8]_INST_0_i_30_n_4 ),
        .I3(conv1_bias_EN_A),
        .I4(reg_631940_out),
        .I5(reg_6311041_out),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_13_n_4 ));
  LUT6 #(
    .INIT(64'h001FFFFFFFE00000)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_14 
       (.I0(tmp_reg_2705[1]),
        .I1(tmp_reg_2705[2]),
        .I2(tmp_reg_2705[3]),
        .I3(tmp_reg_2705[4]),
        .I4(tmp_reg_2705[5]),
        .I5(tmp_reg_2705[6]),
        .O(tmp_85_cast_fu_2384_p1[6]));
  LUT6 #(
    .INIT(64'h00F2FFF2FFF800F8)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_15 
       (.I0(reg_6312252_out),
        .I1(\conv1_kernel_Addr_A[8]_INST_0_i_31_n_4 ),
        .I2(\conv1_kernel_Addr_A[8]_INST_0_i_32_n_4 ),
        .I3(reg_6312353_out),
        .I4(\conv1_kernel_Addr_A[8]_INST_0_i_33_n_4 ),
        .I5(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_15_n_4 ));
  LUT6 #(
    .INIT(64'h0072FF72FFD800D8)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_16 
       (.I0(reg_63125),
        .I1(\conv1_kernel_Addr_A[8]_INST_0_i_34_n_4 ),
        .I2(\conv1_kernel_Addr_A[8]_INST_0_i_35_n_4 ),
        .I3(reg_6312555_out),
        .I4(\conv1_kernel_Addr_A[11]_INST_0_i_37_n_4 ),
        .I5(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_16_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_17 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[3]),
        .I2(tmp_reg_2705[2]),
        .I3(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_17_n_4 ));
  LUT6 #(
    .INIT(64'h6AAA000000000000)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_18 
       (.I0(tmp_reg_2705[6]),
        .I1(tmp_reg_2705[5]),
        .I2(\conv1_kernel_Addr_A[6]_INST_0_i_26_n_4 ),
        .I3(tmp_reg_2705[4]),
        .I4(ap_CS_fsm_pp0_stage10),
        .I5(ap_enable_reg_pp0_iter0),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_18_n_4 ));
  LUT6 #(
    .INIT(64'h8880808000000000)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_19 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[3]),
        .I2(tmp_reg_2705[2]),
        .I3(tmp_reg_2705[1]),
        .I4(tmp_reg_2705[0]),
        .I5(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_19_n_4 ));
  LUT6 #(
    .INIT(64'hFFFF600000000000)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_2 
       (.I0(tmp_reg_2705[6]),
        .I1(\conv1_kernel_Addr_A[8]_INST_0_i_8_n_4 ),
        .I2(ap_CS_fsm_pp0_stage18),
        .I3(ap_enable_reg_pp0_iter0),
        .I4(\conv1_kernel_Addr_A[8]_INST_0_i_9_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_2_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT5 #(
    .INIT(32'h88800000)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_20 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[3]),
        .I2(tmp_reg_2705[2]),
        .I3(tmp_reg_2705[1]),
        .I4(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_20_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair33" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_21 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[3]),
        .I2(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_21_n_4 ));
  LUT6 #(
    .INIT(64'hAAAAA88800000000)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_22 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[2]),
        .I2(tmp_reg_2705[1]),
        .I3(tmp_reg_2705[0]),
        .I4(tmp_reg_2705[3]),
        .I5(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_22_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT5 #(
    .INIT(32'hAAA80000)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_23 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[2]),
        .I2(tmp_reg_2705[1]),
        .I3(tmp_reg_2705[3]),
        .I4(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_23_n_4 ));
  LUT6 #(
    .INIT(64'hAAAAA80000000000)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_24 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[0]),
        .I2(tmp_reg_2705[1]),
        .I3(tmp_reg_2705[2]),
        .I4(tmp_reg_2705[3]),
        .I5(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_24_n_4 ));
  LUT6 #(
    .INIT(64'hA8A8A8A8A8A8A888)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_25 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[4]),
        .I2(tmp_reg_2705[3]),
        .I3(tmp_reg_2705[2]),
        .I4(tmp_reg_2705[0]),
        .I5(tmp_reg_2705[1]),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_25_n_4 ));
  LUT6 #(
    .INIT(64'hAAAA800000000000)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_26 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[1]),
        .I2(tmp_reg_2705[0]),
        .I3(tmp_reg_2705[2]),
        .I4(tmp_reg_2705[3]),
        .I5(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_26_n_4 ));
  LUT6 #(
    .INIT(64'h8888888000000000)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_27 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[3]),
        .I2(tmp_reg_2705[2]),
        .I3(tmp_reg_2705[0]),
        .I4(tmp_reg_2705[1]),
        .I5(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_27_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT5 #(
    .INIT(32'hAA800000)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_28 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[1]),
        .I2(tmp_reg_2705[2]),
        .I3(tmp_reg_2705[3]),
        .I4(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_28_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_29 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[3]),
        .I2(tmp_reg_2705[1]),
        .I3(tmp_reg_2705[2]),
        .I4(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_29_n_4 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF00FD00A8)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_3 
       (.I0(\input_r_Addr_A[4]_INST_0_i_12_n_4 ),
        .I1(\conv1_kernel_Addr_A[8]_INST_0_i_10_n_4 ),
        .I2(\conv1_kernel_Addr_A[8]_INST_0_i_11_n_4 ),
        .I3(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .I4(\conv1_kernel_Addr_A[8]_INST_0_i_12_n_4 ),
        .I5(\conv1_kernel_Addr_A[8]_INST_0_i_13_n_4 ),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_3_n_4 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_30 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[3]),
        .I2(tmp_reg_2705[1]),
        .I3(tmp_reg_2705[0]),
        .I4(tmp_reg_2705[2]),
        .I5(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_30_n_4 ));
  LUT6 #(
    .INIT(64'hA888888888888888)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_31 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[4]),
        .I2(tmp_reg_2705[3]),
        .I3(tmp_reg_2705[1]),
        .I4(tmp_reg_2705[0]),
        .I5(tmp_reg_2705[2]),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_31_n_4 ));
  LUT6 #(
    .INIT(64'h00002A8000000000)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_32 
       (.I0(ap_CS_fsm_pp0_stage19),
        .I1(tmp_reg_2705[4]),
        .I2(tmp_reg_2705[5]),
        .I3(tmp_reg_2705[6]),
        .I4(ap_CS_fsm_pp0_stage20),
        .I5(ap_enable_reg_pp0_iter0),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_32_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT5 #(
    .INIT(32'hA8888888)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_33 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[4]),
        .I2(tmp_reg_2705[3]),
        .I3(tmp_reg_2705[1]),
        .I4(tmp_reg_2705[2]),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_33_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair56" *) 
  LUT4 #(
    .INIT(16'hA888)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_34 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[4]),
        .I2(tmp_reg_2705[3]),
        .I3(tmp_reg_2705[2]),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_34_n_4 ));
  LUT6 #(
    .INIT(64'h666A000000000000)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_35 
       (.I0(tmp_reg_2705[6]),
        .I1(tmp_reg_2705[5]),
        .I2(tmp_reg_2705[4]),
        .I3(\conv1_kernel_Addr_A[6]_INST_0_i_26_n_4 ),
        .I4(ap_CS_fsm_pp0_stage22),
        .I5(ap_enable_reg_pp0_iter0),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_35_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_4 
       (.I0(tmp_85_cast_fu_2384_p1[6]),
        .I1(\conv1_kernel_Addr_A[8]_INST_0_i_15_n_4 ),
        .I2(\conv1_kernel_Addr_A[8]_INST_0_i_16_n_4 ),
        .I3(ap_phi_mux_indvar_flatten2_phi_fu_580_p42),
        .I4(\conv1_kernel_Addr_A[11]_INST_0_i_13_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_24_n_4 ),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_4_n_4 ));
  LUT6 #(
    .INIT(64'h0072FF72FFD800D8)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_5 
       (.I0(reg_6311343_out),
        .I1(\conv1_kernel_Addr_A[8]_INST_0_i_17_n_4 ),
        .I2(\conv1_kernel_Addr_A[8]_INST_0_i_18_n_4 ),
        .I3(reg_6311444_out),
        .I4(\conv1_kernel_Addr_A[8]_INST_0_i_19_n_4 ),
        .I5(tmp_reg_2705[6]),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_5_n_4 ));
  LUT6 #(
    .INIT(64'h666AAAAA00000000)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_6 
       (.I0(tmp_reg_2705[6]),
        .I1(tmp_reg_2705[5]),
        .I2(tmp_reg_2705[2]),
        .I3(tmp_reg_2705[3]),
        .I4(tmp_reg_2705[4]),
        .I5(reg_6311747_out),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_6_n_4 ));
  LUT6 #(
    .INIT(64'h000F0F0002080208)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_7 
       (.I0(reg_6311545_out),
        .I1(\conv1_kernel_Addr_A[8]_INST_0_i_20_n_4 ),
        .I2(reg_6311747_out),
        .I3(tmp_reg_2705[6]),
        .I4(\conv1_kernel_Addr_A[8]_INST_0_i_21_n_4 ),
        .I5(reg_6311646_out),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_7_n_4 ));
  LUT6 #(
    .INIT(64'hAAAAAAA800000000)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_8 
       (.I0(tmp_reg_2705[5]),
        .I1(tmp_reg_2705[2]),
        .I2(tmp_reg_2705[0]),
        .I3(tmp_reg_2705[1]),
        .I4(tmp_reg_2705[3]),
        .I5(tmp_reg_2705[4]),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_8_n_4 ));
  LUT6 #(
    .INIT(64'h000F0F0002080208)) 
    \conv1_kernel_Addr_A[8]_INST_0_i_9 
       (.I0(reg_6311848_out),
        .I1(\conv1_kernel_Addr_A[8]_INST_0_i_22_n_4 ),
        .I2(reg_6312050_out),
        .I3(tmp_reg_2705[6]),
        .I4(\conv1_kernel_Addr_A[8]_INST_0_i_23_n_4 ),
        .I5(reg_6311949_out),
        .O(\conv1_kernel_Addr_A[8]_INST_0_i_9_n_4 ));
  LUT5 #(
    .INIT(32'hFFBA00BA)) 
    \conv1_kernel_Addr_A[9]_INST_0 
       (.I0(\conv1_kernel_Addr_A[9]_INST_0_i_1_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .I2(\conv1_kernel_Addr_A[9]_INST_0_i_2_n_4 ),
        .I3(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I4(\conv1_kernel_Addr_A[9]_INST_0_i_3_n_4 ),
        .O(conv1_kernel_Addr_A[7]));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_1 
       (.I0(\conv1_kernel_Addr_A[9]_INST_0_i_4_n_4 ),
        .I1(\conv1_kernel_Addr_A[9]_INST_0_i_5_n_4 ),
        .I2(\conv1_kernel_Addr_A[9]_INST_0_i_6_n_4 ),
        .I3(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .I4(\conv1_kernel_Addr_A[10]_INST_0_i_8_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_7_n_4 ),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_1_n_4 ));
  LUT6 #(
    .INIT(64'h665A665A66AA6600)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_10 
       (.I0(tmp_reg_2705[7]),
        .I1(\conv1_kernel_Addr_A[9]_INST_0_i_26_n_4 ),
        .I2(\conv1_kernel_Addr_A[9]_INST_0_i_27_n_4 ),
        .I3(conv1_bias_EN_A),
        .I4(reg_631940_out),
        .I5(reg_6311041_out),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_10_n_4 ));
  LUT6 #(
    .INIT(64'h0072FF72FFD800D8)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_11 
       (.I0(reg_63125),
        .I1(\conv1_kernel_Addr_A[9]_INST_0_i_28_n_4 ),
        .I2(\conv1_kernel_Addr_A[9]_INST_0_i_29_n_4 ),
        .I3(reg_6312555_out),
        .I4(\conv1_kernel_Addr_A[9]_INST_0_i_30_n_4 ),
        .I5(tmp_reg_2705[7]),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_11_n_4 ));
  LUT6 #(
    .INIT(64'h6F6F6F6000000000)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_12 
       (.I0(tmp_reg_2705[7]),
        .I1(\conv1_kernel_Addr_A[9]_INST_0_i_31_n_4 ),
        .I2(reg_6312353_out),
        .I3(\conv1_kernel_Addr_A[9]_INST_0_i_32_n_4 ),
        .I4(\conv1_kernel_Addr_A[9]_INST_0_i_33_n_4 ),
        .I5(\conv1_kernel_Addr_A[11]_INST_0_i_13_n_4 ),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_12_n_4 ));
  LUT6 #(
    .INIT(64'h8888888000000000)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_13 
       (.I0(tmp_reg_2705[6]),
        .I1(tmp_reg_2705[4]),
        .I2(tmp_reg_2705[3]),
        .I3(tmp_reg_2705[1]),
        .I4(tmp_reg_2705[2]),
        .I5(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_13_n_4 ));
  LUT6 #(
    .INIT(64'h00002A8000000000)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_14 
       (.I0(ap_CS_fsm_pp0_stage16),
        .I1(\conv1_kernel_Addr_A[8]_INST_0_i_22_n_4 ),
        .I2(tmp_reg_2705[6]),
        .I3(tmp_reg_2705[7]),
        .I4(ap_CS_fsm_pp0_stage17),
        .I5(ap_enable_reg_pp0_iter0),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_14_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT5 #(
    .INIT(32'h88800000)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_15 
       (.I0(tmp_reg_2705[6]),
        .I1(tmp_reg_2705[4]),
        .I2(tmp_reg_2705[3]),
        .I3(\conv1_kernel_Addr_A[10]_INST_0_i_34_n_4 ),
        .I4(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_15_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_16 
       (.I0(tmp_reg_2705[6]),
        .I1(tmp_reg_2705[4]),
        .I2(tmp_reg_2705[2]),
        .I3(tmp_reg_2705[3]),
        .I4(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_16_n_4 ));
  LUT6 #(
    .INIT(64'h6AAAAAAA00000000)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_17 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[6]),
        .I2(tmp_reg_2705[4]),
        .I3(\conv1_kernel_Addr_A[6]_INST_0_i_26_n_4 ),
        .I4(tmp_reg_2705[5]),
        .I5(reg_6311242_out),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_17_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair57" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_18 
       (.I0(tmp_reg_2705[6]),
        .I1(tmp_reg_2705[4]),
        .I2(\conv1_kernel_Addr_A[10]_INST_0_i_35_n_4 ),
        .I3(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_18_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_19 
       (.I0(tmp_reg_2705[6]),
        .I1(tmp_reg_2705[4]),
        .I2(tmp_reg_2705[3]),
        .I3(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_19_n_4 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF00FD00A8)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_2 
       (.I0(\input_r_Addr_A[4]_INST_0_i_12_n_4 ),
        .I1(\conv1_kernel_Addr_A[9]_INST_0_i_7_n_4 ),
        .I2(\conv1_kernel_Addr_A[9]_INST_0_i_8_n_4 ),
        .I3(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .I4(\conv1_kernel_Addr_A[9]_INST_0_i_9_n_4 ),
        .I5(\conv1_kernel_Addr_A[9]_INST_0_i_10_n_4 ),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_2_n_4 ));
  LUT6 #(
    .INIT(64'h6AAAAAAA00000000)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_20 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[6]),
        .I2(tmp_reg_2705[4]),
        .I3(\conv1_kernel_Addr_A[10]_INST_0_i_29_n_4 ),
        .I4(tmp_reg_2705[5]),
        .I5(reg_6311545_out),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_20_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT5 #(
    .INIT(32'h88800000)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_21 
       (.I0(tmp_reg_2705[6]),
        .I1(tmp_reg_2705[4]),
        .I2(tmp_reg_2705[3]),
        .I3(tmp_reg_2705[2]),
        .I4(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_21_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair33" *) 
  LUT5 #(
    .INIT(32'h88800000)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_22 
       (.I0(tmp_reg_2705[6]),
        .I1(tmp_reg_2705[4]),
        .I2(tmp_reg_2705[3]),
        .I3(\conv1_kernel_Addr_A[10]_INST_0_i_37_n_4 ),
        .I4(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_22_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair51" *) 
  LUT4 #(
    .INIT(16'hA800)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_23 
       (.I0(tmp_reg_2705[6]),
        .I1(\conv1_kernel_Addr_A[6]_INST_0_i_23_n_4 ),
        .I2(tmp_reg_2705[4]),
        .I3(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_23_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair35" *) 
  LUT5 #(
    .INIT(32'h88800000)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_24 
       (.I0(tmp_reg_2705[6]),
        .I1(tmp_reg_2705[4]),
        .I2(tmp_reg_2705[3]),
        .I3(\conv1_kernel_Addr_A[11]_INST_0_i_43_n_4 ),
        .I4(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_24_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair51" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_25 
       (.I0(tmp_reg_2705[6]),
        .I1(tmp_reg_2705[4]),
        .I2(\conv1_kernel_Addr_A[6]_INST_0_i_23_n_4 ),
        .I3(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_25_n_4 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_26 
       (.I0(tmp_reg_2705[6]),
        .I1(tmp_reg_2705[4]),
        .I2(tmp_reg_2705[2]),
        .I3(tmp_reg_2705[1]),
        .I4(tmp_reg_2705[3]),
        .I5(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_26_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair57" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_27 
       (.I0(tmp_reg_2705[6]),
        .I1(tmp_reg_2705[4]),
        .I2(\conv1_kernel_Addr_A[10]_INST_0_i_28_n_4 ),
        .I3(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_27_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT5 #(
    .INIT(32'hAA800000)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_28 
       (.I0(tmp_reg_2705[6]),
        .I1(tmp_reg_2705[2]),
        .I2(tmp_reg_2705[3]),
        .I3(tmp_reg_2705[4]),
        .I4(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_28_n_4 ));
  LUT6 #(
    .INIT(64'h666AAAAA00000000)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_29 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[6]),
        .I2(\conv1_kernel_Addr_A[6]_INST_0_i_26_n_4 ),
        .I3(tmp_reg_2705[4]),
        .I4(tmp_reg_2705[5]),
        .I5(reg_6312454_out),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_29_n_4 ));
  LUT6 #(
    .INIT(64'h00D8FFD8FFD800D8)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_3 
       (.I0(\input_r_Addr_A[12]_INST_0_i_24_n_4 ),
        .I1(\conv1_kernel_Addr_A[9]_INST_0_i_11_n_4 ),
        .I2(\conv1_kernel_Addr_A[9]_INST_0_i_12_n_4 ),
        .I3(ap_phi_mux_indvar_flatten2_phi_fu_580_p42),
        .I4(tmp_reg_2705[7]),
        .I5(\conv1_kernel_Addr_A[11]_INST_0_i_17_n_4 ),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_3_n_4 ));
  LUT4 #(
    .INIT(16'hA800)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_30 
       (.I0(tmp_reg_2705[6]),
        .I1(\conv1_kernel_Addr_A[10]_INST_0_i_35_n_4 ),
        .I2(tmp_reg_2705[4]),
        .I3(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_30_n_4 ));
  LUT6 #(
    .INIT(64'hAAAA800000000000)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_31 
       (.I0(tmp_reg_2705[6]),
        .I1(tmp_reg_2705[2]),
        .I2(tmp_reg_2705[1]),
        .I3(tmp_reg_2705[3]),
        .I4(tmp_reg_2705[4]),
        .I5(tmp_reg_2705[5]),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_31_n_4 ));
  LUT6 #(
    .INIT(64'h000000002AAA8000)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_32 
       (.I0(reg_6312151_out),
        .I1(tmp_reg_2705[5]),
        .I2(tmp_reg_2705[4]),
        .I3(tmp_reg_2705[6]),
        .I4(tmp_reg_2705[7]),
        .I5(reg_6312252_out),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_32_n_4 ));
  LUT6 #(
    .INIT(64'h666AAAAA00000000)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_33 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[6]),
        .I2(\conv1_kernel_Addr_A[10]_INST_0_i_28_n_4 ),
        .I3(tmp_reg_2705[4]),
        .I4(tmp_reg_2705[5]),
        .I5(reg_6312252_out),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_33_n_4 ));
  LUT6 #(
    .INIT(64'h00F2FFF2FFF800F8)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_4 
       (.I0(reg_6311949_out),
        .I1(\conv1_kernel_Addr_A[9]_INST_0_i_13_n_4 ),
        .I2(\conv1_kernel_Addr_A[9]_INST_0_i_14_n_4 ),
        .I3(reg_6312050_out),
        .I4(\conv1_kernel_Addr_A[9]_INST_0_i_15_n_4 ),
        .I5(tmp_reg_2705[7]),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_4_n_4 ));
  LUT6 #(
    .INIT(64'h0072FF72FFD800D8)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_5 
       (.I0(reg_6311343_out),
        .I1(\conv1_kernel_Addr_A[9]_INST_0_i_16_n_4 ),
        .I2(\conv1_kernel_Addr_A[9]_INST_0_i_17_n_4 ),
        .I3(reg_6311444_out),
        .I4(\conv1_kernel_Addr_A[9]_INST_0_i_18_n_4 ),
        .I5(tmp_reg_2705[7]),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_5_n_4 ));
  LUT6 #(
    .INIT(64'h0072FF72FFD800D8)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_6 
       (.I0(reg_6311646_out),
        .I1(\conv1_kernel_Addr_A[9]_INST_0_i_19_n_4 ),
        .I2(\conv1_kernel_Addr_A[9]_INST_0_i_20_n_4 ),
        .I3(reg_6311747_out),
        .I4(\conv1_kernel_Addr_A[9]_INST_0_i_21_n_4 ),
        .I5(tmp_reg_2705[7]),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_6_n_4 ));
  LUT6 #(
    .INIT(64'h000F0F0002080208)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_7 
       (.I0(reg_631637_out),
        .I1(\conv1_kernel_Addr_A[9]_INST_0_i_22_n_4 ),
        .I2(reg_631839_out),
        .I3(tmp_reg_2705[7]),
        .I4(\conv1_kernel_Addr_A[9]_INST_0_i_23_n_4 ),
        .I5(reg_631738_out),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_7_n_4 ));
  LUT6 #(
    .INIT(64'h666AAAAA00000000)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_8 
       (.I0(tmp_reg_2705[7]),
        .I1(tmp_reg_2705[6]),
        .I2(tmp_reg_2705[3]),
        .I3(tmp_reg_2705[4]),
        .I4(tmp_reg_2705[5]),
        .I5(reg_631839_out),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_8_n_4 ));
  LUT6 #(
    .INIT(64'h0027FF27FFD800D8)) 
    \conv1_kernel_Addr_A[9]_INST_0_i_9 
       (.I0(reg_631435_out),
        .I1(\conv1_kernel_Addr_A[9]_INST_0_i_24_n_4 ),
        .I2(\conv1_kernel_Addr_A[9]_INST_0_i_25_n_4 ),
        .I3(reg_631536_out),
        .I4(\conv1_kernel_Addr_A[11]_INST_0_i_31_n_4 ),
        .I5(tmp_reg_2705[7]),
        .O(\conv1_kernel_Addr_A[9]_INST_0_i_9_n_4 ));
  LUT5 #(
    .INIT(32'hFFFFFFEA)) 
    conv1_kernel_EN_A_INST_0
       (.I0(conv1_kernel_EN_A_INST_0_i_1_n_4),
        .I1(ap_enable_reg_pp0_iter0),
        .I2(ap_CS_fsm_pp0_stage1),
        .I3(conv1_kernel_EN_A_INST_0_i_2_n_4),
        .I4(conv1_kernel_EN_A_INST_0_i_3_n_4),
        .O(conv1_kernel_EN_A));
  LUT6 #(
    .INIT(64'hFFAAFFAAFFAAFEAA)) 
    conv1_kernel_EN_A_INST_0_i_1
       (.I0(conv1_kernel_EN_A_INST_0_i_4_n_4),
        .I1(ap_CS_fsm_pp0_stage7),
        .I2(ap_CS_fsm_pp0_stage8),
        .I3(ap_enable_reg_pp0_iter0),
        .I4(ap_CS_fsm_pp0_stage5),
        .I5(ap_CS_fsm_pp0_stage6),
        .O(conv1_kernel_EN_A_INST_0_i_1_n_4));
  LUT6 #(
    .INIT(64'hFFFFFFFFF0F0F0E0)) 
    conv1_kernel_EN_A_INST_0_i_2
       (.I0(ap_CS_fsm_pp0_stage19),
        .I1(ap_CS_fsm_pp0_stage20),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage17),
        .I4(ap_CS_fsm_pp0_stage18),
        .I5(conv1_kernel_EN_A_INST_0_i_5_n_4),
        .O(conv1_kernel_EN_A_INST_0_i_2_n_4));
  LUT6 #(
    .INIT(64'hFFFFFFFFF0F0F0E0)) 
    conv1_kernel_EN_A_INST_0_i_3
       (.I0(ap_CS_fsm_pp0_stage11),
        .I1(ap_CS_fsm_pp0_stage12),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage9),
        .I4(ap_CS_fsm_pp0_stage10),
        .I5(conv1_kernel_EN_A_INST_0_i_6_n_4),
        .O(conv1_kernel_EN_A_INST_0_i_3_n_4));
  LUT6 #(
    .INIT(64'hFFC0FFC0FFC0EAC0)) 
    conv1_kernel_EN_A_INST_0_i_4
       (.I0(ap_CS_fsm_pp0_stage2),
        .I1(ap_CS_fsm_pp0_stage0),
        .I2(ap_enable_reg_pp0_iter1_reg_n_4),
        .I3(ap_enable_reg_pp0_iter0),
        .I4(ap_CS_fsm_pp0_stage4),
        .I5(ap_CS_fsm_pp0_stage3),
        .O(conv1_kernel_EN_A_INST_0_i_4_n_4));
  (* SOFT_HLUTNM = "soft_lutpair36" *) 
  LUT5 #(
    .INIT(32'hF0F0F0E0)) 
    conv1_kernel_EN_A_INST_0_i_5
       (.I0(ap_CS_fsm_pp0_stage22),
        .I1(ap_CS_fsm_pp0_stage21),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage24),
        .I4(ap_CS_fsm_pp0_stage23),
        .O(conv1_kernel_EN_A_INST_0_i_5_n_4));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT5 #(
    .INIT(32'hF0F0F0E0)) 
    conv1_kernel_EN_A_INST_0_i_6
       (.I0(ap_CS_fsm_pp0_stage14),
        .I1(ap_CS_fsm_pp0_stage13),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage16),
        .I4(ap_CS_fsm_pp0_stage15),
        .O(conv1_kernel_EN_A_INST_0_i_6_n_4));
  LUT3 #(
    .INIT(8'hB8)) 
    \exitcond_flatten2_reg_2688[0]_i_1 
       (.I0(exitcond_flatten2_fu_663_p2),
        .I1(ap_CS_fsm_pp0_stage0),
        .I2(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .O(\exitcond_flatten2_reg_2688[0]_i_1_n_4 ));
  FDRE \exitcond_flatten2_reg_2688_reg[0] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\exitcond_flatten2_reg_2688[0]_i_1_n_4 ),
        .Q(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .R(1'b0));
  FDRE \filter_index_reg_587_reg[0] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(bias_Addr_A[0]),
        .Q(\filter_index_reg_587_reg_n_4_[0] ),
        .R(filter_index_reg_587));
  FDRE \filter_index_reg_587_reg[1] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(bias_Addr_A[1]),
        .Q(\filter_index_reg_587_reg_n_4_[1] ),
        .R(filter_index_reg_587));
  FDRE \filter_index_reg_587_reg[2] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(bias_Addr_A[2]),
        .Q(\filter_index_reg_587_reg_n_4_[2] ),
        .R(filter_index_reg_587));
  FDRE \filter_index_reg_587_reg[3] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(bias_Addr_A[3]),
        .Q(\filter_index_reg_587_reg_n_4_[3] ),
        .R(filter_index_reg_587));
  FDRE \filter_index_reg_587_reg[4] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(bias_Addr_A[4]),
        .Q(\filter_index_reg_587_reg_n_4_[4] ),
        .R(filter_index_reg_587));
  (* SOFT_HLUTNM = "soft_lutpair39" *) 
  LUT4 #(
    .INIT(16'h8F88)) 
    grp_Conv1_28x28x1_5x5x20_fu_74_ap_start_reg_i_1
       (.I0(ap_start),
        .I1(\ap_CS_fsm_reg[0]_0 ),
        .I2(grp_Conv1_28x28x1_5x5x20_fu_74_ap_ready),
        .I3(grp_Conv1_28x28x1_5x5x20_fu_74_ap_start_reg),
        .O(grp_Conv1_28x28x1_5x5x20_fu_74_ap_start_reg_reg));
  LUT5 #(
    .INIT(32'h80888888)) 
    \indvar_flatten2_reg_576[13]_i_1 
       (.I0(grp_Conv1_28x28x1_5x5x20_fu_74_ap_start_reg),
        .I1(\ap_CS_fsm_reg_n_4_[0] ),
        .I2(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I3(ap_CS_fsm_pp0_stage0),
        .I4(ap_enable_reg_pp0_iter1_reg_n_4),
        .O(filter_index_reg_587));
  LUT3 #(
    .INIT(8'h08)) 
    \indvar_flatten2_reg_576[13]_i_2 
       (.I0(ap_enable_reg_pp0_iter1_reg_n_4),
        .I1(ap_CS_fsm_pp0_stage0),
        .I2(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .O(\indvar_flatten2_reg_576[13]_i_2_n_4 ));
  FDRE \indvar_flatten2_reg_576_reg[0] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next2_reg_2692_reg[0]),
        .Q(indvar_flatten2_reg_576[0]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten2_reg_576_reg[10] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next2_reg_2692_reg[10]),
        .Q(indvar_flatten2_reg_576[10]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten2_reg_576_reg[11] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next2_reg_2692_reg[11]),
        .Q(indvar_flatten2_reg_576[11]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten2_reg_576_reg[12] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next2_reg_2692_reg[12]),
        .Q(indvar_flatten2_reg_576[12]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten2_reg_576_reg[13] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next2_reg_2692_reg[13]),
        .Q(indvar_flatten2_reg_576[13]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten2_reg_576_reg[1] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next2_reg_2692_reg[1]),
        .Q(indvar_flatten2_reg_576[1]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten2_reg_576_reg[2] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next2_reg_2692_reg[2]),
        .Q(indvar_flatten2_reg_576[2]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten2_reg_576_reg[3] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next2_reg_2692_reg[3]),
        .Q(indvar_flatten2_reg_576[3]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten2_reg_576_reg[4] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next2_reg_2692_reg[4]),
        .Q(indvar_flatten2_reg_576[4]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten2_reg_576_reg[5] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next2_reg_2692_reg[5]),
        .Q(indvar_flatten2_reg_576[5]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten2_reg_576_reg[6] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next2_reg_2692_reg[6]),
        .Q(indvar_flatten2_reg_576[6]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten2_reg_576_reg[7] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next2_reg_2692_reg[7]),
        .Q(indvar_flatten2_reg_576[7]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten2_reg_576_reg[8] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next2_reg_2692_reg[8]),
        .Q(indvar_flatten2_reg_576[8]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten2_reg_576_reg[9] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next2_reg_2692_reg[9]),
        .Q(indvar_flatten2_reg_576[9]),
        .R(filter_index_reg_587));
  LUT2 #(
    .INIT(4'h8)) 
    \indvar_flatten_next2_reg_2692[0]_i_1 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage0),
        .O(indvar_flatten_next2_reg_26920));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \indvar_flatten_next2_reg_2692[0]_i_3 
       (.I0(indvar_flatten_next2_reg_2692_reg[3]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I4(indvar_flatten2_reg_576[3]),
        .O(\indvar_flatten_next2_reg_2692[0]_i_3_n_4 ));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \indvar_flatten_next2_reg_2692[0]_i_4 
       (.I0(indvar_flatten_next2_reg_2692_reg[2]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I4(indvar_flatten2_reg_576[2]),
        .O(\indvar_flatten_next2_reg_2692[0]_i_4_n_4 ));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \indvar_flatten_next2_reg_2692[0]_i_5 
       (.I0(indvar_flatten_next2_reg_2692_reg[1]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I4(indvar_flatten2_reg_576[1]),
        .O(\indvar_flatten_next2_reg_2692[0]_i_5_n_4 ));
  LUT5 #(
    .INIT(32'h45557555)) 
    \indvar_flatten_next2_reg_2692[0]_i_6 
       (.I0(indvar_flatten2_reg_576[0]),
        .I1(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(ap_enable_reg_pp0_iter1_reg_n_4),
        .I4(indvar_flatten_next2_reg_2692_reg[0]),
        .O(\indvar_flatten_next2_reg_2692[0]_i_6_n_4 ));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \indvar_flatten_next2_reg_2692[12]_i_2 
       (.I0(indvar_flatten_next2_reg_2692_reg[13]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I4(indvar_flatten2_reg_576[13]),
        .O(\indvar_flatten_next2_reg_2692[12]_i_2_n_4 ));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \indvar_flatten_next2_reg_2692[12]_i_3 
       (.I0(indvar_flatten_next2_reg_2692_reg[12]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I4(indvar_flatten2_reg_576[12]),
        .O(\indvar_flatten_next2_reg_2692[12]_i_3_n_4 ));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \indvar_flatten_next2_reg_2692[4]_i_2 
       (.I0(indvar_flatten_next2_reg_2692_reg[7]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I4(indvar_flatten2_reg_576[7]),
        .O(\indvar_flatten_next2_reg_2692[4]_i_2_n_4 ));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \indvar_flatten_next2_reg_2692[4]_i_3 
       (.I0(indvar_flatten_next2_reg_2692_reg[6]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I4(indvar_flatten2_reg_576[6]),
        .O(\indvar_flatten_next2_reg_2692[4]_i_3_n_4 ));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \indvar_flatten_next2_reg_2692[4]_i_4 
       (.I0(indvar_flatten_next2_reg_2692_reg[5]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I4(indvar_flatten2_reg_576[5]),
        .O(\indvar_flatten_next2_reg_2692[4]_i_4_n_4 ));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \indvar_flatten_next2_reg_2692[4]_i_5 
       (.I0(indvar_flatten_next2_reg_2692_reg[4]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I4(indvar_flatten2_reg_576[4]),
        .O(\indvar_flatten_next2_reg_2692[4]_i_5_n_4 ));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \indvar_flatten_next2_reg_2692[8]_i_2 
       (.I0(indvar_flatten_next2_reg_2692_reg[11]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I4(indvar_flatten2_reg_576[11]),
        .O(\indvar_flatten_next2_reg_2692[8]_i_2_n_4 ));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \indvar_flatten_next2_reg_2692[8]_i_3 
       (.I0(indvar_flatten_next2_reg_2692_reg[10]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I4(indvar_flatten2_reg_576[10]),
        .O(\indvar_flatten_next2_reg_2692[8]_i_3_n_4 ));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \indvar_flatten_next2_reg_2692[8]_i_4 
       (.I0(indvar_flatten_next2_reg_2692_reg[9]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I4(indvar_flatten2_reg_576[9]),
        .O(\indvar_flatten_next2_reg_2692[8]_i_4_n_4 ));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \indvar_flatten_next2_reg_2692[8]_i_5 
       (.I0(indvar_flatten_next2_reg_2692_reg[8]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I4(indvar_flatten2_reg_576[8]),
        .O(\indvar_flatten_next2_reg_2692[8]_i_5_n_4 ));
  FDRE \indvar_flatten_next2_reg_2692_reg[0] 
       (.C(ap_clk),
        .CE(indvar_flatten_next2_reg_26920),
        .D(\indvar_flatten_next2_reg_2692_reg[0]_i_2_n_11 ),
        .Q(indvar_flatten_next2_reg_2692_reg[0]),
        .R(1'b0));
  CARRY4 \indvar_flatten_next2_reg_2692_reg[0]_i_2 
       (.CI(1'b0),
        .CO({\indvar_flatten_next2_reg_2692_reg[0]_i_2_n_4 ,\indvar_flatten_next2_reg_2692_reg[0]_i_2_n_5 ,\indvar_flatten_next2_reg_2692_reg[0]_i_2_n_6 ,\indvar_flatten_next2_reg_2692_reg[0]_i_2_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\indvar_flatten_next2_reg_2692_reg[0]_i_2_n_8 ,\indvar_flatten_next2_reg_2692_reg[0]_i_2_n_9 ,\indvar_flatten_next2_reg_2692_reg[0]_i_2_n_10 ,\indvar_flatten_next2_reg_2692_reg[0]_i_2_n_11 }),
        .S({\indvar_flatten_next2_reg_2692[0]_i_3_n_4 ,\indvar_flatten_next2_reg_2692[0]_i_4_n_4 ,\indvar_flatten_next2_reg_2692[0]_i_5_n_4 ,\indvar_flatten_next2_reg_2692[0]_i_6_n_4 }));
  FDRE \indvar_flatten_next2_reg_2692_reg[10] 
       (.C(ap_clk),
        .CE(indvar_flatten_next2_reg_26920),
        .D(\indvar_flatten_next2_reg_2692_reg[8]_i_1_n_9 ),
        .Q(indvar_flatten_next2_reg_2692_reg[10]),
        .R(1'b0));
  FDRE \indvar_flatten_next2_reg_2692_reg[11] 
       (.C(ap_clk),
        .CE(indvar_flatten_next2_reg_26920),
        .D(\indvar_flatten_next2_reg_2692_reg[8]_i_1_n_8 ),
        .Q(indvar_flatten_next2_reg_2692_reg[11]),
        .R(1'b0));
  FDRE \indvar_flatten_next2_reg_2692_reg[12] 
       (.C(ap_clk),
        .CE(indvar_flatten_next2_reg_26920),
        .D(\indvar_flatten_next2_reg_2692_reg[12]_i_1_n_11 ),
        .Q(indvar_flatten_next2_reg_2692_reg[12]),
        .R(1'b0));
  CARRY4 \indvar_flatten_next2_reg_2692_reg[12]_i_1 
       (.CI(\indvar_flatten_next2_reg_2692_reg[8]_i_1_n_4 ),
        .CO({\NLW_indvar_flatten_next2_reg_2692_reg[12]_i_1_CO_UNCONNECTED [3:1],\indvar_flatten_next2_reg_2692_reg[12]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_indvar_flatten_next2_reg_2692_reg[12]_i_1_O_UNCONNECTED [3:2],\indvar_flatten_next2_reg_2692_reg[12]_i_1_n_10 ,\indvar_flatten_next2_reg_2692_reg[12]_i_1_n_11 }),
        .S({1'b0,1'b0,\indvar_flatten_next2_reg_2692[12]_i_2_n_4 ,\indvar_flatten_next2_reg_2692[12]_i_3_n_4 }));
  FDRE \indvar_flatten_next2_reg_2692_reg[13] 
       (.C(ap_clk),
        .CE(indvar_flatten_next2_reg_26920),
        .D(\indvar_flatten_next2_reg_2692_reg[12]_i_1_n_10 ),
        .Q(indvar_flatten_next2_reg_2692_reg[13]),
        .R(1'b0));
  FDRE \indvar_flatten_next2_reg_2692_reg[1] 
       (.C(ap_clk),
        .CE(indvar_flatten_next2_reg_26920),
        .D(\indvar_flatten_next2_reg_2692_reg[0]_i_2_n_10 ),
        .Q(indvar_flatten_next2_reg_2692_reg[1]),
        .R(1'b0));
  FDRE \indvar_flatten_next2_reg_2692_reg[2] 
       (.C(ap_clk),
        .CE(indvar_flatten_next2_reg_26920),
        .D(\indvar_flatten_next2_reg_2692_reg[0]_i_2_n_9 ),
        .Q(indvar_flatten_next2_reg_2692_reg[2]),
        .R(1'b0));
  FDRE \indvar_flatten_next2_reg_2692_reg[3] 
       (.C(ap_clk),
        .CE(indvar_flatten_next2_reg_26920),
        .D(\indvar_flatten_next2_reg_2692_reg[0]_i_2_n_8 ),
        .Q(indvar_flatten_next2_reg_2692_reg[3]),
        .R(1'b0));
  FDRE \indvar_flatten_next2_reg_2692_reg[4] 
       (.C(ap_clk),
        .CE(indvar_flatten_next2_reg_26920),
        .D(\indvar_flatten_next2_reg_2692_reg[4]_i_1_n_11 ),
        .Q(indvar_flatten_next2_reg_2692_reg[4]),
        .R(1'b0));
  CARRY4 \indvar_flatten_next2_reg_2692_reg[4]_i_1 
       (.CI(\indvar_flatten_next2_reg_2692_reg[0]_i_2_n_4 ),
        .CO({\indvar_flatten_next2_reg_2692_reg[4]_i_1_n_4 ,\indvar_flatten_next2_reg_2692_reg[4]_i_1_n_5 ,\indvar_flatten_next2_reg_2692_reg[4]_i_1_n_6 ,\indvar_flatten_next2_reg_2692_reg[4]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\indvar_flatten_next2_reg_2692_reg[4]_i_1_n_8 ,\indvar_flatten_next2_reg_2692_reg[4]_i_1_n_9 ,\indvar_flatten_next2_reg_2692_reg[4]_i_1_n_10 ,\indvar_flatten_next2_reg_2692_reg[4]_i_1_n_11 }),
        .S({\indvar_flatten_next2_reg_2692[4]_i_2_n_4 ,\indvar_flatten_next2_reg_2692[4]_i_3_n_4 ,\indvar_flatten_next2_reg_2692[4]_i_4_n_4 ,\indvar_flatten_next2_reg_2692[4]_i_5_n_4 }));
  FDRE \indvar_flatten_next2_reg_2692_reg[5] 
       (.C(ap_clk),
        .CE(indvar_flatten_next2_reg_26920),
        .D(\indvar_flatten_next2_reg_2692_reg[4]_i_1_n_10 ),
        .Q(indvar_flatten_next2_reg_2692_reg[5]),
        .R(1'b0));
  FDRE \indvar_flatten_next2_reg_2692_reg[6] 
       (.C(ap_clk),
        .CE(indvar_flatten_next2_reg_26920),
        .D(\indvar_flatten_next2_reg_2692_reg[4]_i_1_n_9 ),
        .Q(indvar_flatten_next2_reg_2692_reg[6]),
        .R(1'b0));
  FDRE \indvar_flatten_next2_reg_2692_reg[7] 
       (.C(ap_clk),
        .CE(indvar_flatten_next2_reg_26920),
        .D(\indvar_flatten_next2_reg_2692_reg[4]_i_1_n_8 ),
        .Q(indvar_flatten_next2_reg_2692_reg[7]),
        .R(1'b0));
  FDRE \indvar_flatten_next2_reg_2692_reg[8] 
       (.C(ap_clk),
        .CE(indvar_flatten_next2_reg_26920),
        .D(\indvar_flatten_next2_reg_2692_reg[8]_i_1_n_11 ),
        .Q(indvar_flatten_next2_reg_2692_reg[8]),
        .R(1'b0));
  CARRY4 \indvar_flatten_next2_reg_2692_reg[8]_i_1 
       (.CI(\indvar_flatten_next2_reg_2692_reg[4]_i_1_n_4 ),
        .CO({\indvar_flatten_next2_reg_2692_reg[8]_i_1_n_4 ,\indvar_flatten_next2_reg_2692_reg[8]_i_1_n_5 ,\indvar_flatten_next2_reg_2692_reg[8]_i_1_n_6 ,\indvar_flatten_next2_reg_2692_reg[8]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\indvar_flatten_next2_reg_2692_reg[8]_i_1_n_8 ,\indvar_flatten_next2_reg_2692_reg[8]_i_1_n_9 ,\indvar_flatten_next2_reg_2692_reg[8]_i_1_n_10 ,\indvar_flatten_next2_reg_2692_reg[8]_i_1_n_11 }),
        .S({\indvar_flatten_next2_reg_2692[8]_i_2_n_4 ,\indvar_flatten_next2_reg_2692[8]_i_3_n_4 ,\indvar_flatten_next2_reg_2692[8]_i_4_n_4 ,\indvar_flatten_next2_reg_2692[8]_i_5_n_4 }));
  FDRE \indvar_flatten_next2_reg_2692_reg[9] 
       (.C(ap_clk),
        .CE(indvar_flatten_next2_reg_26920),
        .D(\indvar_flatten_next2_reg_2692_reg[8]_i_1_n_10 ),
        .Q(indvar_flatten_next2_reg_2692_reg[9]),
        .R(1'b0));
  LUT5 #(
    .INIT(32'hAAEFBAFF)) 
    \indvar_flatten_next_reg_2776[0]_i_1 
       (.I0(exitcond_flatten_fu_681_p2),
        .I1(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I2(ap_enable_reg_pp0_iter1_reg_n_4),
        .I3(indvar_flatten_reg_598[0]),
        .I4(indvar_flatten_next_reg_2776[0]),
        .O(\indvar_flatten_next_reg_2776[0]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT5 #(
    .INIT(32'h353AC5CA)) 
    \indvar_flatten_next_reg_2776[1]_i_1 
       (.I0(indvar_flatten_reg_598[0]),
        .I1(indvar_flatten_next_reg_2776[0]),
        .I2(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I3(indvar_flatten_reg_598[1]),
        .I4(indvar_flatten_next_reg_2776[1]),
        .O(indvar_flatten_op_fu_847_p2[1]));
  LUT6 #(
    .INIT(64'h775F77A0885F88A0)) 
    \indvar_flatten_next_reg_2776[2]_i_1 
       (.I0(\indvar_flatten_next_reg_2776[2]_i_2_n_4 ),
        .I1(indvar_flatten_next_reg_2776[1]),
        .I2(indvar_flatten_reg_598[1]),
        .I3(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I4(indvar_flatten_reg_598[2]),
        .I5(indvar_flatten_next_reg_2776[2]),
        .O(indvar_flatten_op_fu_847_p2[2]));
  LUT5 #(
    .INIT(32'hCCCCACCC)) 
    \indvar_flatten_next_reg_2776[2]_i_2 
       (.I0(indvar_flatten_next_reg_2776[0]),
        .I1(indvar_flatten_reg_598[0]),
        .I2(ap_enable_reg_pp0_iter1_reg_n_4),
        .I3(ap_CS_fsm_pp0_stage0),
        .I4(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .O(\indvar_flatten_next_reg_2776[2]_i_2_n_4 ));
  LUT6 #(
    .INIT(64'h775F77A0885F88A0)) 
    \indvar_flatten_next_reg_2776[3]_i_1 
       (.I0(\indvar_flatten_next_reg_2776[3]_i_2_n_4 ),
        .I1(indvar_flatten_next_reg_2776[2]),
        .I2(indvar_flatten_reg_598[2]),
        .I3(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I4(indvar_flatten_reg_598[3]),
        .I5(indvar_flatten_next_reg_2776[3]),
        .O(indvar_flatten_op_fu_847_p2[3]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT5 #(
    .INIT(32'hCAC00A00)) 
    \indvar_flatten_next_reg_2776[3]_i_2 
       (.I0(indvar_flatten_reg_598[1]),
        .I1(indvar_flatten_next_reg_2776[1]),
        .I2(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I3(indvar_flatten_reg_598[0]),
        .I4(indvar_flatten_next_reg_2776[0]),
        .O(\indvar_flatten_next_reg_2776[3]_i_2_n_4 ));
  LUT6 #(
    .INIT(64'h775F77A0885F88A0)) 
    \indvar_flatten_next_reg_2776[4]_i_1 
       (.I0(\indvar_flatten_next_reg_2776[4]_i_2_n_4 ),
        .I1(indvar_flatten_next_reg_2776[3]),
        .I2(indvar_flatten_reg_598[3]),
        .I3(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I4(indvar_flatten_reg_598[4]),
        .I5(indvar_flatten_next_reg_2776[4]),
        .O(indvar_flatten_op_fu_847_p2[4]));
  LUT6 #(
    .INIT(64'hC000C000A0A00000)) 
    \indvar_flatten_next_reg_2776[4]_i_2 
       (.I0(indvar_flatten_reg_598[2]),
        .I1(indvar_flatten_next_reg_2776[2]),
        .I2(\indvar_flatten_next_reg_2776[2]_i_2_n_4 ),
        .I3(indvar_flatten_next_reg_2776[1]),
        .I4(indvar_flatten_reg_598[1]),
        .I5(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .O(\indvar_flatten_next_reg_2776[4]_i_2_n_4 ));
  LUT6 #(
    .INIT(64'h775F77A0885F88A0)) 
    \indvar_flatten_next_reg_2776[5]_i_1 
       (.I0(\indvar_flatten_next_reg_2776[5]_i_2_n_4 ),
        .I1(indvar_flatten_next_reg_2776[4]),
        .I2(indvar_flatten_reg_598[4]),
        .I3(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I4(indvar_flatten_reg_598[5]),
        .I5(indvar_flatten_next_reg_2776[5]),
        .O(indvar_flatten_op_fu_847_p2[5]));
  LUT6 #(
    .INIT(64'hC000C000A0A00000)) 
    \indvar_flatten_next_reg_2776[5]_i_2 
       (.I0(indvar_flatten_reg_598[3]),
        .I1(indvar_flatten_next_reg_2776[3]),
        .I2(\indvar_flatten_next_reg_2776[3]_i_2_n_4 ),
        .I3(indvar_flatten_next_reg_2776[2]),
        .I4(indvar_flatten_reg_598[2]),
        .I5(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .O(\indvar_flatten_next_reg_2776[5]_i_2_n_4 ));
  LUT6 #(
    .INIT(64'h775F77A0885F88A0)) 
    \indvar_flatten_next_reg_2776[6]_i_1 
       (.I0(\indvar_flatten_next_reg_2776[6]_i_2_n_4 ),
        .I1(indvar_flatten_next_reg_2776[5]),
        .I2(indvar_flatten_reg_598[5]),
        .I3(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I4(indvar_flatten_reg_598[6]),
        .I5(indvar_flatten_next_reg_2776[6]),
        .O(indvar_flatten_op_fu_847_p2[6]));
  LUT6 #(
    .INIT(64'hC000C000A0A00000)) 
    \indvar_flatten_next_reg_2776[6]_i_2 
       (.I0(indvar_flatten_reg_598[4]),
        .I1(indvar_flatten_next_reg_2776[4]),
        .I2(\indvar_flatten_next_reg_2776[4]_i_2_n_4 ),
        .I3(indvar_flatten_next_reg_2776[3]),
        .I4(indvar_flatten_reg_598[3]),
        .I5(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .O(\indvar_flatten_next_reg_2776[6]_i_2_n_4 ));
  LUT6 #(
    .INIT(64'h775F77A0885F88A0)) 
    \indvar_flatten_next_reg_2776[7]_i_1 
       (.I0(\indvar_flatten_next_reg_2776[7]_i_2_n_4 ),
        .I1(indvar_flatten_next_reg_2776[6]),
        .I2(indvar_flatten_reg_598[6]),
        .I3(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I4(indvar_flatten_reg_598[7]),
        .I5(indvar_flatten_next_reg_2776[7]),
        .O(indvar_flatten_op_fu_847_p2[7]));
  LUT6 #(
    .INIT(64'hC000C000A0A00000)) 
    \indvar_flatten_next_reg_2776[7]_i_2 
       (.I0(indvar_flatten_reg_598[5]),
        .I1(indvar_flatten_next_reg_2776[5]),
        .I2(\indvar_flatten_next_reg_2776[5]_i_2_n_4 ),
        .I3(indvar_flatten_next_reg_2776[4]),
        .I4(indvar_flatten_reg_598[4]),
        .I5(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .O(\indvar_flatten_next_reg_2776[7]_i_2_n_4 ));
  LUT6 #(
    .INIT(64'h775F77A0885F88A0)) 
    \indvar_flatten_next_reg_2776[8]_i_1 
       (.I0(\indvar_flatten_next_reg_2776[9]_i_4_n_4 ),
        .I1(indvar_flatten_next_reg_2776[7]),
        .I2(indvar_flatten_reg_598[7]),
        .I3(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I4(indvar_flatten_reg_598[8]),
        .I5(indvar_flatten_next_reg_2776[8]),
        .O(indvar_flatten_op_fu_847_p2[8]));
  LUT2 #(
    .INIT(4'h8)) 
    \indvar_flatten_next_reg_2776[9]_i_1 
       (.I0(exitcond_flatten_fu_681_p2),
        .I1(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ),
        .O(\indvar_flatten_next_reg_2776[9]_i_1_n_4 ));
  LUT6 #(
    .INIT(64'h7F7F7F80807F8080)) 
    \indvar_flatten_next_reg_2776[9]_i_2 
       (.I0(\indvar_flatten_next_reg_2776[9]_i_3_n_4 ),
        .I1(\indvar_flatten_next_reg_2776[9]_i_4_n_4 ),
        .I2(\indvar_flatten_next_reg_2776[9]_i_5_n_4 ),
        .I3(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I4(indvar_flatten_reg_598[9]),
        .I5(indvar_flatten_next_reg_2776[9]),
        .O(indvar_flatten_op_fu_847_p2[9]));
  LUT5 #(
    .INIT(32'hCCCCACCC)) 
    \indvar_flatten_next_reg_2776[9]_i_3 
       (.I0(indvar_flatten_next_reg_2776[7]),
        .I1(indvar_flatten_reg_598[7]),
        .I2(ap_enable_reg_pp0_iter1_reg_n_4),
        .I3(ap_CS_fsm_pp0_stage0),
        .I4(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .O(\indvar_flatten_next_reg_2776[9]_i_3_n_4 ));
  LUT6 #(
    .INIT(64'hC000C000A0A00000)) 
    \indvar_flatten_next_reg_2776[9]_i_4 
       (.I0(indvar_flatten_reg_598[6]),
        .I1(indvar_flatten_next_reg_2776[6]),
        .I2(\indvar_flatten_next_reg_2776[6]_i_2_n_4 ),
        .I3(indvar_flatten_next_reg_2776[5]),
        .I4(indvar_flatten_reg_598[5]),
        .I5(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .O(\indvar_flatten_next_reg_2776[9]_i_4_n_4 ));
  LUT5 #(
    .INIT(32'hCCCCACCC)) 
    \indvar_flatten_next_reg_2776[9]_i_5 
       (.I0(indvar_flatten_next_reg_2776[8]),
        .I1(indvar_flatten_reg_598[8]),
        .I2(ap_enable_reg_pp0_iter1_reg_n_4),
        .I3(ap_CS_fsm_pp0_stage0),
        .I4(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .O(\indvar_flatten_next_reg_2776[9]_i_5_n_4 ));
  FDRE \indvar_flatten_next_reg_2776_reg[0] 
       (.C(ap_clk),
        .CE(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ),
        .D(\indvar_flatten_next_reg_2776[0]_i_1_n_4 ),
        .Q(indvar_flatten_next_reg_2776[0]),
        .R(1'b0));
  FDRE \indvar_flatten_next_reg_2776_reg[1] 
       (.C(ap_clk),
        .CE(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ),
        .D(indvar_flatten_op_fu_847_p2[1]),
        .Q(indvar_flatten_next_reg_2776[1]),
        .R(\indvar_flatten_next_reg_2776[9]_i_1_n_4 ));
  FDRE \indvar_flatten_next_reg_2776_reg[2] 
       (.C(ap_clk),
        .CE(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ),
        .D(indvar_flatten_op_fu_847_p2[2]),
        .Q(indvar_flatten_next_reg_2776[2]),
        .R(\indvar_flatten_next_reg_2776[9]_i_1_n_4 ));
  FDRE \indvar_flatten_next_reg_2776_reg[3] 
       (.C(ap_clk),
        .CE(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ),
        .D(indvar_flatten_op_fu_847_p2[3]),
        .Q(indvar_flatten_next_reg_2776[3]),
        .R(\indvar_flatten_next_reg_2776[9]_i_1_n_4 ));
  FDRE \indvar_flatten_next_reg_2776_reg[4] 
       (.C(ap_clk),
        .CE(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ),
        .D(indvar_flatten_op_fu_847_p2[4]),
        .Q(indvar_flatten_next_reg_2776[4]),
        .R(\indvar_flatten_next_reg_2776[9]_i_1_n_4 ));
  FDRE \indvar_flatten_next_reg_2776_reg[5] 
       (.C(ap_clk),
        .CE(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ),
        .D(indvar_flatten_op_fu_847_p2[5]),
        .Q(indvar_flatten_next_reg_2776[5]),
        .R(\indvar_flatten_next_reg_2776[9]_i_1_n_4 ));
  FDRE \indvar_flatten_next_reg_2776_reg[6] 
       (.C(ap_clk),
        .CE(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ),
        .D(indvar_flatten_op_fu_847_p2[6]),
        .Q(indvar_flatten_next_reg_2776[6]),
        .R(\indvar_flatten_next_reg_2776[9]_i_1_n_4 ));
  FDRE \indvar_flatten_next_reg_2776_reg[7] 
       (.C(ap_clk),
        .CE(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ),
        .D(indvar_flatten_op_fu_847_p2[7]),
        .Q(indvar_flatten_next_reg_2776[7]),
        .R(\indvar_flatten_next_reg_2776[9]_i_1_n_4 ));
  FDRE \indvar_flatten_next_reg_2776_reg[8] 
       (.C(ap_clk),
        .CE(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ),
        .D(indvar_flatten_op_fu_847_p2[8]),
        .Q(indvar_flatten_next_reg_2776[8]),
        .R(\indvar_flatten_next_reg_2776[9]_i_1_n_4 ));
  FDRE \indvar_flatten_next_reg_2776_reg[9] 
       (.C(ap_clk),
        .CE(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ),
        .D(indvar_flatten_op_fu_847_p2[9]),
        .Q(indvar_flatten_next_reg_2776[9]),
        .R(\indvar_flatten_next_reg_2776[9]_i_1_n_4 ));
  FDRE \indvar_flatten_reg_598_reg[0] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next_reg_2776[0]),
        .Q(indvar_flatten_reg_598[0]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten_reg_598_reg[1] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next_reg_2776[1]),
        .Q(indvar_flatten_reg_598[1]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten_reg_598_reg[2] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next_reg_2776[2]),
        .Q(indvar_flatten_reg_598[2]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten_reg_598_reg[3] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next_reg_2776[3]),
        .Q(indvar_flatten_reg_598[3]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten_reg_598_reg[4] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next_reg_2776[4]),
        .Q(indvar_flatten_reg_598[4]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten_reg_598_reg[5] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next_reg_2776[5]),
        .Q(indvar_flatten_reg_598[5]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten_reg_598_reg[6] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next_reg_2776[6]),
        .Q(indvar_flatten_reg_598[6]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten_reg_598_reg[7] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next_reg_2776[7]),
        .Q(indvar_flatten_reg_598[7]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten_reg_598_reg[8] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next_reg_2776[8]),
        .Q(indvar_flatten_reg_598[8]),
        .R(filter_index_reg_587));
  FDRE \indvar_flatten_reg_598_reg[9] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(indvar_flatten_next_reg_2776[9]),
        .Q(indvar_flatten_reg_598[9]),
        .R(filter_index_reg_587));
  LUT6 #(
    .INIT(64'hFFFFFDA80000FDA8)) 
    \input_r_Addr_A[10]_INST_0 
       (.I0(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .I1(\input_r_Addr_A[10]_INST_0_i_1_n_4 ),
        .I2(\input_r_Addr_A[10]_INST_0_i_2_n_4 ),
        .I3(\input_r_Addr_A[10]_INST_0_i_3_n_4 ),
        .I4(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I5(\input_r_Addr_A[10]_INST_0_i_4_n_4 ),
        .O(input_r_Addr_A[8]));
  LUT6 #(
    .INIT(64'h3333300022222222)) 
    \input_r_Addr_A[10]_INST_0_i_1 
       (.I0(\input_r_Addr_A[10]_INST_0_i_5_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .I2(data10[8]),
        .I3(reg_6311747_out),
        .I4(\input_r_Addr_A[10]_INST_0_i_6_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_7_n_4 ),
        .O(\input_r_Addr_A[10]_INST_0_i_1_n_4 ));
  LUT6 #(
    .INIT(64'h00F0000000800080)) 
    \input_r_Addr_A[10]_INST_0_i_10 
       (.I0(ap_CS_fsm_pp0_stage7),
        .I1(data18[8]),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage9),
        .I4(data17[8]),
        .I5(ap_CS_fsm_pp0_stage8),
        .O(\input_r_Addr_A[10]_INST_0_i_10_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[10]_INST_0_i_11 
       (.I0(tmp_109_reg_3426[8]),
        .I1(tmp_123_reg_3446[8]),
        .I2(tmp_103_reg_3416[8]),
        .I3(reg_6312555_out),
        .I4(reg_6312454_out),
        .I5(reg_63125),
        .O(\input_r_Addr_A[10]_INST_0_i_11_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[10]_INST_0_i_12 
       (.I0(tmp_118_reg_3441[8]),
        .I1(data6[8]),
        .I2(tmp_113_reg_3431[8]),
        .I3(reg_6312353_out),
        .I4(reg_6312151_out),
        .I5(reg_6312252_out),
        .O(\input_r_Addr_A[10]_INST_0_i_12_n_4 ));
  LUT5 #(
    .INIT(32'hBABA0444)) 
    \input_r_Addr_A[10]_INST_0_i_13 
       (.I0(tmp_37_3_cast_mid2_reg_2764[2]),
        .I1(tmp_37_3_cast_mid2_reg_2764[4]),
        .I2(tmp_37_3_cast_mid2_reg_2764[1]),
        .I3(tmp_37_3_cast_mid2_reg_2764[0]),
        .I4(tmp_37_3_cast_mid2_reg_2764[3]),
        .O(\input_r_Addr_A[10]_INST_0_i_13_n_4 ));
  LUT5 #(
    .INIT(32'h40F4BF0A)) 
    \input_r_Addr_A[10]_INST_0_i_14 
       (.I0(tmp_37_3_cast_mid2_reg_2764[3]),
        .I1(tmp_37_3_cast_mid2_reg_2764[0]),
        .I2(tmp_37_3_cast_mid2_reg_2764[1]),
        .I3(tmp_37_3_cast_mid2_reg_2764[4]),
        .I4(tmp_37_3_cast_mid2_reg_2764[2]),
        .O(\input_r_Addr_A[10]_INST_0_i_14_n_4 ));
  LUT5 #(
    .INIT(32'hF30C0DF2)) 
    \input_r_Addr_A[10]_INST_0_i_15 
       (.I0(tmp_37_3_cast_mid2_reg_2764[2]),
        .I1(tmp_37_3_cast_mid2_reg_2764[0]),
        .I2(tmp_37_3_cast_mid2_reg_2764[3]),
        .I3(tmp_37_3_cast_mid2_reg_2764[4]),
        .I4(tmp_37_3_cast_mid2_reg_2764[1]),
        .O(\input_r_Addr_A[10]_INST_0_i_15_n_4 ));
  LUT4 #(
    .INIT(16'hF01E)) 
    \input_r_Addr_A[10]_INST_0_i_16 
       (.I0(tmp_37_3_cast_mid2_reg_2764[2]),
        .I1(tmp_37_3_cast_mid2_reg_2764[1]),
        .I2(tmp_37_3_cast_mid2_reg_2764[3]),
        .I3(tmp_37_3_cast_mid2_reg_2764[0]),
        .O(\input_r_Addr_A[10]_INST_0_i_16_n_4 ));
  LUT5 #(
    .INIT(32'hBABA0444)) 
    \input_r_Addr_A[10]_INST_0_i_17 
       (.I0(tmp_37_3_cast_mid2_reg_2764[2]),
        .I1(tmp_37_3_cast_mid2_reg_2764[4]),
        .I2(tmp_37_3_cast_mid2_reg_2764[1]),
        .I3(tmp_37_3_cast_mid2_reg_2764[0]),
        .I4(tmp_37_3_cast_mid2_reg_2764[3]),
        .O(\input_r_Addr_A[10]_INST_0_i_17_n_4 ));
  LUT5 #(
    .INIT(32'h40F4BF0A)) 
    \input_r_Addr_A[10]_INST_0_i_18 
       (.I0(tmp_37_3_cast_mid2_reg_2764[3]),
        .I1(tmp_37_3_cast_mid2_reg_2764[0]),
        .I2(tmp_37_3_cast_mid2_reg_2764[1]),
        .I3(tmp_37_3_cast_mid2_reg_2764[4]),
        .I4(tmp_37_3_cast_mid2_reg_2764[2]),
        .O(\input_r_Addr_A[10]_INST_0_i_18_n_4 ));
  LUT5 #(
    .INIT(32'hF30C0DF2)) 
    \input_r_Addr_A[10]_INST_0_i_19 
       (.I0(tmp_37_3_cast_mid2_reg_2764[2]),
        .I1(tmp_37_3_cast_mid2_reg_2764[0]),
        .I2(tmp_37_3_cast_mid2_reg_2764[3]),
        .I3(tmp_37_3_cast_mid2_reg_2764[4]),
        .I4(tmp_37_3_cast_mid2_reg_2764[1]),
        .O(\input_r_Addr_A[10]_INST_0_i_19_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[10]_INST_0_i_2 
       (.I0(data7[8]),
        .I1(data9[8]),
        .I2(data8[8]),
        .I3(reg_6312050_out),
        .I4(reg_6311848_out),
        .I5(reg_6311949_out),
        .O(\input_r_Addr_A[10]_INST_0_i_2_n_4 ));
  LUT4 #(
    .INIT(16'hF01E)) 
    \input_r_Addr_A[10]_INST_0_i_20 
       (.I0(tmp_37_3_cast_mid2_reg_2764[2]),
        .I1(tmp_37_3_cast_mid2_reg_2764[1]),
        .I2(tmp_37_3_cast_mid2_reg_2764[3]),
        .I3(tmp_37_3_cast_mid2_reg_2764[0]),
        .O(\input_r_Addr_A[10]_INST_0_i_20_n_4 ));
  CARRY4 \input_r_Addr_A[10]_INST_0_i_21 
       (.CI(\input_r_Addr_A[6]_INST_0_i_16_n_4 ),
        .CO({\input_r_Addr_A[10]_INST_0_i_21_n_4 ,\input_r_Addr_A[10]_INST_0_i_21_n_5 ,\input_r_Addr_A[10]_INST_0_i_21_n_6 ,\input_r_Addr_A[10]_INST_0_i_21_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data20[8:5]),
        .S({\input_r_Addr_A[10]_INST_0_i_25_n_4 ,\input_r_Addr_A[10]_INST_0_i_26_n_4 ,\input_r_Addr_A[10]_INST_0_i_27_n_4 ,\input_r_Addr_A[10]_INST_0_i_28_n_4 }));
  CARRY4 \input_r_Addr_A[10]_INST_0_i_22 
       (.CI(\input_r_Addr_A[6]_INST_0_i_17_n_4 ),
        .CO({\input_r_Addr_A[10]_INST_0_i_22_n_4 ,\input_r_Addr_A[10]_INST_0_i_22_n_5 ,\input_r_Addr_A[10]_INST_0_i_22_n_6 ,\input_r_Addr_A[10]_INST_0_i_22_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data22[8:5]),
        .S({\input_r_Addr_A[10]_INST_0_i_29_n_4 ,\input_r_Addr_A[10]_INST_0_i_30_n_4 ,\input_r_Addr_A[10]_INST_0_i_31_n_4 ,\input_r_Addr_A[10]_INST_0_i_32_n_4 }));
  CARRY4 \input_r_Addr_A[10]_INST_0_i_23 
       (.CI(\input_r_Addr_A[6]_INST_0_i_18_n_4 ),
        .CO({\input_r_Addr_A[10]_INST_0_i_23_n_4 ,\input_r_Addr_A[10]_INST_0_i_23_n_5 ,\input_r_Addr_A[10]_INST_0_i_23_n_6 ,\input_r_Addr_A[10]_INST_0_i_23_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data24[8:5]),
        .S({\input_r_Addr_A[10]_INST_0_i_33_n_4 ,\input_r_Addr_A[10]_INST_0_i_34_n_4 ,\input_r_Addr_A[10]_INST_0_i_35_n_4 ,\input_r_Addr_A[10]_INST_0_i_36_n_4 }));
  CARRY4 \input_r_Addr_A[10]_INST_0_i_24 
       (.CI(\input_r_Addr_A[4]_INST_0_i_14_n_4 ),
        .CO({\input_r_Addr_A[10]_INST_0_i_24_n_4 ,\input_r_Addr_A[10]_INST_0_i_24_n_5 ,\input_r_Addr_A[10]_INST_0_i_24_n_6 ,\input_r_Addr_A[10]_INST_0_i_24_n_7 }),
        .CYINIT(1'b0),
        .DI({\input_r_Addr_A[10]_INST_0_i_37_n_4 ,\input_r_Addr_A[10]_INST_0_i_38_n_4 ,\input_r_Addr_A[10]_INST_0_i_39_n_4 ,\input_r_Addr_A[10]_INST_0_i_40_n_4 }),
        .O(data18[8:5]),
        .S({\input_r_Addr_A[10]_INST_0_i_41_n_4 ,\input_r_Addr_A[10]_INST_0_i_42_n_4 ,\input_r_Addr_A[10]_INST_0_i_43_n_4 ,\input_r_Addr_A[10]_INST_0_i_44_n_4 }));
  LUT5 #(
    .INIT(32'hBABA0444)) 
    \input_r_Addr_A[10]_INST_0_i_25 
       (.I0(tmp_37_4_cast_mid2_reg_2770[2]),
        .I1(tmp_37_4_cast_mid2_reg_2770[4]),
        .I2(tmp_37_4_cast_mid2_reg_2770[1]),
        .I3(tmp_37_4_cast_mid2_reg_2770[0]),
        .I4(tmp_37_4_cast_mid2_reg_2770[3]),
        .O(\input_r_Addr_A[10]_INST_0_i_25_n_4 ));
  LUT5 #(
    .INIT(32'h40F4BF0A)) 
    \input_r_Addr_A[10]_INST_0_i_26 
       (.I0(tmp_37_4_cast_mid2_reg_2770[3]),
        .I1(tmp_37_4_cast_mid2_reg_2770[0]),
        .I2(tmp_37_4_cast_mid2_reg_2770[1]),
        .I3(tmp_37_4_cast_mid2_reg_2770[4]),
        .I4(tmp_37_4_cast_mid2_reg_2770[2]),
        .O(\input_r_Addr_A[10]_INST_0_i_26_n_4 ));
  LUT5 #(
    .INIT(32'hF30C0DF2)) 
    \input_r_Addr_A[10]_INST_0_i_27 
       (.I0(tmp_37_4_cast_mid2_reg_2770[2]),
        .I1(tmp_37_4_cast_mid2_reg_2770[0]),
        .I2(tmp_37_4_cast_mid2_reg_2770[3]),
        .I3(tmp_37_4_cast_mid2_reg_2770[4]),
        .I4(tmp_37_4_cast_mid2_reg_2770[1]),
        .O(\input_r_Addr_A[10]_INST_0_i_27_n_4 ));
  LUT4 #(
    .INIT(16'hF01E)) 
    \input_r_Addr_A[10]_INST_0_i_28 
       (.I0(tmp_37_4_cast_mid2_reg_2770[2]),
        .I1(tmp_37_4_cast_mid2_reg_2770[1]),
        .I2(tmp_37_4_cast_mid2_reg_2770[3]),
        .I3(tmp_37_4_cast_mid2_reg_2770[0]),
        .O(\input_r_Addr_A[10]_INST_0_i_28_n_4 ));
  LUT5 #(
    .INIT(32'hBABA0444)) 
    \input_r_Addr_A[10]_INST_0_i_29 
       (.I0(tmp_37_2_cast_mid2_reg_2758[2]),
        .I1(tmp_37_2_cast_mid2_reg_2758[4]),
        .I2(tmp_37_2_cast_mid2_reg_2758[1]),
        .I3(tmp_37_4_cast_mid2_reg_2770[0]),
        .I4(tmp_37_2_cast_mid2_reg_2758[3]),
        .O(\input_r_Addr_A[10]_INST_0_i_29_n_4 ));
  LUT6 #(
    .INIT(64'hFEFEFE0EFE0EFE0E)) 
    \input_r_Addr_A[10]_INST_0_i_3 
       (.I0(\input_r_Addr_A[10]_INST_0_i_8_n_4 ),
        .I1(\input_r_Addr_A[10]_INST_0_i_9_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .I3(\input_r_Addr_A[10]_INST_0_i_10_n_4 ),
        .I4(conv1_bias_EN_A),
        .I5(data16[8]),
        .O(\input_r_Addr_A[10]_INST_0_i_3_n_4 ));
  LUT5 #(
    .INIT(32'h40F4BF0A)) 
    \input_r_Addr_A[10]_INST_0_i_30 
       (.I0(tmp_37_2_cast_mid2_reg_2758[3]),
        .I1(tmp_37_4_cast_mid2_reg_2770[0]),
        .I2(tmp_37_2_cast_mid2_reg_2758[1]),
        .I3(tmp_37_2_cast_mid2_reg_2758[4]),
        .I4(tmp_37_2_cast_mid2_reg_2758[2]),
        .O(\input_r_Addr_A[10]_INST_0_i_30_n_4 ));
  LUT5 #(
    .INIT(32'hF30C0DF2)) 
    \input_r_Addr_A[10]_INST_0_i_31 
       (.I0(tmp_37_2_cast_mid2_reg_2758[2]),
        .I1(tmp_37_4_cast_mid2_reg_2770[0]),
        .I2(tmp_37_2_cast_mid2_reg_2758[3]),
        .I3(tmp_37_2_cast_mid2_reg_2758[4]),
        .I4(tmp_37_2_cast_mid2_reg_2758[1]),
        .O(\input_r_Addr_A[10]_INST_0_i_31_n_4 ));
  LUT4 #(
    .INIT(16'hF01E)) 
    \input_r_Addr_A[10]_INST_0_i_32 
       (.I0(tmp_37_2_cast_mid2_reg_2758[2]),
        .I1(tmp_37_2_cast_mid2_reg_2758[1]),
        .I2(tmp_37_2_cast_mid2_reg_2758[3]),
        .I3(tmp_37_4_cast_mid2_reg_2770[0]),
        .O(\input_r_Addr_A[10]_INST_0_i_32_n_4 ));
  LUT5 #(
    .INIT(32'hBABA0444)) 
    \input_r_Addr_A[10]_INST_0_i_33 
       (.I0(p_shl6_cast_fu_878_p1[7]),
        .I1(p_shl6_cast_fu_878_p1[9]),
        .I2(p_shl6_cast_fu_878_p1[6]),
        .I3(tmp_37_3_cast_mid2_reg_2764[0]),
        .I4(p_shl6_cast_fu_878_p1[8]),
        .O(\input_r_Addr_A[10]_INST_0_i_33_n_4 ));
  LUT5 #(
    .INIT(32'h40F4BF0A)) 
    \input_r_Addr_A[10]_INST_0_i_34 
       (.I0(p_shl6_cast_fu_878_p1[8]),
        .I1(tmp_37_3_cast_mid2_reg_2764[0]),
        .I2(p_shl6_cast_fu_878_p1[6]),
        .I3(p_shl6_cast_fu_878_p1[9]),
        .I4(p_shl6_cast_fu_878_p1[7]),
        .O(\input_r_Addr_A[10]_INST_0_i_34_n_4 ));
  LUT5 #(
    .INIT(32'hF30C0DF2)) 
    \input_r_Addr_A[10]_INST_0_i_35 
       (.I0(p_shl6_cast_fu_878_p1[7]),
        .I1(tmp_37_3_cast_mid2_reg_2764[0]),
        .I2(p_shl6_cast_fu_878_p1[8]),
        .I3(p_shl6_cast_fu_878_p1[9]),
        .I4(p_shl6_cast_fu_878_p1[6]),
        .O(\input_r_Addr_A[10]_INST_0_i_35_n_4 ));
  LUT4 #(
    .INIT(16'hF01E)) 
    \input_r_Addr_A[10]_INST_0_i_36 
       (.I0(p_shl6_cast_fu_878_p1[7]),
        .I1(p_shl6_cast_fu_878_p1[6]),
        .I2(p_shl6_cast_fu_878_p1[8]),
        .I3(tmp_37_3_cast_mid2_reg_2764[0]),
        .O(\input_r_Addr_A[10]_INST_0_i_36_n_4 ));
  LUT5 #(
    .INIT(32'hBABA0444)) 
    \input_r_Addr_A[10]_INST_0_i_37 
       (.I0(p_shl10_cast_fu_1237_p1[7]),
        .I1(p_shl10_cast_fu_1237_p1[9]),
        .I2(p_shl10_cast_fu_1237_p1[6]),
        .I3(p_shl10_cast_fu_1237_p1[5]),
        .I4(p_shl10_cast_fu_1237_p1[8]),
        .O(\input_r_Addr_A[10]_INST_0_i_37_n_4 ));
  LUT5 #(
    .INIT(32'h40F4BF0A)) 
    \input_r_Addr_A[10]_INST_0_i_38 
       (.I0(p_shl10_cast_fu_1237_p1[8]),
        .I1(p_shl10_cast_fu_1237_p1[5]),
        .I2(p_shl10_cast_fu_1237_p1[6]),
        .I3(p_shl10_cast_fu_1237_p1[9]),
        .I4(p_shl10_cast_fu_1237_p1[7]),
        .O(\input_r_Addr_A[10]_INST_0_i_38_n_4 ));
  LUT5 #(
    .INIT(32'hF30C0DF2)) 
    \input_r_Addr_A[10]_INST_0_i_39 
       (.I0(p_shl10_cast_fu_1237_p1[7]),
        .I1(p_shl10_cast_fu_1237_p1[5]),
        .I2(p_shl10_cast_fu_1237_p1[8]),
        .I3(p_shl10_cast_fu_1237_p1[9]),
        .I4(p_shl10_cast_fu_1237_p1[6]),
        .O(\input_r_Addr_A[10]_INST_0_i_39_n_4 ));
  LUT6 #(
    .INIT(64'hFFBABABA00BABABA)) 
    \input_r_Addr_A[10]_INST_0_i_4 
       (.I0(\input_r_Addr_A[10]_INST_0_i_11_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_24_n_4 ),
        .I2(\input_r_Addr_A[10]_INST_0_i_12_n_4 ),
        .I3(ap_CS_fsm_pp0_stage0),
        .I4(ap_enable_reg_pp0_iter1_reg_n_4),
        .I5(tmp_114_reg_3436[8]),
        .O(\input_r_Addr_A[10]_INST_0_i_4_n_4 ));
  LUT4 #(
    .INIT(16'hF01E)) 
    \input_r_Addr_A[10]_INST_0_i_40 
       (.I0(p_shl10_cast_fu_1237_p1[7]),
        .I1(p_shl10_cast_fu_1237_p1[6]),
        .I2(p_shl10_cast_fu_1237_p1[8]),
        .I3(p_shl10_cast_fu_1237_p1[5]),
        .O(\input_r_Addr_A[10]_INST_0_i_40_n_4 ));
  LUT5 #(
    .INIT(32'hBABA0444)) 
    \input_r_Addr_A[10]_INST_0_i_41 
       (.I0(p_shl10_cast_fu_1237_p1[7]),
        .I1(p_shl10_cast_fu_1237_p1[9]),
        .I2(p_shl10_cast_fu_1237_p1[6]),
        .I3(p_shl10_cast_fu_1237_p1[5]),
        .I4(p_shl10_cast_fu_1237_p1[8]),
        .O(\input_r_Addr_A[10]_INST_0_i_41_n_4 ));
  LUT5 #(
    .INIT(32'h40F4BF0A)) 
    \input_r_Addr_A[10]_INST_0_i_42 
       (.I0(p_shl10_cast_fu_1237_p1[8]),
        .I1(p_shl10_cast_fu_1237_p1[5]),
        .I2(p_shl10_cast_fu_1237_p1[6]),
        .I3(p_shl10_cast_fu_1237_p1[9]),
        .I4(p_shl10_cast_fu_1237_p1[7]),
        .O(\input_r_Addr_A[10]_INST_0_i_42_n_4 ));
  LUT5 #(
    .INIT(32'hF30C0DF2)) 
    \input_r_Addr_A[10]_INST_0_i_43 
       (.I0(p_shl10_cast_fu_1237_p1[7]),
        .I1(p_shl10_cast_fu_1237_p1[5]),
        .I2(p_shl10_cast_fu_1237_p1[8]),
        .I3(p_shl10_cast_fu_1237_p1[9]),
        .I4(p_shl10_cast_fu_1237_p1[6]),
        .O(\input_r_Addr_A[10]_INST_0_i_43_n_4 ));
  LUT4 #(
    .INIT(16'hF01E)) 
    \input_r_Addr_A[10]_INST_0_i_44 
       (.I0(p_shl10_cast_fu_1237_p1[7]),
        .I1(p_shl10_cast_fu_1237_p1[6]),
        .I2(p_shl10_cast_fu_1237_p1[8]),
        .I3(p_shl10_cast_fu_1237_p1[5]),
        .O(\input_r_Addr_A[10]_INST_0_i_44_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[10]_INST_0_i_5 
       (.I0(data13[8]),
        .I1(data15[8]),
        .I2(data14[8]),
        .I3(reg_6311444_out),
        .I4(reg_6311242_out),
        .I5(reg_6311343_out),
        .O(\input_r_Addr_A[10]_INST_0_i_5_n_4 ));
  LUT6 #(
    .INIT(64'h00F0000000800080)) 
    \input_r_Addr_A[10]_INST_0_i_6 
       (.I0(ap_CS_fsm_pp0_stage13),
        .I1(data12[8]),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage15),
        .I4(data11[8]),
        .I5(ap_CS_fsm_pp0_stage14),
        .O(\input_r_Addr_A[10]_INST_0_i_6_n_4 ));
  CARRY4 \input_r_Addr_A[10]_INST_0_i_7 
       (.CI(\input_r_Addr_A[6]_INST_0_i_7_n_4 ),
        .CO({\input_r_Addr_A[10]_INST_0_i_7_n_4 ,\input_r_Addr_A[10]_INST_0_i_7_n_5 ,\input_r_Addr_A[10]_INST_0_i_7_n_6 ,\input_r_Addr_A[10]_INST_0_i_7_n_7 }),
        .CYINIT(1'b0),
        .DI({\input_r_Addr_A[10]_INST_0_i_13_n_4 ,\input_r_Addr_A[10]_INST_0_i_14_n_4 ,\input_r_Addr_A[10]_INST_0_i_15_n_4 ,\input_r_Addr_A[10]_INST_0_i_16_n_4 }),
        .O(data7[8:5]),
        .S({\input_r_Addr_A[10]_INST_0_i_17_n_4 ,\input_r_Addr_A[10]_INST_0_i_18_n_4 ,\input_r_Addr_A[10]_INST_0_i_19_n_4 ,\input_r_Addr_A[10]_INST_0_i_20_n_4 }));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[10]_INST_0_i_8 
       (.I0(data19[8]),
        .I1(data21[8]),
        .I2(data20[8]),
        .I3(reg_631839_out),
        .I4(reg_631637_out),
        .I5(reg_631738_out),
        .O(\input_r_Addr_A[10]_INST_0_i_8_n_4 ));
  LUT6 #(
    .INIT(64'h00000000BB88B8B8)) 
    \input_r_Addr_A[10]_INST_0_i_9 
       (.I0(data22[8]),
        .I1(reg_631536_out),
        .I2(data24[8]),
        .I3(data23[8]),
        .I4(reg_631435_out),
        .I5(\input_r_Addr_A[4]_INST_0_i_12_n_4 ),
        .O(\input_r_Addr_A[10]_INST_0_i_9_n_4 ));
  LUT6 #(
    .INIT(64'hFFFFFDA80000FDA8)) 
    \input_r_Addr_A[11]_INST_0 
       (.I0(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .I1(\input_r_Addr_A[11]_INST_0_i_1_n_4 ),
        .I2(\input_r_Addr_A[11]_INST_0_i_2_n_4 ),
        .I3(\input_r_Addr_A[11]_INST_0_i_3_n_4 ),
        .I4(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I5(\input_r_Addr_A[11]_INST_0_i_4_n_4 ),
        .O(input_r_Addr_A[9]));
  LUT6 #(
    .INIT(64'h3333300022222222)) 
    \input_r_Addr_A[11]_INST_0_i_1 
       (.I0(\input_r_Addr_A[11]_INST_0_i_5_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .I2(data10[9]),
        .I3(reg_6311747_out),
        .I4(\input_r_Addr_A[11]_INST_0_i_6_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_7_n_4 ),
        .O(\input_r_Addr_A[11]_INST_0_i_1_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[11]_INST_0_i_10 
       (.I0(tmp_109_reg_3426[9]),
        .I1(tmp_123_reg_3446[9]),
        .I2(tmp_103_reg_3416[9]),
        .I3(reg_6312555_out),
        .I4(reg_6312454_out),
        .I5(reg_63125),
        .O(\input_r_Addr_A[11]_INST_0_i_10_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[11]_INST_0_i_11 
       (.I0(tmp_118_reg_3441[9]),
        .I1(data6[9]),
        .I2(tmp_113_reg_3431[9]),
        .I3(reg_6312353_out),
        .I4(reg_6312151_out),
        .I5(reg_6312252_out),
        .O(\input_r_Addr_A[11]_INST_0_i_11_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[11]_INST_0_i_2 
       (.I0(data7[9]),
        .I1(data9[9]),
        .I2(data8[9]),
        .I3(reg_6312050_out),
        .I4(reg_6311848_out),
        .I5(reg_6311949_out),
        .O(\input_r_Addr_A[11]_INST_0_i_2_n_4 ));
  LUT6 #(
    .INIT(64'hFEFEFE0EFE0EFE0E)) 
    \input_r_Addr_A[11]_INST_0_i_3 
       (.I0(\input_r_Addr_A[11]_INST_0_i_7_n_4 ),
        .I1(\input_r_Addr_A[11]_INST_0_i_8_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .I3(\input_r_Addr_A[11]_INST_0_i_9_n_4 ),
        .I4(conv1_bias_EN_A),
        .I5(data16[9]),
        .O(\input_r_Addr_A[11]_INST_0_i_3_n_4 ));
  LUT6 #(
    .INIT(64'hFFBABABA00BABABA)) 
    \input_r_Addr_A[11]_INST_0_i_4 
       (.I0(\input_r_Addr_A[11]_INST_0_i_10_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_24_n_4 ),
        .I2(\input_r_Addr_A[11]_INST_0_i_11_n_4 ),
        .I3(ap_CS_fsm_pp0_stage0),
        .I4(ap_enable_reg_pp0_iter1_reg_n_4),
        .I5(tmp_114_reg_3436[9]),
        .O(\input_r_Addr_A[11]_INST_0_i_4_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[11]_INST_0_i_5 
       (.I0(data13[9]),
        .I1(data15[9]),
        .I2(data14[9]),
        .I3(reg_6311444_out),
        .I4(reg_6311242_out),
        .I5(reg_6311343_out),
        .O(\input_r_Addr_A[11]_INST_0_i_5_n_4 ));
  LUT6 #(
    .INIT(64'h00F0000000800080)) 
    \input_r_Addr_A[11]_INST_0_i_6 
       (.I0(ap_CS_fsm_pp0_stage13),
        .I1(data12[9]),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage15),
        .I4(data11[9]),
        .I5(ap_CS_fsm_pp0_stage14),
        .O(\input_r_Addr_A[11]_INST_0_i_6_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[11]_INST_0_i_7 
       (.I0(data19[9]),
        .I1(data21[9]),
        .I2(data20[9]),
        .I3(reg_631839_out),
        .I4(reg_631637_out),
        .I5(reg_631738_out),
        .O(\input_r_Addr_A[11]_INST_0_i_7_n_4 ));
  LUT6 #(
    .INIT(64'h00000000BB88B8B8)) 
    \input_r_Addr_A[11]_INST_0_i_8 
       (.I0(data22[9]),
        .I1(reg_631536_out),
        .I2(data24[9]),
        .I3(data23[9]),
        .I4(reg_631435_out),
        .I5(\input_r_Addr_A[4]_INST_0_i_12_n_4 ),
        .O(\input_r_Addr_A[11]_INST_0_i_8_n_4 ));
  LUT6 #(
    .INIT(64'h00F0000000800080)) 
    \input_r_Addr_A[11]_INST_0_i_9 
       (.I0(ap_CS_fsm_pp0_stage7),
        .I1(data18[9]),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage9),
        .I4(data17[9]),
        .I5(ap_CS_fsm_pp0_stage8),
        .O(\input_r_Addr_A[11]_INST_0_i_9_n_4 ));
  LUT6 #(
    .INIT(64'hFFFFFDA80000FDA8)) 
    \input_r_Addr_A[12]_INST_0 
       (.I0(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_2_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_3_n_4 ),
        .I3(\input_r_Addr_A[12]_INST_0_i_4_n_4 ),
        .I4(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_6_n_4 ),
        .O(input_r_Addr_A[10]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFEAAAA)) 
    \input_r_Addr_A[12]_INST_0_i_1 
       (.I0(\input_r_Addr_A[12]_INST_0_i_7_n_4 ),
        .I1(ap_CS_fsm_pp0_stage11),
        .I2(ap_CS_fsm_pp0_stage10),
        .I3(ap_CS_fsm_pp0_stage12),
        .I4(ap_enable_reg_pp0_iter0),
        .I5(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .O(\input_r_Addr_A[12]_INST_0_i_1_n_4 ));
  CARRY4 \input_r_Addr_A[12]_INST_0_i_10 
       (.CI(\input_r_Addr_A[7]_INST_0_i_6_n_4 ),
        .CO({data10[10],\input_r_Addr_A[12]_INST_0_i_10_n_5 ,\input_r_Addr_A[12]_INST_0_i_10_n_6 ,\input_r_Addr_A[12]_INST_0_i_10_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_92_reg_2830_reg__0[7:4]),
        .O(data10[9:6]),
        .S(tmp_92_reg_2830_reg__0[7:4]));
  (* SOFT_HLUTNM = "soft_lutpair87" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \input_r_Addr_A[12]_INST_0_i_11 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage15),
        .O(reg_6311747_out));
  LUT6 #(
    .INIT(64'h00F0000000800080)) 
    \input_r_Addr_A[12]_INST_0_i_12 
       (.I0(ap_CS_fsm_pp0_stage13),
        .I1(data12[10]),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage15),
        .I4(data11[10]),
        .I5(ap_CS_fsm_pp0_stage14),
        .O(\input_r_Addr_A[12]_INST_0_i_12_n_4 ));
  CARRY4 \input_r_Addr_A[12]_INST_0_i_13 
       (.CI(\input_r_Addr_A[10]_INST_0_i_7_n_4 ),
        .CO({\NLW_input_r_Addr_A[12]_INST_0_i_13_CO_UNCONNECTED [3:1],\input_r_Addr_A[12]_INST_0_i_13_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\input_r_Addr_A[12]_INST_0_i_35_n_4 }),
        .O({\NLW_input_r_Addr_A[12]_INST_0_i_13_O_UNCONNECTED [3:2],data7[10:9]}),
        .S({1'b0,1'b0,1'b0,\input_r_Addr_A[12]_INST_0_i_36_n_4 }));
  CARRY4 \input_r_Addr_A[12]_INST_0_i_14 
       (.CI(\input_r_Addr_A[7]_INST_0_i_8_n_4 ),
        .CO({data9[10],\input_r_Addr_A[12]_INST_0_i_14_n_5 ,\input_r_Addr_A[12]_INST_0_i_14_n_6 ,\input_r_Addr_A[12]_INST_0_i_14_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_92_reg_2830_reg__0[7:4]),
        .O(data9[9:6]),
        .S(tmp_92_reg_2830_reg__0[7:4]));
  CARRY4 \input_r_Addr_A[12]_INST_0_i_15 
       (.CI(\input_r_Addr_A[7]_INST_0_i_9_n_4 ),
        .CO({data8[10],\input_r_Addr_A[12]_INST_0_i_15_n_5 ,\input_r_Addr_A[12]_INST_0_i_15_n_6 ,\input_r_Addr_A[12]_INST_0_i_15_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_92_reg_2830_reg__0[7:4]),
        .O(data8[9:6]),
        .S(tmp_92_reg_2830_reg__0[7:4]));
  LUT2 #(
    .INIT(4'h8)) 
    \input_r_Addr_A[12]_INST_0_i_16 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage18),
        .O(reg_6312050_out));
  (* SOFT_HLUTNM = "soft_lutpair58" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \input_r_Addr_A[12]_INST_0_i_17 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage16),
        .O(reg_6311848_out));
  (* SOFT_HLUTNM = "soft_lutpair88" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \input_r_Addr_A[12]_INST_0_i_18 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage17),
        .O(reg_6311949_out));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[12]_INST_0_i_19 
       (.I0(data19[10]),
        .I1(data21[10]),
        .I2(data20[10]),
        .I3(reg_631839_out),
        .I4(reg_631637_out),
        .I5(reg_631738_out),
        .O(\input_r_Addr_A[12]_INST_0_i_19_n_4 ));
  LUT6 #(
    .INIT(64'h3333300022222222)) 
    \input_r_Addr_A[12]_INST_0_i_2 
       (.I0(\input_r_Addr_A[12]_INST_0_i_9_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .I2(data10[10]),
        .I3(reg_6311747_out),
        .I4(\input_r_Addr_A[12]_INST_0_i_12_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_7_n_4 ),
        .O(\input_r_Addr_A[12]_INST_0_i_2_n_4 ));
  LUT6 #(
    .INIT(64'h00000000BB88B8B8)) 
    \input_r_Addr_A[12]_INST_0_i_20 
       (.I0(data22[10]),
        .I1(reg_631536_out),
        .I2(data24[10]),
        .I3(data23[10]),
        .I4(reg_631435_out),
        .I5(\input_r_Addr_A[4]_INST_0_i_12_n_4 ),
        .O(\input_r_Addr_A[12]_INST_0_i_20_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair54" *) 
  LUT4 #(
    .INIT(16'hFE00)) 
    \input_r_Addr_A[12]_INST_0_i_21 
       (.I0(ap_CS_fsm_pp0_stage8),
        .I1(ap_CS_fsm_pp0_stage7),
        .I2(ap_CS_fsm_pp0_stage9),
        .I3(ap_enable_reg_pp0_iter0),
        .O(\input_r_Addr_A[12]_INST_0_i_21_n_4 ));
  LUT6 #(
    .INIT(64'h00F0000000800080)) 
    \input_r_Addr_A[12]_INST_0_i_22 
       (.I0(ap_CS_fsm_pp0_stage7),
        .I1(data18[10]),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage9),
        .I4(data17[10]),
        .I5(ap_CS_fsm_pp0_stage8),
        .O(\input_r_Addr_A[12]_INST_0_i_22_n_4 ));
  CARRY4 \input_r_Addr_A[12]_INST_0_i_23 
       (.CI(\input_r_Addr_A[7]_INST_0_i_13_n_4 ),
        .CO({data16[10],\input_r_Addr_A[12]_INST_0_i_23_n_5 ,\input_r_Addr_A[12]_INST_0_i_23_n_6 ,\input_r_Addr_A[12]_INST_0_i_23_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_83_reg_2990_reg__0[7:4]),
        .O(data16[9:6]),
        .S(tmp_83_reg_2990_reg__0[7:4]));
  (* SOFT_HLUTNM = "soft_lutpair36" *) 
  LUT4 #(
    .INIT(16'hFE00)) 
    \input_r_Addr_A[12]_INST_0_i_24 
       (.I0(ap_CS_fsm_pp0_stage23),
        .I1(ap_CS_fsm_pp0_stage22),
        .I2(ap_CS_fsm_pp0_stage24),
        .I3(ap_enable_reg_pp0_iter0),
        .O(\input_r_Addr_A[12]_INST_0_i_24_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[12]_INST_0_i_25 
       (.I0(tmp_109_reg_3426[10]),
        .I1(tmp_123_reg_3446[10]),
        .I2(tmp_103_reg_3416[10]),
        .I3(reg_6312555_out),
        .I4(reg_6312454_out),
        .I5(reg_63125),
        .O(\input_r_Addr_A[12]_INST_0_i_25_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[12]_INST_0_i_26 
       (.I0(tmp_118_reg_3441[10]),
        .I1(data6[10]),
        .I2(tmp_113_reg_3431[10]),
        .I3(reg_6312353_out),
        .I4(reg_6312151_out),
        .I5(reg_6312252_out),
        .O(\input_r_Addr_A[12]_INST_0_i_26_n_4 ));
  CARRY4 \input_r_Addr_A[12]_INST_0_i_27 
       (.CI(\input_r_Addr_A[7]_INST_0_i_16_n_4 ),
        .CO({data13[10],\input_r_Addr_A[12]_INST_0_i_27_n_5 ,\input_r_Addr_A[12]_INST_0_i_27_n_6 ,\input_r_Addr_A[12]_INST_0_i_27_n_7 }),
        .CYINIT(1'b0),
        .DI({\tmp_89_reg_2786_reg_n_4_[9] ,\tmp_89_reg_2786_reg_n_4_[8] ,\tmp_89_reg_2786_reg_n_4_[7] ,\tmp_89_reg_2786_reg_n_4_[6] }),
        .O(data13[9:6]),
        .S({\tmp_89_reg_2786_reg_n_4_[9] ,\tmp_89_reg_2786_reg_n_4_[8] ,\tmp_89_reg_2786_reg_n_4_[7] ,\tmp_89_reg_2786_reg_n_4_[6] }));
  CARRY4 \input_r_Addr_A[12]_INST_0_i_28 
       (.CI(\input_r_Addr_A[7]_INST_0_i_17_n_4 ),
        .CO({data15[10],\input_r_Addr_A[12]_INST_0_i_28_n_5 ,\input_r_Addr_A[12]_INST_0_i_28_n_6 ,\input_r_Addr_A[12]_INST_0_i_28_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_83_reg_2990_reg__0[7:4]),
        .O(data15[9:6]),
        .S(tmp_83_reg_2990_reg__0[7:4]));
  CARRY4 \input_r_Addr_A[12]_INST_0_i_29 
       (.CI(\input_r_Addr_A[7]_INST_0_i_18_n_4 ),
        .CO({data14[10],\input_r_Addr_A[12]_INST_0_i_29_n_5 ,\input_r_Addr_A[12]_INST_0_i_29_n_6 ,\input_r_Addr_A[12]_INST_0_i_29_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_83_reg_2990_reg__0[7:4]),
        .O(data14[9:6]),
        .S(tmp_83_reg_2990_reg__0[7:4]));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[12]_INST_0_i_3 
       (.I0(data7[10]),
        .I1(data9[10]),
        .I2(data8[10]),
        .I3(reg_6312050_out),
        .I4(reg_6311848_out),
        .I5(reg_6311949_out),
        .O(\input_r_Addr_A[12]_INST_0_i_3_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair86" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \input_r_Addr_A[12]_INST_0_i_30 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage12),
        .O(reg_6311444_out));
  (* SOFT_HLUTNM = "soft_lutpair85" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \input_r_Addr_A[12]_INST_0_i_31 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage10),
        .O(reg_6311242_out));
  (* SOFT_HLUTNM = "soft_lutpair86" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \input_r_Addr_A[12]_INST_0_i_32 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage11),
        .O(reg_6311343_out));
  CARRY4 \input_r_Addr_A[12]_INST_0_i_33 
       (.CI(\input_r_Addr_A[7]_INST_0_i_22_n_4 ),
        .CO({data12[10],\input_r_Addr_A[12]_INST_0_i_33_n_5 ,\input_r_Addr_A[12]_INST_0_i_33_n_6 ,\input_r_Addr_A[12]_INST_0_i_33_n_7 }),
        .CYINIT(1'b0),
        .DI({\tmp_89_reg_2786_reg_n_4_[9] ,\tmp_89_reg_2786_reg_n_4_[8] ,\tmp_89_reg_2786_reg_n_4_[7] ,\tmp_89_reg_2786_reg_n_4_[6] }),
        .O(data12[9:6]),
        .S({\tmp_89_reg_2786_reg_n_4_[9] ,\tmp_89_reg_2786_reg_n_4_[8] ,\tmp_89_reg_2786_reg_n_4_[7] ,\tmp_89_reg_2786_reg_n_4_[6] }));
  CARRY4 \input_r_Addr_A[12]_INST_0_i_34 
       (.CI(\input_r_Addr_A[7]_INST_0_i_23_n_4 ),
        .CO({data11[10],\input_r_Addr_A[12]_INST_0_i_34_n_5 ,\input_r_Addr_A[12]_INST_0_i_34_n_6 ,\input_r_Addr_A[12]_INST_0_i_34_n_7 }),
        .CYINIT(1'b0),
        .DI({\tmp_89_reg_2786_reg_n_4_[9] ,\tmp_89_reg_2786_reg_n_4_[8] ,\tmp_89_reg_2786_reg_n_4_[7] ,\tmp_89_reg_2786_reg_n_4_[6] }),
        .O(data11[9:6]),
        .S({\tmp_89_reg_2786_reg_n_4_[9] ,\tmp_89_reg_2786_reg_n_4_[8] ,\tmp_89_reg_2786_reg_n_4_[7] ,\tmp_89_reg_2786_reg_n_4_[6] }));
  LUT5 #(
    .INIT(32'hFFEA0000)) 
    \input_r_Addr_A[12]_INST_0_i_35 
       (.I0(tmp_37_3_cast_mid2_reg_2764[3]),
        .I1(tmp_37_3_cast_mid2_reg_2764[0]),
        .I2(tmp_37_3_cast_mid2_reg_2764[1]),
        .I3(tmp_37_3_cast_mid2_reg_2764[2]),
        .I4(tmp_37_3_cast_mid2_reg_2764[4]),
        .O(\input_r_Addr_A[12]_INST_0_i_35_n_4 ));
  LUT5 #(
    .INIT(32'hFFEA0000)) 
    \input_r_Addr_A[12]_INST_0_i_36 
       (.I0(tmp_37_3_cast_mid2_reg_2764[3]),
        .I1(tmp_37_3_cast_mid2_reg_2764[0]),
        .I2(tmp_37_3_cast_mid2_reg_2764[1]),
        .I3(tmp_37_3_cast_mid2_reg_2764[2]),
        .I4(tmp_37_3_cast_mid2_reg_2764[4]),
        .O(\input_r_Addr_A[12]_INST_0_i_36_n_4 ));
  CARRY4 \input_r_Addr_A[12]_INST_0_i_37 
       (.CI(\input_r_Addr_A[7]_INST_0_i_30_n_4 ),
        .CO({data19[10],\input_r_Addr_A[12]_INST_0_i_37_n_5 ,\input_r_Addr_A[12]_INST_0_i_37_n_6 ,\input_r_Addr_A[12]_INST_0_i_37_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_98_reg_2909[9:6]),
        .O(data19[9:6]),
        .S(tmp_98_reg_2909[9:6]));
  CARRY4 \input_r_Addr_A[12]_INST_0_i_38 
       (.CI(\input_r_Addr_A[7]_INST_0_i_31_n_4 ),
        .CO({data21[10],\input_r_Addr_A[12]_INST_0_i_38_n_5 ,\input_r_Addr_A[12]_INST_0_i_38_n_6 ,\input_r_Addr_A[12]_INST_0_i_38_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data21[9:6]),
        .S(tmp_92_reg_2830_reg__0[7:4]));
  CARRY4 \input_r_Addr_A[12]_INST_0_i_39 
       (.CI(\input_r_Addr_A[10]_INST_0_i_21_n_4 ),
        .CO({\NLW_input_r_Addr_A[12]_INST_0_i_39_CO_UNCONNECTED [3:1],\input_r_Addr_A[12]_INST_0_i_39_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_input_r_Addr_A[12]_INST_0_i_39_O_UNCONNECTED [3:2],data20[10:9]}),
        .S({1'b0,1'b0,1'b0,\input_r_Addr_A[12]_INST_0_i_50_n_4 }));
  LUT6 #(
    .INIT(64'hFEFEFE0EFE0EFE0E)) 
    \input_r_Addr_A[12]_INST_0_i_4 
       (.I0(\input_r_Addr_A[12]_INST_0_i_19_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_20_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .I3(\input_r_Addr_A[12]_INST_0_i_22_n_4 ),
        .I4(conv1_bias_EN_A),
        .I5(data16[10]),
        .O(\input_r_Addr_A[12]_INST_0_i_4_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair72" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \input_r_Addr_A[12]_INST_0_i_40 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage4),
        .O(reg_631637_out));
  (* SOFT_HLUTNM = "soft_lutpair81" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \input_r_Addr_A[12]_INST_0_i_41 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage5),
        .O(reg_631738_out));
  CARRY4 \input_r_Addr_A[12]_INST_0_i_42 
       (.CI(\input_r_Addr_A[10]_INST_0_i_22_n_4 ),
        .CO({\NLW_input_r_Addr_A[12]_INST_0_i_42_CO_UNCONNECTED [3:1],\input_r_Addr_A[12]_INST_0_i_42_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_input_r_Addr_A[12]_INST_0_i_42_O_UNCONNECTED [3:2],data22[10:9]}),
        .S({1'b0,1'b0,1'b0,\input_r_Addr_A[12]_INST_0_i_51_n_4 }));
  (* SOFT_HLUTNM = "soft_lutpair74" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \input_r_Addr_A[12]_INST_0_i_43 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage3),
        .O(reg_631536_out));
  CARRY4 \input_r_Addr_A[12]_INST_0_i_44 
       (.CI(\input_r_Addr_A[10]_INST_0_i_23_n_4 ),
        .CO({\NLW_input_r_Addr_A[12]_INST_0_i_44_CO_UNCONNECTED [3:1],\input_r_Addr_A[12]_INST_0_i_44_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_input_r_Addr_A[12]_INST_0_i_44_O_UNCONNECTED [3:2],data24[10:9]}),
        .S({1'b0,1'b0,1'b0,\input_r_Addr_A[12]_INST_0_i_52_n_4 }));
  CARRY4 \input_r_Addr_A[12]_INST_0_i_45 
       (.CI(\input_r_Addr_A[7]_INST_0_i_32_n_4 ),
        .CO({data23[10],\input_r_Addr_A[12]_INST_0_i_45_n_5 ,\input_r_Addr_A[12]_INST_0_i_45_n_6 ,\input_r_Addr_A[12]_INST_0_i_45_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data23[9:6]),
        .S({\tmp_89_reg_2786_reg_n_4_[9] ,\tmp_89_reg_2786_reg_n_4_[8] ,\tmp_89_reg_2786_reg_n_4_[7] ,\tmp_89_reg_2786_reg_n_4_[6] }));
  (* SOFT_HLUTNM = "soft_lutpair73" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \input_r_Addr_A[12]_INST_0_i_46 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage2),
        .O(reg_631435_out));
  CARRY4 \input_r_Addr_A[12]_INST_0_i_47 
       (.CI(\input_r_Addr_A[10]_INST_0_i_24_n_4 ),
        .CO({\NLW_input_r_Addr_A[12]_INST_0_i_47_CO_UNCONNECTED [3:1],\input_r_Addr_A[12]_INST_0_i_47_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\input_r_Addr_A[12]_INST_0_i_53_n_4 }),
        .O({\NLW_input_r_Addr_A[12]_INST_0_i_47_O_UNCONNECTED [3:2],data18[10:9]}),
        .S({1'b0,1'b0,1'b0,\input_r_Addr_A[12]_INST_0_i_54_n_4 }));
  CARRY4 \input_r_Addr_A[12]_INST_0_i_48 
       (.CI(\input_r_Addr_A[7]_INST_0_i_33_n_4 ),
        .CO({data17[10],\input_r_Addr_A[12]_INST_0_i_48_n_5 ,\input_r_Addr_A[12]_INST_0_i_48_n_6 ,\input_r_Addr_A[12]_INST_0_i_48_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_83_reg_2990_reg__0[7:4]),
        .O(data17[9:6]),
        .S(tmp_83_reg_2990_reg__0[7:4]));
  CARRY4 \input_r_Addr_A[12]_INST_0_i_49 
       (.CI(\input_r_Addr_A[7]_INST_0_i_37_n_4 ),
        .CO({data6[10],\input_r_Addr_A[12]_INST_0_i_49_n_5 ,\input_r_Addr_A[12]_INST_0_i_49_n_6 ,\input_r_Addr_A[12]_INST_0_i_49_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_95_reg_3368_reg__0[7:4]),
        .O(data6[9:6]),
        .S(tmp_95_reg_3368_reg__0[7:4]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFAAFEAA)) 
    \input_r_Addr_A[12]_INST_0_i_5 
       (.I0(\input_r_Addr_A[12]_INST_0_i_24_n_4 ),
        .I1(ap_CS_fsm_pp0_stage20),
        .I2(ap_CS_fsm_pp0_stage19),
        .I3(ap_enable_reg_pp0_iter0),
        .I4(ap_CS_fsm_pp0_stage21),
        .I5(ap_phi_mux_indvar_flatten2_phi_fu_580_p42),
        .O(\input_r_Addr_A[12]_INST_0_i_5_n_4 ));
  LUT5 #(
    .INIT(32'hFFEA0000)) 
    \input_r_Addr_A[12]_INST_0_i_50 
       (.I0(tmp_37_4_cast_mid2_reg_2770[3]),
        .I1(tmp_37_4_cast_mid2_reg_2770[0]),
        .I2(tmp_37_4_cast_mid2_reg_2770[1]),
        .I3(tmp_37_4_cast_mid2_reg_2770[2]),
        .I4(tmp_37_4_cast_mid2_reg_2770[4]),
        .O(\input_r_Addr_A[12]_INST_0_i_50_n_4 ));
  LUT5 #(
    .INIT(32'hFFEA0000)) 
    \input_r_Addr_A[12]_INST_0_i_51 
       (.I0(tmp_37_2_cast_mid2_reg_2758[3]),
        .I1(tmp_37_4_cast_mid2_reg_2770[0]),
        .I2(tmp_37_2_cast_mid2_reg_2758[1]),
        .I3(tmp_37_2_cast_mid2_reg_2758[2]),
        .I4(tmp_37_2_cast_mid2_reg_2758[4]),
        .O(\input_r_Addr_A[12]_INST_0_i_51_n_4 ));
  LUT5 #(
    .INIT(32'hFFEA0000)) 
    \input_r_Addr_A[12]_INST_0_i_52 
       (.I0(p_shl6_cast_fu_878_p1[8]),
        .I1(tmp_37_3_cast_mid2_reg_2764[0]),
        .I2(p_shl6_cast_fu_878_p1[6]),
        .I3(p_shl6_cast_fu_878_p1[7]),
        .I4(p_shl6_cast_fu_878_p1[9]),
        .O(\input_r_Addr_A[12]_INST_0_i_52_n_4 ));
  LUT5 #(
    .INIT(32'hFFEA0000)) 
    \input_r_Addr_A[12]_INST_0_i_53 
       (.I0(p_shl10_cast_fu_1237_p1[8]),
        .I1(p_shl10_cast_fu_1237_p1[5]),
        .I2(p_shl10_cast_fu_1237_p1[6]),
        .I3(p_shl10_cast_fu_1237_p1[7]),
        .I4(p_shl10_cast_fu_1237_p1[9]),
        .O(\input_r_Addr_A[12]_INST_0_i_53_n_4 ));
  LUT5 #(
    .INIT(32'hFFEA0000)) 
    \input_r_Addr_A[12]_INST_0_i_54 
       (.I0(p_shl10_cast_fu_1237_p1[8]),
        .I1(p_shl10_cast_fu_1237_p1[5]),
        .I2(p_shl10_cast_fu_1237_p1[6]),
        .I3(p_shl10_cast_fu_1237_p1[7]),
        .I4(p_shl10_cast_fu_1237_p1[9]),
        .O(\input_r_Addr_A[12]_INST_0_i_54_n_4 ));
  LUT6 #(
    .INIT(64'hFFBABABA00BABABA)) 
    \input_r_Addr_A[12]_INST_0_i_6 
       (.I0(\input_r_Addr_A[12]_INST_0_i_25_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_24_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_26_n_4 ),
        .I3(ap_CS_fsm_pp0_stage0),
        .I4(ap_enable_reg_pp0_iter1_reg_n_4),
        .I5(tmp_114_reg_3436[10]),
        .O(\input_r_Addr_A[12]_INST_0_i_6_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'hFE00)) 
    \input_r_Addr_A[12]_INST_0_i_7 
       (.I0(ap_CS_fsm_pp0_stage14),
        .I1(ap_CS_fsm_pp0_stage13),
        .I2(ap_CS_fsm_pp0_stage15),
        .I3(ap_enable_reg_pp0_iter0),
        .O(\input_r_Addr_A[12]_INST_0_i_7_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair58" *) 
  LUT4 #(
    .INIT(16'hFE00)) 
    \input_r_Addr_A[12]_INST_0_i_8 
       (.I0(ap_CS_fsm_pp0_stage17),
        .I1(ap_CS_fsm_pp0_stage16),
        .I2(ap_CS_fsm_pp0_stage18),
        .I3(ap_enable_reg_pp0_iter0),
        .O(\input_r_Addr_A[12]_INST_0_i_8_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[12]_INST_0_i_9 
       (.I0(data13[10]),
        .I1(data15[10]),
        .I2(data14[10]),
        .I3(reg_6311444_out),
        .I4(reg_6311242_out),
        .I5(reg_6311343_out),
        .O(\input_r_Addr_A[12]_INST_0_i_9_n_4 ));
  LUT6 #(
    .INIT(64'hFFFFDDD80000DDD8)) 
    \input_r_Addr_A[2]_INST_0 
       (.I0(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .I1(\input_r_Addr_A[2]_INST_0_i_1_n_4 ),
        .I2(\input_r_Addr_A[2]_INST_0_i_2_n_4 ),
        .I3(\input_r_Addr_A[2]_INST_0_i_3_n_4 ),
        .I4(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I5(\input_r_Addr_A[2]_INST_0_i_4_n_4 ),
        .O(input_r_Addr_A[0]));
  LUT5 #(
    .INIT(32'hFFFF2322)) 
    \input_r_Addr_A[2]_INST_0_i_1 
       (.I0(\input_r_Addr_A[2]_INST_0_i_5_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_7_n_4 ),
        .I3(\input_r_Addr_A[2]_INST_0_i_6_n_4 ),
        .I4(\input_r_Addr_A[2]_INST_0_i_7_n_4 ),
        .O(\input_r_Addr_A[2]_INST_0_i_1_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[2]_INST_0_i_10 
       (.I0(tmp_118_reg_3441[0]),
        .I1(tmp_39_0_1_cast_cast_reg_2871_reg__0[0]),
        .I2(tmp_114_reg_3436[0]),
        .I3(reg_6312353_out),
        .I4(reg_6312151_out),
        .I5(reg_6312252_out),
        .O(\input_r_Addr_A[2]_INST_0_i_10_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair47" *) 
  LUT4 #(
    .INIT(16'h0F02)) 
    \input_r_Addr_A[2]_INST_0_i_2 
       (.I0(\x_mid2_reg_2734_reg_n_4_[0] ),
        .I1(\input_r_Addr_A[4]_INST_0_i_12_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .I3(\input_r_Addr_A[2]_INST_0_i_8_n_4 ),
        .O(\input_r_Addr_A[2]_INST_0_i_2_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[2]_INST_0_i_3 
       (.I0(tmp_39_0_2_cast_cast_reg_2794[0]),
        .I1(tmp_6_cast_reg_2838_reg__0[0]),
        .I2(tmp_39_0_1_cast_cast_reg_2871_reg__0[0]),
        .I3(conv1_bias_EN_A),
        .I4(reg_631940_out),
        .I5(reg_6311041_out),
        .O(\input_r_Addr_A[2]_INST_0_i_3_n_4 ));
  LUT6 #(
    .INIT(64'hFFBABABA00BABABA)) 
    \input_r_Addr_A[2]_INST_0_i_4 
       (.I0(\input_r_Addr_A[2]_INST_0_i_9_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_24_n_4 ),
        .I2(\input_r_Addr_A[2]_INST_0_i_10_n_4 ),
        .I3(ap_CS_fsm_pp0_stage0),
        .I4(ap_enable_reg_pp0_iter1_reg_n_4),
        .I5(tmp_114_reg_3436[0]),
        .O(\input_r_Addr_A[2]_INST_0_i_4_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[2]_INST_0_i_5 
       (.I0(tmp_39_0_2_cast_cast_reg_2794[0]),
        .I1(tmp_39_0_1_cast_cast_reg_2871_reg__0[0]),
        .I2(tmp_39_0_3_cast_cast_reg_2917_reg__0[0]),
        .I3(reg_6311747_out),
        .I4(reg_6311545_out),
        .I5(reg_6311646_out),
        .O(\input_r_Addr_A[2]_INST_0_i_5_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[2]_INST_0_i_6 
       (.I0(tmp_6_cast_reg_2838_reg__0[0]),
        .I1(tmp_39_0_3_cast_cast_reg_2917_reg__0[0]),
        .I2(tmp_39_0_4_cast_cast_reg_2812_reg__0[0]),
        .I3(reg_6311444_out),
        .I4(reg_6311242_out),
        .I5(reg_6311343_out),
        .O(\input_r_Addr_A[2]_INST_0_i_6_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[2]_INST_0_i_7 
       (.I0(tmp_6_cast_reg_2838_reg__0[0]),
        .I1(tmp_39_0_3_cast_cast_reg_2917_reg__0[0]),
        .I2(tmp_39_0_4_cast_cast_reg_2812_reg__0[0]),
        .I3(reg_6312050_out),
        .I4(reg_6311848_out),
        .I5(reg_6311949_out),
        .O(\input_r_Addr_A[2]_INST_0_i_7_n_4 ));
  LUT6 #(
    .INIT(64'hA030A030A030A000)) 
    \input_r_Addr_A[2]_INST_0_i_8 
       (.I0(tmp_39_0_4_cast_cast_reg_2812_reg__0[0]),
        .I1(\x_mid2_reg_2734_reg_n_4_[0] ),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage6),
        .I4(ap_CS_fsm_pp0_stage4),
        .I5(ap_CS_fsm_pp0_stage5),
        .O(\input_r_Addr_A[2]_INST_0_i_8_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[2]_INST_0_i_9 
       (.I0(tmp_109_reg_3426[0]),
        .I1(tmp_123_reg_3446[0]),
        .I2(tmp_103_reg_3416[0]),
        .I3(reg_6312555_out),
        .I4(reg_6312454_out),
        .I5(reg_63125),
        .O(\input_r_Addr_A[2]_INST_0_i_9_n_4 ));
  LUT6 #(
    .INIT(64'hFFFFDDD80000DDD8)) 
    \input_r_Addr_A[3]_INST_0 
       (.I0(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .I1(\input_r_Addr_A[3]_INST_0_i_1_n_4 ),
        .I2(\input_r_Addr_A[3]_INST_0_i_2_n_4 ),
        .I3(\input_r_Addr_A[3]_INST_0_i_3_n_4 ),
        .I4(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I5(\input_r_Addr_A[3]_INST_0_i_4_n_4 ),
        .O(input_r_Addr_A[1]));
  LUT5 #(
    .INIT(32'hFFFF2322)) 
    \input_r_Addr_A[3]_INST_0_i_1 
       (.I0(\input_r_Addr_A[3]_INST_0_i_5_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_7_n_4 ),
        .I3(\input_r_Addr_A[3]_INST_0_i_6_n_4 ),
        .I4(\input_r_Addr_A[3]_INST_0_i_7_n_4 ),
        .O(\input_r_Addr_A[3]_INST_0_i_1_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[3]_INST_0_i_10 
       (.I0(tmp_109_reg_3426[1]),
        .I1(tmp_123_reg_3446[1]),
        .I2(tmp_103_reg_3416[1]),
        .I3(reg_6312555_out),
        .I4(reg_6312454_out),
        .I5(reg_63125),
        .O(\input_r_Addr_A[3]_INST_0_i_10_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[3]_INST_0_i_11 
       (.I0(tmp_118_reg_3441[1]),
        .I1(tmp_39_0_1_cast_cast_reg_2871_reg__0[1]),
        .I2(tmp_114_reg_3436[1]),
        .I3(reg_6312353_out),
        .I4(reg_6312151_out),
        .I5(reg_6312252_out),
        .O(\input_r_Addr_A[3]_INST_0_i_11_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair87" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \input_r_Addr_A[3]_INST_0_i_12 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage13),
        .O(reg_6311545_out));
  (* SOFT_HLUTNM = "soft_lutpair88" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \input_r_Addr_A[3]_INST_0_i_13 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage14),
        .O(reg_6311646_out));
  LUT6 #(
    .INIT(64'h3333300022222222)) 
    \input_r_Addr_A[3]_INST_0_i_2 
       (.I0(\input_r_Addr_A[3]_INST_0_i_8_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .I2(tmp_39_0_4_cast_cast_reg_2812_reg__0[1]),
        .I3(reg_631839_out),
        .I4(\input_r_Addr_A[3]_INST_0_i_9_n_4 ),
        .I5(\input_r_Addr_A[4]_INST_0_i_12_n_4 ),
        .O(\input_r_Addr_A[3]_INST_0_i_2_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[3]_INST_0_i_3 
       (.I0(tmp_39_0_2_cast_cast_reg_2794[1]),
        .I1(data18[1]),
        .I2(tmp_39_0_1_cast_cast_reg_2871_reg__0[1]),
        .I3(conv1_bias_EN_A),
        .I4(reg_631940_out),
        .I5(reg_6311041_out),
        .O(\input_r_Addr_A[3]_INST_0_i_3_n_4 ));
  LUT6 #(
    .INIT(64'hFFBABABA00BABABA)) 
    \input_r_Addr_A[3]_INST_0_i_4 
       (.I0(\input_r_Addr_A[3]_INST_0_i_10_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_24_n_4 ),
        .I2(\input_r_Addr_A[3]_INST_0_i_11_n_4 ),
        .I3(ap_CS_fsm_pp0_stage0),
        .I4(ap_enable_reg_pp0_iter1_reg_n_4),
        .I5(tmp_114_reg_3436[1]),
        .O(\input_r_Addr_A[3]_INST_0_i_4_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[3]_INST_0_i_5 
       (.I0(tmp_39_0_2_cast_cast_reg_2794[1]),
        .I1(tmp_39_0_1_cast_cast_reg_2871_reg__0[1]),
        .I2(tmp_39_0_3_cast_cast_reg_2917_reg__0[1]),
        .I3(reg_6311747_out),
        .I4(reg_6311545_out),
        .I5(reg_6311646_out),
        .O(\input_r_Addr_A[3]_INST_0_i_5_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[3]_INST_0_i_6 
       (.I0(data7[1]),
        .I1(tmp_39_0_3_cast_cast_reg_2917_reg__0[1]),
        .I2(tmp_39_0_4_cast_cast_reg_2812_reg__0[1]),
        .I3(reg_6311444_out),
        .I4(reg_6311242_out),
        .I5(reg_6311343_out),
        .O(\input_r_Addr_A[3]_INST_0_i_6_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[3]_INST_0_i_7 
       (.I0(data7[1]),
        .I1(tmp_39_0_3_cast_cast_reg_2917_reg__0[1]),
        .I2(tmp_39_0_4_cast_cast_reg_2812_reg__0[1]),
        .I3(reg_6312050_out),
        .I4(reg_6311848_out),
        .I5(reg_6311949_out),
        .O(\input_r_Addr_A[3]_INST_0_i_7_n_4 ));
  LUT6 #(
    .INIT(64'hFFF0D8F000F0D8F0)) 
    \input_r_Addr_A[3]_INST_0_i_8 
       (.I0(ap_CS_fsm_pp0_stage2),
        .I1(\x_mid2_reg_2734_reg_n_4_[1] ),
        .I2(data24[1]),
        .I3(ap_enable_reg_pp0_iter0),
        .I4(ap_CS_fsm_pp0_stage3),
        .I5(data22[1]),
        .O(\input_r_Addr_A[3]_INST_0_i_8_n_4 ));
  LUT6 #(
    .INIT(64'h00FF000000280028)) 
    \input_r_Addr_A[3]_INST_0_i_9 
       (.I0(reg_631637_out),
        .I1(\x_mid2_reg_2734_reg_n_4_[0] ),
        .I2(\x_mid2_reg_2734_reg_n_4_[1] ),
        .I3(reg_631839_out),
        .I4(data20[1]),
        .I5(reg_631738_out),
        .O(\input_r_Addr_A[3]_INST_0_i_9_n_4 ));
  LUT6 #(
    .INIT(64'hFFFFDDD80000DDD8)) 
    \input_r_Addr_A[4]_INST_0 
       (.I0(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .I1(\input_r_Addr_A[4]_INST_0_i_1_n_4 ),
        .I2(\input_r_Addr_A[4]_INST_0_i_2_n_4 ),
        .I3(\input_r_Addr_A[4]_INST_0_i_3_n_4 ),
        .I4(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I5(\input_r_Addr_A[4]_INST_0_i_4_n_4 ),
        .O(input_r_Addr_A[2]));
  LUT6 #(
    .INIT(64'hFEFEFE0EFE0EFE0E)) 
    \input_r_Addr_A[4]_INST_0_i_1 
       (.I0(\input_r_Addr_A[4]_INST_0_i_5_n_4 ),
        .I1(\input_r_Addr_A[4]_INST_0_i_6_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .I3(\input_r_Addr_A[4]_INST_0_i_7_n_4 ),
        .I4(reg_6312050_out),
        .I5(data7[2]),
        .O(\input_r_Addr_A[4]_INST_0_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair82" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \input_r_Addr_A[4]_INST_0_i_10 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage6),
        .O(reg_631839_out));
  LUT6 #(
    .INIT(64'h00FF000000280028)) 
    \input_r_Addr_A[4]_INST_0_i_11 
       (.I0(reg_631637_out),
        .I1(tmp_92_reg_2830_reg__0[0]),
        .I2(tmp_39_0_1_cast_cast_fu_1029_p1[2]),
        .I3(reg_631839_out),
        .I4(data20[2]),
        .I5(reg_631738_out),
        .O(\input_r_Addr_A[4]_INST_0_i_11_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'hFE00)) 
    \input_r_Addr_A[4]_INST_0_i_12 
       (.I0(ap_CS_fsm_pp0_stage5),
        .I1(ap_CS_fsm_pp0_stage4),
        .I2(ap_CS_fsm_pp0_stage6),
        .I3(ap_enable_reg_pp0_iter0),
        .O(\input_r_Addr_A[4]_INST_0_i_12_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair78" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[4]_INST_0_i_13 
       (.I0(tmp_83_reg_2990_reg__0[0]),
        .I1(tmp_39_0_2_cast_cast_reg_2794[2]),
        .O(data16[2]));
  CARRY4 \input_r_Addr_A[4]_INST_0_i_14 
       (.CI(1'b0),
        .CO({\input_r_Addr_A[4]_INST_0_i_14_n_4 ,\input_r_Addr_A[4]_INST_0_i_14_n_5 ,\input_r_Addr_A[4]_INST_0_i_14_n_6 ,\input_r_Addr_A[4]_INST_0_i_14_n_7 }),
        .CYINIT(1'b0),
        .DI({tmp_6_cast_reg_2838_reg__0[4:3],p_shl10_cast_fu_1237_p1[5],1'b0}),
        .O({data18[4:2],\NLW_input_r_Addr_A[4]_INST_0_i_14_O_UNCONNECTED [0]}),
        .S({\input_r_Addr_A[4]_INST_0_i_22_n_4 ,\input_r_Addr_A[4]_INST_0_i_23_n_4 ,\input_r_Addr_A[4]_INST_0_i_24_n_4 ,data7[1]}));
  (* SOFT_HLUTNM = "soft_lutpair78" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[4]_INST_0_i_15 
       (.I0(tmp_83_reg_2990_reg__0[0]),
        .I1(tmp_39_0_1_cast_cast_reg_2871_reg__0[2]),
        .O(data17[2]));
  (* SOFT_HLUTNM = "soft_lutpair83" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \input_r_Addr_A[4]_INST_0_i_16 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage7),
        .O(reg_631940_out));
  (* SOFT_HLUTNM = "soft_lutpair84" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \input_r_Addr_A[4]_INST_0_i_17 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage8),
        .O(reg_6311041_out));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[4]_INST_0_i_18 
       (.I0(tmp_109_reg_3426[2]),
        .I1(tmp_123_reg_3446[2]),
        .I2(tmp_103_reg_3416[2]),
        .I3(reg_6312555_out),
        .I4(reg_6312454_out),
        .I5(reg_63125),
        .O(\input_r_Addr_A[4]_INST_0_i_18_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[4]_INST_0_i_19 
       (.I0(tmp_118_reg_3441[2]),
        .I1(data6[2]),
        .I2(tmp_113_reg_3431[2]),
        .I3(reg_6312353_out),
        .I4(reg_6312151_out),
        .I5(reg_6312252_out),
        .O(\input_r_Addr_A[4]_INST_0_i_19_n_4 ));
  LUT6 #(
    .INIT(64'h3333300022222222)) 
    \input_r_Addr_A[4]_INST_0_i_2 
       (.I0(\input_r_Addr_A[4]_INST_0_i_8_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .I2(data19[2]),
        .I3(reg_631839_out),
        .I4(\input_r_Addr_A[4]_INST_0_i_11_n_4 ),
        .I5(\input_r_Addr_A[4]_INST_0_i_12_n_4 ),
        .O(\input_r_Addr_A[4]_INST_0_i_2_n_4 ));
  LUT6 #(
    .INIT(64'h000F0F0002020808)) 
    \input_r_Addr_A[4]_INST_0_i_20 
       (.I0(reg_6311545_out),
        .I1(tmp_39_0_1_cast_cast_reg_2871_reg__0[2]),
        .I2(reg_6311747_out),
        .I3(tmp_39_0_3_cast_cast_reg_2917_reg__0[2]),
        .I4(\tmp_89_reg_2786_reg_n_4_[2] ),
        .I5(reg_6311646_out),
        .O(\input_r_Addr_A[4]_INST_0_i_20_n_4 ));
  LUT6 #(
    .INIT(64'h000F0F0002020808)) 
    \input_r_Addr_A[4]_INST_0_i_21 
       (.I0(reg_6311242_out),
        .I1(tmp_39_0_3_cast_cast_reg_2917_reg__0[2]),
        .I2(reg_6311444_out),
        .I3(tmp_39_0_4_cast_cast_reg_2812_reg__0[2]),
        .I4(tmp_83_reg_2990_reg__0[0]),
        .I5(reg_6311343_out),
        .O(\input_r_Addr_A[4]_INST_0_i_21_n_4 ));
  LUT4 #(
    .INIT(16'hA956)) 
    \input_r_Addr_A[4]_INST_0_i_22 
       (.I0(p_shl10_cast_fu_1237_p1[7]),
        .I1(p_shl10_cast_fu_1237_p1[6]),
        .I2(p_shl10_cast_fu_1237_p1[5]),
        .I3(tmp_6_cast_reg_2838_reg__0[4]),
        .O(\input_r_Addr_A[4]_INST_0_i_22_n_4 ));
  LUT3 #(
    .INIT(8'h96)) 
    \input_r_Addr_A[4]_INST_0_i_23 
       (.I0(p_shl10_cast_fu_1237_p1[6]),
        .I1(p_shl10_cast_fu_1237_p1[5]),
        .I2(tmp_6_cast_reg_2838_reg__0[3]),
        .O(\input_r_Addr_A[4]_INST_0_i_23_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[4]_INST_0_i_24 
       (.I0(p_shl10_cast_fu_1237_p1[5]),
        .I1(tmp_6_cast_reg_2838_reg__0[2]),
        .O(\input_r_Addr_A[4]_INST_0_i_24_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair77" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[4]_INST_0_i_25 
       (.I0(tmp_95_reg_3368_reg__0[0]),
        .I1(tmp_39_0_1_cast_cast_reg_2871_reg__0[2]),
        .O(data6[2]));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[4]_INST_0_i_3 
       (.I0(data16[2]),
        .I1(data18[2]),
        .I2(data17[2]),
        .I3(conv1_bias_EN_A),
        .I4(reg_631940_out),
        .I5(reg_6311041_out),
        .O(\input_r_Addr_A[4]_INST_0_i_3_n_4 ));
  LUT6 #(
    .INIT(64'hFFBABABA00BABABA)) 
    \input_r_Addr_A[4]_INST_0_i_4 
       (.I0(\input_r_Addr_A[4]_INST_0_i_18_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_24_n_4 ),
        .I2(\input_r_Addr_A[4]_INST_0_i_19_n_4 ),
        .I3(ap_CS_fsm_pp0_stage0),
        .I4(ap_enable_reg_pp0_iter1_reg_n_4),
        .I5(tmp_114_reg_3436[2]),
        .O(\input_r_Addr_A[4]_INST_0_i_4_n_4 ));
  LUT6 #(
    .INIT(64'hFFFF600000000000)) 
    \input_r_Addr_A[4]_INST_0_i_5 
       (.I0(tmp_39_0_2_cast_cast_reg_2794[2]),
        .I1(tmp_92_reg_2830_reg__0[0]),
        .I2(ap_CS_fsm_pp0_stage15),
        .I3(ap_enable_reg_pp0_iter0),
        .I4(\input_r_Addr_A[4]_INST_0_i_20_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_7_n_4 ),
        .O(\input_r_Addr_A[4]_INST_0_i_5_n_4 ));
  LUT6 #(
    .INIT(64'h0000000088A8A888)) 
    \input_r_Addr_A[4]_INST_0_i_6 
       (.I0(\conv1_kernel_Addr_A[10]_INST_0_i_8_n_4 ),
        .I1(\input_r_Addr_A[4]_INST_0_i_21_n_4 ),
        .I2(reg_6311444_out),
        .I3(\tmp_89_reg_2786_reg_n_4_[2] ),
        .I4(tmp_6_cast_reg_2838_reg__0[2]),
        .I5(\input_r_Addr_A[12]_INST_0_i_7_n_4 ),
        .O(\input_r_Addr_A[4]_INST_0_i_6_n_4 ));
  LUT6 #(
    .INIT(64'h000F0F0002020808)) 
    \input_r_Addr_A[4]_INST_0_i_7 
       (.I0(reg_6311848_out),
        .I1(tmp_39_0_3_cast_cast_reg_2917_reg__0[2]),
        .I2(reg_6312050_out),
        .I3(tmp_39_0_4_cast_cast_reg_2812_reg__0[2]),
        .I4(tmp_92_reg_2830_reg__0[0]),
        .I5(reg_6311949_out),
        .O(\input_r_Addr_A[4]_INST_0_i_7_n_4 ));
  LUT6 #(
    .INIT(64'hFFFFD7820000D782)) 
    \input_r_Addr_A[4]_INST_0_i_8 
       (.I0(reg_631435_out),
        .I1(\tmp_89_reg_2786_reg_n_4_[2] ),
        .I2(\x_mid2_reg_2734_reg_n_4_[2] ),
        .I3(data24[2]),
        .I4(reg_631536_out),
        .I5(data22[2]),
        .O(\input_r_Addr_A[4]_INST_0_i_8_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair80" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[4]_INST_0_i_9 
       (.I0(tmp_98_reg_2909[2]),
        .I1(tmp_39_0_4_cast_cast_reg_2812_reg__0[2]),
        .O(data19[2]));
  LUT6 #(
    .INIT(64'hFFFFFDA80000FDA8)) 
    \input_r_Addr_A[5]_INST_0 
       (.I0(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .I1(\input_r_Addr_A[5]_INST_0_i_1_n_4 ),
        .I2(\input_r_Addr_A[5]_INST_0_i_2_n_4 ),
        .I3(\input_r_Addr_A[5]_INST_0_i_3_n_4 ),
        .I4(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I5(\input_r_Addr_A[5]_INST_0_i_4_n_4 ),
        .O(input_r_Addr_A[3]));
  LUT6 #(
    .INIT(64'h3333300022222222)) 
    \input_r_Addr_A[5]_INST_0_i_1 
       (.I0(\input_r_Addr_A[5]_INST_0_i_5_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .I2(data10[3]),
        .I3(reg_6311747_out),
        .I4(\input_r_Addr_A[5]_INST_0_i_6_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_7_n_4 ),
        .O(\input_r_Addr_A[5]_INST_0_i_1_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[5]_INST_0_i_10 
       (.I0(tmp_109_reg_3426[3]),
        .I1(tmp_123_reg_3446[3]),
        .I2(tmp_103_reg_3416[3]),
        .I3(reg_6312555_out),
        .I4(reg_6312454_out),
        .I5(reg_63125),
        .O(\input_r_Addr_A[5]_INST_0_i_10_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[5]_INST_0_i_11 
       (.I0(tmp_118_reg_3441[3]),
        .I1(data6[3]),
        .I2(tmp_113_reg_3431[3]),
        .I3(reg_6312353_out),
        .I4(reg_6312151_out),
        .I5(reg_6312252_out),
        .O(\input_r_Addr_A[5]_INST_0_i_11_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[5]_INST_0_i_2 
       (.I0(data7[3]),
        .I1(data9[3]),
        .I2(data8[3]),
        .I3(reg_6312050_out),
        .I4(reg_6311848_out),
        .I5(reg_6311949_out),
        .O(\input_r_Addr_A[5]_INST_0_i_2_n_4 ));
  LUT6 #(
    .INIT(64'hFEFEFE0EFE0EFE0E)) 
    \input_r_Addr_A[5]_INST_0_i_3 
       (.I0(\input_r_Addr_A[5]_INST_0_i_7_n_4 ),
        .I1(\input_r_Addr_A[5]_INST_0_i_8_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .I3(\input_r_Addr_A[5]_INST_0_i_9_n_4 ),
        .I4(conv1_bias_EN_A),
        .I5(data16[3]),
        .O(\input_r_Addr_A[5]_INST_0_i_3_n_4 ));
  LUT6 #(
    .INIT(64'hFFBABABA00BABABA)) 
    \input_r_Addr_A[5]_INST_0_i_4 
       (.I0(\input_r_Addr_A[5]_INST_0_i_10_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_24_n_4 ),
        .I2(\input_r_Addr_A[5]_INST_0_i_11_n_4 ),
        .I3(ap_CS_fsm_pp0_stage0),
        .I4(ap_enable_reg_pp0_iter1_reg_n_4),
        .I5(tmp_114_reg_3436[3]),
        .O(\input_r_Addr_A[5]_INST_0_i_4_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[5]_INST_0_i_5 
       (.I0(data13[3]),
        .I1(data15[3]),
        .I2(data14[3]),
        .I3(reg_6311444_out),
        .I4(reg_6311242_out),
        .I5(reg_6311343_out),
        .O(\input_r_Addr_A[5]_INST_0_i_5_n_4 ));
  LUT6 #(
    .INIT(64'h00F0000000800080)) 
    \input_r_Addr_A[5]_INST_0_i_6 
       (.I0(ap_CS_fsm_pp0_stage13),
        .I1(data12[3]),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage15),
        .I4(data11[3]),
        .I5(ap_CS_fsm_pp0_stage14),
        .O(\input_r_Addr_A[5]_INST_0_i_6_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[5]_INST_0_i_7 
       (.I0(data19[3]),
        .I1(data21[3]),
        .I2(data20[3]),
        .I3(reg_631839_out),
        .I4(reg_631637_out),
        .I5(reg_631738_out),
        .O(\input_r_Addr_A[5]_INST_0_i_7_n_4 ));
  LUT6 #(
    .INIT(64'h00000000BB88B8B8)) 
    \input_r_Addr_A[5]_INST_0_i_8 
       (.I0(data22[3]),
        .I1(reg_631536_out),
        .I2(data24[3]),
        .I3(data23[3]),
        .I4(reg_631435_out),
        .I5(\input_r_Addr_A[4]_INST_0_i_12_n_4 ),
        .O(\input_r_Addr_A[5]_INST_0_i_8_n_4 ));
  LUT6 #(
    .INIT(64'h00F0000000800080)) 
    \input_r_Addr_A[5]_INST_0_i_9 
       (.I0(ap_CS_fsm_pp0_stage7),
        .I1(data18[3]),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage9),
        .I4(data17[3]),
        .I5(ap_CS_fsm_pp0_stage8),
        .O(\input_r_Addr_A[5]_INST_0_i_9_n_4 ));
  LUT6 #(
    .INIT(64'hFFFFFDA80000FDA8)) 
    \input_r_Addr_A[6]_INST_0 
       (.I0(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .I1(\input_r_Addr_A[6]_INST_0_i_1_n_4 ),
        .I2(\input_r_Addr_A[6]_INST_0_i_2_n_4 ),
        .I3(\input_r_Addr_A[6]_INST_0_i_3_n_4 ),
        .I4(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I5(\input_r_Addr_A[6]_INST_0_i_4_n_4 ),
        .O(input_r_Addr_A[4]));
  LUT6 #(
    .INIT(64'h3333300022222222)) 
    \input_r_Addr_A[6]_INST_0_i_1 
       (.I0(\input_r_Addr_A[6]_INST_0_i_5_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .I2(data10[4]),
        .I3(reg_6311747_out),
        .I4(\input_r_Addr_A[6]_INST_0_i_6_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_7_n_4 ),
        .O(\input_r_Addr_A[6]_INST_0_i_1_n_4 ));
  LUT6 #(
    .INIT(64'h00F0000000800080)) 
    \input_r_Addr_A[6]_INST_0_i_10 
       (.I0(ap_CS_fsm_pp0_stage7),
        .I1(data18[4]),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage9),
        .I4(data17[4]),
        .I5(ap_CS_fsm_pp0_stage8),
        .O(\input_r_Addr_A[6]_INST_0_i_10_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[6]_INST_0_i_11 
       (.I0(tmp_109_reg_3426[4]),
        .I1(tmp_123_reg_3446[4]),
        .I2(tmp_103_reg_3416[4]),
        .I3(reg_6312555_out),
        .I4(reg_6312454_out),
        .I5(reg_63125),
        .O(\input_r_Addr_A[6]_INST_0_i_11_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[6]_INST_0_i_12 
       (.I0(tmp_118_reg_3441[4]),
        .I1(data6[4]),
        .I2(tmp_113_reg_3431[4]),
        .I3(reg_6312353_out),
        .I4(reg_6312151_out),
        .I5(reg_6312252_out),
        .O(\input_r_Addr_A[6]_INST_0_i_12_n_4 ));
  LUT4 #(
    .INIT(16'hA956)) 
    \input_r_Addr_A[6]_INST_0_i_13 
       (.I0(tmp_37_3_cast_mid2_reg_2764[2]),
        .I1(tmp_37_3_cast_mid2_reg_2764[1]),
        .I2(tmp_37_3_cast_mid2_reg_2764[0]),
        .I3(tmp_6_cast_reg_2838_reg__0[4]),
        .O(\input_r_Addr_A[6]_INST_0_i_13_n_4 ));
  LUT3 #(
    .INIT(8'h96)) 
    \input_r_Addr_A[6]_INST_0_i_14 
       (.I0(tmp_37_3_cast_mid2_reg_2764[1]),
        .I1(tmp_37_3_cast_mid2_reg_2764[0]),
        .I2(tmp_6_cast_reg_2838_reg__0[3]),
        .O(\input_r_Addr_A[6]_INST_0_i_14_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[6]_INST_0_i_15 
       (.I0(tmp_37_3_cast_mid2_reg_2764[0]),
        .I1(tmp_6_cast_reg_2838_reg__0[2]),
        .O(\input_r_Addr_A[6]_INST_0_i_15_n_4 ));
  CARRY4 \input_r_Addr_A[6]_INST_0_i_16 
       (.CI(1'b0),
        .CO({\input_r_Addr_A[6]_INST_0_i_16_n_4 ,\input_r_Addr_A[6]_INST_0_i_16_n_5 ,\input_r_Addr_A[6]_INST_0_i_16_n_6 ,\input_r_Addr_A[6]_INST_0_i_16_n_7 }),
        .CYINIT(1'b0),
        .DI({\tmp_98_reg_2909[4]_i_1_n_4 ,\tmp_98_reg_2909[3]_i_1_n_4 ,tmp_37_4_cast_mid2_reg_2770[0],1'b0}),
        .O(data20[4:1]),
        .S({\input_r_Addr_A[6]_INST_0_i_19_n_4 ,\input_r_Addr_A[6]_INST_0_i_20_n_4 ,\input_r_Addr_A[6]_INST_0_i_21_n_4 ,\input_r_Addr_A[6]_INST_0_i_22_n_4 }));
  CARRY4 \input_r_Addr_A[6]_INST_0_i_17 
       (.CI(1'b0),
        .CO({\input_r_Addr_A[6]_INST_0_i_17_n_4 ,\input_r_Addr_A[6]_INST_0_i_17_n_5 ,\input_r_Addr_A[6]_INST_0_i_17_n_6 ,\input_r_Addr_A[6]_INST_0_i_17_n_7 }),
        .CYINIT(1'b0),
        .DI({\x_mid2_reg_2734_reg_n_4_[4] ,\x_mid2_reg_2734_reg_n_4_[3] ,tmp_37_4_cast_mid2_reg_2770[0],1'b0}),
        .O(data22[4:1]),
        .S({\input_r_Addr_A[6]_INST_0_i_23_n_4 ,\input_r_Addr_A[6]_INST_0_i_24_n_4 ,\input_r_Addr_A[6]_INST_0_i_25_n_4 ,\x_mid2_reg_2734_reg_n_4_[1] }));
  CARRY4 \input_r_Addr_A[6]_INST_0_i_18 
       (.CI(1'b0),
        .CO({\input_r_Addr_A[6]_INST_0_i_18_n_4 ,\input_r_Addr_A[6]_INST_0_i_18_n_5 ,\input_r_Addr_A[6]_INST_0_i_18_n_6 ,\input_r_Addr_A[6]_INST_0_i_18_n_7 }),
        .CYINIT(1'b0),
        .DI({\tmp_89_reg_2786[4]_i_1_n_4 ,\input_r_Addr_A[6]_INST_0_i_26_n_4 ,tmp_37_3_cast_mid2_reg_2764[0],1'b0}),
        .O(data24[4:1]),
        .S({\input_r_Addr_A[6]_INST_0_i_27_n_4 ,\input_r_Addr_A[6]_INST_0_i_28_n_4 ,\input_r_Addr_A[6]_INST_0_i_29_n_4 ,\input_r_Addr_A[6]_INST_0_i_30_n_4 }));
  LUT6 #(
    .INIT(64'h9696966666666666)) 
    \input_r_Addr_A[6]_INST_0_i_19 
       (.I0(\tmp_98_reg_2909[4]_i_1_n_4 ),
        .I1(\x_mid2_reg_2734_reg_n_4_[4] ),
        .I2(\x_mid2_reg_2734_reg_n_4_[3] ),
        .I3(\x_mid2_reg_2734_reg_n_4_[0] ),
        .I4(\x_mid2_reg_2734_reg_n_4_[1] ),
        .I5(\x_mid2_reg_2734_reg_n_4_[2] ),
        .O(\input_r_Addr_A[6]_INST_0_i_19_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[6]_INST_0_i_2 
       (.I0(data7[4]),
        .I1(data9[4]),
        .I2(data8[4]),
        .I3(reg_6312050_out),
        .I4(reg_6311848_out),
        .I5(reg_6311949_out),
        .O(\input_r_Addr_A[6]_INST_0_i_2_n_4 ));
  LUT6 #(
    .INIT(64'h6996699669969696)) 
    \input_r_Addr_A[6]_INST_0_i_20 
       (.I0(tmp_37_4_cast_mid2_reg_2770[1]),
        .I1(tmp_37_4_cast_mid2_reg_2770[0]),
        .I2(\x_mid2_reg_2734_reg_n_4_[3] ),
        .I3(\x_mid2_reg_2734_reg_n_4_[2] ),
        .I4(\x_mid2_reg_2734_reg_n_4_[1] ),
        .I5(\x_mid2_reg_2734_reg_n_4_[0] ),
        .O(\input_r_Addr_A[6]_INST_0_i_20_n_4 ));
  LUT4 #(
    .INIT(16'h9996)) 
    \input_r_Addr_A[6]_INST_0_i_21 
       (.I0(tmp_37_4_cast_mid2_reg_2770[0]),
        .I1(\x_mid2_reg_2734_reg_n_4_[2] ),
        .I2(\x_mid2_reg_2734_reg_n_4_[0] ),
        .I3(\x_mid2_reg_2734_reg_n_4_[1] ),
        .O(\input_r_Addr_A[6]_INST_0_i_21_n_4 ));
  LUT2 #(
    .INIT(4'h9)) 
    \input_r_Addr_A[6]_INST_0_i_22 
       (.I0(\x_mid2_reg_2734_reg_n_4_[1] ),
        .I1(\x_mid2_reg_2734_reg_n_4_[0] ),
        .O(\input_r_Addr_A[6]_INST_0_i_22_n_4 ));
  LUT4 #(
    .INIT(16'hA956)) 
    \input_r_Addr_A[6]_INST_0_i_23 
       (.I0(tmp_37_2_cast_mid2_reg_2758[2]),
        .I1(tmp_37_2_cast_mid2_reg_2758[1]),
        .I2(tmp_37_4_cast_mid2_reg_2770[0]),
        .I3(\x_mid2_reg_2734_reg_n_4_[4] ),
        .O(\input_r_Addr_A[6]_INST_0_i_23_n_4 ));
  LUT3 #(
    .INIT(8'h96)) 
    \input_r_Addr_A[6]_INST_0_i_24 
       (.I0(tmp_37_2_cast_mid2_reg_2758[1]),
        .I1(tmp_37_4_cast_mid2_reg_2770[0]),
        .I2(\x_mid2_reg_2734_reg_n_4_[3] ),
        .O(\input_r_Addr_A[6]_INST_0_i_24_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[6]_INST_0_i_25 
       (.I0(tmp_37_4_cast_mid2_reg_2770[0]),
        .I1(\x_mid2_reg_2734_reg_n_4_[2] ),
        .O(\input_r_Addr_A[6]_INST_0_i_25_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[6]_INST_0_i_26 
       (.I0(tmp_37_3_cast_mid2_reg_2764[0]),
        .I1(p_shl6_cast_fu_878_p1[6]),
        .O(\input_r_Addr_A[6]_INST_0_i_26_n_4 ));
  LUT5 #(
    .INIT(32'h96666666)) 
    \input_r_Addr_A[6]_INST_0_i_27 
       (.I0(\tmp_89_reg_2786[4]_i_1_n_4 ),
        .I1(\x_mid2_reg_2734_reg_n_4_[4] ),
        .I2(\x_mid2_reg_2734_reg_n_4_[3] ),
        .I3(\x_mid2_reg_2734_reg_n_4_[1] ),
        .I4(\x_mid2_reg_2734_reg_n_4_[2] ),
        .O(\input_r_Addr_A[6]_INST_0_i_27_n_4 ));
  LUT5 #(
    .INIT(32'h69969696)) 
    \input_r_Addr_A[6]_INST_0_i_28 
       (.I0(p_shl6_cast_fu_878_p1[6]),
        .I1(tmp_37_3_cast_mid2_reg_2764[0]),
        .I2(\x_mid2_reg_2734_reg_n_4_[3] ),
        .I3(\x_mid2_reg_2734_reg_n_4_[2] ),
        .I4(\x_mid2_reg_2734_reg_n_4_[1] ),
        .O(\input_r_Addr_A[6]_INST_0_i_28_n_4 ));
  LUT3 #(
    .INIT(8'h96)) 
    \input_r_Addr_A[6]_INST_0_i_29 
       (.I0(tmp_37_3_cast_mid2_reg_2764[0]),
        .I1(\x_mid2_reg_2734_reg_n_4_[2] ),
        .I2(\x_mid2_reg_2734_reg_n_4_[1] ),
        .O(\input_r_Addr_A[6]_INST_0_i_29_n_4 ));
  LUT6 #(
    .INIT(64'hFEFEFE0EFE0EFE0E)) 
    \input_r_Addr_A[6]_INST_0_i_3 
       (.I0(\input_r_Addr_A[6]_INST_0_i_8_n_4 ),
        .I1(\input_r_Addr_A[6]_INST_0_i_9_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .I3(\input_r_Addr_A[6]_INST_0_i_10_n_4 ),
        .I4(conv1_bias_EN_A),
        .I5(data16[4]),
        .O(\input_r_Addr_A[6]_INST_0_i_3_n_4 ));
  LUT1 #(
    .INIT(2'h1)) 
    \input_r_Addr_A[6]_INST_0_i_30 
       (.I0(\x_mid2_reg_2734_reg_n_4_[1] ),
        .O(\input_r_Addr_A[6]_INST_0_i_30_n_4 ));
  LUT6 #(
    .INIT(64'hFFBABABA00BABABA)) 
    \input_r_Addr_A[6]_INST_0_i_4 
       (.I0(\input_r_Addr_A[6]_INST_0_i_11_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_24_n_4 ),
        .I2(\input_r_Addr_A[6]_INST_0_i_12_n_4 ),
        .I3(ap_CS_fsm_pp0_stage0),
        .I4(ap_enable_reg_pp0_iter1_reg_n_4),
        .I5(tmp_114_reg_3436[4]),
        .O(\input_r_Addr_A[6]_INST_0_i_4_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[6]_INST_0_i_5 
       (.I0(data13[4]),
        .I1(data15[4]),
        .I2(data14[4]),
        .I3(reg_6311444_out),
        .I4(reg_6311242_out),
        .I5(reg_6311343_out),
        .O(\input_r_Addr_A[6]_INST_0_i_5_n_4 ));
  LUT6 #(
    .INIT(64'h00F0000000800080)) 
    \input_r_Addr_A[6]_INST_0_i_6 
       (.I0(ap_CS_fsm_pp0_stage13),
        .I1(data12[4]),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage15),
        .I4(data11[4]),
        .I5(ap_CS_fsm_pp0_stage14),
        .O(\input_r_Addr_A[6]_INST_0_i_6_n_4 ));
  CARRY4 \input_r_Addr_A[6]_INST_0_i_7 
       (.CI(1'b0),
        .CO({\input_r_Addr_A[6]_INST_0_i_7_n_4 ,\input_r_Addr_A[6]_INST_0_i_7_n_5 ,\input_r_Addr_A[6]_INST_0_i_7_n_6 ,\input_r_Addr_A[6]_INST_0_i_7_n_7 }),
        .CYINIT(1'b0),
        .DI({tmp_6_cast_reg_2838_reg__0[4:3],tmp_37_3_cast_mid2_reg_2764[0],1'b0}),
        .O({data7[4:2],data18[1]}),
        .S({\input_r_Addr_A[6]_INST_0_i_13_n_4 ,\input_r_Addr_A[6]_INST_0_i_14_n_4 ,\input_r_Addr_A[6]_INST_0_i_15_n_4 ,data7[1]}));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[6]_INST_0_i_8 
       (.I0(data19[4]),
        .I1(data21[4]),
        .I2(data20[4]),
        .I3(reg_631839_out),
        .I4(reg_631637_out),
        .I5(reg_631738_out),
        .O(\input_r_Addr_A[6]_INST_0_i_8_n_4 ));
  LUT6 #(
    .INIT(64'h00000000BB88B8B8)) 
    \input_r_Addr_A[6]_INST_0_i_9 
       (.I0(data22[4]),
        .I1(reg_631536_out),
        .I2(data24[4]),
        .I3(data23[4]),
        .I4(reg_631435_out),
        .I5(\input_r_Addr_A[4]_INST_0_i_12_n_4 ),
        .O(\input_r_Addr_A[6]_INST_0_i_9_n_4 ));
  LUT6 #(
    .INIT(64'hFFFFFDA80000FDA8)) 
    \input_r_Addr_A[7]_INST_0 
       (.I0(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .I1(\input_r_Addr_A[7]_INST_0_i_1_n_4 ),
        .I2(\input_r_Addr_A[7]_INST_0_i_2_n_4 ),
        .I3(\input_r_Addr_A[7]_INST_0_i_3_n_4 ),
        .I4(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I5(\input_r_Addr_A[7]_INST_0_i_4_n_4 ),
        .O(input_r_Addr_A[5]));
  LUT6 #(
    .INIT(64'h3333300022222222)) 
    \input_r_Addr_A[7]_INST_0_i_1 
       (.I0(\input_r_Addr_A[7]_INST_0_i_5_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .I2(data10[5]),
        .I3(reg_6311747_out),
        .I4(\input_r_Addr_A[7]_INST_0_i_7_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_7_n_4 ),
        .O(\input_r_Addr_A[7]_INST_0_i_1_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[7]_INST_0_i_10 
       (.I0(data19[5]),
        .I1(data21[5]),
        .I2(data20[5]),
        .I3(reg_631839_out),
        .I4(reg_631637_out),
        .I5(reg_631738_out),
        .O(\input_r_Addr_A[7]_INST_0_i_10_n_4 ));
  LUT6 #(
    .INIT(64'h00000000BB88B8B8)) 
    \input_r_Addr_A[7]_INST_0_i_11 
       (.I0(data22[5]),
        .I1(reg_631536_out),
        .I2(data24[5]),
        .I3(data23[5]),
        .I4(reg_631435_out),
        .I5(\input_r_Addr_A[4]_INST_0_i_12_n_4 ),
        .O(\input_r_Addr_A[7]_INST_0_i_11_n_4 ));
  LUT6 #(
    .INIT(64'h00F0000000800080)) 
    \input_r_Addr_A[7]_INST_0_i_12 
       (.I0(ap_CS_fsm_pp0_stage7),
        .I1(data18[5]),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage9),
        .I4(data17[5]),
        .I5(ap_CS_fsm_pp0_stage8),
        .O(\input_r_Addr_A[7]_INST_0_i_12_n_4 ));
  CARRY4 \input_r_Addr_A[7]_INST_0_i_13 
       (.CI(1'b0),
        .CO({\input_r_Addr_A[7]_INST_0_i_13_n_4 ,\input_r_Addr_A[7]_INST_0_i_13_n_5 ,\input_r_Addr_A[7]_INST_0_i_13_n_6 ,\input_r_Addr_A[7]_INST_0_i_13_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_83_reg_2990_reg__0[3:0]),
        .O({data16[5:3],\NLW_input_r_Addr_A[7]_INST_0_i_13_O_UNCONNECTED [0]}),
        .S({tmp_83_reg_2990_reg__0[3],\input_r_Addr_A[7]_INST_0_i_34_n_4 ,\input_r_Addr_A[7]_INST_0_i_35_n_4 ,\input_r_Addr_A[7]_INST_0_i_36_n_4 }));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[7]_INST_0_i_14 
       (.I0(tmp_109_reg_3426[5]),
        .I1(tmp_123_reg_3446[5]),
        .I2(tmp_103_reg_3416[5]),
        .I3(reg_6312555_out),
        .I4(reg_6312454_out),
        .I5(reg_63125),
        .O(\input_r_Addr_A[7]_INST_0_i_14_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[7]_INST_0_i_15 
       (.I0(tmp_118_reg_3441[5]),
        .I1(data6[5]),
        .I2(tmp_113_reg_3431[5]),
        .I3(reg_6312353_out),
        .I4(reg_6312151_out),
        .I5(reg_6312252_out),
        .O(\input_r_Addr_A[7]_INST_0_i_15_n_4 ));
  CARRY4 \input_r_Addr_A[7]_INST_0_i_16 
       (.CI(1'b0),
        .CO({\input_r_Addr_A[7]_INST_0_i_16_n_4 ,\input_r_Addr_A[7]_INST_0_i_16_n_5 ,\input_r_Addr_A[7]_INST_0_i_16_n_6 ,\input_r_Addr_A[7]_INST_0_i_16_n_7 }),
        .CYINIT(1'b0),
        .DI({\tmp_89_reg_2786_reg_n_4_[5] ,\tmp_89_reg_2786_reg_n_4_[4] ,\tmp_89_reg_2786_reg_n_4_[3] ,\tmp_89_reg_2786_reg_n_4_[2] }),
        .O({data13[5:3],\NLW_input_r_Addr_A[7]_INST_0_i_16_O_UNCONNECTED [0]}),
        .S({\tmp_89_reg_2786_reg_n_4_[5] ,\input_r_Addr_A[7]_INST_0_i_38_n_4 ,\input_r_Addr_A[7]_INST_0_i_39_n_4 ,data13[2]}));
  CARRY4 \input_r_Addr_A[7]_INST_0_i_17 
       (.CI(1'b0),
        .CO({\input_r_Addr_A[7]_INST_0_i_17_n_4 ,\input_r_Addr_A[7]_INST_0_i_17_n_5 ,\input_r_Addr_A[7]_INST_0_i_17_n_6 ,\input_r_Addr_A[7]_INST_0_i_17_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_83_reg_2990_reg__0[3:0]),
        .O({data15[5:3],\NLW_input_r_Addr_A[7]_INST_0_i_17_O_UNCONNECTED [0]}),
        .S({tmp_83_reg_2990_reg__0[3],\input_r_Addr_A[7]_INST_0_i_41_n_4 ,\input_r_Addr_A[7]_INST_0_i_42_n_4 ,data15[2]}));
  CARRY4 \input_r_Addr_A[7]_INST_0_i_18 
       (.CI(1'b0),
        .CO({\input_r_Addr_A[7]_INST_0_i_18_n_4 ,\input_r_Addr_A[7]_INST_0_i_18_n_5 ,\input_r_Addr_A[7]_INST_0_i_18_n_6 ,\input_r_Addr_A[7]_INST_0_i_18_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_83_reg_2990_reg__0[3:0]),
        .O({data14[5:3],\NLW_input_r_Addr_A[7]_INST_0_i_18_O_UNCONNECTED [0]}),
        .S({tmp_83_reg_2990_reg__0[3],\input_r_Addr_A[7]_INST_0_i_44_n_4 ,\input_r_Addr_A[7]_INST_0_i_45_n_4 ,data14[2]}));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_19 
       (.I0(tmp_92_reg_2830_reg__0[2]),
        .I1(tmp_39_0_2_cast_cast_reg_2794[4]),
        .O(\input_r_Addr_A[7]_INST_0_i_19_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[7]_INST_0_i_2 
       (.I0(data7[5]),
        .I1(data9[5]),
        .I2(data8[5]),
        .I3(reg_6312050_out),
        .I4(reg_6311848_out),
        .I5(reg_6311949_out),
        .O(\input_r_Addr_A[7]_INST_0_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_20 
       (.I0(tmp_92_reg_2830_reg__0[1]),
        .I1(tmp_39_0_2_cast_cast_reg_2794[3]),
        .O(\input_r_Addr_A[7]_INST_0_i_20_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_21 
       (.I0(tmp_92_reg_2830_reg__0[0]),
        .I1(tmp_39_0_2_cast_cast_reg_2794[2]),
        .O(data10[2]));
  CARRY4 \input_r_Addr_A[7]_INST_0_i_22 
       (.CI(1'b0),
        .CO({\input_r_Addr_A[7]_INST_0_i_22_n_4 ,\input_r_Addr_A[7]_INST_0_i_22_n_5 ,\input_r_Addr_A[7]_INST_0_i_22_n_6 ,\input_r_Addr_A[7]_INST_0_i_22_n_7 }),
        .CYINIT(1'b0),
        .DI({\tmp_89_reg_2786_reg_n_4_[5] ,\tmp_89_reg_2786_reg_n_4_[4] ,\tmp_89_reg_2786_reg_n_4_[3] ,\tmp_89_reg_2786_reg_n_4_[2] }),
        .O({data12[5:3],\NLW_input_r_Addr_A[7]_INST_0_i_22_O_UNCONNECTED [0]}),
        .S({\tmp_89_reg_2786_reg_n_4_[5] ,\input_r_Addr_A[7]_INST_0_i_47_n_4 ,\input_r_Addr_A[7]_INST_0_i_48_n_4 ,data12[2]}));
  CARRY4 \input_r_Addr_A[7]_INST_0_i_23 
       (.CI(1'b0),
        .CO({\input_r_Addr_A[7]_INST_0_i_23_n_4 ,\input_r_Addr_A[7]_INST_0_i_23_n_5 ,\input_r_Addr_A[7]_INST_0_i_23_n_6 ,\input_r_Addr_A[7]_INST_0_i_23_n_7 }),
        .CYINIT(1'b0),
        .DI({\tmp_89_reg_2786_reg_n_4_[5] ,\tmp_89_reg_2786_reg_n_4_[4] ,\tmp_89_reg_2786_reg_n_4_[3] ,\tmp_89_reg_2786_reg_n_4_[2] }),
        .O({data11[5:3],\NLW_input_r_Addr_A[7]_INST_0_i_23_O_UNCONNECTED [0]}),
        .S({\tmp_89_reg_2786_reg_n_4_[5] ,\input_r_Addr_A[7]_INST_0_i_50_n_4 ,\input_r_Addr_A[7]_INST_0_i_51_n_4 ,data11[2]}));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_24 
       (.I0(tmp_92_reg_2830_reg__0[2]),
        .I1(tmp_39_0_3_cast_cast_reg_2917_reg__0[4]),
        .O(\input_r_Addr_A[7]_INST_0_i_24_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_25 
       (.I0(tmp_92_reg_2830_reg__0[1]),
        .I1(tmp_39_0_3_cast_cast_reg_2917_reg__0[3]),
        .O(\input_r_Addr_A[7]_INST_0_i_25_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_26 
       (.I0(tmp_92_reg_2830_reg__0[0]),
        .I1(tmp_39_0_3_cast_cast_reg_2917_reg__0[2]),
        .O(data9[2]));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_27 
       (.I0(tmp_92_reg_2830_reg__0[2]),
        .I1(tmp_39_0_4_cast_cast_reg_2812_reg__0[4]),
        .O(\input_r_Addr_A[7]_INST_0_i_27_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_28 
       (.I0(tmp_92_reg_2830_reg__0[1]),
        .I1(tmp_39_0_4_cast_cast_reg_2812_reg__0[3]),
        .O(\input_r_Addr_A[7]_INST_0_i_28_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_29 
       (.I0(tmp_92_reg_2830_reg__0[0]),
        .I1(tmp_39_0_4_cast_cast_reg_2812_reg__0[2]),
        .O(data8[2]));
  LUT6 #(
    .INIT(64'hFEFEFE0EFE0EFE0E)) 
    \input_r_Addr_A[7]_INST_0_i_3 
       (.I0(\input_r_Addr_A[7]_INST_0_i_10_n_4 ),
        .I1(\input_r_Addr_A[7]_INST_0_i_11_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .I3(\input_r_Addr_A[7]_INST_0_i_12_n_4 ),
        .I4(conv1_bias_EN_A),
        .I5(data16[5]),
        .O(\input_r_Addr_A[7]_INST_0_i_3_n_4 ));
  CARRY4 \input_r_Addr_A[7]_INST_0_i_30 
       (.CI(1'b0),
        .CO({\input_r_Addr_A[7]_INST_0_i_30_n_4 ,\input_r_Addr_A[7]_INST_0_i_30_n_5 ,\input_r_Addr_A[7]_INST_0_i_30_n_6 ,\input_r_Addr_A[7]_INST_0_i_30_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_98_reg_2909[5:2]),
        .O({data19[5:3],\NLW_input_r_Addr_A[7]_INST_0_i_30_O_UNCONNECTED [0]}),
        .S({tmp_98_reg_2909[5],\input_r_Addr_A[7]_INST_0_i_53_n_4 ,\input_r_Addr_A[7]_INST_0_i_54_n_4 ,\input_r_Addr_A[7]_INST_0_i_55_n_4 }));
  CARRY4 \input_r_Addr_A[7]_INST_0_i_31 
       (.CI(1'b0),
        .CO({\input_r_Addr_A[7]_INST_0_i_31_n_4 ,\input_r_Addr_A[7]_INST_0_i_31_n_5 ,\input_r_Addr_A[7]_INST_0_i_31_n_6 ,\input_r_Addr_A[7]_INST_0_i_31_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,tmp_92_reg_2830_reg__0[2:0]}),
        .O({data21[5:3],\NLW_input_r_Addr_A[7]_INST_0_i_31_O_UNCONNECTED [0]}),
        .S({tmp_92_reg_2830_reg__0[3],\input_r_Addr_A[7]_INST_0_i_56_n_4 ,\input_r_Addr_A[7]_INST_0_i_57_n_4 ,data21[2]}));
  CARRY4 \input_r_Addr_A[7]_INST_0_i_32 
       (.CI(1'b0),
        .CO({\input_r_Addr_A[7]_INST_0_i_32_n_4 ,\input_r_Addr_A[7]_INST_0_i_32_n_5 ,\input_r_Addr_A[7]_INST_0_i_32_n_6 ,\input_r_Addr_A[7]_INST_0_i_32_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,\tmp_89_reg_2786_reg_n_4_[4] ,\tmp_89_reg_2786_reg_n_4_[3] ,\tmp_89_reg_2786_reg_n_4_[2] }),
        .O({data23[5:3],\NLW_input_r_Addr_A[7]_INST_0_i_32_O_UNCONNECTED [0]}),
        .S({\tmp_89_reg_2786_reg_n_4_[5] ,\input_r_Addr_A[7]_INST_0_i_59_n_4 ,\input_r_Addr_A[7]_INST_0_i_60_n_4 ,\input_r_Addr_A[7]_INST_0_i_61_n_4 }));
  CARRY4 \input_r_Addr_A[7]_INST_0_i_33 
       (.CI(1'b0),
        .CO({\input_r_Addr_A[7]_INST_0_i_33_n_4 ,\input_r_Addr_A[7]_INST_0_i_33_n_5 ,\input_r_Addr_A[7]_INST_0_i_33_n_6 ,\input_r_Addr_A[7]_INST_0_i_33_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_83_reg_2990_reg__0[3:0]),
        .O({data17[5:3],\NLW_input_r_Addr_A[7]_INST_0_i_33_O_UNCONNECTED [0]}),
        .S({tmp_83_reg_2990_reg__0[3],\input_r_Addr_A[7]_INST_0_i_62_n_4 ,\input_r_Addr_A[7]_INST_0_i_63_n_4 ,\input_r_Addr_A[7]_INST_0_i_64_n_4 }));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_34 
       (.I0(tmp_83_reg_2990_reg__0[2]),
        .I1(tmp_39_0_2_cast_cast_reg_2794[4]),
        .O(\input_r_Addr_A[7]_INST_0_i_34_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_35 
       (.I0(tmp_83_reg_2990_reg__0[1]),
        .I1(tmp_39_0_2_cast_cast_reg_2794[3]),
        .O(\input_r_Addr_A[7]_INST_0_i_35_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_36 
       (.I0(tmp_83_reg_2990_reg__0[0]),
        .I1(tmp_39_0_2_cast_cast_reg_2794[2]),
        .O(\input_r_Addr_A[7]_INST_0_i_36_n_4 ));
  CARRY4 \input_r_Addr_A[7]_INST_0_i_37 
       (.CI(1'b0),
        .CO({\input_r_Addr_A[7]_INST_0_i_37_n_4 ,\input_r_Addr_A[7]_INST_0_i_37_n_5 ,\input_r_Addr_A[7]_INST_0_i_37_n_6 ,\input_r_Addr_A[7]_INST_0_i_37_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_95_reg_3368_reg__0[3:0]),
        .O({data6[5:3],\NLW_input_r_Addr_A[7]_INST_0_i_37_O_UNCONNECTED [0]}),
        .S({tmp_95_reg_3368_reg__0[3],\input_r_Addr_A[7]_INST_0_i_65_n_4 ,\input_r_Addr_A[7]_INST_0_i_66_n_4 ,\input_r_Addr_A[7]_INST_0_i_67_n_4 }));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_38 
       (.I0(\tmp_89_reg_2786_reg_n_4_[4] ),
        .I1(tmp_6_cast_reg_2838_reg__0[4]),
        .O(\input_r_Addr_A[7]_INST_0_i_38_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_39 
       (.I0(\tmp_89_reg_2786_reg_n_4_[3] ),
        .I1(tmp_6_cast_reg_2838_reg__0[3]),
        .O(\input_r_Addr_A[7]_INST_0_i_39_n_4 ));
  LUT6 #(
    .INIT(64'hFFBABABA00BABABA)) 
    \input_r_Addr_A[7]_INST_0_i_4 
       (.I0(\input_r_Addr_A[7]_INST_0_i_14_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_24_n_4 ),
        .I2(\input_r_Addr_A[7]_INST_0_i_15_n_4 ),
        .I3(ap_CS_fsm_pp0_stage0),
        .I4(ap_enable_reg_pp0_iter1_reg_n_4),
        .I5(tmp_114_reg_3436[5]),
        .O(\input_r_Addr_A[7]_INST_0_i_4_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_40 
       (.I0(\tmp_89_reg_2786_reg_n_4_[2] ),
        .I1(tmp_6_cast_reg_2838_reg__0[2]),
        .O(data13[2]));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_41 
       (.I0(tmp_83_reg_2990_reg__0[2]),
        .I1(tmp_39_0_3_cast_cast_reg_2917_reg__0[4]),
        .O(\input_r_Addr_A[7]_INST_0_i_41_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_42 
       (.I0(tmp_83_reg_2990_reg__0[1]),
        .I1(tmp_39_0_3_cast_cast_reg_2917_reg__0[3]),
        .O(\input_r_Addr_A[7]_INST_0_i_42_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_43 
       (.I0(tmp_83_reg_2990_reg__0[0]),
        .I1(tmp_39_0_3_cast_cast_reg_2917_reg__0[2]),
        .O(data15[2]));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_44 
       (.I0(tmp_83_reg_2990_reg__0[2]),
        .I1(tmp_39_0_4_cast_cast_reg_2812_reg__0[4]),
        .O(\input_r_Addr_A[7]_INST_0_i_44_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_45 
       (.I0(tmp_83_reg_2990_reg__0[1]),
        .I1(tmp_39_0_4_cast_cast_reg_2812_reg__0[3]),
        .O(\input_r_Addr_A[7]_INST_0_i_45_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_46 
       (.I0(tmp_83_reg_2990_reg__0[0]),
        .I1(tmp_39_0_4_cast_cast_reg_2812_reg__0[2]),
        .O(data14[2]));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_47 
       (.I0(\tmp_89_reg_2786_reg_n_4_[4] ),
        .I1(tmp_39_0_1_cast_cast_reg_2871_reg__0[4]),
        .O(\input_r_Addr_A[7]_INST_0_i_47_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_48 
       (.I0(\tmp_89_reg_2786_reg_n_4_[3] ),
        .I1(tmp_39_0_1_cast_cast_reg_2871_reg__0[3]),
        .O(\input_r_Addr_A[7]_INST_0_i_48_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_49 
       (.I0(\tmp_89_reg_2786_reg_n_4_[2] ),
        .I1(tmp_39_0_1_cast_cast_reg_2871_reg__0[2]),
        .O(data12[2]));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[7]_INST_0_i_5 
       (.I0(data13[5]),
        .I1(data15[5]),
        .I2(data14[5]),
        .I3(reg_6311444_out),
        .I4(reg_6311242_out),
        .I5(reg_6311343_out),
        .O(\input_r_Addr_A[7]_INST_0_i_5_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_50 
       (.I0(\tmp_89_reg_2786_reg_n_4_[4] ),
        .I1(tmp_39_0_3_cast_cast_reg_2917_reg__0[4]),
        .O(\input_r_Addr_A[7]_INST_0_i_50_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_51 
       (.I0(\tmp_89_reg_2786_reg_n_4_[3] ),
        .I1(tmp_39_0_3_cast_cast_reg_2917_reg__0[3]),
        .O(\input_r_Addr_A[7]_INST_0_i_51_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_52 
       (.I0(\tmp_89_reg_2786_reg_n_4_[2] ),
        .I1(tmp_39_0_3_cast_cast_reg_2917_reg__0[2]),
        .O(data11[2]));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_53 
       (.I0(tmp_98_reg_2909[4]),
        .I1(tmp_39_0_4_cast_cast_reg_2812_reg__0[4]),
        .O(\input_r_Addr_A[7]_INST_0_i_53_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_54 
       (.I0(tmp_98_reg_2909[3]),
        .I1(tmp_39_0_4_cast_cast_reg_2812_reg__0[3]),
        .O(\input_r_Addr_A[7]_INST_0_i_54_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_55 
       (.I0(tmp_98_reg_2909[2]),
        .I1(tmp_39_0_4_cast_cast_reg_2812_reg__0[2]),
        .O(\input_r_Addr_A[7]_INST_0_i_55_n_4 ));
  LUT6 #(
    .INIT(64'h9666666666666666)) 
    \input_r_Addr_A[7]_INST_0_i_56 
       (.I0(tmp_92_reg_2830_reg__0[2]),
        .I1(\x_mid2_reg_2734_reg_n_4_[4] ),
        .I2(\x_mid2_reg_2734_reg_n_4_[3] ),
        .I3(\x_mid2_reg_2734_reg_n_4_[1] ),
        .I4(\x_mid2_reg_2734_reg_n_4_[0] ),
        .I5(\x_mid2_reg_2734_reg_n_4_[2] ),
        .O(\input_r_Addr_A[7]_INST_0_i_56_n_4 ));
  LUT5 #(
    .INIT(32'h96666666)) 
    \input_r_Addr_A[7]_INST_0_i_57 
       (.I0(tmp_92_reg_2830_reg__0[1]),
        .I1(\x_mid2_reg_2734_reg_n_4_[3] ),
        .I2(\x_mid2_reg_2734_reg_n_4_[2] ),
        .I3(\x_mid2_reg_2734_reg_n_4_[0] ),
        .I4(\x_mid2_reg_2734_reg_n_4_[1] ),
        .O(\input_r_Addr_A[7]_INST_0_i_57_n_4 ));
  LUT4 #(
    .INIT(16'h9666)) 
    \input_r_Addr_A[7]_INST_0_i_58 
       (.I0(tmp_92_reg_2830_reg__0[0]),
        .I1(\x_mid2_reg_2734_reg_n_4_[2] ),
        .I2(\x_mid2_reg_2734_reg_n_4_[1] ),
        .I3(\x_mid2_reg_2734_reg_n_4_[0] ),
        .O(data21[2]));
  LUT4 #(
    .INIT(16'h9666)) 
    \input_r_Addr_A[7]_INST_0_i_59 
       (.I0(\tmp_89_reg_2786_reg_n_4_[4] ),
        .I1(\x_mid2_reg_2734_reg_n_4_[4] ),
        .I2(\x_mid2_reg_2734_reg_n_4_[3] ),
        .I3(\x_mid2_reg_2734_reg_n_4_[2] ),
        .O(\input_r_Addr_A[7]_INST_0_i_59_n_4 ));
  CARRY4 \input_r_Addr_A[7]_INST_0_i_6 
       (.CI(1'b0),
        .CO({\input_r_Addr_A[7]_INST_0_i_6_n_4 ,\input_r_Addr_A[7]_INST_0_i_6_n_5 ,\input_r_Addr_A[7]_INST_0_i_6_n_6 ,\input_r_Addr_A[7]_INST_0_i_6_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_92_reg_2830_reg__0[3:0]),
        .O({data10[5:3],\NLW_input_r_Addr_A[7]_INST_0_i_6_O_UNCONNECTED [0]}),
        .S({tmp_92_reg_2830_reg__0[3],\input_r_Addr_A[7]_INST_0_i_19_n_4 ,\input_r_Addr_A[7]_INST_0_i_20_n_4 ,data10[2]}));
  LUT3 #(
    .INIT(8'h96)) 
    \input_r_Addr_A[7]_INST_0_i_60 
       (.I0(\tmp_89_reg_2786_reg_n_4_[3] ),
        .I1(\x_mid2_reg_2734_reg_n_4_[3] ),
        .I2(\x_mid2_reg_2734_reg_n_4_[2] ),
        .O(\input_r_Addr_A[7]_INST_0_i_60_n_4 ));
  LUT2 #(
    .INIT(4'h9)) 
    \input_r_Addr_A[7]_INST_0_i_61 
       (.I0(\tmp_89_reg_2786_reg_n_4_[2] ),
        .I1(\x_mid2_reg_2734_reg_n_4_[2] ),
        .O(\input_r_Addr_A[7]_INST_0_i_61_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_62 
       (.I0(tmp_83_reg_2990_reg__0[2]),
        .I1(tmp_39_0_1_cast_cast_reg_2871_reg__0[4]),
        .O(\input_r_Addr_A[7]_INST_0_i_62_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_63 
       (.I0(tmp_83_reg_2990_reg__0[1]),
        .I1(tmp_39_0_1_cast_cast_reg_2871_reg__0[3]),
        .O(\input_r_Addr_A[7]_INST_0_i_63_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_64 
       (.I0(tmp_83_reg_2990_reg__0[0]),
        .I1(tmp_39_0_1_cast_cast_reg_2871_reg__0[2]),
        .O(\input_r_Addr_A[7]_INST_0_i_64_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_65 
       (.I0(tmp_95_reg_3368_reg__0[2]),
        .I1(tmp_39_0_1_cast_cast_reg_2871_reg__0[4]),
        .O(\input_r_Addr_A[7]_INST_0_i_65_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_66 
       (.I0(tmp_95_reg_3368_reg__0[1]),
        .I1(tmp_39_0_1_cast_cast_reg_2871_reg__0[3]),
        .O(\input_r_Addr_A[7]_INST_0_i_66_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \input_r_Addr_A[7]_INST_0_i_67 
       (.I0(tmp_95_reg_3368_reg__0[0]),
        .I1(tmp_39_0_1_cast_cast_reg_2871_reg__0[2]),
        .O(\input_r_Addr_A[7]_INST_0_i_67_n_4 ));
  LUT6 #(
    .INIT(64'h00F0000000800080)) 
    \input_r_Addr_A[7]_INST_0_i_7 
       (.I0(ap_CS_fsm_pp0_stage13),
        .I1(data12[5]),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage15),
        .I4(data11[5]),
        .I5(ap_CS_fsm_pp0_stage14),
        .O(\input_r_Addr_A[7]_INST_0_i_7_n_4 ));
  CARRY4 \input_r_Addr_A[7]_INST_0_i_8 
       (.CI(1'b0),
        .CO({\input_r_Addr_A[7]_INST_0_i_8_n_4 ,\input_r_Addr_A[7]_INST_0_i_8_n_5 ,\input_r_Addr_A[7]_INST_0_i_8_n_6 ,\input_r_Addr_A[7]_INST_0_i_8_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_92_reg_2830_reg__0[3:0]),
        .O({data9[5:3],\NLW_input_r_Addr_A[7]_INST_0_i_8_O_UNCONNECTED [0]}),
        .S({tmp_92_reg_2830_reg__0[3],\input_r_Addr_A[7]_INST_0_i_24_n_4 ,\input_r_Addr_A[7]_INST_0_i_25_n_4 ,data9[2]}));
  CARRY4 \input_r_Addr_A[7]_INST_0_i_9 
       (.CI(1'b0),
        .CO({\input_r_Addr_A[7]_INST_0_i_9_n_4 ,\input_r_Addr_A[7]_INST_0_i_9_n_5 ,\input_r_Addr_A[7]_INST_0_i_9_n_6 ,\input_r_Addr_A[7]_INST_0_i_9_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_92_reg_2830_reg__0[3:0]),
        .O({data8[5:3],\NLW_input_r_Addr_A[7]_INST_0_i_9_O_UNCONNECTED [0]}),
        .S({tmp_92_reg_2830_reg__0[3],\input_r_Addr_A[7]_INST_0_i_27_n_4 ,\input_r_Addr_A[7]_INST_0_i_28_n_4 ,data8[2]}));
  LUT6 #(
    .INIT(64'hFFFFFDA80000FDA8)) 
    \input_r_Addr_A[8]_INST_0 
       (.I0(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .I1(\input_r_Addr_A[8]_INST_0_i_1_n_4 ),
        .I2(\input_r_Addr_A[8]_INST_0_i_2_n_4 ),
        .I3(\input_r_Addr_A[8]_INST_0_i_3_n_4 ),
        .I4(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I5(\input_r_Addr_A[8]_INST_0_i_4_n_4 ),
        .O(input_r_Addr_A[6]));
  LUT6 #(
    .INIT(64'h3333300022222222)) 
    \input_r_Addr_A[8]_INST_0_i_1 
       (.I0(\input_r_Addr_A[8]_INST_0_i_5_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .I2(data10[6]),
        .I3(reg_6311747_out),
        .I4(\input_r_Addr_A[8]_INST_0_i_6_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_7_n_4 ),
        .O(\input_r_Addr_A[8]_INST_0_i_1_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[8]_INST_0_i_10 
       (.I0(tmp_109_reg_3426[6]),
        .I1(tmp_123_reg_3446[6]),
        .I2(tmp_103_reg_3416[6]),
        .I3(reg_6312555_out),
        .I4(reg_6312454_out),
        .I5(reg_63125),
        .O(\input_r_Addr_A[8]_INST_0_i_10_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[8]_INST_0_i_11 
       (.I0(tmp_118_reg_3441[6]),
        .I1(data6[6]),
        .I2(tmp_113_reg_3431[6]),
        .I3(reg_6312353_out),
        .I4(reg_6312151_out),
        .I5(reg_6312252_out),
        .O(\input_r_Addr_A[8]_INST_0_i_11_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[8]_INST_0_i_2 
       (.I0(data7[6]),
        .I1(data9[6]),
        .I2(data8[6]),
        .I3(reg_6312050_out),
        .I4(reg_6311848_out),
        .I5(reg_6311949_out),
        .O(\input_r_Addr_A[8]_INST_0_i_2_n_4 ));
  LUT6 #(
    .INIT(64'hFEFEFE0EFE0EFE0E)) 
    \input_r_Addr_A[8]_INST_0_i_3 
       (.I0(\input_r_Addr_A[8]_INST_0_i_7_n_4 ),
        .I1(\input_r_Addr_A[8]_INST_0_i_8_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .I3(\input_r_Addr_A[8]_INST_0_i_9_n_4 ),
        .I4(conv1_bias_EN_A),
        .I5(data16[6]),
        .O(\input_r_Addr_A[8]_INST_0_i_3_n_4 ));
  LUT6 #(
    .INIT(64'hFFBABABA00BABABA)) 
    \input_r_Addr_A[8]_INST_0_i_4 
       (.I0(\input_r_Addr_A[8]_INST_0_i_10_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_24_n_4 ),
        .I2(\input_r_Addr_A[8]_INST_0_i_11_n_4 ),
        .I3(ap_CS_fsm_pp0_stage0),
        .I4(ap_enable_reg_pp0_iter1_reg_n_4),
        .I5(tmp_114_reg_3436[6]),
        .O(\input_r_Addr_A[8]_INST_0_i_4_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[8]_INST_0_i_5 
       (.I0(data13[6]),
        .I1(data15[6]),
        .I2(data14[6]),
        .I3(reg_6311444_out),
        .I4(reg_6311242_out),
        .I5(reg_6311343_out),
        .O(\input_r_Addr_A[8]_INST_0_i_5_n_4 ));
  LUT6 #(
    .INIT(64'h00F0000000800080)) 
    \input_r_Addr_A[8]_INST_0_i_6 
       (.I0(ap_CS_fsm_pp0_stage13),
        .I1(data12[6]),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage15),
        .I4(data11[6]),
        .I5(ap_CS_fsm_pp0_stage14),
        .O(\input_r_Addr_A[8]_INST_0_i_6_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[8]_INST_0_i_7 
       (.I0(data19[6]),
        .I1(data21[6]),
        .I2(data20[6]),
        .I3(reg_631839_out),
        .I4(reg_631637_out),
        .I5(reg_631738_out),
        .O(\input_r_Addr_A[8]_INST_0_i_7_n_4 ));
  LUT6 #(
    .INIT(64'h00000000BB88B8B8)) 
    \input_r_Addr_A[8]_INST_0_i_8 
       (.I0(data22[6]),
        .I1(reg_631536_out),
        .I2(data24[6]),
        .I3(data23[6]),
        .I4(reg_631435_out),
        .I5(\input_r_Addr_A[4]_INST_0_i_12_n_4 ),
        .O(\input_r_Addr_A[8]_INST_0_i_8_n_4 ));
  LUT6 #(
    .INIT(64'h00F0000000800080)) 
    \input_r_Addr_A[8]_INST_0_i_9 
       (.I0(ap_CS_fsm_pp0_stage7),
        .I1(data18[6]),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage9),
        .I4(data17[6]),
        .I5(ap_CS_fsm_pp0_stage8),
        .O(\input_r_Addr_A[8]_INST_0_i_9_n_4 ));
  LUT6 #(
    .INIT(64'hFFFFFDA80000FDA8)) 
    \input_r_Addr_A[9]_INST_0 
       (.I0(\input_r_Addr_A[12]_INST_0_i_1_n_4 ),
        .I1(\input_r_Addr_A[9]_INST_0_i_1_n_4 ),
        .I2(\input_r_Addr_A[9]_INST_0_i_2_n_4 ),
        .I3(\input_r_Addr_A[9]_INST_0_i_3_n_4 ),
        .I4(\input_r_Addr_A[12]_INST_0_i_5_n_4 ),
        .I5(\input_r_Addr_A[9]_INST_0_i_4_n_4 ),
        .O(input_r_Addr_A[7]));
  LUT6 #(
    .INIT(64'h3333300022222222)) 
    \input_r_Addr_A[9]_INST_0_i_1 
       (.I0(\input_r_Addr_A[9]_INST_0_i_5_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_8_n_4 ),
        .I2(data10[7]),
        .I3(reg_6311747_out),
        .I4(\input_r_Addr_A[9]_INST_0_i_6_n_4 ),
        .I5(\input_r_Addr_A[12]_INST_0_i_7_n_4 ),
        .O(\input_r_Addr_A[9]_INST_0_i_1_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[9]_INST_0_i_10 
       (.I0(tmp_109_reg_3426[7]),
        .I1(tmp_123_reg_3446[7]),
        .I2(tmp_103_reg_3416[7]),
        .I3(reg_6312555_out),
        .I4(reg_6312454_out),
        .I5(reg_63125),
        .O(\input_r_Addr_A[9]_INST_0_i_10_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[9]_INST_0_i_11 
       (.I0(tmp_118_reg_3441[7]),
        .I1(data6[7]),
        .I2(tmp_113_reg_3431[7]),
        .I3(reg_6312353_out),
        .I4(reg_6312151_out),
        .I5(reg_6312252_out),
        .O(\input_r_Addr_A[9]_INST_0_i_11_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[9]_INST_0_i_2 
       (.I0(data7[7]),
        .I1(data9[7]),
        .I2(data8[7]),
        .I3(reg_6312050_out),
        .I4(reg_6311848_out),
        .I5(reg_6311949_out),
        .O(\input_r_Addr_A[9]_INST_0_i_2_n_4 ));
  LUT6 #(
    .INIT(64'hFEFEFE0EFE0EFE0E)) 
    \input_r_Addr_A[9]_INST_0_i_3 
       (.I0(\input_r_Addr_A[9]_INST_0_i_7_n_4 ),
        .I1(\input_r_Addr_A[9]_INST_0_i_8_n_4 ),
        .I2(\input_r_Addr_A[12]_INST_0_i_21_n_4 ),
        .I3(\input_r_Addr_A[9]_INST_0_i_9_n_4 ),
        .I4(conv1_bias_EN_A),
        .I5(data16[7]),
        .O(\input_r_Addr_A[9]_INST_0_i_3_n_4 ));
  LUT6 #(
    .INIT(64'hFFBABABA00BABABA)) 
    \input_r_Addr_A[9]_INST_0_i_4 
       (.I0(\input_r_Addr_A[9]_INST_0_i_10_n_4 ),
        .I1(\input_r_Addr_A[12]_INST_0_i_24_n_4 ),
        .I2(\input_r_Addr_A[9]_INST_0_i_11_n_4 ),
        .I3(ap_CS_fsm_pp0_stage0),
        .I4(ap_enable_reg_pp0_iter1_reg_n_4),
        .I5(tmp_114_reg_3436[7]),
        .O(\input_r_Addr_A[9]_INST_0_i_4_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[9]_INST_0_i_5 
       (.I0(data13[7]),
        .I1(data15[7]),
        .I2(data14[7]),
        .I3(reg_6311444_out),
        .I4(reg_6311242_out),
        .I5(reg_6311343_out),
        .O(\input_r_Addr_A[9]_INST_0_i_5_n_4 ));
  LUT6 #(
    .INIT(64'h00F0000000800080)) 
    \input_r_Addr_A[9]_INST_0_i_6 
       (.I0(ap_CS_fsm_pp0_stage13),
        .I1(data12[7]),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage15),
        .I4(data11[7]),
        .I5(ap_CS_fsm_pp0_stage14),
        .O(\input_r_Addr_A[9]_INST_0_i_6_n_4 ));
  LUT6 #(
    .INIT(64'hAAF0AAF0AACCAA00)) 
    \input_r_Addr_A[9]_INST_0_i_7 
       (.I0(data19[7]),
        .I1(data21[7]),
        .I2(data20[7]),
        .I3(reg_631839_out),
        .I4(reg_631637_out),
        .I5(reg_631738_out),
        .O(\input_r_Addr_A[9]_INST_0_i_7_n_4 ));
  LUT6 #(
    .INIT(64'h00000000BB88B8B8)) 
    \input_r_Addr_A[9]_INST_0_i_8 
       (.I0(data22[7]),
        .I1(reg_631536_out),
        .I2(data24[7]),
        .I3(data23[7]),
        .I4(reg_631435_out),
        .I5(\input_r_Addr_A[4]_INST_0_i_12_n_4 ),
        .O(\input_r_Addr_A[9]_INST_0_i_8_n_4 ));
  LUT6 #(
    .INIT(64'h00F0000000800080)) 
    \input_r_Addr_A[9]_INST_0_i_9 
       (.I0(ap_CS_fsm_pp0_stage7),
        .I1(data18[7]),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_CS_fsm_pp0_stage9),
        .I4(data17[7]),
        .I5(ap_CS_fsm_pp0_stage8),
        .O(\input_r_Addr_A[9]_INST_0_i_9_n_4 ));
  LUT1 #(
    .INIT(2'h1)) 
    output_r_Rst_A_INST_0
       (.I0(ap_rst_n),
        .O(output_r_Rst_A));
  (* SOFT_HLUTNM = "soft_lutpair80" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_103_reg_3416[2]_i_1 
       (.I0(tmp_98_reg_2909[2]),
        .I1(tmp_6_cast_reg_2838_reg__0[2]),
        .O(tmp_103_fu_2000_p2[2]));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_103_reg_3416[5]_i_2 
       (.I0(tmp_98_reg_2909[4]),
        .I1(tmp_6_cast_reg_2838_reg__0[4]),
        .O(\tmp_103_reg_3416[5]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_103_reg_3416[5]_i_3 
       (.I0(tmp_98_reg_2909[3]),
        .I1(tmp_6_cast_reg_2838_reg__0[3]),
        .O(\tmp_103_reg_3416[5]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_103_reg_3416[5]_i_4 
       (.I0(tmp_98_reg_2909[2]),
        .I1(tmp_6_cast_reg_2838_reg__0[2]),
        .O(\tmp_103_reg_3416[5]_i_4_n_4 ));
  FDRE \tmp_103_reg_3416_reg[0] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_6_cast_reg_2838_reg__0[0]),
        .Q(tmp_103_reg_3416[0]),
        .R(1'b0));
  FDRE \tmp_103_reg_3416_reg[10] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_103_fu_2000_p2[10]),
        .Q(tmp_103_reg_3416[10]),
        .R(1'b0));
  CARRY4 \tmp_103_reg_3416_reg[10]_i_1 
       (.CI(\tmp_103_reg_3416_reg[5]_i_1_n_4 ),
        .CO({xlnx_opt_,\tmp_103_reg_3416_reg[10]_i_1_n_5 ,\tmp_103_reg_3416_reg[10]_i_1_n_6 ,\tmp_103_reg_3416_reg[10]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_98_reg_2909[9:6]),
        .O(tmp_103_fu_2000_p2[9:6]),
        .S(tmp_98_reg_2909[9:6]));
  FDRE \tmp_103_reg_3416_reg[1] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(data7[1]),
        .Q(tmp_103_reg_3416[1]),
        .R(1'b0));
  FDRE \tmp_103_reg_3416_reg[2] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_103_fu_2000_p2[2]),
        .Q(tmp_103_reg_3416[2]),
        .R(1'b0));
  FDRE \tmp_103_reg_3416_reg[3] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_103_fu_2000_p2[3]),
        .Q(tmp_103_reg_3416[3]),
        .R(1'b0));
  FDRE \tmp_103_reg_3416_reg[4] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_103_fu_2000_p2[4]),
        .Q(tmp_103_reg_3416[4]),
        .R(1'b0));
  FDRE \tmp_103_reg_3416_reg[5] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_103_fu_2000_p2[5]),
        .Q(tmp_103_reg_3416[5]),
        .R(1'b0));
  CARRY4 \tmp_103_reg_3416_reg[5]_i_1 
       (.CI(1'b0),
        .CO({\tmp_103_reg_3416_reg[5]_i_1_n_4 ,\tmp_103_reg_3416_reg[5]_i_1_n_5 ,\tmp_103_reg_3416_reg[5]_i_1_n_6 ,\tmp_103_reg_3416_reg[5]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_98_reg_2909[5:2]),
        .O({tmp_103_fu_2000_p2[5:3],\NLW_tmp_103_reg_3416_reg[5]_i_1_O_UNCONNECTED [0]}),
        .S({tmp_98_reg_2909[5],\tmp_103_reg_3416[5]_i_2_n_4 ,\tmp_103_reg_3416[5]_i_3_n_4 ,\tmp_103_reg_3416[5]_i_4_n_4 }));
  FDRE \tmp_103_reg_3416_reg[6] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_103_fu_2000_p2[6]),
        .Q(tmp_103_reg_3416[6]),
        .R(1'b0));
  FDRE \tmp_103_reg_3416_reg[7] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_103_fu_2000_p2[7]),
        .Q(tmp_103_reg_3416[7]),
        .R(1'b0));
  FDRE \tmp_103_reg_3416_reg[8] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_103_fu_2000_p2[8]),
        .Q(tmp_103_reg_3416[8]),
        .R(1'b0));
  FDRE \tmp_103_reg_3416_reg[9] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_103_fu_2000_p2[9]),
        .Q(tmp_103_reg_3416[9]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair70" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_109_reg_3426[2]_i_1 
       (.I0(tmp_98_reg_2909[2]),
        .I1(tmp_39_0_1_cast_cast_reg_2871_reg__0[2]),
        .O(tmp_109_fu_2013_p2[2]));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_109_reg_3426[5]_i_2 
       (.I0(tmp_98_reg_2909[4]),
        .I1(tmp_39_0_1_cast_cast_reg_2871_reg__0[4]),
        .O(\tmp_109_reg_3426[5]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_109_reg_3426[5]_i_3 
       (.I0(tmp_98_reg_2909[3]),
        .I1(tmp_39_0_1_cast_cast_reg_2871_reg__0[3]),
        .O(\tmp_109_reg_3426[5]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_109_reg_3426[5]_i_4 
       (.I0(tmp_98_reg_2909[2]),
        .I1(tmp_39_0_1_cast_cast_reg_2871_reg__0[2]),
        .O(\tmp_109_reg_3426[5]_i_4_n_4 ));
  FDRE \tmp_109_reg_3426_reg[0] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_39_0_1_cast_cast_reg_2871_reg__0[0]),
        .Q(tmp_109_reg_3426[0]),
        .R(1'b0));
  FDRE \tmp_109_reg_3426_reg[10] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_109_fu_2013_p2[10]),
        .Q(tmp_109_reg_3426[10]),
        .R(1'b0));
  CARRY4 \tmp_109_reg_3426_reg[10]_i_1 
       (.CI(\tmp_109_reg_3426_reg[5]_i_1_n_4 ),
        .CO({xlnx_opt__3,\tmp_109_reg_3426_reg[10]_i_1_n_5 ,\tmp_109_reg_3426_reg[10]_i_1_n_6 ,\tmp_109_reg_3426_reg[10]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_98_reg_2909[9:6]),
        .O(tmp_109_fu_2013_p2[9:6]),
        .S(tmp_98_reg_2909[9:6]));
  FDRE \tmp_109_reg_3426_reg[1] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_39_0_1_cast_cast_reg_2871_reg__0[1]),
        .Q(tmp_109_reg_3426[1]),
        .R(1'b0));
  FDRE \tmp_109_reg_3426_reg[2] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_109_fu_2013_p2[2]),
        .Q(tmp_109_reg_3426[2]),
        .R(1'b0));
  FDRE \tmp_109_reg_3426_reg[3] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_109_fu_2013_p2[3]),
        .Q(tmp_109_reg_3426[3]),
        .R(1'b0));
  FDRE \tmp_109_reg_3426_reg[4] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_109_fu_2013_p2[4]),
        .Q(tmp_109_reg_3426[4]),
        .R(1'b0));
  FDRE \tmp_109_reg_3426_reg[5] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_109_fu_2013_p2[5]),
        .Q(tmp_109_reg_3426[5]),
        .R(1'b0));
  CARRY4 \tmp_109_reg_3426_reg[5]_i_1 
       (.CI(1'b0),
        .CO({\tmp_109_reg_3426_reg[5]_i_1_n_4 ,\tmp_109_reg_3426_reg[5]_i_1_n_5 ,\tmp_109_reg_3426_reg[5]_i_1_n_6 ,\tmp_109_reg_3426_reg[5]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_98_reg_2909[5:2]),
        .O({tmp_109_fu_2013_p2[5:3],\NLW_tmp_109_reg_3426_reg[5]_i_1_O_UNCONNECTED [0]}),
        .S({tmp_98_reg_2909[5],\tmp_109_reg_3426[5]_i_2_n_4 ,\tmp_109_reg_3426[5]_i_3_n_4 ,\tmp_109_reg_3426[5]_i_4_n_4 }));
  FDRE \tmp_109_reg_3426_reg[6] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_109_fu_2013_p2[6]),
        .Q(tmp_109_reg_3426[6]),
        .R(1'b0));
  FDRE \tmp_109_reg_3426_reg[7] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_109_fu_2013_p2[7]),
        .Q(tmp_109_reg_3426[7]),
        .R(1'b0));
  FDRE \tmp_109_reg_3426_reg[8] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_109_fu_2013_p2[8]),
        .Q(tmp_109_reg_3426[8]),
        .R(1'b0));
  FDRE \tmp_109_reg_3426_reg[9] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_109_fu_2013_p2[9]),
        .Q(tmp_109_reg_3426[9]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair71" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_113_reg_3431[2]_i_1 
       (.I0(tmp_95_reg_3368_reg__0[0]),
        .I1(tmp_39_0_2_cast_cast_reg_2794[2]),
        .O(tmp_113_fu_2017_p2[2]));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_113_reg_3431[5]_i_2 
       (.I0(tmp_95_reg_3368_reg__0[2]),
        .I1(tmp_39_0_2_cast_cast_reg_2794[4]),
        .O(\tmp_113_reg_3431[5]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_113_reg_3431[5]_i_3 
       (.I0(tmp_95_reg_3368_reg__0[1]),
        .I1(tmp_39_0_2_cast_cast_reg_2794[3]),
        .O(\tmp_113_reg_3431[5]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_113_reg_3431[5]_i_4 
       (.I0(tmp_95_reg_3368_reg__0[0]),
        .I1(tmp_39_0_2_cast_cast_reg_2794[2]),
        .O(\tmp_113_reg_3431[5]_i_4_n_4 ));
  FDRE \tmp_113_reg_3431_reg[10] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_113_fu_2017_p2[10]),
        .Q(tmp_113_reg_3431[10]),
        .R(1'b0));
  CARRY4 \tmp_113_reg_3431_reg[10]_i_1 
       (.CI(\tmp_113_reg_3431_reg[5]_i_1_n_4 ),
        .CO({xlnx_opt__6,\tmp_113_reg_3431_reg[10]_i_1_n_5 ,\tmp_113_reg_3431_reg[10]_i_1_n_6 ,\tmp_113_reg_3431_reg[10]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_95_reg_3368_reg__0[7:4]),
        .O(tmp_113_fu_2017_p2[9:6]),
        .S(tmp_95_reg_3368_reg__0[7:4]));
  FDRE \tmp_113_reg_3431_reg[2] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_113_fu_2017_p2[2]),
        .Q(tmp_113_reg_3431[2]),
        .R(1'b0));
  FDRE \tmp_113_reg_3431_reg[3] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_113_fu_2017_p2[3]),
        .Q(tmp_113_reg_3431[3]),
        .R(1'b0));
  FDRE \tmp_113_reg_3431_reg[4] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_113_fu_2017_p2[4]),
        .Q(tmp_113_reg_3431[4]),
        .R(1'b0));
  FDRE \tmp_113_reg_3431_reg[5] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_113_fu_2017_p2[5]),
        .Q(tmp_113_reg_3431[5]),
        .R(1'b0));
  CARRY4 \tmp_113_reg_3431_reg[5]_i_1 
       (.CI(1'b0),
        .CO({\tmp_113_reg_3431_reg[5]_i_1_n_4 ,\tmp_113_reg_3431_reg[5]_i_1_n_5 ,\tmp_113_reg_3431_reg[5]_i_1_n_6 ,\tmp_113_reg_3431_reg[5]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_95_reg_3368_reg__0[3:0]),
        .O({tmp_113_fu_2017_p2[5:3],\NLW_tmp_113_reg_3431_reg[5]_i_1_O_UNCONNECTED [0]}),
        .S({tmp_95_reg_3368_reg__0[3],\tmp_113_reg_3431[5]_i_2_n_4 ,\tmp_113_reg_3431[5]_i_3_n_4 ,\tmp_113_reg_3431[5]_i_4_n_4 }));
  FDRE \tmp_113_reg_3431_reg[6] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_113_fu_2017_p2[6]),
        .Q(tmp_113_reg_3431[6]),
        .R(1'b0));
  FDRE \tmp_113_reg_3431_reg[7] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_113_fu_2017_p2[7]),
        .Q(tmp_113_reg_3431[7]),
        .R(1'b0));
  FDRE \tmp_113_reg_3431_reg[8] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_113_fu_2017_p2[8]),
        .Q(tmp_113_reg_3431[8]),
        .R(1'b0));
  FDRE \tmp_113_reg_3431_reg[9] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_113_fu_2017_p2[9]),
        .Q(tmp_113_reg_3431[9]),
        .R(1'b0));
  LUT2 #(
    .INIT(4'h2)) 
    \tmp_114_reg_3436[10]_i_1 
       (.I0(ap_CS_fsm_pp0_stage19),
        .I1(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .O(\tmp_114_reg_3436[10]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair70" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_114_reg_3436[2]_i_1 
       (.I0(tmp_98_reg_2909[2]),
        .I1(tmp_39_0_2_cast_cast_reg_2794[2]),
        .O(tmp_114_fu_2021_p2[2]));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_114_reg_3436[5]_i_2 
       (.I0(tmp_98_reg_2909[4]),
        .I1(tmp_39_0_2_cast_cast_reg_2794[4]),
        .O(\tmp_114_reg_3436[5]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_114_reg_3436[5]_i_3 
       (.I0(tmp_98_reg_2909[3]),
        .I1(tmp_39_0_2_cast_cast_reg_2794[3]),
        .O(\tmp_114_reg_3436[5]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_114_reg_3436[5]_i_4 
       (.I0(tmp_98_reg_2909[2]),
        .I1(tmp_39_0_2_cast_cast_reg_2794[2]),
        .O(\tmp_114_reg_3436[5]_i_4_n_4 ));
  FDRE \tmp_114_reg_3436_reg[0] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_39_0_2_cast_cast_reg_2794[0]),
        .Q(tmp_114_reg_3436[0]),
        .R(1'b0));
  FDRE \tmp_114_reg_3436_reg[10] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_114_fu_2021_p2[10]),
        .Q(tmp_114_reg_3436[10]),
        .R(1'b0));
  CARRY4 \tmp_114_reg_3436_reg[10]_i_2 
       (.CI(\tmp_114_reg_3436_reg[5]_i_1_n_4 ),
        .CO({xlnx_opt__9,\tmp_114_reg_3436_reg[10]_i_2_n_5 ,\tmp_114_reg_3436_reg[10]_i_2_n_6 ,\tmp_114_reg_3436_reg[10]_i_2_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_98_reg_2909[9:6]),
        .O(tmp_114_fu_2021_p2[9:6]),
        .S(tmp_98_reg_2909[9:6]));
  FDRE \tmp_114_reg_3436_reg[1] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_39_0_2_cast_cast_reg_2794[1]),
        .Q(tmp_114_reg_3436[1]),
        .R(1'b0));
  FDRE \tmp_114_reg_3436_reg[2] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_114_fu_2021_p2[2]),
        .Q(tmp_114_reg_3436[2]),
        .R(1'b0));
  FDRE \tmp_114_reg_3436_reg[3] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_114_fu_2021_p2[3]),
        .Q(tmp_114_reg_3436[3]),
        .R(1'b0));
  FDRE \tmp_114_reg_3436_reg[4] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_114_fu_2021_p2[4]),
        .Q(tmp_114_reg_3436[4]),
        .R(1'b0));
  FDRE \tmp_114_reg_3436_reg[5] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_114_fu_2021_p2[5]),
        .Q(tmp_114_reg_3436[5]),
        .R(1'b0));
  CARRY4 \tmp_114_reg_3436_reg[5]_i_1 
       (.CI(1'b0),
        .CO({\tmp_114_reg_3436_reg[5]_i_1_n_4 ,\tmp_114_reg_3436_reg[5]_i_1_n_5 ,\tmp_114_reg_3436_reg[5]_i_1_n_6 ,\tmp_114_reg_3436_reg[5]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_98_reg_2909[5:2]),
        .O({tmp_114_fu_2021_p2[5:3],\NLW_tmp_114_reg_3436_reg[5]_i_1_O_UNCONNECTED [0]}),
        .S({tmp_98_reg_2909[5],\tmp_114_reg_3436[5]_i_2_n_4 ,\tmp_114_reg_3436[5]_i_3_n_4 ,\tmp_114_reg_3436[5]_i_4_n_4 }));
  FDRE \tmp_114_reg_3436_reg[6] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_114_fu_2021_p2[6]),
        .Q(tmp_114_reg_3436[6]),
        .R(1'b0));
  FDRE \tmp_114_reg_3436_reg[7] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_114_fu_2021_p2[7]),
        .Q(tmp_114_reg_3436[7]),
        .R(1'b0));
  FDRE \tmp_114_reg_3436_reg[8] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_114_fu_2021_p2[8]),
        .Q(tmp_114_reg_3436[8]),
        .R(1'b0));
  FDRE \tmp_114_reg_3436_reg[9] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_114_fu_2021_p2[9]),
        .Q(tmp_114_reg_3436[9]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair77" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_118_reg_3441[2]_i_1 
       (.I0(tmp_95_reg_3368_reg__0[0]),
        .I1(tmp_39_0_3_cast_cast_reg_2917_reg__0[2]),
        .O(tmp_118_fu_2025_p2[2]));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_118_reg_3441[5]_i_2 
       (.I0(tmp_95_reg_3368_reg__0[2]),
        .I1(tmp_39_0_3_cast_cast_reg_2917_reg__0[4]),
        .O(\tmp_118_reg_3441[5]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_118_reg_3441[5]_i_3 
       (.I0(tmp_95_reg_3368_reg__0[1]),
        .I1(tmp_39_0_3_cast_cast_reg_2917_reg__0[3]),
        .O(\tmp_118_reg_3441[5]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_118_reg_3441[5]_i_4 
       (.I0(tmp_95_reg_3368_reg__0[0]),
        .I1(tmp_39_0_3_cast_cast_reg_2917_reg__0[2]),
        .O(\tmp_118_reg_3441[5]_i_4_n_4 ));
  FDRE \tmp_118_reg_3441_reg[0] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_39_0_3_cast_cast_reg_2917_reg__0[0]),
        .Q(tmp_118_reg_3441[0]),
        .R(1'b0));
  FDRE \tmp_118_reg_3441_reg[10] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_118_fu_2025_p2[10]),
        .Q(tmp_118_reg_3441[10]),
        .R(1'b0));
  CARRY4 \tmp_118_reg_3441_reg[10]_i_1 
       (.CI(\tmp_118_reg_3441_reg[5]_i_1_n_4 ),
        .CO({xlnx_opt__12,\tmp_118_reg_3441_reg[10]_i_1_n_5 ,\tmp_118_reg_3441_reg[10]_i_1_n_6 ,\tmp_118_reg_3441_reg[10]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_95_reg_3368_reg__0[7:4]),
        .O(tmp_118_fu_2025_p2[9:6]),
        .S(tmp_95_reg_3368_reg__0[7:4]));
  FDRE \tmp_118_reg_3441_reg[1] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_39_0_3_cast_cast_reg_2917_reg__0[1]),
        .Q(tmp_118_reg_3441[1]),
        .R(1'b0));
  FDRE \tmp_118_reg_3441_reg[2] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_118_fu_2025_p2[2]),
        .Q(tmp_118_reg_3441[2]),
        .R(1'b0));
  FDRE \tmp_118_reg_3441_reg[3] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_118_fu_2025_p2[3]),
        .Q(tmp_118_reg_3441[3]),
        .R(1'b0));
  FDRE \tmp_118_reg_3441_reg[4] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_118_fu_2025_p2[4]),
        .Q(tmp_118_reg_3441[4]),
        .R(1'b0));
  FDRE \tmp_118_reg_3441_reg[5] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_118_fu_2025_p2[5]),
        .Q(tmp_118_reg_3441[5]),
        .R(1'b0));
  CARRY4 \tmp_118_reg_3441_reg[5]_i_1 
       (.CI(1'b0),
        .CO({\tmp_118_reg_3441_reg[5]_i_1_n_4 ,\tmp_118_reg_3441_reg[5]_i_1_n_5 ,\tmp_118_reg_3441_reg[5]_i_1_n_6 ,\tmp_118_reg_3441_reg[5]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_95_reg_3368_reg__0[3:0]),
        .O({tmp_118_fu_2025_p2[5:3],\NLW_tmp_118_reg_3441_reg[5]_i_1_O_UNCONNECTED [0]}),
        .S({tmp_95_reg_3368_reg__0[3],\tmp_118_reg_3441[5]_i_2_n_4 ,\tmp_118_reg_3441[5]_i_3_n_4 ,\tmp_118_reg_3441[5]_i_4_n_4 }));
  FDRE \tmp_118_reg_3441_reg[6] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_118_fu_2025_p2[6]),
        .Q(tmp_118_reg_3441[6]),
        .R(1'b0));
  FDRE \tmp_118_reg_3441_reg[7] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_118_fu_2025_p2[7]),
        .Q(tmp_118_reg_3441[7]),
        .R(1'b0));
  FDRE \tmp_118_reg_3441_reg[8] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_118_fu_2025_p2[8]),
        .Q(tmp_118_reg_3441[8]),
        .R(1'b0));
  FDRE \tmp_118_reg_3441_reg[9] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_118_fu_2025_p2[9]),
        .Q(tmp_118_reg_3441[9]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair71" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_123_reg_3446[2]_i_1 
       (.I0(tmp_95_reg_3368_reg__0[0]),
        .I1(tmp_39_0_4_cast_cast_reg_2812_reg__0[2]),
        .O(tmp_123_fu_2029_p2[2]));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_123_reg_3446[5]_i_2 
       (.I0(tmp_95_reg_3368_reg__0[2]),
        .I1(tmp_39_0_4_cast_cast_reg_2812_reg__0[4]),
        .O(\tmp_123_reg_3446[5]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_123_reg_3446[5]_i_3 
       (.I0(tmp_95_reg_3368_reg__0[1]),
        .I1(tmp_39_0_4_cast_cast_reg_2812_reg__0[3]),
        .O(\tmp_123_reg_3446[5]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_123_reg_3446[5]_i_4 
       (.I0(tmp_95_reg_3368_reg__0[0]),
        .I1(tmp_39_0_4_cast_cast_reg_2812_reg__0[2]),
        .O(\tmp_123_reg_3446[5]_i_4_n_4 ));
  FDRE \tmp_123_reg_3446_reg[0] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_39_0_4_cast_cast_reg_2812_reg__0[0]),
        .Q(tmp_123_reg_3446[0]),
        .R(1'b0));
  FDRE \tmp_123_reg_3446_reg[10] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_123_fu_2029_p2[10]),
        .Q(tmp_123_reg_3446[10]),
        .R(1'b0));
  CARRY4 \tmp_123_reg_3446_reg[10]_i_1 
       (.CI(\tmp_123_reg_3446_reg[5]_i_1_n_4 ),
        .CO({xlnx_opt__15,\tmp_123_reg_3446_reg[10]_i_1_n_5 ,\tmp_123_reg_3446_reg[10]_i_1_n_6 ,\tmp_123_reg_3446_reg[10]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_95_reg_3368_reg__0[7:4]),
        .O(tmp_123_fu_2029_p2[9:6]),
        .S(tmp_95_reg_3368_reg__0[7:4]));
  FDRE \tmp_123_reg_3446_reg[1] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_39_0_4_cast_cast_reg_2812_reg__0[1]),
        .Q(tmp_123_reg_3446[1]),
        .R(1'b0));
  FDRE \tmp_123_reg_3446_reg[2] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_123_fu_2029_p2[2]),
        .Q(tmp_123_reg_3446[2]),
        .R(1'b0));
  FDRE \tmp_123_reg_3446_reg[3] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_123_fu_2029_p2[3]),
        .Q(tmp_123_reg_3446[3]),
        .R(1'b0));
  FDRE \tmp_123_reg_3446_reg[4] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_123_fu_2029_p2[4]),
        .Q(tmp_123_reg_3446[4]),
        .R(1'b0));
  FDRE \tmp_123_reg_3446_reg[5] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_123_fu_2029_p2[5]),
        .Q(tmp_123_reg_3446[5]),
        .R(1'b0));
  CARRY4 \tmp_123_reg_3446_reg[5]_i_1 
       (.CI(1'b0),
        .CO({\tmp_123_reg_3446_reg[5]_i_1_n_4 ,\tmp_123_reg_3446_reg[5]_i_1_n_5 ,\tmp_123_reg_3446_reg[5]_i_1_n_6 ,\tmp_123_reg_3446_reg[5]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI(tmp_95_reg_3368_reg__0[3:0]),
        .O({tmp_123_fu_2029_p2[5:3],\NLW_tmp_123_reg_3446_reg[5]_i_1_O_UNCONNECTED [0]}),
        .S({tmp_95_reg_3368_reg__0[3],\tmp_123_reg_3446[5]_i_2_n_4 ,\tmp_123_reg_3446[5]_i_3_n_4 ,\tmp_123_reg_3446[5]_i_4_n_4 }));
  FDRE \tmp_123_reg_3446_reg[6] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_123_fu_2029_p2[6]),
        .Q(tmp_123_reg_3446[6]),
        .R(1'b0));
  FDRE \tmp_123_reg_3446_reg[7] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_123_fu_2029_p2[7]),
        .Q(tmp_123_reg_3446[7]),
        .R(1'b0));
  FDRE \tmp_123_reg_3446_reg[8] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_123_fu_2029_p2[8]),
        .Q(tmp_123_reg_3446[8]),
        .R(1'b0));
  FDRE \tmp_123_reg_3446_reg[9] 
       (.C(ap_clk),
        .CE(\tmp_114_reg_3436[10]_i_1_n_4 ),
        .D(tmp_123_fu_2029_p2[9]),
        .Q(tmp_123_reg_3446[9]),
        .R(1'b0));
  LUT6 #(
    .INIT(64'h4447774777744474)) 
    \tmp_37_1_cast_mid2_reg_2752[1]_i_1 
       (.I0(y_mid_fu_687_p3[1]),
        .I1(p_0_in28_out),
        .I2(y_reg_609[0]),
        .I3(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I4(p_shl10_cast_fu_1237_p1[5]),
        .I5(ap_phi_mux_y_phi_fu_613_p4[1]),
        .O(tmp_37_1_cast_mid2_fu_797_p3[1]));
  LUT6 #(
    .INIT(64'h606F6F6F6F606060)) 
    \tmp_37_1_cast_mid2_reg_2752[2]_i_1 
       (.I0(y_mid_fu_687_p3[1]),
        .I1(y_mid_fu_687_p3[2]),
        .I2(p_0_in28_out),
        .I3(ap_phi_mux_y_phi_fu_613_p4[0]),
        .I4(ap_phi_mux_y_phi_fu_613_p4[1]),
        .I5(ap_phi_mux_y_phi_fu_613_p4[2]),
        .O(tmp_37_1_cast_mid2_fu_797_p3[2]));
  LUT6 #(
    .INIT(64'h0737777770400000)) 
    \tmp_37_1_cast_mid2_reg_2752[3]_i_1 
       (.I0(exitcond_flatten_fu_681_p2),
        .I1(p_0_in28_out),
        .I2(ap_phi_mux_y_phi_fu_613_p4[1]),
        .I3(ap_phi_mux_y_phi_fu_613_p4[0]),
        .I4(ap_phi_mux_y_phi_fu_613_p4[2]),
        .I5(ap_phi_mux_y_phi_fu_613_p4[3]),
        .O(tmp_37_1_cast_mid2_fu_797_p3[3]));
  LUT6 #(
    .INIT(64'h101F3F3F2F200000)) 
    \tmp_37_1_cast_mid2_reg_2752[4]_i_1 
       (.I0(\tmp_37_1_cast_mid2_reg_2752[4]_i_2_n_4 ),
        .I1(exitcond_flatten_fu_681_p2),
        .I2(p_0_in28_out),
        .I3(\tmp_37_1_cast_mid2_reg_2752[4]_i_3_n_4 ),
        .I4(ap_phi_mux_y_phi_fu_613_p4[3]),
        .I5(ap_phi_mux_y_phi_fu_613_p4[4]),
        .O(tmp_37_1_cast_mid2_fu_797_p3[4]));
  LUT6 #(
    .INIT(64'h0A000C0C0A000000)) 
    \tmp_37_1_cast_mid2_reg_2752[4]_i_2 
       (.I0(p_shl10_cast_fu_1237_p1[7]),
        .I1(y_reg_609[2]),
        .I2(exitcond_flatten_fu_681_p2),
        .I3(p_shl10_cast_fu_1237_p1[6]),
        .I4(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I5(y_reg_609[1]),
        .O(\tmp_37_1_cast_mid2_reg_2752[4]_i_2_n_4 ));
  LUT6 #(
    .INIT(64'h8A800A0080800000)) 
    \tmp_37_1_cast_mid2_reg_2752[4]_i_3 
       (.I0(ap_phi_mux_y_phi_fu_613_p4[2]),
        .I1(p_shl10_cast_fu_1237_p1[5]),
        .I2(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I3(y_reg_609[0]),
        .I4(p_shl10_cast_fu_1237_p1[6]),
        .I5(y_reg_609[1]),
        .O(\tmp_37_1_cast_mid2_reg_2752[4]_i_3_n_4 ));
  FDRE \tmp_37_1_cast_mid2_reg_2752_reg[1] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_37_1_cast_mid2_fu_797_p3[1]),
        .Q(p_shl6_cast_fu_878_p1[6]),
        .R(tmp_37_1_cast_mid2_reg_2752));
  FDRE \tmp_37_1_cast_mid2_reg_2752_reg[2] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_37_1_cast_mid2_fu_797_p3[2]),
        .Q(p_shl6_cast_fu_878_p1[7]),
        .R(tmp_37_1_cast_mid2_reg_2752));
  FDRE \tmp_37_1_cast_mid2_reg_2752_reg[3] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_37_1_cast_mid2_fu_797_p3[3]),
        .Q(p_shl6_cast_fu_878_p1[8]),
        .R(tmp_37_1_cast_mid2_reg_2752));
  FDRE \tmp_37_1_cast_mid2_reg_2752_reg[4] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_37_1_cast_mid2_fu_797_p3[4]),
        .Q(p_shl6_cast_fu_878_p1[9]),
        .R(tmp_37_1_cast_mid2_reg_2752));
  LUT6 #(
    .INIT(64'h9090909F9F9F909F)) 
    \tmp_37_2_cast_mid2_reg_2758[1]_i_1 
       (.I0(y_mid_fu_687_p3[1]),
        .I1(y_mid_fu_687_p3[0]),
        .I2(p_0_in28_out),
        .I3(y_reg_609[1]),
        .I4(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I5(p_shl10_cast_fu_1237_p1[6]),
        .O(tmp_37_2_cast_mid2_fu_811_p3[1]));
  LUT6 #(
    .INIT(64'h1E001EFF1EFF1E00)) 
    \tmp_37_2_cast_mid2_reg_2758[2]_i_1 
       (.I0(y_mid_fu_687_p3[1]),
        .I1(y_mid_fu_687_p3[0]),
        .I2(y_mid_fu_687_p3[2]),
        .I3(p_0_in28_out),
        .I4(ap_phi_mux_y_phi_fu_613_p4[1]),
        .I5(ap_phi_mux_y_phi_fu_613_p4[2]),
        .O(tmp_37_2_cast_mid2_fu_811_p3[2]));
  LUT6 #(
    .INIT(64'h001F3F3F3F200000)) 
    \tmp_37_2_cast_mid2_reg_2758[3]_i_1 
       (.I0(ap_phi_mux_y_phi_fu_613_p4[0]),
        .I1(exitcond_flatten_fu_681_p2),
        .I2(p_0_in28_out),
        .I3(ap_phi_mux_y_phi_fu_613_p4[1]),
        .I4(ap_phi_mux_y_phi_fu_613_p4[2]),
        .I5(ap_phi_mux_y_phi_fu_613_p4[3]),
        .O(tmp_37_2_cast_mid2_fu_811_p3[3]));
  LUT6 #(
    .INIT(64'h101F3F3F2F200000)) 
    \tmp_37_2_cast_mid2_reg_2758[4]_i_1 
       (.I0(\tmp_37_2_cast_mid2_reg_2758[4]_i_2_n_4 ),
        .I1(exitcond_flatten_fu_681_p2),
        .I2(p_0_in28_out),
        .I3(\tmp_37_2_cast_mid2_reg_2758[4]_i_3_n_4 ),
        .I4(ap_phi_mux_y_phi_fu_613_p4[3]),
        .I5(ap_phi_mux_y_phi_fu_613_p4[4]),
        .O(tmp_37_2_cast_mid2_fu_811_p3[4]));
  LUT6 #(
    .INIT(64'h0A0A0A0808080A08)) 
    \tmp_37_2_cast_mid2_reg_2758[4]_i_2 
       (.I0(ap_phi_mux_y_phi_fu_613_p4[2]),
        .I1(ap_phi_mux_y_phi_fu_613_p4[1]),
        .I2(exitcond_flatten_fu_681_p2),
        .I3(y_reg_609[0]),
        .I4(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I5(p_shl10_cast_fu_1237_p1[5]),
        .O(\tmp_37_2_cast_mid2_reg_2758[4]_i_2_n_4 ));
  LUT5 #(
    .INIT(32'hCCA000A0)) 
    \tmp_37_2_cast_mid2_reg_2758[4]_i_3 
       (.I0(y_reg_609[2]),
        .I1(p_shl10_cast_fu_1237_p1[7]),
        .I2(y_reg_609[1]),
        .I3(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I4(p_shl10_cast_fu_1237_p1[6]),
        .O(\tmp_37_2_cast_mid2_reg_2758[4]_i_3_n_4 ));
  FDSE \tmp_37_2_cast_mid2_reg_2758_reg[1] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_37_2_cast_mid2_fu_811_p3[1]),
        .Q(tmp_37_2_cast_mid2_reg_2758[1]),
        .S(tmp_37_1_cast_mid2_reg_2752));
  FDRE \tmp_37_2_cast_mid2_reg_2758_reg[2] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_37_2_cast_mid2_fu_811_p3[2]),
        .Q(tmp_37_2_cast_mid2_reg_2758[2]),
        .R(tmp_37_1_cast_mid2_reg_2752));
  FDRE \tmp_37_2_cast_mid2_reg_2758_reg[3] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_37_2_cast_mid2_fu_811_p3[3]),
        .Q(tmp_37_2_cast_mid2_reg_2758[3]),
        .R(tmp_37_1_cast_mid2_reg_2752));
  FDRE \tmp_37_2_cast_mid2_reg_2758_reg[4] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_37_2_cast_mid2_fu_811_p3[4]),
        .Q(tmp_37_2_cast_mid2_reg_2758[4]),
        .R(tmp_37_1_cast_mid2_reg_2752));
  LUT5 #(
    .INIT(32'h888BBB8B)) 
    \tmp_37_3_cast_mid2_reg_2764[0]_i_1 
       (.I0(y_mid_fu_687_p3[0]),
        .I1(p_0_in28_out),
        .I2(y_reg_609[0]),
        .I3(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I4(p_shl10_cast_fu_1237_p1[5]),
        .O(tmp_37_3_cast_mid2_fu_825_p3[0]));
  LUT6 #(
    .INIT(64'hB88BB8B8B88B8B8B)) 
    \tmp_37_3_cast_mid2_reg_2764[1]_i_1 
       (.I0(y_mid_fu_687_p3[1]),
        .I1(p_0_in28_out),
        .I2(ap_phi_mux_y_phi_fu_613_p4[1]),
        .I3(p_shl10_cast_fu_1237_p1[5]),
        .I4(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I5(y_reg_609[0]),
        .O(tmp_37_3_cast_mid2_fu_825_p3[1]));
  LUT5 #(
    .INIT(32'h44477774)) 
    \tmp_37_3_cast_mid2_reg_2764[2]_i_1 
       (.I0(y_mid_fu_687_p3[2]),
        .I1(p_0_in28_out),
        .I2(ap_phi_mux_y_phi_fu_613_p4[1]),
        .I3(ap_phi_mux_y_phi_fu_613_p4[0]),
        .I4(ap_phi_mux_y_phi_fu_613_p4[2]),
        .O(tmp_37_3_cast_mid2_fu_825_p3[2]));
  LUT5 #(
    .INIT(32'h606F6F60)) 
    \tmp_37_3_cast_mid2_reg_2764[3]_i_1 
       (.I0(y_mid_fu_687_p3[2]),
        .I1(y_mid_fu_687_p3[3]),
        .I2(p_0_in28_out),
        .I3(\tmp_37_3_cast_mid2_reg_2764[3]_i_2_n_4 ),
        .I4(ap_phi_mux_y_phi_fu_613_p4[3]),
        .O(tmp_37_3_cast_mid2_fu_825_p3[3]));
  LUT6 #(
    .INIT(64'hAAAA8A8AAAA08A80)) 
    \tmp_37_3_cast_mid2_reg_2764[3]_i_2 
       (.I0(ap_phi_mux_y_phi_fu_613_p4[2]),
        .I1(p_shl10_cast_fu_1237_p1[6]),
        .I2(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I3(y_reg_609[1]),
        .I4(p_shl10_cast_fu_1237_p1[5]),
        .I5(y_reg_609[0]),
        .O(\tmp_37_3_cast_mid2_reg_2764[3]_i_2_n_4 ));
  LUT6 #(
    .INIT(64'h0737777770400000)) 
    \tmp_37_3_cast_mid2_reg_2764[4]_i_1 
       (.I0(exitcond_flatten_fu_681_p2),
        .I1(p_0_in28_out),
        .I2(ap_phi_mux_y_phi_fu_613_p4[2]),
        .I3(\tmp_37_3_cast_mid2_reg_2764[4]_i_2_n_4 ),
        .I4(ap_phi_mux_y_phi_fu_613_p4[3]),
        .I5(ap_phi_mux_y_phi_fu_613_p4[4]),
        .O(tmp_37_3_cast_mid2_fu_825_p3[4]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT5 #(
    .INIT(32'hFFFACCFA)) 
    \tmp_37_3_cast_mid2_reg_2764[4]_i_2 
       (.I0(y_reg_609[0]),
        .I1(p_shl10_cast_fu_1237_p1[5]),
        .I2(y_reg_609[1]),
        .I3(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I4(p_shl10_cast_fu_1237_p1[6]),
        .O(\tmp_37_3_cast_mid2_reg_2764[4]_i_2_n_4 ));
  FDSE \tmp_37_3_cast_mid2_reg_2764_reg[0] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_37_3_cast_mid2_fu_825_p3[0]),
        .Q(tmp_37_3_cast_mid2_reg_2764[0]),
        .S(tmp_37_1_cast_mid2_reg_2752));
  FDSE \tmp_37_3_cast_mid2_reg_2764_reg[1] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_37_3_cast_mid2_fu_825_p3[1]),
        .Q(tmp_37_3_cast_mid2_reg_2764[1]),
        .S(tmp_37_1_cast_mid2_reg_2752));
  FDRE \tmp_37_3_cast_mid2_reg_2764_reg[2] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_37_3_cast_mid2_fu_825_p3[2]),
        .Q(tmp_37_3_cast_mid2_reg_2764[2]),
        .R(tmp_37_1_cast_mid2_reg_2752));
  FDRE \tmp_37_3_cast_mid2_reg_2764_reg[3] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_37_3_cast_mid2_fu_825_p3[3]),
        .Q(tmp_37_3_cast_mid2_reg_2764[3]),
        .R(tmp_37_1_cast_mid2_reg_2752));
  FDRE \tmp_37_3_cast_mid2_reg_2764_reg[4] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_37_3_cast_mid2_fu_825_p3[4]),
        .Q(tmp_37_3_cast_mid2_reg_2764[4]),
        .R(tmp_37_1_cast_mid2_reg_2752));
  LUT5 #(
    .INIT(32'h74777444)) 
    \tmp_37_4_cast_mid2_reg_2770[0]_i_1 
       (.I0(y_mid_fu_687_p3[0]),
        .I1(p_0_in28_out),
        .I2(p_shl10_cast_fu_1237_p1[5]),
        .I3(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I4(y_reg_609[0]),
        .O(tmp_37_4_cast_mid2_fu_839_p3[0]));
  LUT6 #(
    .INIT(64'h6F606F6F6F606060)) 
    \tmp_37_4_cast_mid2_reg_2770[1]_i_1 
       (.I0(y_mid_fu_687_p3[0]),
        .I1(y_mid_fu_687_p3[1]),
        .I2(p_0_in28_out),
        .I3(p_shl10_cast_fu_1237_p1[6]),
        .I4(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I5(y_reg_609[1]),
        .O(tmp_37_4_cast_mid2_fu_839_p3[1]));
  LUT5 #(
    .INIT(32'h870087FF)) 
    \tmp_37_4_cast_mid2_reg_2770[2]_i_1 
       (.I0(y_mid_fu_687_p3[0]),
        .I1(y_mid_fu_687_p3[1]),
        .I2(y_mid_fu_687_p3[2]),
        .I3(p_0_in28_out),
        .I4(ap_phi_mux_y_phi_fu_613_p4[2]),
        .O(tmp_37_4_cast_mid2_fu_839_p3[2]));
  LUT6 #(
    .INIT(64'h000007FF0FFF0800)) 
    \tmp_37_4_cast_mid2_reg_2770[3]_i_1 
       (.I0(ap_phi_mux_y_phi_fu_613_p4[1]),
        .I1(ap_phi_mux_y_phi_fu_613_p4[0]),
        .I2(exitcond_flatten_fu_681_p2),
        .I3(p_0_in28_out),
        .I4(ap_phi_mux_y_phi_fu_613_p4[2]),
        .I5(ap_phi_mux_y_phi_fu_613_p4[3]),
        .O(tmp_37_4_cast_mid2_fu_839_p3[3]));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \tmp_37_4_cast_mid2_reg_2770[3]_i_2 
       (.I0(p_shl10_cast_fu_1237_p1[6]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I4(y_reg_609[1]),
        .O(ap_phi_mux_y_phi_fu_613_p4[1]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \tmp_37_4_cast_mid2_reg_2770[3]_i_3 
       (.I0(p_shl10_cast_fu_1237_p1[5]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I4(y_reg_609[0]),
        .O(ap_phi_mux_y_phi_fu_613_p4[0]));
  LUT3 #(
    .INIT(8'h20)) 
    \tmp_37_4_cast_mid2_reg_2770[4]_i_1 
       (.I0(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .I1(p_0_in28_out),
        .I2(exitcond_flatten_fu_681_p2),
        .O(tmp_37_1_cast_mid2_reg_2752));
  LUT6 #(
    .INIT(64'h001F3F3F3F200000)) 
    \tmp_37_4_cast_mid2_reg_2770[4]_i_2 
       (.I0(\tmp_37_4_cast_mid2_reg_2770[4]_i_3_n_4 ),
        .I1(exitcond_flatten_fu_681_p2),
        .I2(p_0_in28_out),
        .I3(ap_phi_mux_y_phi_fu_613_p4[2]),
        .I4(ap_phi_mux_y_phi_fu_613_p4[3]),
        .I5(ap_phi_mux_y_phi_fu_613_p4[4]),
        .O(tmp_37_4_cast_mid2_fu_839_p3[4]));
  LUT6 #(
    .INIT(64'h0A000C0C0A000000)) 
    \tmp_37_4_cast_mid2_reg_2770[4]_i_3 
       (.I0(p_shl10_cast_fu_1237_p1[6]),
        .I1(y_reg_609[1]),
        .I2(exitcond_flatten_fu_681_p2),
        .I3(p_shl10_cast_fu_1237_p1[5]),
        .I4(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I5(y_reg_609[0]),
        .O(\tmp_37_4_cast_mid2_reg_2770[4]_i_3_n_4 ));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \tmp_37_4_cast_mid2_reg_2770[4]_i_4 
       (.I0(p_shl10_cast_fu_1237_p1[7]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I4(y_reg_609[2]),
        .O(ap_phi_mux_y_phi_fu_613_p4[2]));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \tmp_37_4_cast_mid2_reg_2770[4]_i_5 
       (.I0(p_shl10_cast_fu_1237_p1[8]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I4(y_reg_609[3]),
        .O(ap_phi_mux_y_phi_fu_613_p4[3]));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \tmp_37_4_cast_mid2_reg_2770[4]_i_6 
       (.I0(p_shl10_cast_fu_1237_p1[9]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I4(y_reg_609[4]),
        .O(ap_phi_mux_y_phi_fu_613_p4[4]));
  FDRE \tmp_37_4_cast_mid2_reg_2770_reg[0] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_37_4_cast_mid2_fu_839_p3[0]),
        .Q(tmp_37_4_cast_mid2_reg_2770[0]),
        .R(tmp_37_1_cast_mid2_reg_2752));
  FDRE \tmp_37_4_cast_mid2_reg_2770_reg[1] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_37_4_cast_mid2_fu_839_p3[1]),
        .Q(tmp_37_4_cast_mid2_reg_2770[1]),
        .R(tmp_37_1_cast_mid2_reg_2752));
  FDSE \tmp_37_4_cast_mid2_reg_2770_reg[2] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_37_4_cast_mid2_fu_839_p3[2]),
        .Q(tmp_37_4_cast_mid2_reg_2770[2]),
        .S(tmp_37_1_cast_mid2_reg_2752));
  FDRE \tmp_37_4_cast_mid2_reg_2770_reg[3] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_37_4_cast_mid2_fu_839_p3[3]),
        .Q(tmp_37_4_cast_mid2_reg_2770[3]),
        .R(tmp_37_1_cast_mid2_reg_2752));
  FDRE \tmp_37_4_cast_mid2_reg_2770_reg[4] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_37_4_cast_mid2_fu_839_p3[4]),
        .Q(tmp_37_4_cast_mid2_reg_2770[4]),
        .R(tmp_37_1_cast_mid2_reg_2752));
  LUT2 #(
    .INIT(4'h2)) 
    \tmp_39_0_1_cast_cast_reg_2871[4]_i_1 
       (.I0(ap_CS_fsm_pp0_stage4),
        .I1(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .O(\tmp_39_0_1_cast_cast_reg_2871[4]_i_1_n_4 ));
  FDRE \tmp_39_0_1_cast_cast_reg_2871_reg[0] 
       (.C(ap_clk),
        .CE(\tmp_39_0_1_cast_cast_reg_2871[4]_i_1_n_4 ),
        .D(tmp_39_0_1_cast_cast_fu_1029_p1[0]),
        .Q(tmp_39_0_1_cast_cast_reg_2871_reg__0[0]),
        .R(1'b0));
  FDRE \tmp_39_0_1_cast_cast_reg_2871_reg[1] 
       (.C(ap_clk),
        .CE(\tmp_39_0_1_cast_cast_reg_2871[4]_i_1_n_4 ),
        .D(tmp_39_0_1_cast_cast_fu_1029_p1[1]),
        .Q(tmp_39_0_1_cast_cast_reg_2871_reg__0[1]),
        .R(1'b0));
  FDRE \tmp_39_0_1_cast_cast_reg_2871_reg[2] 
       (.C(ap_clk),
        .CE(\tmp_39_0_1_cast_cast_reg_2871[4]_i_1_n_4 ),
        .D(tmp_39_0_1_cast_cast_fu_1029_p1[2]),
        .Q(tmp_39_0_1_cast_cast_reg_2871_reg__0[2]),
        .R(1'b0));
  FDRE \tmp_39_0_1_cast_cast_reg_2871_reg[3] 
       (.C(ap_clk),
        .CE(\tmp_39_0_1_cast_cast_reg_2871[4]_i_1_n_4 ),
        .D(tmp_39_0_1_cast_cast_fu_1029_p1[3]),
        .Q(tmp_39_0_1_cast_cast_reg_2871_reg__0[3]),
        .R(1'b0));
  FDRE \tmp_39_0_1_cast_cast_reg_2871_reg[4] 
       (.C(ap_clk),
        .CE(\tmp_39_0_1_cast_cast_reg_2871[4]_i_1_n_4 ),
        .D(tmp_39_0_1_cast_cast_fu_1029_p1[4]),
        .Q(tmp_39_0_1_cast_cast_reg_2871_reg__0[4]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair79" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \tmp_39_0_2_cast_cast_reg_2794[1]_i_1 
       (.I0(\x_mid2_reg_2734_reg_n_4_[1] ),
        .O(tmp_39_0_2_fu_899_p2[1]));
  (* SOFT_HLUTNM = "soft_lutpair79" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_39_0_2_cast_cast_reg_2794[2]_i_1 
       (.I0(\x_mid2_reg_2734_reg_n_4_[1] ),
        .I1(\x_mid2_reg_2734_reg_n_4_[2] ),
        .O(tmp_39_0_2_fu_899_p2[2]));
  (* SOFT_HLUTNM = "soft_lutpair52" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \tmp_39_0_2_cast_cast_reg_2794[3]_i_1 
       (.I0(\x_mid2_reg_2734_reg_n_4_[1] ),
        .I1(\x_mid2_reg_2734_reg_n_4_[2] ),
        .I2(\x_mid2_reg_2734_reg_n_4_[3] ),
        .O(tmp_39_0_2_fu_899_p2[3]));
  LUT2 #(
    .INIT(4'h2)) 
    \tmp_39_0_2_cast_cast_reg_2794[4]_i_1 
       (.I0(ap_CS_fsm_pp0_stage1),
        .I1(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .O(\tmp_39_0_2_cast_cast_reg_2794[4]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair52" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \tmp_39_0_2_cast_cast_reg_2794[4]_i_2 
       (.I0(\x_mid2_reg_2734_reg_n_4_[2] ),
        .I1(\x_mid2_reg_2734_reg_n_4_[1] ),
        .I2(\x_mid2_reg_2734_reg_n_4_[3] ),
        .I3(\x_mid2_reg_2734_reg_n_4_[4] ),
        .O(tmp_39_0_2_fu_899_p2[4]));
  FDRE \tmp_39_0_2_cast_cast_reg_2794_reg[0] 
       (.C(ap_clk),
        .CE(\tmp_39_0_2_cast_cast_reg_2794[4]_i_1_n_4 ),
        .D(\x_mid2_reg_2734_reg_n_4_[0] ),
        .Q(tmp_39_0_2_cast_cast_reg_2794[0]),
        .R(1'b0));
  FDRE \tmp_39_0_2_cast_cast_reg_2794_reg[1] 
       (.C(ap_clk),
        .CE(\tmp_39_0_2_cast_cast_reg_2794[4]_i_1_n_4 ),
        .D(tmp_39_0_2_fu_899_p2[1]),
        .Q(tmp_39_0_2_cast_cast_reg_2794[1]),
        .R(1'b0));
  FDRE \tmp_39_0_2_cast_cast_reg_2794_reg[2] 
       (.C(ap_clk),
        .CE(\tmp_39_0_2_cast_cast_reg_2794[4]_i_1_n_4 ),
        .D(tmp_39_0_2_fu_899_p2[2]),
        .Q(tmp_39_0_2_cast_cast_reg_2794[2]),
        .R(1'b0));
  FDRE \tmp_39_0_2_cast_cast_reg_2794_reg[3] 
       (.C(ap_clk),
        .CE(\tmp_39_0_2_cast_cast_reg_2794[4]_i_1_n_4 ),
        .D(tmp_39_0_2_fu_899_p2[3]),
        .Q(tmp_39_0_2_cast_cast_reg_2794[3]),
        .R(1'b0));
  FDRE \tmp_39_0_2_cast_cast_reg_2794_reg[4] 
       (.C(ap_clk),
        .CE(\tmp_39_0_2_cast_cast_reg_2794[4]_i_1_n_4 ),
        .D(tmp_39_0_2_fu_899_p2[4]),
        .Q(tmp_39_0_2_cast_cast_reg_2794[4]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair47" *) 
  LUT2 #(
    .INIT(4'h9)) 
    \tmp_39_0_3_cast_cast_reg_2917[1]_i_1 
       (.I0(\x_mid2_reg_2734_reg_n_4_[1] ),
        .I1(\x_mid2_reg_2734_reg_n_4_[0] ),
        .O(tmp_39_0_3_fu_1115_p2[1]));
  (* SOFT_HLUTNM = "soft_lutpair62" *) 
  LUT3 #(
    .INIT(8'h1E)) 
    \tmp_39_0_3_cast_cast_reg_2917[2]_i_1 
       (.I0(\x_mid2_reg_2734_reg_n_4_[1] ),
        .I1(\x_mid2_reg_2734_reg_n_4_[0] ),
        .I2(\x_mid2_reg_2734_reg_n_4_[2] ),
        .O(tmp_39_0_3_fu_1115_p2[2]));
  (* SOFT_HLUTNM = "soft_lutpair45" *) 
  LUT4 #(
    .INIT(16'h1FE0)) 
    \tmp_39_0_3_cast_cast_reg_2917[3]_i_1 
       (.I0(\x_mid2_reg_2734_reg_n_4_[0] ),
        .I1(\x_mid2_reg_2734_reg_n_4_[1] ),
        .I2(\x_mid2_reg_2734_reg_n_4_[2] ),
        .I3(\x_mid2_reg_2734_reg_n_4_[3] ),
        .O(tmp_39_0_3_fu_1115_p2[3]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h57FFA800)) 
    \tmp_39_0_3_cast_cast_reg_2917[4]_i_1 
       (.I0(\x_mid2_reg_2734_reg_n_4_[2] ),
        .I1(\x_mid2_reg_2734_reg_n_4_[1] ),
        .I2(\x_mid2_reg_2734_reg_n_4_[0] ),
        .I3(\x_mid2_reg_2734_reg_n_4_[3] ),
        .I4(\x_mid2_reg_2734_reg_n_4_[4] ),
        .O(tmp_39_0_3_fu_1115_p2[4]));
  FDRE \tmp_39_0_3_cast_cast_reg_2917_reg[0] 
       (.C(ap_clk),
        .CE(\tmp_98_reg_2909[9]_i_1_n_4 ),
        .D(tmp_39_0_1_cast_cast_fu_1029_p1[0]),
        .Q(tmp_39_0_3_cast_cast_reg_2917_reg__0[0]),
        .R(1'b0));
  FDRE \tmp_39_0_3_cast_cast_reg_2917_reg[1] 
       (.C(ap_clk),
        .CE(\tmp_98_reg_2909[9]_i_1_n_4 ),
        .D(tmp_39_0_3_fu_1115_p2[1]),
        .Q(tmp_39_0_3_cast_cast_reg_2917_reg__0[1]),
        .R(1'b0));
  FDRE \tmp_39_0_3_cast_cast_reg_2917_reg[2] 
       (.C(ap_clk),
        .CE(\tmp_98_reg_2909[9]_i_1_n_4 ),
        .D(tmp_39_0_3_fu_1115_p2[2]),
        .Q(tmp_39_0_3_cast_cast_reg_2917_reg__0[2]),
        .R(1'b0));
  FDRE \tmp_39_0_3_cast_cast_reg_2917_reg[3] 
       (.C(ap_clk),
        .CE(\tmp_98_reg_2909[9]_i_1_n_4 ),
        .D(tmp_39_0_3_fu_1115_p2[3]),
        .Q(tmp_39_0_3_cast_cast_reg_2917_reg__0[3]),
        .R(1'b0));
  FDRE \tmp_39_0_3_cast_cast_reg_2917_reg[4] 
       (.C(ap_clk),
        .CE(\tmp_98_reg_2909[9]_i_1_n_4 ),
        .D(tmp_39_0_3_fu_1115_p2[4]),
        .Q(tmp_39_0_3_cast_cast_reg_2917_reg__0[4]),
        .R(1'b0));
  LUT1 #(
    .INIT(2'h1)) 
    \tmp_39_0_4_cast_cast_reg_2812[2]_i_1 
       (.I0(\x_mid2_reg_2734_reg_n_4_[2] ),
        .O(tmp_39_0_4_fu_929_p2[2]));
  (* SOFT_HLUTNM = "soft_lutpair63" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_39_0_4_cast_cast_reg_2812[3]_i_1 
       (.I0(\x_mid2_reg_2734_reg_n_4_[2] ),
        .I1(\x_mid2_reg_2734_reg_n_4_[3] ),
        .O(tmp_39_0_4_fu_929_p2[3]));
  LUT2 #(
    .INIT(4'h2)) 
    \tmp_39_0_4_cast_cast_reg_2812[4]_i_1 
       (.I0(ap_CS_fsm_pp0_stage2),
        .I1(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .O(\tmp_39_0_4_cast_cast_reg_2812[4]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair63" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \tmp_39_0_4_cast_cast_reg_2812[4]_i_2 
       (.I0(\x_mid2_reg_2734_reg_n_4_[2] ),
        .I1(\x_mid2_reg_2734_reg_n_4_[3] ),
        .I2(\x_mid2_reg_2734_reg_n_4_[4] ),
        .O(tmp_39_0_4_fu_929_p2[4]));
  FDRE \tmp_39_0_4_cast_cast_reg_2812_reg[0] 
       (.C(ap_clk),
        .CE(\tmp_39_0_4_cast_cast_reg_2812[4]_i_1_n_4 ),
        .D(\x_mid2_reg_2734_reg_n_4_[0] ),
        .Q(tmp_39_0_4_cast_cast_reg_2812_reg__0[0]),
        .R(1'b0));
  FDRE \tmp_39_0_4_cast_cast_reg_2812_reg[1] 
       (.C(ap_clk),
        .CE(\tmp_39_0_4_cast_cast_reg_2812[4]_i_1_n_4 ),
        .D(\x_mid2_reg_2734_reg_n_4_[1] ),
        .Q(tmp_39_0_4_cast_cast_reg_2812_reg__0[1]),
        .R(1'b0));
  FDRE \tmp_39_0_4_cast_cast_reg_2812_reg[2] 
       (.C(ap_clk),
        .CE(\tmp_39_0_4_cast_cast_reg_2812[4]_i_1_n_4 ),
        .D(tmp_39_0_4_fu_929_p2[2]),
        .Q(tmp_39_0_4_cast_cast_reg_2812_reg__0[2]),
        .R(1'b0));
  FDRE \tmp_39_0_4_cast_cast_reg_2812_reg[3] 
       (.C(ap_clk),
        .CE(\tmp_39_0_4_cast_cast_reg_2812[4]_i_1_n_4 ),
        .D(tmp_39_0_4_fu_929_p2[3]),
        .Q(tmp_39_0_4_cast_cast_reg_2812_reg__0[3]),
        .R(1'b0));
  FDRE \tmp_39_0_4_cast_cast_reg_2812_reg[4] 
       (.C(ap_clk),
        .CE(\tmp_39_0_4_cast_cast_reg_2812[4]_i_1_n_4 ),
        .D(tmp_39_0_4_fu_929_p2[4]),
        .Q(tmp_39_0_4_cast_cast_reg_2812_reg__0[4]),
        .R(1'b0));
  LUT2 #(
    .INIT(4'h2)) 
    \tmp_6_cast_reg_2838[4]_i_1 
       (.I0(ap_CS_fsm_pp0_stage3),
        .I1(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .O(\tmp_6_cast_reg_2838[4]_i_1_n_4 ));
  FDRE \tmp_6_cast_reg_2838_reg[0] 
       (.C(ap_clk),
        .CE(\tmp_6_cast_reg_2838[4]_i_1_n_4 ),
        .D(\x_mid2_reg_2734_reg_n_4_[0] ),
        .Q(tmp_6_cast_reg_2838_reg__0[0]),
        .R(1'b0));
  FDRE \tmp_6_cast_reg_2838_reg[1] 
       (.C(ap_clk),
        .CE(\tmp_6_cast_reg_2838[4]_i_1_n_4 ),
        .D(\x_mid2_reg_2734_reg_n_4_[1] ),
        .Q(data7[1]),
        .R(1'b0));
  FDRE \tmp_6_cast_reg_2838_reg[2] 
       (.C(ap_clk),
        .CE(\tmp_6_cast_reg_2838[4]_i_1_n_4 ),
        .D(\x_mid2_reg_2734_reg_n_4_[2] ),
        .Q(tmp_6_cast_reg_2838_reg__0[2]),
        .R(1'b0));
  FDRE \tmp_6_cast_reg_2838_reg[3] 
       (.C(ap_clk),
        .CE(\tmp_6_cast_reg_2838[4]_i_1_n_4 ),
        .D(\x_mid2_reg_2734_reg_n_4_[3] ),
        .Q(tmp_6_cast_reg_2838_reg__0[3]),
        .R(1'b0));
  FDRE \tmp_6_cast_reg_2838_reg[4] 
       (.C(ap_clk),
        .CE(\tmp_6_cast_reg_2838[4]_i_1_n_4 ),
        .D(\x_mid2_reg_2734_reg_n_4_[4] ),
        .Q(tmp_6_cast_reg_2838_reg__0[4]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_83_reg_2990[3]_i_1 
       (.I0(p_shl10_cast_fu_1237_p1[5]),
        .I1(p_shl10_cast_fu_1237_p1[6]),
        .O(\tmp_83_reg_2990[3]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair48" *) 
  LUT3 #(
    .INIT(8'h1E)) 
    \tmp_83_reg_2990[4]_i_1 
       (.I0(p_shl10_cast_fu_1237_p1[5]),
        .I1(p_shl10_cast_fu_1237_p1[6]),
        .I2(p_shl10_cast_fu_1237_p1[7]),
        .O(\tmp_83_reg_2990[4]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair48" *) 
  LUT4 #(
    .INIT(16'hF01E)) 
    \tmp_83_reg_2990[5]_i_1 
       (.I0(p_shl10_cast_fu_1237_p1[7]),
        .I1(p_shl10_cast_fu_1237_p1[6]),
        .I2(p_shl10_cast_fu_1237_p1[8]),
        .I3(p_shl10_cast_fu_1237_p1[5]),
        .O(tmp_83_fu_1252_p2[5]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT5 #(
    .INIT(32'hF30C0DF2)) 
    \tmp_83_reg_2990[6]_i_1 
       (.I0(p_shl10_cast_fu_1237_p1[7]),
        .I1(p_shl10_cast_fu_1237_p1[5]),
        .I2(p_shl10_cast_fu_1237_p1[8]),
        .I3(p_shl10_cast_fu_1237_p1[9]),
        .I4(p_shl10_cast_fu_1237_p1[6]),
        .O(tmp_83_fu_1252_p2[6]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT5 #(
    .INIT(32'h40F4BF0A)) 
    \tmp_83_reg_2990[7]_i_1 
       (.I0(p_shl10_cast_fu_1237_p1[8]),
        .I1(p_shl10_cast_fu_1237_p1[5]),
        .I2(p_shl10_cast_fu_1237_p1[6]),
        .I3(p_shl10_cast_fu_1237_p1[9]),
        .I4(p_shl10_cast_fu_1237_p1[7]),
        .O(\tmp_83_reg_2990[7]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT5 #(
    .INIT(32'hBABA0444)) 
    \tmp_83_reg_2990[8]_i_1 
       (.I0(p_shl10_cast_fu_1237_p1[7]),
        .I1(p_shl10_cast_fu_1237_p1[9]),
        .I2(p_shl10_cast_fu_1237_p1[6]),
        .I3(p_shl10_cast_fu_1237_p1[5]),
        .I4(p_shl10_cast_fu_1237_p1[8]),
        .O(\tmp_83_reg_2990[8]_i_1_n_4 ));
  LUT2 #(
    .INIT(4'h2)) 
    \tmp_83_reg_2990[9]_i_1 
       (.I0(ap_CS_fsm_pp0_stage7),
        .I1(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .O(\tmp_83_reg_2990[9]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT5 #(
    .INIT(32'hFFEA0000)) 
    \tmp_83_reg_2990[9]_i_2 
       (.I0(p_shl10_cast_fu_1237_p1[8]),
        .I1(p_shl10_cast_fu_1237_p1[5]),
        .I2(p_shl10_cast_fu_1237_p1[6]),
        .I3(p_shl10_cast_fu_1237_p1[7]),
        .I4(p_shl10_cast_fu_1237_p1[9]),
        .O(\tmp_83_reg_2990[9]_i_2_n_4 ));
  FDRE \tmp_83_reg_2990_reg[2] 
       (.C(ap_clk),
        .CE(\tmp_83_reg_2990[9]_i_1_n_4 ),
        .D(p_shl10_cast_fu_1237_p1[5]),
        .Q(tmp_83_reg_2990_reg__0[0]),
        .R(1'b0));
  FDRE \tmp_83_reg_2990_reg[3] 
       (.C(ap_clk),
        .CE(\tmp_83_reg_2990[9]_i_1_n_4 ),
        .D(\tmp_83_reg_2990[3]_i_1_n_4 ),
        .Q(tmp_83_reg_2990_reg__0[1]),
        .R(1'b0));
  FDRE \tmp_83_reg_2990_reg[4] 
       (.C(ap_clk),
        .CE(\tmp_83_reg_2990[9]_i_1_n_4 ),
        .D(\tmp_83_reg_2990[4]_i_1_n_4 ),
        .Q(tmp_83_reg_2990_reg__0[2]),
        .R(1'b0));
  FDRE \tmp_83_reg_2990_reg[5] 
       (.C(ap_clk),
        .CE(\tmp_83_reg_2990[9]_i_1_n_4 ),
        .D(tmp_83_fu_1252_p2[5]),
        .Q(tmp_83_reg_2990_reg__0[3]),
        .R(1'b0));
  FDRE \tmp_83_reg_2990_reg[6] 
       (.C(ap_clk),
        .CE(\tmp_83_reg_2990[9]_i_1_n_4 ),
        .D(tmp_83_fu_1252_p2[6]),
        .Q(tmp_83_reg_2990_reg__0[4]),
        .R(1'b0));
  FDRE \tmp_83_reg_2990_reg[7] 
       (.C(ap_clk),
        .CE(\tmp_83_reg_2990[9]_i_1_n_4 ),
        .D(\tmp_83_reg_2990[7]_i_1_n_4 ),
        .Q(tmp_83_reg_2990_reg__0[5]),
        .R(1'b0));
  FDRE \tmp_83_reg_2990_reg[8] 
       (.C(ap_clk),
        .CE(\tmp_83_reg_2990[9]_i_1_n_4 ),
        .D(\tmp_83_reg_2990[8]_i_1_n_4 ),
        .Q(tmp_83_reg_2990_reg__0[6]),
        .R(1'b0));
  FDRE \tmp_83_reg_2990_reg[9] 
       (.C(ap_clk),
        .CE(\tmp_83_reg_2990[9]_i_1_n_4 ),
        .D(\tmp_83_reg_2990[9]_i_2_n_4 ),
        .Q(tmp_83_reg_2990_reg__0[7]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair43" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_89_reg_2786[3]_i_1 
       (.I0(tmp_37_3_cast_mid2_reg_2764[0]),
        .I1(p_shl6_cast_fu_878_p1[6]),
        .O(\tmp_89_reg_2786[3]_i_1_n_4 ));
  LUT3 #(
    .INIT(8'h1E)) 
    \tmp_89_reg_2786[4]_i_1 
       (.I0(tmp_37_3_cast_mid2_reg_2764[0]),
        .I1(p_shl6_cast_fu_878_p1[6]),
        .I2(p_shl6_cast_fu_878_p1[7]),
        .O(\tmp_89_reg_2786[4]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair43" *) 
  LUT4 #(
    .INIT(16'hF01E)) 
    \tmp_89_reg_2786[5]_i_1 
       (.I0(p_shl6_cast_fu_878_p1[7]),
        .I1(p_shl6_cast_fu_878_p1[6]),
        .I2(p_shl6_cast_fu_878_p1[8]),
        .I3(tmp_37_3_cast_mid2_reg_2764[0]),
        .O(tmp_89_fu_893_p2[5]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT5 #(
    .INIT(32'hF30C0DF2)) 
    \tmp_89_reg_2786[6]_i_1 
       (.I0(p_shl6_cast_fu_878_p1[7]),
        .I1(tmp_37_3_cast_mid2_reg_2764[0]),
        .I2(p_shl6_cast_fu_878_p1[8]),
        .I3(p_shl6_cast_fu_878_p1[9]),
        .I4(p_shl6_cast_fu_878_p1[6]),
        .O(tmp_89_fu_893_p2[6]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT5 #(
    .INIT(32'h40F4BF0A)) 
    \tmp_89_reg_2786[7]_i_1 
       (.I0(p_shl6_cast_fu_878_p1[8]),
        .I1(tmp_37_3_cast_mid2_reg_2764[0]),
        .I2(p_shl6_cast_fu_878_p1[6]),
        .I3(p_shl6_cast_fu_878_p1[9]),
        .I4(p_shl6_cast_fu_878_p1[7]),
        .O(\tmp_89_reg_2786[7]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT5 #(
    .INIT(32'hBABA0444)) 
    \tmp_89_reg_2786[8]_i_1 
       (.I0(p_shl6_cast_fu_878_p1[7]),
        .I1(p_shl6_cast_fu_878_p1[9]),
        .I2(p_shl6_cast_fu_878_p1[6]),
        .I3(tmp_37_3_cast_mid2_reg_2764[0]),
        .I4(p_shl6_cast_fu_878_p1[8]),
        .O(\tmp_89_reg_2786[8]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT5 #(
    .INIT(32'hFFEA0000)) 
    \tmp_89_reg_2786[9]_i_1 
       (.I0(p_shl6_cast_fu_878_p1[8]),
        .I1(tmp_37_3_cast_mid2_reg_2764[0]),
        .I2(p_shl6_cast_fu_878_p1[6]),
        .I3(p_shl6_cast_fu_878_p1[7]),
        .I4(p_shl6_cast_fu_878_p1[9]),
        .O(\tmp_89_reg_2786[9]_i_1_n_4 ));
  FDRE \tmp_89_reg_2786_reg[2] 
       (.C(ap_clk),
        .CE(\tmp_39_0_2_cast_cast_reg_2794[4]_i_1_n_4 ),
        .D(tmp_37_3_cast_mid2_reg_2764[0]),
        .Q(\tmp_89_reg_2786_reg_n_4_[2] ),
        .R(1'b0));
  FDRE \tmp_89_reg_2786_reg[3] 
       (.C(ap_clk),
        .CE(\tmp_39_0_2_cast_cast_reg_2794[4]_i_1_n_4 ),
        .D(\tmp_89_reg_2786[3]_i_1_n_4 ),
        .Q(\tmp_89_reg_2786_reg_n_4_[3] ),
        .R(1'b0));
  FDRE \tmp_89_reg_2786_reg[4] 
       (.C(ap_clk),
        .CE(\tmp_39_0_2_cast_cast_reg_2794[4]_i_1_n_4 ),
        .D(\tmp_89_reg_2786[4]_i_1_n_4 ),
        .Q(\tmp_89_reg_2786_reg_n_4_[4] ),
        .R(1'b0));
  FDRE \tmp_89_reg_2786_reg[5] 
       (.C(ap_clk),
        .CE(\tmp_39_0_2_cast_cast_reg_2794[4]_i_1_n_4 ),
        .D(tmp_89_fu_893_p2[5]),
        .Q(\tmp_89_reg_2786_reg_n_4_[5] ),
        .R(1'b0));
  FDRE \tmp_89_reg_2786_reg[6] 
       (.C(ap_clk),
        .CE(\tmp_39_0_2_cast_cast_reg_2794[4]_i_1_n_4 ),
        .D(tmp_89_fu_893_p2[6]),
        .Q(\tmp_89_reg_2786_reg_n_4_[6] ),
        .R(1'b0));
  FDRE \tmp_89_reg_2786_reg[7] 
       (.C(ap_clk),
        .CE(\tmp_39_0_2_cast_cast_reg_2794[4]_i_1_n_4 ),
        .D(\tmp_89_reg_2786[7]_i_1_n_4 ),
        .Q(\tmp_89_reg_2786_reg_n_4_[7] ),
        .R(1'b0));
  FDRE \tmp_89_reg_2786_reg[8] 
       (.C(ap_clk),
        .CE(\tmp_39_0_2_cast_cast_reg_2794[4]_i_1_n_4 ),
        .D(\tmp_89_reg_2786[8]_i_1_n_4 ),
        .Q(\tmp_89_reg_2786_reg_n_4_[8] ),
        .R(1'b0));
  FDRE \tmp_89_reg_2786_reg[9] 
       (.C(ap_clk),
        .CE(\tmp_39_0_2_cast_cast_reg_2794[4]_i_1_n_4 ),
        .D(\tmp_89_reg_2786[9]_i_1_n_4 ),
        .Q(\tmp_89_reg_2786_reg_n_4_[9] ),
        .R(1'b0));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_92_reg_2830[3]_i_1 
       (.I0(tmp_37_4_cast_mid2_reg_2770[0]),
        .I1(tmp_37_2_cast_mid2_reg_2758[1]),
        .O(\tmp_92_reg_2830[3]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair50" *) 
  LUT3 #(
    .INIT(8'h1E)) 
    \tmp_92_reg_2830[4]_i_1 
       (.I0(tmp_37_4_cast_mid2_reg_2770[0]),
        .I1(tmp_37_2_cast_mid2_reg_2758[1]),
        .I2(tmp_37_2_cast_mid2_reg_2758[2]),
        .O(\tmp_92_reg_2830[4]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair50" *) 
  LUT4 #(
    .INIT(16'hF01E)) 
    \tmp_92_reg_2830[5]_i_1 
       (.I0(tmp_37_2_cast_mid2_reg_2758[2]),
        .I1(tmp_37_2_cast_mid2_reg_2758[1]),
        .I2(tmp_37_2_cast_mid2_reg_2758[3]),
        .I3(tmp_37_4_cast_mid2_reg_2770[0]),
        .O(tmp_92_fu_980_p2[5]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hF30C0DF2)) 
    \tmp_92_reg_2830[6]_i_1 
       (.I0(tmp_37_2_cast_mid2_reg_2758[2]),
        .I1(tmp_37_4_cast_mid2_reg_2770[0]),
        .I2(tmp_37_2_cast_mid2_reg_2758[3]),
        .I3(tmp_37_2_cast_mid2_reg_2758[4]),
        .I4(tmp_37_2_cast_mid2_reg_2758[1]),
        .O(tmp_92_fu_980_p2[6]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h40F4BF0A)) 
    \tmp_92_reg_2830[7]_i_1 
       (.I0(tmp_37_2_cast_mid2_reg_2758[3]),
        .I1(tmp_37_4_cast_mid2_reg_2770[0]),
        .I2(tmp_37_2_cast_mid2_reg_2758[1]),
        .I3(tmp_37_2_cast_mid2_reg_2758[4]),
        .I4(tmp_37_2_cast_mid2_reg_2758[2]),
        .O(\tmp_92_reg_2830[7]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT5 #(
    .INIT(32'hBABA0444)) 
    \tmp_92_reg_2830[8]_i_1 
       (.I0(tmp_37_2_cast_mid2_reg_2758[2]),
        .I1(tmp_37_2_cast_mid2_reg_2758[4]),
        .I2(tmp_37_2_cast_mid2_reg_2758[1]),
        .I3(tmp_37_4_cast_mid2_reg_2770[0]),
        .I4(tmp_37_2_cast_mid2_reg_2758[3]),
        .O(\tmp_92_reg_2830[8]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT5 #(
    .INIT(32'hFFEA0000)) 
    \tmp_92_reg_2830[9]_i_1 
       (.I0(tmp_37_2_cast_mid2_reg_2758[3]),
        .I1(tmp_37_4_cast_mid2_reg_2770[0]),
        .I2(tmp_37_2_cast_mid2_reg_2758[1]),
        .I3(tmp_37_2_cast_mid2_reg_2758[2]),
        .I4(tmp_37_2_cast_mid2_reg_2758[4]),
        .O(\tmp_92_reg_2830[9]_i_1_n_4 ));
  FDRE \tmp_92_reg_2830_reg[2] 
       (.C(ap_clk),
        .CE(\tmp_6_cast_reg_2838[4]_i_1_n_4 ),
        .D(tmp_37_4_cast_mid2_reg_2770[0]),
        .Q(tmp_92_reg_2830_reg__0[0]),
        .R(1'b0));
  FDRE \tmp_92_reg_2830_reg[3] 
       (.C(ap_clk),
        .CE(\tmp_6_cast_reg_2838[4]_i_1_n_4 ),
        .D(\tmp_92_reg_2830[3]_i_1_n_4 ),
        .Q(tmp_92_reg_2830_reg__0[1]),
        .R(1'b0));
  FDRE \tmp_92_reg_2830_reg[4] 
       (.C(ap_clk),
        .CE(\tmp_6_cast_reg_2838[4]_i_1_n_4 ),
        .D(\tmp_92_reg_2830[4]_i_1_n_4 ),
        .Q(tmp_92_reg_2830_reg__0[2]),
        .R(1'b0));
  FDRE \tmp_92_reg_2830_reg[5] 
       (.C(ap_clk),
        .CE(\tmp_6_cast_reg_2838[4]_i_1_n_4 ),
        .D(tmp_92_fu_980_p2[5]),
        .Q(tmp_92_reg_2830_reg__0[3]),
        .R(1'b0));
  FDRE \tmp_92_reg_2830_reg[6] 
       (.C(ap_clk),
        .CE(\tmp_6_cast_reg_2838[4]_i_1_n_4 ),
        .D(tmp_92_fu_980_p2[6]),
        .Q(tmp_92_reg_2830_reg__0[4]),
        .R(1'b0));
  FDRE \tmp_92_reg_2830_reg[7] 
       (.C(ap_clk),
        .CE(\tmp_6_cast_reg_2838[4]_i_1_n_4 ),
        .D(\tmp_92_reg_2830[7]_i_1_n_4 ),
        .Q(tmp_92_reg_2830_reg__0[5]),
        .R(1'b0));
  FDRE \tmp_92_reg_2830_reg[8] 
       (.C(ap_clk),
        .CE(\tmp_6_cast_reg_2838[4]_i_1_n_4 ),
        .D(\tmp_92_reg_2830[8]_i_1_n_4 ),
        .Q(tmp_92_reg_2830_reg__0[6]),
        .R(1'b0));
  FDRE \tmp_92_reg_2830_reg[9] 
       (.C(ap_clk),
        .CE(\tmp_6_cast_reg_2838[4]_i_1_n_4 ),
        .D(\tmp_92_reg_2830[9]_i_1_n_4 ),
        .Q(tmp_92_reg_2830_reg__0[7]),
        .R(1'b0));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_95_reg_3368[3]_i_1 
       (.I0(tmp_37_3_cast_mid2_reg_2764[0]),
        .I1(tmp_37_3_cast_mid2_reg_2764[1]),
        .O(\tmp_95_reg_3368[3]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair53" *) 
  LUT3 #(
    .INIT(8'h1E)) 
    \tmp_95_reg_3368[4]_i_1 
       (.I0(tmp_37_3_cast_mid2_reg_2764[0]),
        .I1(tmp_37_3_cast_mid2_reg_2764[1]),
        .I2(tmp_37_3_cast_mid2_reg_2764[2]),
        .O(\tmp_95_reg_3368[4]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair53" *) 
  LUT4 #(
    .INIT(16'hF01E)) 
    \tmp_95_reg_3368[5]_i_1 
       (.I0(tmp_37_3_cast_mid2_reg_2764[2]),
        .I1(tmp_37_3_cast_mid2_reg_2764[1]),
        .I2(tmp_37_3_cast_mid2_reg_2764[3]),
        .I3(tmp_37_3_cast_mid2_reg_2764[0]),
        .O(tmp_95_fu_1917_p2[5]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'hF30C0DF2)) 
    \tmp_95_reg_3368[6]_i_1 
       (.I0(tmp_37_3_cast_mid2_reg_2764[2]),
        .I1(tmp_37_3_cast_mid2_reg_2764[0]),
        .I2(tmp_37_3_cast_mid2_reg_2764[3]),
        .I3(tmp_37_3_cast_mid2_reg_2764[4]),
        .I4(tmp_37_3_cast_mid2_reg_2764[1]),
        .O(tmp_95_fu_1917_p2[6]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h40F4BF0A)) 
    \tmp_95_reg_3368[7]_i_1 
       (.I0(tmp_37_3_cast_mid2_reg_2764[3]),
        .I1(tmp_37_3_cast_mid2_reg_2764[0]),
        .I2(tmp_37_3_cast_mid2_reg_2764[1]),
        .I3(tmp_37_3_cast_mid2_reg_2764[4]),
        .I4(tmp_37_3_cast_mid2_reg_2764[2]),
        .O(\tmp_95_reg_3368[7]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT5 #(
    .INIT(32'hBABA0444)) 
    \tmp_95_reg_3368[8]_i_1 
       (.I0(tmp_37_3_cast_mid2_reg_2764[2]),
        .I1(tmp_37_3_cast_mid2_reg_2764[4]),
        .I2(tmp_37_3_cast_mid2_reg_2764[1]),
        .I3(tmp_37_3_cast_mid2_reg_2764[0]),
        .I4(tmp_37_3_cast_mid2_reg_2764[3]),
        .O(\tmp_95_reg_3368[8]_i_1_n_4 ));
  LUT2 #(
    .INIT(4'h2)) 
    \tmp_95_reg_3368[9]_i_1 
       (.I0(ap_CS_fsm_pp0_stage18),
        .I1(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .O(\tmp_95_reg_3368[9]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT5 #(
    .INIT(32'hFFEA0000)) 
    \tmp_95_reg_3368[9]_i_2 
       (.I0(tmp_37_3_cast_mid2_reg_2764[3]),
        .I1(tmp_37_3_cast_mid2_reg_2764[0]),
        .I2(tmp_37_3_cast_mid2_reg_2764[1]),
        .I3(tmp_37_3_cast_mid2_reg_2764[2]),
        .I4(tmp_37_3_cast_mid2_reg_2764[4]),
        .O(\tmp_95_reg_3368[9]_i_2_n_4 ));
  FDRE \tmp_95_reg_3368_reg[2] 
       (.C(ap_clk),
        .CE(\tmp_95_reg_3368[9]_i_1_n_4 ),
        .D(tmp_37_3_cast_mid2_reg_2764[0]),
        .Q(tmp_95_reg_3368_reg__0[0]),
        .R(1'b0));
  FDRE \tmp_95_reg_3368_reg[3] 
       (.C(ap_clk),
        .CE(\tmp_95_reg_3368[9]_i_1_n_4 ),
        .D(\tmp_95_reg_3368[3]_i_1_n_4 ),
        .Q(tmp_95_reg_3368_reg__0[1]),
        .R(1'b0));
  FDRE \tmp_95_reg_3368_reg[4] 
       (.C(ap_clk),
        .CE(\tmp_95_reg_3368[9]_i_1_n_4 ),
        .D(\tmp_95_reg_3368[4]_i_1_n_4 ),
        .Q(tmp_95_reg_3368_reg__0[2]),
        .R(1'b0));
  FDRE \tmp_95_reg_3368_reg[5] 
       (.C(ap_clk),
        .CE(\tmp_95_reg_3368[9]_i_1_n_4 ),
        .D(tmp_95_fu_1917_p2[5]),
        .Q(tmp_95_reg_3368_reg__0[3]),
        .R(1'b0));
  FDRE \tmp_95_reg_3368_reg[6] 
       (.C(ap_clk),
        .CE(\tmp_95_reg_3368[9]_i_1_n_4 ),
        .D(tmp_95_fu_1917_p2[6]),
        .Q(tmp_95_reg_3368_reg__0[4]),
        .R(1'b0));
  FDRE \tmp_95_reg_3368_reg[7] 
       (.C(ap_clk),
        .CE(\tmp_95_reg_3368[9]_i_1_n_4 ),
        .D(\tmp_95_reg_3368[7]_i_1_n_4 ),
        .Q(tmp_95_reg_3368_reg__0[5]),
        .R(1'b0));
  FDRE \tmp_95_reg_3368_reg[8] 
       (.C(ap_clk),
        .CE(\tmp_95_reg_3368[9]_i_1_n_4 ),
        .D(\tmp_95_reg_3368[8]_i_1_n_4 ),
        .Q(tmp_95_reg_3368_reg__0[6]),
        .R(1'b0));
  FDRE \tmp_95_reg_3368_reg[9] 
       (.C(ap_clk),
        .CE(\tmp_95_reg_3368[9]_i_1_n_4 ),
        .D(\tmp_95_reg_3368[9]_i_2_n_4 ),
        .Q(tmp_95_reg_3368_reg__0[7]),
        .R(1'b0));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_98_reg_2909[3]_i_1 
       (.I0(tmp_37_4_cast_mid2_reg_2770[0]),
        .I1(tmp_37_4_cast_mid2_reg_2770[1]),
        .O(\tmp_98_reg_2909[3]_i_1_n_4 ));
  LUT3 #(
    .INIT(8'h1E)) 
    \tmp_98_reg_2909[4]_i_1 
       (.I0(tmp_37_4_cast_mid2_reg_2770[0]),
        .I1(tmp_37_4_cast_mid2_reg_2770[1]),
        .I2(tmp_37_4_cast_mid2_reg_2770[2]),
        .O(\tmp_98_reg_2909[4]_i_1_n_4 ));
  LUT4 #(
    .INIT(16'hF01E)) 
    \tmp_98_reg_2909[5]_i_1 
       (.I0(tmp_37_4_cast_mid2_reg_2770[2]),
        .I1(tmp_37_4_cast_mid2_reg_2770[1]),
        .I2(tmp_37_4_cast_mid2_reg_2770[3]),
        .I3(tmp_37_4_cast_mid2_reg_2770[0]),
        .O(tmp_98_fu_1109_p2[5]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'hF30C0DF2)) 
    \tmp_98_reg_2909[6]_i_1 
       (.I0(tmp_37_4_cast_mid2_reg_2770[2]),
        .I1(tmp_37_4_cast_mid2_reg_2770[0]),
        .I2(tmp_37_4_cast_mid2_reg_2770[3]),
        .I3(tmp_37_4_cast_mid2_reg_2770[4]),
        .I4(tmp_37_4_cast_mid2_reg_2770[1]),
        .O(tmp_98_fu_1109_p2[6]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h40F4BF0A)) 
    \tmp_98_reg_2909[7]_i_1 
       (.I0(tmp_37_4_cast_mid2_reg_2770[3]),
        .I1(tmp_37_4_cast_mid2_reg_2770[0]),
        .I2(tmp_37_4_cast_mid2_reg_2770[1]),
        .I3(tmp_37_4_cast_mid2_reg_2770[4]),
        .I4(tmp_37_4_cast_mid2_reg_2770[2]),
        .O(\tmp_98_reg_2909[7]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT5 #(
    .INIT(32'hBABA0444)) 
    \tmp_98_reg_2909[8]_i_1 
       (.I0(tmp_37_4_cast_mid2_reg_2770[2]),
        .I1(tmp_37_4_cast_mid2_reg_2770[4]),
        .I2(tmp_37_4_cast_mid2_reg_2770[1]),
        .I3(tmp_37_4_cast_mid2_reg_2770[0]),
        .I4(tmp_37_4_cast_mid2_reg_2770[3]),
        .O(\tmp_98_reg_2909[8]_i_1_n_4 ));
  LUT2 #(
    .INIT(4'h2)) 
    \tmp_98_reg_2909[9]_i_1 
       (.I0(ap_CS_fsm_pp0_stage5),
        .I1(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .O(\tmp_98_reg_2909[9]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT5 #(
    .INIT(32'hFFEA0000)) 
    \tmp_98_reg_2909[9]_i_2 
       (.I0(tmp_37_4_cast_mid2_reg_2770[3]),
        .I1(tmp_37_4_cast_mid2_reg_2770[0]),
        .I2(tmp_37_4_cast_mid2_reg_2770[1]),
        .I3(tmp_37_4_cast_mid2_reg_2770[2]),
        .I4(tmp_37_4_cast_mid2_reg_2770[4]),
        .O(\tmp_98_reg_2909[9]_i_2_n_4 ));
  FDRE \tmp_98_reg_2909_reg[2] 
       (.C(ap_clk),
        .CE(\tmp_98_reg_2909[9]_i_1_n_4 ),
        .D(tmp_37_4_cast_mid2_reg_2770[0]),
        .Q(tmp_98_reg_2909[2]),
        .R(1'b0));
  FDRE \tmp_98_reg_2909_reg[3] 
       (.C(ap_clk),
        .CE(\tmp_98_reg_2909[9]_i_1_n_4 ),
        .D(\tmp_98_reg_2909[3]_i_1_n_4 ),
        .Q(tmp_98_reg_2909[3]),
        .R(1'b0));
  FDRE \tmp_98_reg_2909_reg[4] 
       (.C(ap_clk),
        .CE(\tmp_98_reg_2909[9]_i_1_n_4 ),
        .D(\tmp_98_reg_2909[4]_i_1_n_4 ),
        .Q(tmp_98_reg_2909[4]),
        .R(1'b0));
  FDRE \tmp_98_reg_2909_reg[5] 
       (.C(ap_clk),
        .CE(\tmp_98_reg_2909[9]_i_1_n_4 ),
        .D(tmp_98_fu_1109_p2[5]),
        .Q(tmp_98_reg_2909[5]),
        .R(1'b0));
  FDRE \tmp_98_reg_2909_reg[6] 
       (.C(ap_clk),
        .CE(\tmp_98_reg_2909[9]_i_1_n_4 ),
        .D(tmp_98_fu_1109_p2[6]),
        .Q(tmp_98_reg_2909[6]),
        .R(1'b0));
  FDRE \tmp_98_reg_2909_reg[7] 
       (.C(ap_clk),
        .CE(\tmp_98_reg_2909[9]_i_1_n_4 ),
        .D(\tmp_98_reg_2909[7]_i_1_n_4 ),
        .Q(tmp_98_reg_2909[7]),
        .R(1'b0));
  FDRE \tmp_98_reg_2909_reg[8] 
       (.C(ap_clk),
        .CE(\tmp_98_reg_2909[9]_i_1_n_4 ),
        .D(\tmp_98_reg_2909[8]_i_1_n_4 ),
        .Q(tmp_98_reg_2909[8]),
        .R(1'b0));
  FDRE \tmp_98_reg_2909_reg[9] 
       (.C(ap_clk),
        .CE(\tmp_98_reg_2909[9]_i_1_n_4 ),
        .D(\tmp_98_reg_2909[9]_i_2_n_4 ),
        .Q(tmp_98_reg_2909[9]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair69" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_mid2_72_reg_2744[0]_i_1 
       (.I0(p_0_in28_out),
        .I1(y_mid_fu_687_p3[0]),
        .O(tmp_mid2_72_fu_783_p3[0]));
  (* SOFT_HLUTNM = "soft_lutpair69" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \tmp_mid2_72_reg_2744[1]_i_1 
       (.I0(p_0_in28_out),
        .I1(y_mid_fu_687_p3[0]),
        .I2(y_mid_fu_687_p3[1]),
        .O(tmp_mid2_72_fu_783_p3[1]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \tmp_mid2_72_reg_2744[2]_i_1 
       (.I0(y_mid_fu_687_p3[0]),
        .I1(p_0_in28_out),
        .I2(y_mid_fu_687_p3[1]),
        .I3(y_mid_fu_687_p3[2]),
        .O(tmp_mid2_72_fu_783_p3[2]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \tmp_mid2_72_reg_2744[3]_i_1 
       (.I0(y_mid_fu_687_p3[1]),
        .I1(p_0_in28_out),
        .I2(y_mid_fu_687_p3[0]),
        .I3(y_mid_fu_687_p3[2]),
        .I4(y_mid_fu_687_p3[3]),
        .O(tmp_mid2_72_fu_783_p3[3]));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \tmp_mid2_72_reg_2744[4]_i_1 
       (.I0(y_mid_fu_687_p3[2]),
        .I1(y_mid_fu_687_p3[0]),
        .I2(p_0_in28_out),
        .I3(y_mid_fu_687_p3[1]),
        .I4(y_mid_fu_687_p3[3]),
        .I5(y_mid_fu_687_p3[4]),
        .O(tmp_mid2_72_fu_783_p3[4]));
  LUT6 #(
    .INIT(64'h00000000BAAA8AAA)) 
    \tmp_mid2_72_reg_2744[4]_i_2 
       (.I0(y_reg_609[2]),
        .I1(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(ap_enable_reg_pp0_iter1_reg_n_4),
        .I4(p_shl10_cast_fu_1237_p1[7]),
        .I5(exitcond_flatten_fu_681_p2),
        .O(y_mid_fu_687_p3[2]));
  LUT6 #(
    .INIT(64'h00000000BAAA8AAA)) 
    \tmp_mid2_72_reg_2744[4]_i_3 
       (.I0(y_reg_609[0]),
        .I1(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(ap_enable_reg_pp0_iter1_reg_n_4),
        .I4(p_shl10_cast_fu_1237_p1[5]),
        .I5(exitcond_flatten_fu_681_p2),
        .O(y_mid_fu_687_p3[0]));
  LUT6 #(
    .INIT(64'h00000000BAAA8AAA)) 
    \tmp_mid2_72_reg_2744[4]_i_4 
       (.I0(y_reg_609[1]),
        .I1(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(ap_enable_reg_pp0_iter1_reg_n_4),
        .I4(p_shl10_cast_fu_1237_p1[6]),
        .I5(exitcond_flatten_fu_681_p2),
        .O(y_mid_fu_687_p3[1]));
  LUT6 #(
    .INIT(64'h00000000BAAA8AAA)) 
    \tmp_mid2_72_reg_2744[4]_i_5 
       (.I0(y_reg_609[3]),
        .I1(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(ap_enable_reg_pp0_iter1_reg_n_4),
        .I4(p_shl10_cast_fu_1237_p1[8]),
        .I5(exitcond_flatten_fu_681_p2),
        .O(y_mid_fu_687_p3[3]));
  LUT6 #(
    .INIT(64'h00000000BAAA8AAA)) 
    \tmp_mid2_72_reg_2744[4]_i_6 
       (.I0(y_reg_609[4]),
        .I1(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(ap_enable_reg_pp0_iter1_reg_n_4),
        .I4(p_shl10_cast_fu_1237_p1[9]),
        .I5(exitcond_flatten_fu_681_p2),
        .O(y_mid_fu_687_p3[4]));
  FDRE \tmp_mid2_72_reg_2744_reg[0] 
       (.C(ap_clk),
        .CE(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ),
        .D(tmp_mid2_72_fu_783_p3[0]),
        .Q(p_shl10_cast_fu_1237_p1[5]),
        .R(1'b0));
  FDRE \tmp_mid2_72_reg_2744_reg[1] 
       (.C(ap_clk),
        .CE(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ),
        .D(tmp_mid2_72_fu_783_p3[1]),
        .Q(p_shl10_cast_fu_1237_p1[6]),
        .R(1'b0));
  FDRE \tmp_mid2_72_reg_2744_reg[2] 
       (.C(ap_clk),
        .CE(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ),
        .D(tmp_mid2_72_fu_783_p3[2]),
        .Q(p_shl10_cast_fu_1237_p1[7]),
        .R(1'b0));
  FDRE \tmp_mid2_72_reg_2744_reg[3] 
       (.C(ap_clk),
        .CE(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ),
        .D(tmp_mid2_72_fu_783_p3[3]),
        .Q(p_shl10_cast_fu_1237_p1[8]),
        .R(1'b0));
  FDRE \tmp_mid2_72_reg_2744_reg[4] 
       (.C(ap_clk),
        .CE(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ),
        .D(tmp_mid2_72_fu_783_p3[4]),
        .Q(p_shl10_cast_fu_1237_p1[9]),
        .R(1'b0));
  LUT6 #(
    .INIT(64'h656666666A666666)) 
    \tmp_mid2_v_reg_2697[0]_i_1 
       (.I0(exitcond_flatten_fu_681_p2),
        .I1(\filter_index_reg_587_reg_n_4_[0] ),
        .I2(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I3(ap_CS_fsm_pp0_stage0),
        .I4(ap_enable_reg_pp0_iter1_reg_n_4),
        .I5(bias_Addr_A[0]),
        .O(B[0]));
  LUT6 #(
    .INIT(64'h77775FA088885FA0)) 
    \tmp_mid2_v_reg_2697[1]_i_1 
       (.I0(exitcond_flatten_fu_681_p2),
        .I1(bias_Addr_A[0]),
        .I2(\filter_index_reg_587_reg_n_4_[0] ),
        .I3(\filter_index_reg_587_reg_n_4_[1] ),
        .I4(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I5(bias_Addr_A[1]),
        .O(B[1]));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \tmp_mid2_v_reg_2697[1]_i_2 
       (.I0(\tmp_mid2_v_reg_2697[1]_i_3_n_4 ),
        .I1(\indvar_flatten_next_reg_2776[9]_i_5_n_4 ),
        .I2(\tmp_mid2_v_reg_2697[1]_i_4_n_4 ),
        .I3(\indvar_flatten_next_reg_2776[2]_i_2_n_4 ),
        .I4(\indvar_flatten_next_reg_2776[9]_i_3_n_4 ),
        .I5(\tmp_mid2_v_reg_2697[1]_i_5_n_4 ),
        .O(exitcond_flatten_fu_681_p2));
  LUT5 #(
    .INIT(32'hCCCCACCC)) 
    \tmp_mid2_v_reg_2697[1]_i_3 
       (.I0(indvar_flatten_next_reg_2776[1]),
        .I1(indvar_flatten_reg_598[1]),
        .I2(ap_enable_reg_pp0_iter1_reg_n_4),
        .I3(ap_CS_fsm_pp0_stage0),
        .I4(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .O(\tmp_mid2_v_reg_2697[1]_i_3_n_4 ));
  LUT6 #(
    .INIT(64'hEFFFEFFFEFEFFFFF)) 
    \tmp_mid2_v_reg_2697[1]_i_4 
       (.I0(\tmp_mid2_v_reg_2697[1]_i_6_n_4 ),
        .I1(\tmp_mid2_v_reg_2697[1]_i_7_n_4 ),
        .I2(\tmp_mid2_v_reg_2697[1]_i_8_n_4 ),
        .I3(indvar_flatten_next_reg_2776[9]),
        .I4(indvar_flatten_reg_598[9]),
        .I5(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .O(\tmp_mid2_v_reg_2697[1]_i_4_n_4 ));
  LUT5 #(
    .INIT(32'hFFFACFCA)) 
    \tmp_mid2_v_reg_2697[1]_i_5 
       (.I0(indvar_flatten_reg_598[5]),
        .I1(indvar_flatten_next_reg_2776[5]),
        .I2(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I3(indvar_flatten_reg_598[4]),
        .I4(indvar_flatten_next_reg_2776[4]),
        .O(\tmp_mid2_v_reg_2697[1]_i_5_n_4 ));
  LUT5 #(
    .INIT(32'hCCCCACCC)) 
    \tmp_mid2_v_reg_2697[1]_i_6 
       (.I0(indvar_flatten_next_reg_2776[2]),
        .I1(indvar_flatten_reg_598[2]),
        .I2(ap_enable_reg_pp0_iter1_reg_n_4),
        .I3(ap_CS_fsm_pp0_stage0),
        .I4(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .O(\tmp_mid2_v_reg_2697[1]_i_6_n_4 ));
  LUT5 #(
    .INIT(32'hCCCCACCC)) 
    \tmp_mid2_v_reg_2697[1]_i_7 
       (.I0(indvar_flatten_next_reg_2776[3]),
        .I1(indvar_flatten_reg_598[3]),
        .I2(ap_enable_reg_pp0_iter1_reg_n_4),
        .I3(ap_CS_fsm_pp0_stage0),
        .I4(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .O(\tmp_mid2_v_reg_2697[1]_i_7_n_4 ));
  LUT5 #(
    .INIT(32'hCCCCACCC)) 
    \tmp_mid2_v_reg_2697[1]_i_8 
       (.I0(indvar_flatten_next_reg_2776[6]),
        .I1(indvar_flatten_reg_598[6]),
        .I2(ap_enable_reg_pp0_iter1_reg_n_4),
        .I3(ap_CS_fsm_pp0_stage0),
        .I4(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .O(\tmp_mid2_v_reg_2697[1]_i_8_n_4 ));
  LUT6 #(
    .INIT(64'h656666666A666666)) 
    \tmp_mid2_v_reg_2697[2]_i_1 
       (.I0(\tmp_mid2_v_reg_2697[4]_i_8_n_4 ),
        .I1(\filter_index_reg_587_reg_n_4_[2] ),
        .I2(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I3(ap_CS_fsm_pp0_stage0),
        .I4(ap_enable_reg_pp0_iter1_reg_n_4),
        .I5(bias_Addr_A[2]),
        .O(B[2]));
  LUT6 #(
    .INIT(64'h77775FA088885FA0)) 
    \tmp_mid2_v_reg_2697[3]_i_1 
       (.I0(\tmp_mid2_v_reg_2697[4]_i_8_n_4 ),
        .I1(bias_Addr_A[2]),
        .I2(\filter_index_reg_587_reg_n_4_[2] ),
        .I3(\filter_index_reg_587_reg_n_4_[3] ),
        .I4(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I5(bias_Addr_A[3]),
        .O(B__0[3]));
  LUT6 #(
    .INIT(64'h8888888888888880)) 
    \tmp_mid2_v_reg_2697[4]_i_1 
       (.I0(ap_CS_fsm_pp0_stage0),
        .I1(ap_enable_reg_pp0_iter0),
        .I2(\tmp_mid2_v_reg_2697[4]_i_3_n_4 ),
        .I3(\tmp_mid2_v_reg_2697[4]_i_4_n_4 ),
        .I4(\tmp_mid2_v_reg_2697[4]_i_5_n_4 ),
        .I5(\tmp_mid2_v_reg_2697[4]_i_6_n_4 ),
        .O(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ));
  LUT5 #(
    .INIT(32'hFFAFFCAC)) 
    \tmp_mid2_v_reg_2697[4]_i_10 
       (.I0(indvar_flatten_next2_reg_2692_reg[5]),
        .I1(indvar_flatten2_reg_576[5]),
        .I2(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I3(indvar_flatten_next2_reg_2692_reg[4]),
        .I4(indvar_flatten2_reg_576[4]),
        .O(\tmp_mid2_v_reg_2697[4]_i_10_n_4 ));
  LUT5 #(
    .INIT(32'h53F35FFF)) 
    \tmp_mid2_v_reg_2697[4]_i_11 
       (.I0(indvar_flatten_next2_reg_2692_reg[10]),
        .I1(indvar_flatten2_reg_576[10]),
        .I2(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I3(indvar_flatten_next2_reg_2692_reg[11]),
        .I4(indvar_flatten2_reg_576[11]),
        .O(\tmp_mid2_v_reg_2697[4]_i_11_n_4 ));
  LUT5 #(
    .INIT(32'hFFAFFCAC)) 
    \tmp_mid2_v_reg_2697[4]_i_12 
       (.I0(indvar_flatten_next2_reg_2692_reg[9]),
        .I1(indvar_flatten2_reg_576[9]),
        .I2(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I3(indvar_flatten_next2_reg_2692_reg[2]),
        .I4(indvar_flatten2_reg_576[2]),
        .O(\tmp_mid2_v_reg_2697[4]_i_12_n_4 ));
  LUT6 #(
    .INIT(64'h7F7F7F8080807F80)) 
    \tmp_mid2_v_reg_2697[4]_i_2 
       (.I0(ap_phi_mux_filter_index_phi_fu_591_p4[2]),
        .I1(\tmp_mid2_v_reg_2697[4]_i_8_n_4 ),
        .I2(ap_phi_mux_filter_index_phi_fu_591_p4[3]),
        .I3(\filter_index_reg_587_reg_n_4_[4] ),
        .I4(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I5(bias_Addr_A[4]),
        .O(B__0[4]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFACFCA)) 
    \tmp_mid2_v_reg_2697[4]_i_3 
       (.I0(indvar_flatten2_reg_576[6]),
        .I1(indvar_flatten_next2_reg_2692_reg[6]),
        .I2(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I3(indvar_flatten2_reg_576[7]),
        .I4(indvar_flatten_next2_reg_2692_reg[7]),
        .I5(\tmp_mid2_v_reg_2697[4]_i_10_n_4 ),
        .O(\tmp_mid2_v_reg_2697[4]_i_3_n_4 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF353FF5FF)) 
    \tmp_mid2_v_reg_2697[4]_i_4 
       (.I0(indvar_flatten2_reg_576[8]),
        .I1(indvar_flatten_next2_reg_2692_reg[8]),
        .I2(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I3(indvar_flatten2_reg_576[13]),
        .I4(indvar_flatten_next2_reg_2692_reg[13]),
        .I5(\tmp_mid2_v_reg_2697[4]_i_11_n_4 ),
        .O(\tmp_mid2_v_reg_2697[4]_i_4_n_4 ));
  LUT5 #(
    .INIT(32'hFFAFFCAC)) 
    \tmp_mid2_v_reg_2697[4]_i_5 
       (.I0(indvar_flatten_next2_reg_2692_reg[12]),
        .I1(indvar_flatten2_reg_576[12]),
        .I2(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I3(indvar_flatten_next2_reg_2692_reg[3]),
        .I4(indvar_flatten2_reg_576[3]),
        .O(\tmp_mid2_v_reg_2697[4]_i_5_n_4 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFACFCA)) 
    \tmp_mid2_v_reg_2697[4]_i_6 
       (.I0(indvar_flatten2_reg_576[1]),
        .I1(indvar_flatten_next2_reg_2692_reg[1]),
        .I2(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I3(indvar_flatten2_reg_576[0]),
        .I4(indvar_flatten_next2_reg_2692_reg[0]),
        .I5(\tmp_mid2_v_reg_2697[4]_i_12_n_4 ),
        .O(\tmp_mid2_v_reg_2697[4]_i_6_n_4 ));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \tmp_mid2_v_reg_2697[4]_i_7 
       (.I0(bias_Addr_A[2]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I4(\filter_index_reg_587_reg_n_4_[2] ),
        .O(ap_phi_mux_filter_index_phi_fu_591_p4[2]));
  LUT6 #(
    .INIT(64'hC000A0A0C0000000)) 
    \tmp_mid2_v_reg_2697[4]_i_8 
       (.I0(\filter_index_reg_587_reg_n_4_[1] ),
        .I1(bias_Addr_A[1]),
        .I2(exitcond_flatten_fu_681_p2),
        .I3(bias_Addr_A[0]),
        .I4(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I5(\filter_index_reg_587_reg_n_4_[0] ),
        .O(\tmp_mid2_v_reg_2697[4]_i_8_n_4 ));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \tmp_mid2_v_reg_2697[4]_i_9 
       (.I0(bias_Addr_A[3]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I4(\filter_index_reg_587_reg_n_4_[3] ),
        .O(ap_phi_mux_filter_index_phi_fu_591_p4[3]));
  FDRE \tmp_mid2_v_reg_2697_reg[0] 
       (.C(ap_clk),
        .CE(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ),
        .D(B[0]),
        .Q(bias_Addr_A[0]),
        .R(1'b0));
  FDRE \tmp_mid2_v_reg_2697_reg[1] 
       (.C(ap_clk),
        .CE(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ),
        .D(B[1]),
        .Q(bias_Addr_A[1]),
        .R(1'b0));
  FDRE \tmp_mid2_v_reg_2697_reg[2] 
       (.C(ap_clk),
        .CE(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ),
        .D(B[2]),
        .Q(bias_Addr_A[2]),
        .R(1'b0));
  FDRE \tmp_mid2_v_reg_2697_reg[3] 
       (.C(ap_clk),
        .CE(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ),
        .D(B__0[3]),
        .Q(bias_Addr_A[3]),
        .R(1'b0));
  FDRE \tmp_mid2_v_reg_2697_reg[4] 
       (.C(ap_clk),
        .CE(\tmp_mid2_v_reg_2697[4]_i_1_n_4 ),
        .D(B__0[4]),
        .Q(bias_Addr_A[4]),
        .R(1'b0));
  LUT5 #(
    .INIT(32'h8A80202A)) 
    \tmp_reg_2705[6]_i_2 
       (.I0(B[0]),
        .I1(bias_Addr_A[2]),
        .I2(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I3(\filter_index_reg_587_reg_n_4_[2] ),
        .I4(\tmp_mid2_v_reg_2697[4]_i_8_n_4 ),
        .O(\tmp_reg_2705[6]_i_2_n_4 ));
  LUT5 #(
    .INIT(32'h00006AAA)) 
    \tmp_reg_2705[6]_i_3 
       (.I0(ap_phi_mux_filter_index_phi_fu_591_p4[4]),
        .I1(ap_phi_mux_filter_index_phi_fu_591_p4[3]),
        .I2(\tmp_mid2_v_reg_2697[4]_i_8_n_4 ),
        .I3(ap_phi_mux_filter_index_phi_fu_591_p4[2]),
        .I4(B[1]),
        .O(\tmp_reg_2705[6]_i_3_n_4 ));
  LUT6 #(
    .INIT(64'h56A6AAAAFFFFFFFF)) 
    \tmp_reg_2705[6]_i_4 
       (.I0(ap_phi_mux_filter_index_phi_fu_591_p4[3]),
        .I1(\filter_index_reg_587_reg_n_4_[2] ),
        .I2(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I3(bias_Addr_A[2]),
        .I4(\tmp_mid2_v_reg_2697[4]_i_8_n_4 ),
        .I5(B[0]),
        .O(\tmp_reg_2705[6]_i_4_n_4 ));
  LUT5 #(
    .INIT(32'hBD4242BD)) 
    \tmp_reg_2705[6]_i_5 
       (.I0(B[0]),
        .I1(\tmp_mid2_v_reg_2697[4]_i_8_n_4 ),
        .I2(ap_phi_mux_filter_index_phi_fu_591_p4[2]),
        .I3(ap_phi_mux_filter_index_phi_fu_591_p4[3]),
        .I4(B[1]),
        .O(\tmp_reg_2705[6]_i_5_n_4 ));
  LUT6 #(
    .INIT(64'h14AFAF50EB5050AF)) 
    \tmp_reg_2705[6]_i_6 
       (.I0(B[1]),
        .I1(ap_phi_mux_filter_index_phi_fu_591_p4[3]),
        .I2(ap_phi_mux_filter_index_phi_fu_591_p4[4]),
        .I3(\tmp_mid2_v_reg_2697[4]_i_8_n_4 ),
        .I4(ap_phi_mux_filter_index_phi_fu_591_p4[2]),
        .I5(B[0]),
        .O(\tmp_reg_2705[6]_i_6_n_4 ));
  LUT6 #(
    .INIT(64'h402ABFD5BFD5402A)) 
    \tmp_reg_2705[6]_i_7 
       (.I0(B[0]),
        .I1(ap_phi_mux_filter_index_phi_fu_591_p4[2]),
        .I2(\tmp_mid2_v_reg_2697[4]_i_8_n_4 ),
        .I3(ap_phi_mux_filter_index_phi_fu_591_p4[3]),
        .I4(ap_phi_mux_filter_index_phi_fu_591_p4[4]),
        .I5(B[1]),
        .O(\tmp_reg_2705[6]_i_7_n_4 ));
  LUT6 #(
    .INIT(64'h9996669666666666)) 
    \tmp_reg_2705[6]_i_8 
       (.I0(B[0]),
        .I1(ap_phi_mux_filter_index_phi_fu_591_p4[3]),
        .I2(\filter_index_reg_587_reg_n_4_[2] ),
        .I3(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I4(bias_Addr_A[2]),
        .I5(\tmp_mid2_v_reg_2697[4]_i_8_n_4 ),
        .O(\tmp_reg_2705[6]_i_8_n_4 ));
  LUT5 #(
    .INIT(32'h00474700)) 
    \tmp_reg_2705[9]_i_2 
       (.I0(bias_Addr_A[4]),
        .I1(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I2(\filter_index_reg_587_reg_n_4_[4] ),
        .I3(\tmp_mid2_v_reg_2697[4]_i_8_n_4 ),
        .I4(ap_phi_mux_filter_index_phi_fu_591_p4[2]),
        .O(\tmp_reg_2705[9]_i_2_n_4 ));
  LUT6 #(
    .INIT(64'h8882228222222222)) 
    \tmp_reg_2705[9]_i_3 
       (.I0(B[1]),
        .I1(ap_phi_mux_filter_index_phi_fu_591_p4[3]),
        .I2(\filter_index_reg_587_reg_n_4_[2] ),
        .I3(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I4(bias_Addr_A[2]),
        .I5(\tmp_mid2_v_reg_2697[4]_i_8_n_4 ),
        .O(\tmp_reg_2705[9]_i_3_n_4 ));
  LUT6 #(
    .INIT(64'hB8B8B847B847B847)) 
    \tmp_reg_2705[9]_i_4 
       (.I0(bias_Addr_A[4]),
        .I1(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I2(\filter_index_reg_587_reg_n_4_[4] ),
        .I3(ap_phi_mux_filter_index_phi_fu_591_p4[3]),
        .I4(\tmp_mid2_v_reg_2697[4]_i_8_n_4 ),
        .I5(ap_phi_mux_filter_index_phi_fu_591_p4[2]),
        .O(\tmp_reg_2705[9]_i_4_n_4 ));
  LUT6 #(
    .INIT(64'hFF001DE21DE200FF)) 
    \tmp_reg_2705[9]_i_5 
       (.I0(\filter_index_reg_587_reg_n_4_[4] ),
        .I1(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I2(bias_Addr_A[4]),
        .I3(ap_phi_mux_filter_index_phi_fu_591_p4[3]),
        .I4(ap_phi_mux_filter_index_phi_fu_591_p4[2]),
        .I5(\tmp_mid2_v_reg_2697[4]_i_8_n_4 ),
        .O(\tmp_reg_2705[9]_i_5_n_4 ));
  LUT5 #(
    .INIT(32'h7C1683E9)) 
    \tmp_reg_2705[9]_i_6 
       (.I0(B[1]),
        .I1(ap_phi_mux_filter_index_phi_fu_591_p4[2]),
        .I2(\tmp_mid2_v_reg_2697[4]_i_8_n_4 ),
        .I3(ap_phi_mux_filter_index_phi_fu_591_p4[3]),
        .I4(ap_phi_mux_filter_index_phi_fu_591_p4[4]),
        .O(\tmp_reg_2705[9]_i_6_n_4 ));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \tmp_reg_2705[9]_i_7 
       (.I0(bias_Addr_A[4]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I4(\filter_index_reg_587_reg_n_4_[4] ),
        .O(ap_phi_mux_filter_index_phi_fu_591_p4[4]));
  FDRE \tmp_reg_2705_reg[0] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(B[0]),
        .Q(tmp_reg_2705[0]),
        .R(1'b0));
  FDRE \tmp_reg_2705_reg[1] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(B[1]),
        .Q(tmp_reg_2705[1]),
        .R(1'b0));
  FDRE \tmp_reg_2705_reg[2] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(B[2]),
        .Q(tmp_reg_2705[2]),
        .R(1'b0));
  FDRE \tmp_reg_2705_reg[3] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_fu_707_p2[3]),
        .Q(tmp_reg_2705[3]),
        .R(1'b0));
  FDRE \tmp_reg_2705_reg[4] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_fu_707_p2[4]),
        .Q(tmp_reg_2705[4]),
        .R(1'b0));
  FDRE \tmp_reg_2705_reg[5] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_fu_707_p2[5]),
        .Q(tmp_reg_2705[5]),
        .R(1'b0));
  FDRE \tmp_reg_2705_reg[6] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_fu_707_p2[6]),
        .Q(tmp_reg_2705[6]),
        .R(1'b0));
  CARRY4 \tmp_reg_2705_reg[6]_i_1 
       (.CI(1'b0),
        .CO({\tmp_reg_2705_reg[6]_i_1_n_4 ,\tmp_reg_2705_reg[6]_i_1_n_5 ,\tmp_reg_2705_reg[6]_i_1_n_6 ,\tmp_reg_2705_reg[6]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({\tmp_reg_2705[6]_i_2_n_4 ,\tmp_reg_2705[6]_i_3_n_4 ,\tmp_reg_2705[6]_i_4_n_4 ,1'b0}),
        .O(tmp_fu_707_p2[6:3]),
        .S({\tmp_reg_2705[6]_i_5_n_4 ,\tmp_reg_2705[6]_i_6_n_4 ,\tmp_reg_2705[6]_i_7_n_4 ,\tmp_reg_2705[6]_i_8_n_4 }));
  FDRE \tmp_reg_2705_reg[7] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_fu_707_p2[7]),
        .Q(tmp_reg_2705[7]),
        .R(1'b0));
  FDRE \tmp_reg_2705_reg[8] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_fu_707_p2[8]),
        .Q(tmp_reg_2705[8]),
        .R(1'b0));
  FDRE \tmp_reg_2705_reg[9] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(tmp_fu_707_p2[9]),
        .Q(tmp_reg_2705[9]),
        .R(1'b0));
  CARRY4 \tmp_reg_2705_reg[9]_i_1 
       (.CI(\tmp_reg_2705_reg[6]_i_1_n_4 ),
        .CO({\NLW_tmp_reg_2705_reg[9]_i_1_CO_UNCONNECTED [3:2],\tmp_reg_2705_reg[9]_i_1_n_6 ,\tmp_reg_2705_reg[9]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\tmp_reg_2705[9]_i_2_n_4 ,\tmp_reg_2705[9]_i_3_n_4 }),
        .O({\NLW_tmp_reg_2705_reg[9]_i_1_O_UNCONNECTED [3],tmp_fu_707_p2[9:7]}),
        .S({1'b0,\tmp_reg_2705[9]_i_4_n_4 ,\tmp_reg_2705[9]_i_5_n_4 ,\tmp_reg_2705[9]_i_6_n_4 }));
  (* SOFT_HLUTNM = "soft_lutpair76" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \x_4_reg_2866[0]_i_1 
       (.I0(\x_mid2_reg_2734_reg_n_4_[0] ),
        .O(tmp_39_0_1_cast_cast_fu_1029_p1[0]));
  (* SOFT_HLUTNM = "soft_lutpair76" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \x_4_reg_2866[1]_i_1 
       (.I0(\x_mid2_reg_2734_reg_n_4_[0] ),
        .I1(\x_mid2_reg_2734_reg_n_4_[1] ),
        .O(tmp_39_0_1_cast_cast_fu_1029_p1[1]));
  (* SOFT_HLUTNM = "soft_lutpair62" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \x_4_reg_2866[2]_i_1 
       (.I0(\x_mid2_reg_2734_reg_n_4_[0] ),
        .I1(\x_mid2_reg_2734_reg_n_4_[1] ),
        .I2(\x_mid2_reg_2734_reg_n_4_[2] ),
        .O(tmp_39_0_1_cast_cast_fu_1029_p1[2]));
  (* SOFT_HLUTNM = "soft_lutpair45" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \x_4_reg_2866[3]_i_1 
       (.I0(\x_mid2_reg_2734_reg_n_4_[1] ),
        .I1(\x_mid2_reg_2734_reg_n_4_[0] ),
        .I2(\x_mid2_reg_2734_reg_n_4_[2] ),
        .I3(\x_mid2_reg_2734_reg_n_4_[3] ),
        .O(tmp_39_0_1_cast_cast_fu_1029_p1[3]));
  LUT3 #(
    .INIT(8'h08)) 
    \x_4_reg_2866[4]_i_1 
       (.I0(ap_CS_fsm_pp0_stage4),
        .I1(ap_enable_reg_pp0_iter0),
        .I2(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .O(\x_4_reg_2866[4]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \x_4_reg_2866[4]_i_2 
       (.I0(\x_mid2_reg_2734_reg_n_4_[2] ),
        .I1(\x_mid2_reg_2734_reg_n_4_[0] ),
        .I2(\x_mid2_reg_2734_reg_n_4_[1] ),
        .I3(\x_mid2_reg_2734_reg_n_4_[3] ),
        .I4(\x_mid2_reg_2734_reg_n_4_[4] ),
        .O(tmp_39_0_1_cast_cast_fu_1029_p1[4]));
  FDRE \x_4_reg_2866_reg[0] 
       (.C(ap_clk),
        .CE(\x_4_reg_2866[4]_i_1_n_4 ),
        .D(tmp_39_0_1_cast_cast_fu_1029_p1[0]),
        .Q(x_4_reg_2866[0]),
        .R(1'b0));
  FDRE \x_4_reg_2866_reg[1] 
       (.C(ap_clk),
        .CE(\x_4_reg_2866[4]_i_1_n_4 ),
        .D(tmp_39_0_1_cast_cast_fu_1029_p1[1]),
        .Q(x_4_reg_2866[1]),
        .R(1'b0));
  FDRE \x_4_reg_2866_reg[2] 
       (.C(ap_clk),
        .CE(\x_4_reg_2866[4]_i_1_n_4 ),
        .D(tmp_39_0_1_cast_cast_fu_1029_p1[2]),
        .Q(x_4_reg_2866[2]),
        .R(1'b0));
  FDRE \x_4_reg_2866_reg[3] 
       (.C(ap_clk),
        .CE(\x_4_reg_2866[4]_i_1_n_4 ),
        .D(tmp_39_0_1_cast_cast_fu_1029_p1[3]),
        .Q(x_4_reg_2866[3]),
        .R(1'b0));
  FDRE \x_4_reg_2866_reg[4] 
       (.C(ap_clk),
        .CE(\x_4_reg_2866[4]_i_1_n_4 ),
        .D(tmp_39_0_1_cast_cast_fu_1029_p1[4]),
        .Q(x_4_reg_2866[4]),
        .R(1'b0));
  LUT4 #(
    .INIT(16'hFB08)) 
    \x_mid2_reg_2734[0]_i_1 
       (.I0(x_4_reg_2866[0]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I3(x_reg_620[0]),
        .O(ap_phi_mux_x_phi_fu_624_p4[0]));
  LUT4 #(
    .INIT(16'hFB08)) 
    \x_mid2_reg_2734[1]_i_1 
       (.I0(x_4_reg_2866[1]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I3(x_reg_620[1]),
        .O(ap_phi_mux_x_phi_fu_624_p4[1]));
  LUT4 #(
    .INIT(16'hFB08)) 
    \x_mid2_reg_2734[2]_i_1 
       (.I0(x_4_reg_2866[2]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I3(x_reg_620[2]),
        .O(ap_phi_mux_x_phi_fu_624_p4[2]));
  LUT4 #(
    .INIT(16'hFB08)) 
    \x_mid2_reg_2734[3]_i_1 
       (.I0(x_4_reg_2866[3]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I3(x_reg_620[3]),
        .O(ap_phi_mux_x_phi_fu_624_p4[3]));
  LUT3 #(
    .INIT(8'hA8)) 
    \x_mid2_reg_2734[4]_i_1 
       (.I0(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .I1(p_0_in28_out),
        .I2(exitcond_flatten_fu_681_p2),
        .O(x_mid2_reg_2734));
  LUT5 #(
    .INIT(32'hAAAAAAA8)) 
    \x_mid2_reg_2734[4]_i_2 
       (.I0(ap_CS_fsm_pp0_stage0),
        .I1(\tmp_mid2_v_reg_2697[4]_i_3_n_4 ),
        .I2(\tmp_mid2_v_reg_2697[4]_i_4_n_4 ),
        .I3(\tmp_mid2_v_reg_2697[4]_i_5_n_4 ),
        .I4(\tmp_mid2_v_reg_2697[4]_i_6_n_4 ),
        .O(\x_mid2_reg_2734[4]_i_2_n_4 ));
  LUT4 #(
    .INIT(16'hFB08)) 
    \x_mid2_reg_2734[4]_i_3 
       (.I0(x_4_reg_2866[4]),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(\exitcond_flatten2_reg_2688_reg_n_4_[0] ),
        .I3(x_reg_620[4]),
        .O(ap_phi_mux_x_phi_fu_624_p4[4]));
  LUT5 #(
    .INIT(32'h00008A80)) 
    \x_mid2_reg_2734[4]_i_4 
       (.I0(\x_mid2_reg_2734[4]_i_5_n_4 ),
        .I1(x_4_reg_2866[4]),
        .I2(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I3(x_reg_620[4]),
        .I4(exitcond_flatten_fu_681_p2),
        .O(p_0_in28_out));
  LUT6 #(
    .INIT(64'h0000000000440347)) 
    \x_mid2_reg_2734[4]_i_5 
       (.I0(x_4_reg_2866[0]),
        .I1(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I2(x_reg_620[0]),
        .I3(x_4_reg_2866[1]),
        .I4(x_reg_620[1]),
        .I5(\x_mid2_reg_2734[4]_i_6_n_4 ),
        .O(\x_mid2_reg_2734[4]_i_5_n_4 ));
  LUT5 #(
    .INIT(32'hCCAFFFAF)) 
    \x_mid2_reg_2734[4]_i_6 
       (.I0(x_reg_620[2]),
        .I1(x_4_reg_2866[2]),
        .I2(x_reg_620[3]),
        .I3(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .I4(x_4_reg_2866[3]),
        .O(\x_mid2_reg_2734[4]_i_6_n_4 ));
  FDRE \x_mid2_reg_2734_reg[0] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(ap_phi_mux_x_phi_fu_624_p4[0]),
        .Q(\x_mid2_reg_2734_reg_n_4_[0] ),
        .R(x_mid2_reg_2734));
  FDRE \x_mid2_reg_2734_reg[1] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(ap_phi_mux_x_phi_fu_624_p4[1]),
        .Q(\x_mid2_reg_2734_reg_n_4_[1] ),
        .R(x_mid2_reg_2734));
  FDRE \x_mid2_reg_2734_reg[2] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(ap_phi_mux_x_phi_fu_624_p4[2]),
        .Q(\x_mid2_reg_2734_reg_n_4_[2] ),
        .R(x_mid2_reg_2734));
  FDRE \x_mid2_reg_2734_reg[3] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(ap_phi_mux_x_phi_fu_624_p4[3]),
        .Q(\x_mid2_reg_2734_reg_n_4_[3] ),
        .R(x_mid2_reg_2734));
  FDRE \x_mid2_reg_2734_reg[4] 
       (.C(ap_clk),
        .CE(\x_mid2_reg_2734[4]_i_2_n_4 ),
        .D(ap_phi_mux_x_phi_fu_624_p4[4]),
        .Q(\x_mid2_reg_2734_reg_n_4_[4] ),
        .R(x_mid2_reg_2734));
  FDRE \x_reg_620_reg[0] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(x_4_reg_2866[0]),
        .Q(x_reg_620[0]),
        .R(filter_index_reg_587));
  FDRE \x_reg_620_reg[1] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(x_4_reg_2866[1]),
        .Q(x_reg_620[1]),
        .R(filter_index_reg_587));
  FDRE \x_reg_620_reg[2] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(x_4_reg_2866[2]),
        .Q(x_reg_620[2]),
        .R(filter_index_reg_587));
  FDRE \x_reg_620_reg[3] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(x_4_reg_2866[3]),
        .Q(x_reg_620[3]),
        .R(filter_index_reg_587));
  FDRE \x_reg_620_reg[4] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(x_4_reg_2866[4]),
        .Q(x_reg_620[4]),
        .R(filter_index_reg_587));
  FDRE \y_reg_609_reg[0] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(p_shl10_cast_fu_1237_p1[5]),
        .Q(y_reg_609[0]),
        .R(filter_index_reg_587));
  FDRE \y_reg_609_reg[1] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(p_shl10_cast_fu_1237_p1[6]),
        .Q(y_reg_609[1]),
        .R(filter_index_reg_587));
  FDRE \y_reg_609_reg[2] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(p_shl10_cast_fu_1237_p1[7]),
        .Q(y_reg_609[2]),
        .R(filter_index_reg_587));
  FDRE \y_reg_609_reg[3] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(p_shl10_cast_fu_1237_p1[8]),
        .Q(y_reg_609[3]),
        .R(filter_index_reg_587));
  FDRE \y_reg_609_reg[4] 
       (.C(ap_clk),
        .CE(\indvar_flatten2_reg_576[13]_i_2_n_4 ),
        .D(p_shl10_cast_fu_1237_p1[9]),
        .Q(y_reg_609[4]),
        .R(filter_index_reg_587));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x4
   (Q,
    conv2_bias_Addr_A,
    conv2_bias_EN_A,
    grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg_reg,
    ap_rst_n_0,
    ap_clk,
    grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg,
    ap_rst_n,
    ap_start,
    \ap_CS_fsm_reg[0]_0 );
  output [1:0]Q;
  output [5:0]conv2_bias_Addr_A;
  output conv2_bias_EN_A;
  output grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg_reg;
  input ap_rst_n_0;
  input ap_clk;
  input grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg;
  input ap_rst_n;
  input ap_start;
  input [0:0]\ap_CS_fsm_reg[0]_0 ;

  wire [1:0]Q;
  wire \ap_CS_fsm[1]_i_2_n_4 ;
  wire \ap_CS_fsm[2]_i_3__0_n_4 ;
  wire \ap_CS_fsm[2]_i_4_n_4 ;
  wire ap_CS_fsm_pp0_stage0;
  wire [0:0]\ap_CS_fsm_reg[0]_0 ;
  wire [2:0]ap_NS_fsm;
  wire ap_clk;
  wire ap_enable_reg_pp0_iter0;
  wire ap_enable_reg_pp0_iter0_i_1__0_n_4;
  wire ap_enable_reg_pp0_iter1_i_1__0_n_4;
  wire ap_enable_reg_pp0_iter1_reg_n_4;
  wire ap_rst_n;
  wire ap_rst_n_0;
  wire ap_start;
  wire [5:0]conv2_bias_Addr_A;
  wire \conv2_bias_Addr_A[3]_INST_0_i_2_n_4 ;
  wire \conv2_bias_Addr_A[5]_INST_0_i_1_n_4 ;
  wire \conv2_bias_Addr_A[7]_INST_0_i_1_n_4 ;
  wire conv2_bias_EN_A;
  wire exitcond_flatten1_fu_147_p2;
  wire \exitcond_flatten1_reg_317[0]_i_1_n_4 ;
  wire \exitcond_flatten1_reg_317_reg_n_4_[0] ;
  wire exitcond_flatten7_fu_165_p2__7;
  wire filter_index_reg_103;
  wire filter_index_reg_1030;
  wire \filter_index_reg_103_reg_n_4_[0] ;
  wire \filter_index_reg_103_reg_n_4_[1] ;
  wire \filter_index_reg_103_reg_n_4_[2] ;
  wire \filter_index_reg_103_reg_n_4_[3] ;
  wire \filter_index_reg_103_reg_n_4_[4] ;
  wire \filter_index_reg_103_reg_n_4_[5] ;
  wire grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg;
  wire grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg_reg;
  wire grp_Conv2_12x12x20_5x5x4_fu_109_output_r_ce0;
  wire indvar_flatten1_reg_92;
  wire indvar_flatten1_reg_920;
  wire \indvar_flatten1_reg_92[0]_i_4_n_4 ;
  wire [11:0]indvar_flatten1_reg_92_reg;
  wire \indvar_flatten1_reg_92_reg[0]_i_3_n_10 ;
  wire \indvar_flatten1_reg_92_reg[0]_i_3_n_11 ;
  wire \indvar_flatten1_reg_92_reg[0]_i_3_n_4 ;
  wire \indvar_flatten1_reg_92_reg[0]_i_3_n_5 ;
  wire \indvar_flatten1_reg_92_reg[0]_i_3_n_6 ;
  wire \indvar_flatten1_reg_92_reg[0]_i_3_n_7 ;
  wire \indvar_flatten1_reg_92_reg[0]_i_3_n_8 ;
  wire \indvar_flatten1_reg_92_reg[0]_i_3_n_9 ;
  wire \indvar_flatten1_reg_92_reg[4]_i_1_n_10 ;
  wire \indvar_flatten1_reg_92_reg[4]_i_1_n_11 ;
  wire \indvar_flatten1_reg_92_reg[4]_i_1_n_4 ;
  wire \indvar_flatten1_reg_92_reg[4]_i_1_n_5 ;
  wire \indvar_flatten1_reg_92_reg[4]_i_1_n_6 ;
  wire \indvar_flatten1_reg_92_reg[4]_i_1_n_7 ;
  wire \indvar_flatten1_reg_92_reg[4]_i_1_n_8 ;
  wire \indvar_flatten1_reg_92_reg[4]_i_1_n_9 ;
  wire \indvar_flatten1_reg_92_reg[8]_i_1_n_10 ;
  wire \indvar_flatten1_reg_92_reg[8]_i_1_n_11 ;
  wire \indvar_flatten1_reg_92_reg[8]_i_1_n_5 ;
  wire \indvar_flatten1_reg_92_reg[8]_i_1_n_6 ;
  wire \indvar_flatten1_reg_92_reg[8]_i_1_n_7 ;
  wire \indvar_flatten1_reg_92_reg[8]_i_1_n_8 ;
  wire \indvar_flatten1_reg_92_reg[8]_i_1_n_9 ;
  wire [7:0]indvar_flatten_next_fu_250_p3;
  wire \indvar_flatten_reg_114[5]_i_2_n_4 ;
  wire \indvar_flatten_reg_114[7]_i_2_n_4 ;
  wire [7:0]indvar_flatten_reg_114_reg__0;
  wire [5:0]tmp_mid2_v_reg_326_reg__0;
  wire [3:3]\NLW_indvar_flatten1_reg_92_reg[8]_i_1_CO_UNCONNECTED ;

  LUT4 #(
    .INIT(16'h00BF)) 
    \ap_CS_fsm[0]_i_1__4 
       (.I0(Q[1]),
        .I1(Q[0]),
        .I2(grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg),
        .I3(ap_CS_fsm_pp0_stage0),
        .O(ap_NS_fsm[0]));
  (* SOFT_HLUTNM = "soft_lutpair92" *) 
  LUT4 #(
    .INIT(16'hEEC0)) 
    \ap_CS_fsm[1]_i_1__4 
       (.I0(\ap_CS_fsm[1]_i_2_n_4 ),
        .I1(Q[0]),
        .I2(grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg),
        .I3(ap_CS_fsm_pp0_stage0),
        .O(ap_NS_fsm[1]));
  (* SOFT_HLUTNM = "soft_lutpair90" *) 
  LUT4 #(
    .INIT(16'hCDDD)) 
    \ap_CS_fsm[1]_i_2 
       (.I0(grp_Conv2_12x12x20_5x5x4_fu_109_output_r_ce0),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(exitcond_flatten1_fu_147_p2),
        .O(\ap_CS_fsm[1]_i_2_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair90" *) 
  LUT5 #(
    .INIT(32'h00AA0080)) 
    \ap_CS_fsm[2]_i_1__2 
       (.I0(ap_CS_fsm_pp0_stage0),
        .I1(exitcond_flatten1_fu_147_p2),
        .I2(ap_enable_reg_pp0_iter0),
        .I3(ap_enable_reg_pp0_iter1_reg_n_4),
        .I4(grp_Conv2_12x12x20_5x5x4_fu_109_output_r_ce0),
        .O(ap_NS_fsm[2]));
  LUT6 #(
    .INIT(64'h0020000000000000)) 
    \ap_CS_fsm[2]_i_2__0 
       (.I0(\ap_CS_fsm[2]_i_3__0_n_4 ),
        .I1(indvar_flatten1_reg_92_reg[10]),
        .I2(indvar_flatten1_reg_92_reg[11]),
        .I3(indvar_flatten1_reg_92_reg[8]),
        .I4(indvar_flatten1_reg_92_reg[9]),
        .I5(\ap_CS_fsm[2]_i_4_n_4 ),
        .O(exitcond_flatten1_fu_147_p2));
  LUT4 #(
    .INIT(16'h0001)) 
    \ap_CS_fsm[2]_i_3__0 
       (.I0(indvar_flatten1_reg_92_reg[7]),
        .I1(indvar_flatten1_reg_92_reg[6]),
        .I2(indvar_flatten1_reg_92_reg[5]),
        .I3(indvar_flatten1_reg_92_reg[4]),
        .O(\ap_CS_fsm[2]_i_3__0_n_4 ));
  LUT4 #(
    .INIT(16'h0001)) 
    \ap_CS_fsm[2]_i_4 
       (.I0(indvar_flatten1_reg_92_reg[1]),
        .I1(indvar_flatten1_reg_92_reg[0]),
        .I2(indvar_flatten1_reg_92_reg[3]),
        .I3(indvar_flatten1_reg_92_reg[2]),
        .O(\ap_CS_fsm[2]_i_4_n_4 ));
  (* FSM_ENCODING = "none" *) 
  FDSE #(
    .INIT(1'b1)) 
    \ap_CS_fsm_reg[0] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[0]),
        .Q(Q[0]),
        .S(ap_rst_n_0));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[1] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[1]),
        .Q(ap_CS_fsm_pp0_stage0),
        .R(ap_rst_n_0));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[2] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[2]),
        .Q(Q[1]),
        .R(ap_rst_n_0));
  LUT6 #(
    .INIT(64'h0000EA00EA00EA00)) 
    ap_enable_reg_pp0_iter0_i_1__0
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(Q[0]),
        .I2(grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg),
        .I3(ap_rst_n),
        .I4(exitcond_flatten1_fu_147_p2),
        .I5(ap_CS_fsm_pp0_stage0),
        .O(ap_enable_reg_pp0_iter0_i_1__0_n_4));
  FDRE #(
    .INIT(1'b0)) 
    ap_enable_reg_pp0_iter0_reg
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_enable_reg_pp0_iter0_i_1__0_n_4),
        .Q(ap_enable_reg_pp0_iter0),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair94" *) 
  LUT3 #(
    .INIT(8'h08)) 
    ap_enable_reg_pp0_iter1_i_1__0
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_rst_n),
        .I2(exitcond_flatten1_fu_147_p2),
        .O(ap_enable_reg_pp0_iter1_i_1__0_n_4));
  FDRE #(
    .INIT(1'b0)) 
    ap_enable_reg_pp0_iter1_reg
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_enable_reg_pp0_iter1_i_1__0_n_4),
        .Q(ap_enable_reg_pp0_iter1_reg_n_4),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    ap_enable_reg_pp0_iter2_reg
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_enable_reg_pp0_iter1_reg_n_4),
        .Q(grp_Conv2_12x12x20_5x5x4_fu_109_output_r_ce0),
        .R(ap_rst_n_0));
  LUT6 #(
    .INIT(64'h656666666A666666)) 
    \conv2_bias_Addr_A[2]_INST_0 
       (.I0(exitcond_flatten7_fu_165_p2__7),
        .I1(\filter_index_reg_103_reg_n_4_[0] ),
        .I2(\exitcond_flatten1_reg_317_reg_n_4_[0] ),
        .I3(ap_enable_reg_pp0_iter1_reg_n_4),
        .I4(ap_CS_fsm_pp0_stage0),
        .I5(tmp_mid2_v_reg_326_reg__0[0]),
        .O(conv2_bias_Addr_A[0]));
  LUT6 #(
    .INIT(64'h77775FA088885FA0)) 
    \conv2_bias_Addr_A[3]_INST_0 
       (.I0(exitcond_flatten7_fu_165_p2__7),
        .I1(tmp_mid2_v_reg_326_reg__0[0]),
        .I2(\filter_index_reg_103_reg_n_4_[0] ),
        .I3(\filter_index_reg_103_reg_n_4_[1] ),
        .I4(filter_index_reg_1030),
        .I5(tmp_mid2_v_reg_326_reg__0[1]),
        .O(conv2_bias_Addr_A[1]));
  LUT5 #(
    .INIT(32'h00100000)) 
    \conv2_bias_Addr_A[3]_INST_0_i_1 
       (.I0(indvar_flatten_reg_114_reg__0[4]),
        .I1(indvar_flatten_reg_114_reg__0[5]),
        .I2(indvar_flatten_reg_114_reg__0[6]),
        .I3(indvar_flatten_reg_114_reg__0[7]),
        .I4(\conv2_bias_Addr_A[3]_INST_0_i_2_n_4 ),
        .O(exitcond_flatten7_fu_165_p2__7));
  (* SOFT_HLUTNM = "soft_lutpair89" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    \conv2_bias_Addr_A[3]_INST_0_i_2 
       (.I0(indvar_flatten_reg_114_reg__0[1]),
        .I1(indvar_flatten_reg_114_reg__0[0]),
        .I2(indvar_flatten_reg_114_reg__0[3]),
        .I3(indvar_flatten_reg_114_reg__0[2]),
        .O(\conv2_bias_Addr_A[3]_INST_0_i_2_n_4 ));
  LUT6 #(
    .INIT(64'h656666666A666666)) 
    \conv2_bias_Addr_A[4]_INST_0 
       (.I0(\conv2_bias_Addr_A[5]_INST_0_i_1_n_4 ),
        .I1(\filter_index_reg_103_reg_n_4_[2] ),
        .I2(\exitcond_flatten1_reg_317_reg_n_4_[0] ),
        .I3(ap_enable_reg_pp0_iter1_reg_n_4),
        .I4(ap_CS_fsm_pp0_stage0),
        .I5(tmp_mid2_v_reg_326_reg__0[2]),
        .O(conv2_bias_Addr_A[2]));
  LUT6 #(
    .INIT(64'h77775FA088885FA0)) 
    \conv2_bias_Addr_A[5]_INST_0 
       (.I0(\conv2_bias_Addr_A[5]_INST_0_i_1_n_4 ),
        .I1(tmp_mid2_v_reg_326_reg__0[2]),
        .I2(\filter_index_reg_103_reg_n_4_[2] ),
        .I3(\filter_index_reg_103_reg_n_4_[3] ),
        .I4(filter_index_reg_1030),
        .I5(tmp_mid2_v_reg_326_reg__0[3]),
        .O(conv2_bias_Addr_A[3]));
  LUT6 #(
    .INIT(64'hC000A0A0C0000000)) 
    \conv2_bias_Addr_A[5]_INST_0_i_1 
       (.I0(\filter_index_reg_103_reg_n_4_[1] ),
        .I1(tmp_mid2_v_reg_326_reg__0[1]),
        .I2(exitcond_flatten7_fu_165_p2__7),
        .I3(tmp_mid2_v_reg_326_reg__0[0]),
        .I4(filter_index_reg_1030),
        .I5(\filter_index_reg_103_reg_n_4_[0] ),
        .O(\conv2_bias_Addr_A[5]_INST_0_i_1_n_4 ));
  LUT6 #(
    .INIT(64'h656666666A666666)) 
    \conv2_bias_Addr_A[6]_INST_0 
       (.I0(\conv2_bias_Addr_A[7]_INST_0_i_1_n_4 ),
        .I1(\filter_index_reg_103_reg_n_4_[4] ),
        .I2(\exitcond_flatten1_reg_317_reg_n_4_[0] ),
        .I3(ap_enable_reg_pp0_iter1_reg_n_4),
        .I4(ap_CS_fsm_pp0_stage0),
        .I5(tmp_mid2_v_reg_326_reg__0[4]),
        .O(conv2_bias_Addr_A[4]));
  LUT6 #(
    .INIT(64'h77775FA088885FA0)) 
    \conv2_bias_Addr_A[7]_INST_0 
       (.I0(\conv2_bias_Addr_A[7]_INST_0_i_1_n_4 ),
        .I1(tmp_mid2_v_reg_326_reg__0[4]),
        .I2(\filter_index_reg_103_reg_n_4_[4] ),
        .I3(\filter_index_reg_103_reg_n_4_[5] ),
        .I4(filter_index_reg_1030),
        .I5(tmp_mid2_v_reg_326_reg__0[5]),
        .O(conv2_bias_Addr_A[5]));
  LUT6 #(
    .INIT(64'hC000A0A0C0000000)) 
    \conv2_bias_Addr_A[7]_INST_0_i_1 
       (.I0(\filter_index_reg_103_reg_n_4_[3] ),
        .I1(tmp_mid2_v_reg_326_reg__0[3]),
        .I2(\conv2_bias_Addr_A[5]_INST_0_i_1_n_4 ),
        .I3(tmp_mid2_v_reg_326_reg__0[2]),
        .I4(filter_index_reg_1030),
        .I5(\filter_index_reg_103_reg_n_4_[2] ),
        .O(\conv2_bias_Addr_A[7]_INST_0_i_1_n_4 ));
  LUT3 #(
    .INIT(8'h08)) 
    \conv2_bias_Addr_A[7]_INST_0_i_2 
       (.I0(ap_CS_fsm_pp0_stage0),
        .I1(ap_enable_reg_pp0_iter1_reg_n_4),
        .I2(\exitcond_flatten1_reg_317_reg_n_4_[0] ),
        .O(filter_index_reg_1030));
  (* SOFT_HLUTNM = "soft_lutpair92" *) 
  LUT2 #(
    .INIT(4'h8)) 
    conv2_bias_EN_A_INST_0
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage0),
        .O(conv2_bias_EN_A));
  (* SOFT_HLUTNM = "soft_lutpair94" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \exitcond_flatten1_reg_317[0]_i_1 
       (.I0(exitcond_flatten1_fu_147_p2),
        .I1(ap_CS_fsm_pp0_stage0),
        .I2(\exitcond_flatten1_reg_317_reg_n_4_[0] ),
        .O(\exitcond_flatten1_reg_317[0]_i_1_n_4 ));
  FDRE \exitcond_flatten1_reg_317_reg[0] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\exitcond_flatten1_reg_317[0]_i_1_n_4 ),
        .Q(\exitcond_flatten1_reg_317_reg_n_4_[0] ),
        .R(1'b0));
  LUT5 #(
    .INIT(32'h80888888)) 
    \filter_index_reg_103[5]_i_1 
       (.I0(grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg),
        .I1(Q[0]),
        .I2(\exitcond_flatten1_reg_317_reg_n_4_[0] ),
        .I3(ap_enable_reg_pp0_iter1_reg_n_4),
        .I4(ap_CS_fsm_pp0_stage0),
        .O(filter_index_reg_103));
  FDRE \filter_index_reg_103_reg[0] 
       (.C(ap_clk),
        .CE(filter_index_reg_1030),
        .D(tmp_mid2_v_reg_326_reg__0[0]),
        .Q(\filter_index_reg_103_reg_n_4_[0] ),
        .R(filter_index_reg_103));
  FDRE \filter_index_reg_103_reg[1] 
       (.C(ap_clk),
        .CE(filter_index_reg_1030),
        .D(tmp_mid2_v_reg_326_reg__0[1]),
        .Q(\filter_index_reg_103_reg_n_4_[1] ),
        .R(filter_index_reg_103));
  FDRE \filter_index_reg_103_reg[2] 
       (.C(ap_clk),
        .CE(filter_index_reg_1030),
        .D(tmp_mid2_v_reg_326_reg__0[2]),
        .Q(\filter_index_reg_103_reg_n_4_[2] ),
        .R(filter_index_reg_103));
  FDRE \filter_index_reg_103_reg[3] 
       (.C(ap_clk),
        .CE(filter_index_reg_1030),
        .D(tmp_mid2_v_reg_326_reg__0[3]),
        .Q(\filter_index_reg_103_reg_n_4_[3] ),
        .R(filter_index_reg_103));
  FDRE \filter_index_reg_103_reg[4] 
       (.C(ap_clk),
        .CE(filter_index_reg_1030),
        .D(tmp_mid2_v_reg_326_reg__0[4]),
        .Q(\filter_index_reg_103_reg_n_4_[4] ),
        .R(filter_index_reg_103));
  FDRE \filter_index_reg_103_reg[5] 
       (.C(ap_clk),
        .CE(filter_index_reg_1030),
        .D(tmp_mid2_v_reg_326_reg__0[5]),
        .Q(\filter_index_reg_103_reg_n_4_[5] ),
        .R(filter_index_reg_103));
  LUT4 #(
    .INIT(16'h8F88)) 
    grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg_i_1
       (.I0(ap_start),
        .I1(\ap_CS_fsm_reg[0]_0 ),
        .I2(Q[1]),
        .I3(grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg),
        .O(grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg_reg));
  LUT5 #(
    .INIT(32'hF7000000)) 
    \indvar_flatten1_reg_92[0]_i_1 
       (.I0(ap_CS_fsm_pp0_stage0),
        .I1(ap_enable_reg_pp0_iter0),
        .I2(exitcond_flatten1_fu_147_p2),
        .I3(grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg),
        .I4(Q[0]),
        .O(indvar_flatten1_reg_92));
  LUT3 #(
    .INIT(8'h08)) 
    \indvar_flatten1_reg_92[0]_i_2 
       (.I0(ap_CS_fsm_pp0_stage0),
        .I1(ap_enable_reg_pp0_iter0),
        .I2(exitcond_flatten1_fu_147_p2),
        .O(indvar_flatten1_reg_920));
  LUT1 #(
    .INIT(2'h1)) 
    \indvar_flatten1_reg_92[0]_i_4 
       (.I0(indvar_flatten1_reg_92_reg[0]),
        .O(\indvar_flatten1_reg_92[0]_i_4_n_4 ));
  FDRE \indvar_flatten1_reg_92_reg[0] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(\indvar_flatten1_reg_92_reg[0]_i_3_n_11 ),
        .Q(indvar_flatten1_reg_92_reg[0]),
        .R(indvar_flatten1_reg_92));
  CARRY4 \indvar_flatten1_reg_92_reg[0]_i_3 
       (.CI(1'b0),
        .CO({\indvar_flatten1_reg_92_reg[0]_i_3_n_4 ,\indvar_flatten1_reg_92_reg[0]_i_3_n_5 ,\indvar_flatten1_reg_92_reg[0]_i_3_n_6 ,\indvar_flatten1_reg_92_reg[0]_i_3_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\indvar_flatten1_reg_92_reg[0]_i_3_n_8 ,\indvar_flatten1_reg_92_reg[0]_i_3_n_9 ,\indvar_flatten1_reg_92_reg[0]_i_3_n_10 ,\indvar_flatten1_reg_92_reg[0]_i_3_n_11 }),
        .S({indvar_flatten1_reg_92_reg[3:1],\indvar_flatten1_reg_92[0]_i_4_n_4 }));
  FDRE \indvar_flatten1_reg_92_reg[10] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(\indvar_flatten1_reg_92_reg[8]_i_1_n_9 ),
        .Q(indvar_flatten1_reg_92_reg[10]),
        .R(indvar_flatten1_reg_92));
  FDRE \indvar_flatten1_reg_92_reg[11] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(\indvar_flatten1_reg_92_reg[8]_i_1_n_8 ),
        .Q(indvar_flatten1_reg_92_reg[11]),
        .R(indvar_flatten1_reg_92));
  FDRE \indvar_flatten1_reg_92_reg[1] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(\indvar_flatten1_reg_92_reg[0]_i_3_n_10 ),
        .Q(indvar_flatten1_reg_92_reg[1]),
        .R(indvar_flatten1_reg_92));
  FDRE \indvar_flatten1_reg_92_reg[2] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(\indvar_flatten1_reg_92_reg[0]_i_3_n_9 ),
        .Q(indvar_flatten1_reg_92_reg[2]),
        .R(indvar_flatten1_reg_92));
  FDRE \indvar_flatten1_reg_92_reg[3] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(\indvar_flatten1_reg_92_reg[0]_i_3_n_8 ),
        .Q(indvar_flatten1_reg_92_reg[3]),
        .R(indvar_flatten1_reg_92));
  FDRE \indvar_flatten1_reg_92_reg[4] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(\indvar_flatten1_reg_92_reg[4]_i_1_n_11 ),
        .Q(indvar_flatten1_reg_92_reg[4]),
        .R(indvar_flatten1_reg_92));
  CARRY4 \indvar_flatten1_reg_92_reg[4]_i_1 
       (.CI(\indvar_flatten1_reg_92_reg[0]_i_3_n_4 ),
        .CO({\indvar_flatten1_reg_92_reg[4]_i_1_n_4 ,\indvar_flatten1_reg_92_reg[4]_i_1_n_5 ,\indvar_flatten1_reg_92_reg[4]_i_1_n_6 ,\indvar_flatten1_reg_92_reg[4]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\indvar_flatten1_reg_92_reg[4]_i_1_n_8 ,\indvar_flatten1_reg_92_reg[4]_i_1_n_9 ,\indvar_flatten1_reg_92_reg[4]_i_1_n_10 ,\indvar_flatten1_reg_92_reg[4]_i_1_n_11 }),
        .S(indvar_flatten1_reg_92_reg[7:4]));
  FDRE \indvar_flatten1_reg_92_reg[5] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(\indvar_flatten1_reg_92_reg[4]_i_1_n_10 ),
        .Q(indvar_flatten1_reg_92_reg[5]),
        .R(indvar_flatten1_reg_92));
  FDRE \indvar_flatten1_reg_92_reg[6] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(\indvar_flatten1_reg_92_reg[4]_i_1_n_9 ),
        .Q(indvar_flatten1_reg_92_reg[6]),
        .R(indvar_flatten1_reg_92));
  FDRE \indvar_flatten1_reg_92_reg[7] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(\indvar_flatten1_reg_92_reg[4]_i_1_n_8 ),
        .Q(indvar_flatten1_reg_92_reg[7]),
        .R(indvar_flatten1_reg_92));
  FDRE \indvar_flatten1_reg_92_reg[8] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(\indvar_flatten1_reg_92_reg[8]_i_1_n_11 ),
        .Q(indvar_flatten1_reg_92_reg[8]),
        .R(indvar_flatten1_reg_92));
  CARRY4 \indvar_flatten1_reg_92_reg[8]_i_1 
       (.CI(\indvar_flatten1_reg_92_reg[4]_i_1_n_4 ),
        .CO({\NLW_indvar_flatten1_reg_92_reg[8]_i_1_CO_UNCONNECTED [3],\indvar_flatten1_reg_92_reg[8]_i_1_n_5 ,\indvar_flatten1_reg_92_reg[8]_i_1_n_6 ,\indvar_flatten1_reg_92_reg[8]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\indvar_flatten1_reg_92_reg[8]_i_1_n_8 ,\indvar_flatten1_reg_92_reg[8]_i_1_n_9 ,\indvar_flatten1_reg_92_reg[8]_i_1_n_10 ,\indvar_flatten1_reg_92_reg[8]_i_1_n_11 }),
        .S(indvar_flatten1_reg_92_reg[11:8]));
  FDRE \indvar_flatten1_reg_92_reg[9] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(\indvar_flatten1_reg_92_reg[8]_i_1_n_10 ),
        .Q(indvar_flatten1_reg_92_reg[9]),
        .R(indvar_flatten1_reg_92));
  (* SOFT_HLUTNM = "soft_lutpair95" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \indvar_flatten_reg_114[0]_i_1 
       (.I0(exitcond_flatten7_fu_165_p2__7),
        .I1(indvar_flatten_reg_114_reg__0[0]),
        .O(indvar_flatten_next_fu_250_p3[0]));
  (* SOFT_HLUTNM = "soft_lutpair95" *) 
  LUT3 #(
    .INIT(8'h14)) 
    \indvar_flatten_reg_114[1]_i_1 
       (.I0(exitcond_flatten7_fu_165_p2__7),
        .I1(indvar_flatten_reg_114_reg__0[0]),
        .I2(indvar_flatten_reg_114_reg__0[1]),
        .O(indvar_flatten_next_fu_250_p3[1]));
  (* SOFT_HLUTNM = "soft_lutpair91" *) 
  LUT4 #(
    .INIT(16'h1540)) 
    \indvar_flatten_reg_114[2]_i_1 
       (.I0(exitcond_flatten7_fu_165_p2__7),
        .I1(indvar_flatten_reg_114_reg__0[0]),
        .I2(indvar_flatten_reg_114_reg__0[1]),
        .I3(indvar_flatten_reg_114_reg__0[2]),
        .O(indvar_flatten_next_fu_250_p3[2]));
  (* SOFT_HLUTNM = "soft_lutpair91" *) 
  LUT5 #(
    .INIT(32'h15554000)) 
    \indvar_flatten_reg_114[3]_i_1 
       (.I0(exitcond_flatten7_fu_165_p2__7),
        .I1(indvar_flatten_reg_114_reg__0[1]),
        .I2(indvar_flatten_reg_114_reg__0[0]),
        .I3(indvar_flatten_reg_114_reg__0[2]),
        .I4(indvar_flatten_reg_114_reg__0[3]),
        .O(indvar_flatten_next_fu_250_p3[3]));
  LUT6 #(
    .INIT(64'h1555555540000000)) 
    \indvar_flatten_reg_114[4]_i_1 
       (.I0(exitcond_flatten7_fu_165_p2__7),
        .I1(indvar_flatten_reg_114_reg__0[2]),
        .I2(indvar_flatten_reg_114_reg__0[0]),
        .I3(indvar_flatten_reg_114_reg__0[1]),
        .I4(indvar_flatten_reg_114_reg__0[3]),
        .I5(indvar_flatten_reg_114_reg__0[4]),
        .O(indvar_flatten_next_fu_250_p3[4]));
  LUT3 #(
    .INIT(8'h12)) 
    \indvar_flatten_reg_114[5]_i_1 
       (.I0(\indvar_flatten_reg_114[5]_i_2_n_4 ),
        .I1(exitcond_flatten7_fu_165_p2__7),
        .I2(indvar_flatten_reg_114_reg__0[5]),
        .O(indvar_flatten_next_fu_250_p3[5]));
  (* SOFT_HLUTNM = "soft_lutpair89" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \indvar_flatten_reg_114[5]_i_2 
       (.I0(indvar_flatten_reg_114_reg__0[4]),
        .I1(indvar_flatten_reg_114_reg__0[2]),
        .I2(indvar_flatten_reg_114_reg__0[0]),
        .I3(indvar_flatten_reg_114_reg__0[1]),
        .I4(indvar_flatten_reg_114_reg__0[3]),
        .O(\indvar_flatten_reg_114[5]_i_2_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair93" *) 
  LUT3 #(
    .INIT(8'h12)) 
    \indvar_flatten_reg_114[6]_i_1 
       (.I0(\indvar_flatten_reg_114[7]_i_2_n_4 ),
        .I1(exitcond_flatten7_fu_165_p2__7),
        .I2(indvar_flatten_reg_114_reg__0[6]),
        .O(indvar_flatten_next_fu_250_p3[6]));
  (* SOFT_HLUTNM = "soft_lutpair93" *) 
  LUT4 #(
    .INIT(16'h0708)) 
    \indvar_flatten_reg_114[7]_i_1 
       (.I0(indvar_flatten_reg_114_reg__0[6]),
        .I1(\indvar_flatten_reg_114[7]_i_2_n_4 ),
        .I2(exitcond_flatten7_fu_165_p2__7),
        .I3(indvar_flatten_reg_114_reg__0[7]),
        .O(indvar_flatten_next_fu_250_p3[7]));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \indvar_flatten_reg_114[7]_i_2 
       (.I0(indvar_flatten_reg_114_reg__0[5]),
        .I1(indvar_flatten_reg_114_reg__0[3]),
        .I2(indvar_flatten_reg_114_reg__0[1]),
        .I3(indvar_flatten_reg_114_reg__0[0]),
        .I4(indvar_flatten_reg_114_reg__0[2]),
        .I5(indvar_flatten_reg_114_reg__0[4]),
        .O(\indvar_flatten_reg_114[7]_i_2_n_4 ));
  FDRE \indvar_flatten_reg_114_reg[0] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(indvar_flatten_next_fu_250_p3[0]),
        .Q(indvar_flatten_reg_114_reg__0[0]),
        .R(indvar_flatten1_reg_92));
  FDRE \indvar_flatten_reg_114_reg[1] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(indvar_flatten_next_fu_250_p3[1]),
        .Q(indvar_flatten_reg_114_reg__0[1]),
        .R(indvar_flatten1_reg_92));
  FDRE \indvar_flatten_reg_114_reg[2] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(indvar_flatten_next_fu_250_p3[2]),
        .Q(indvar_flatten_reg_114_reg__0[2]),
        .R(indvar_flatten1_reg_92));
  FDRE \indvar_flatten_reg_114_reg[3] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(indvar_flatten_next_fu_250_p3[3]),
        .Q(indvar_flatten_reg_114_reg__0[3]),
        .R(indvar_flatten1_reg_92));
  FDRE \indvar_flatten_reg_114_reg[4] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(indvar_flatten_next_fu_250_p3[4]),
        .Q(indvar_flatten_reg_114_reg__0[4]),
        .R(indvar_flatten1_reg_92));
  FDRE \indvar_flatten_reg_114_reg[5] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(indvar_flatten_next_fu_250_p3[5]),
        .Q(indvar_flatten_reg_114_reg__0[5]),
        .R(indvar_flatten1_reg_92));
  FDRE \indvar_flatten_reg_114_reg[6] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(indvar_flatten_next_fu_250_p3[6]),
        .Q(indvar_flatten_reg_114_reg__0[6]),
        .R(indvar_flatten1_reg_92));
  FDRE \indvar_flatten_reg_114_reg[7] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(indvar_flatten_next_fu_250_p3[7]),
        .Q(indvar_flatten_reg_114_reg__0[7]),
        .R(indvar_flatten1_reg_92));
  FDRE \tmp_mid2_v_reg_326_reg[0] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(conv2_bias_Addr_A[0]),
        .Q(tmp_mid2_v_reg_326_reg__0[0]),
        .R(1'b0));
  FDRE \tmp_mid2_v_reg_326_reg[1] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(conv2_bias_Addr_A[1]),
        .Q(tmp_mid2_v_reg_326_reg__0[1]),
        .R(1'b0));
  FDRE \tmp_mid2_v_reg_326_reg[2] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(conv2_bias_Addr_A[2]),
        .Q(tmp_mid2_v_reg_326_reg__0[2]),
        .R(1'b0));
  FDRE \tmp_mid2_v_reg_326_reg[3] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(conv2_bias_Addr_A[3]),
        .Q(tmp_mid2_v_reg_326_reg__0[3]),
        .R(1'b0));
  FDRE \tmp_mid2_v_reg_326_reg[4] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(conv2_bias_Addr_A[4]),
        .Q(tmp_mid2_v_reg_326_reg__0[4]),
        .R(1'b0));
  FDRE \tmp_mid2_v_reg_326_reg[5] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_920),
        .D(conv2_bias_Addr_A[5]),
        .Q(tmp_mid2_v_reg_326_reg__0[5]),
        .R(1'b0));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Fc1_40_400
   (D,
    fc1_bias_EN_A,
    \fc1_bias_Addr_A[10] ,
    fc1_output_ce0,
    WEA,
    ADDRARDADDR,
    grp_Fc1_40_400_fu_117_ap_start_reg_reg,
    grp_Fc1_40_400_fu_117_output_r_d0,
    Q,
    ap_start,
    \ap_CS_fsm_reg[26] ,
    grp_Fc1_40_400_fu_117_ap_start_reg,
    \ap_CS_fsm_reg[3]_0 ,
    \i_reg_137_reg[8] ,
    fc1_bias_Dout_A,
    ap_rst_n,
    ap_clk);
  output [1:0]D;
  output [0:0]fc1_bias_EN_A;
  output [8:0]\fc1_bias_Addr_A[10] ;
  output fc1_output_ce0;
  output [0:0]WEA;
  output [8:0]ADDRARDADDR;
  output grp_Fc1_40_400_fu_117_ap_start_reg_reg;
  output [30:0]grp_Fc1_40_400_fu_117_output_r_d0;
  input [2:0]Q;
  input ap_start;
  input \ap_CS_fsm_reg[26] ;
  input grp_Fc1_40_400_fu_117_ap_start_reg;
  input [0:0]\ap_CS_fsm_reg[3]_0 ;
  input [8:0]\i_reg_137_reg[8] ;
  input [31:0]fc1_bias_Dout_A;
  input ap_rst_n;
  input ap_clk;

  wire [8:0]ADDRARDADDR;
  wire [1:0]D;
  wire [2:0]Q;
  wire [0:0]WEA;
  wire \ap_CS_fsm_reg[26] ;
  wire [0:0]\ap_CS_fsm_reg[3]_0 ;
  wire \ap_CS_fsm_reg_n_4_[0] ;
  wire ap_CS_fsm_state3;
  wire [2:0]ap_NS_fsm;
  wire ap_block_state2_on_subcall_done;
  wire ap_clk;
  wire ap_rst_n;
  wire ap_start;
  wire [8:0]\fc1_bias_Addr_A[10] ;
  wire [31:0]fc1_bias_Dout_A;
  wire [0:0]fc1_bias_EN_A;
  wire fc1_output_ce0;
  wire grp_Fc1_40_400_fu_117_ap_ready;
  wire grp_Fc1_40_400_fu_117_ap_start_reg;
  wire grp_Fc1_40_400_fu_117_ap_start_reg_reg;
  wire [30:0]grp_Fc1_40_400_fu_117_output_r_d0;
  wire grp_Fc1_40_400_fu_117_output_r_we0;
  wire [8:0]\i_reg_137_reg[8] ;
  wire [8:0]k_2_fu_73_p2;
  wire [8:0]k_2_reg_105;
  wire \k_2_reg_105[8]_i_2_n_4 ;
  wire k_reg_56;
  wire \tmp_1_reg_120[30]_i_1_n_4 ;
  wire \tmp_reg_110[8]_i_2_n_4 ;
  wire [8:0]tmp_reg_110_reg;
  wire tmp_reg_110_reg0;
  wire tmp_s_fu_88_p2_carry__0_i_1_n_4;
  wire tmp_s_fu_88_p2_carry__0_i_2_n_4;
  wire tmp_s_fu_88_p2_carry__0_i_3_n_4;
  wire tmp_s_fu_88_p2_carry__0_i_4_n_4;
  wire tmp_s_fu_88_p2_carry__0_i_5_n_4;
  wire tmp_s_fu_88_p2_carry__0_i_6_n_4;
  wire tmp_s_fu_88_p2_carry__0_i_7_n_4;
  wire tmp_s_fu_88_p2_carry__0_i_8_n_4;
  wire tmp_s_fu_88_p2_carry__0_n_4;
  wire tmp_s_fu_88_p2_carry__0_n_5;
  wire tmp_s_fu_88_p2_carry__0_n_6;
  wire tmp_s_fu_88_p2_carry__0_n_7;
  wire tmp_s_fu_88_p2_carry__1_i_1_n_4;
  wire tmp_s_fu_88_p2_carry__1_i_2_n_4;
  wire tmp_s_fu_88_p2_carry__1_i_3_n_4;
  wire tmp_s_fu_88_p2_carry__1_i_4_n_4;
  wire tmp_s_fu_88_p2_carry__1_i_5_n_4;
  wire tmp_s_fu_88_p2_carry__1_i_6_n_4;
  wire tmp_s_fu_88_p2_carry__1_i_7_n_4;
  wire tmp_s_fu_88_p2_carry__1_i_8_n_4;
  wire tmp_s_fu_88_p2_carry__1_n_4;
  wire tmp_s_fu_88_p2_carry__1_n_5;
  wire tmp_s_fu_88_p2_carry__1_n_6;
  wire tmp_s_fu_88_p2_carry__1_n_7;
  wire tmp_s_fu_88_p2_carry__2_i_1_n_4;
  wire tmp_s_fu_88_p2_carry__2_i_2_n_4;
  wire tmp_s_fu_88_p2_carry__2_i_3_n_4;
  wire tmp_s_fu_88_p2_carry__2_i_4_n_4;
  wire tmp_s_fu_88_p2_carry__2_i_5_n_4;
  wire tmp_s_fu_88_p2_carry__2_i_6_n_4;
  wire tmp_s_fu_88_p2_carry__2_i_7_n_4;
  wire tmp_s_fu_88_p2_carry__2_i_8_n_4;
  wire tmp_s_fu_88_p2_carry__2_n_4;
  wire tmp_s_fu_88_p2_carry__2_n_5;
  wire tmp_s_fu_88_p2_carry__2_n_6;
  wire tmp_s_fu_88_p2_carry__2_n_7;
  wire tmp_s_fu_88_p2_carry_i_1_n_4;
  wire tmp_s_fu_88_p2_carry_i_2_n_4;
  wire tmp_s_fu_88_p2_carry_i_3_n_4;
  wire tmp_s_fu_88_p2_carry_i_4_n_4;
  wire tmp_s_fu_88_p2_carry_i_5_n_4;
  wire tmp_s_fu_88_p2_carry_i_6_n_4;
  wire tmp_s_fu_88_p2_carry_i_7_n_4;
  wire tmp_s_fu_88_p2_carry_i_8_n_4;
  wire tmp_s_fu_88_p2_carry_n_4;
  wire tmp_s_fu_88_p2_carry_n_5;
  wire tmp_s_fu_88_p2_carry_n_6;
  wire tmp_s_fu_88_p2_carry_n_7;
  wire [3:0]NLW_tmp_s_fu_88_p2_carry_O_UNCONNECTED;
  wire [3:0]NLW_tmp_s_fu_88_p2_carry__0_O_UNCONNECTED;
  wire [3:0]NLW_tmp_s_fu_88_p2_carry__1_O_UNCONNECTED;
  wire [3:0]NLW_tmp_s_fu_88_p2_carry__2_O_UNCONNECTED;

  LUT5 #(
    .INIT(32'h5555000C)) 
    \ap_CS_fsm[0]_i_1__5 
       (.I0(grp_Fc1_40_400_fu_117_ap_start_reg),
        .I1(grp_Fc1_40_400_fu_117_ap_ready),
        .I2(grp_Fc1_40_400_fu_117_output_r_we0),
        .I3(ap_CS_fsm_state3),
        .I4(\ap_CS_fsm_reg_n_4_[0] ),
        .O(ap_NS_fsm[0]));
  (* SOFT_HLUTNM = "soft_lutpair100" *) 
  LUT4 #(
    .INIT(16'hF888)) 
    \ap_CS_fsm[1]_i_1__0 
       (.I0(Q[1]),
        .I1(ap_block_state2_on_subcall_done),
        .I2(Q[0]),
        .I3(ap_start),
        .O(D[0]));
  (* SOFT_HLUTNM = "soft_lutpair98" *) 
  LUT3 #(
    .INIT(8'hF8)) 
    \ap_CS_fsm[1]_i_1__5 
       (.I0(grp_Fc1_40_400_fu_117_ap_start_reg),
        .I1(\ap_CS_fsm_reg_n_4_[0] ),
        .I2(grp_Fc1_40_400_fu_117_output_r_we0),
        .O(ap_NS_fsm[1]));
  (* SOFT_HLUTNM = "soft_lutpair100" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \ap_CS_fsm[2]_i_1 
       (.I0(Q[1]),
        .I1(ap_block_state2_on_subcall_done),
        .O(D[1]));
  (* SOFT_HLUTNM = "soft_lutpair99" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \ap_CS_fsm[2]_i_1__3 
       (.I0(fc1_bias_EN_A),
        .I1(grp_Fc1_40_400_fu_117_ap_ready),
        .O(ap_NS_fsm[2]));
  (* SOFT_HLUTNM = "soft_lutpair98" *) 
  LUT4 #(
    .INIT(16'hBBAB)) 
    \ap_CS_fsm[2]_i_2 
       (.I0(\ap_CS_fsm_reg[26] ),
        .I1(grp_Fc1_40_400_fu_117_ap_ready),
        .I2(\ap_CS_fsm_reg_n_4_[0] ),
        .I3(grp_Fc1_40_400_fu_117_ap_start_reg),
        .O(ap_block_state2_on_subcall_done));
  (* SOFT_HLUTNM = "soft_lutpair96" *) 
  LUT5 #(
    .INIT(32'h01000000)) 
    \ap_CS_fsm[2]_i_2__1 
       (.I0(\fc1_bias_Addr_A[10] [2]),
        .I1(\fc1_bias_Addr_A[10] [1]),
        .I2(\fc1_bias_Addr_A[10] [0]),
        .I3(\tmp_reg_110[8]_i_2_n_4 ),
        .I4(fc1_bias_EN_A),
        .O(grp_Fc1_40_400_fu_117_ap_ready));
  (* FSM_ENCODING = "none" *) 
  FDSE #(
    .INIT(1'b1)) 
    \ap_CS_fsm_reg[0] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[0]),
        .Q(\ap_CS_fsm_reg_n_4_[0] ),
        .S(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[1] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[1]),
        .Q(fc1_bias_EN_A),
        .R(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[2] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[2]),
        .Q(ap_CS_fsm_state3),
        .R(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[3] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_state3),
        .Q(grp_Fc1_40_400_fu_117_output_r_we0),
        .R(ap_rst_n));
  (* SOFT_HLUTNM = "soft_lutpair99" *) 
  LUT4 #(
    .INIT(16'h8F88)) 
    grp_Fc1_40_400_fu_117_ap_start_reg_i_1
       (.I0(ap_start),
        .I1(Q[0]),
        .I2(grp_Fc1_40_400_fu_117_ap_ready),
        .I3(grp_Fc1_40_400_fu_117_ap_start_reg),
        .O(grp_Fc1_40_400_fu_117_ap_start_reg_reg));
  (* SOFT_HLUTNM = "soft_lutpair102" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \k_2_reg_105[0]_i_1 
       (.I0(\fc1_bias_Addr_A[10] [0]),
        .O(k_2_fu_73_p2[0]));
  (* SOFT_HLUTNM = "soft_lutpair102" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \k_2_reg_105[1]_i_1 
       (.I0(\fc1_bias_Addr_A[10] [0]),
        .I1(\fc1_bias_Addr_A[10] [1]),
        .O(k_2_fu_73_p2[1]));
  (* SOFT_HLUTNM = "soft_lutpair96" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \k_2_reg_105[2]_i_1 
       (.I0(\fc1_bias_Addr_A[10] [0]),
        .I1(\fc1_bias_Addr_A[10] [1]),
        .I2(\fc1_bias_Addr_A[10] [2]),
        .O(k_2_fu_73_p2[2]));
  (* SOFT_HLUTNM = "soft_lutpair97" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \k_2_reg_105[3]_i_1 
       (.I0(\fc1_bias_Addr_A[10] [1]),
        .I1(\fc1_bias_Addr_A[10] [0]),
        .I2(\fc1_bias_Addr_A[10] [2]),
        .I3(\fc1_bias_Addr_A[10] [3]),
        .O(k_2_fu_73_p2[3]));
  (* SOFT_HLUTNM = "soft_lutpair97" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \k_2_reg_105[4]_i_1 
       (.I0(\fc1_bias_Addr_A[10] [2]),
        .I1(\fc1_bias_Addr_A[10] [0]),
        .I2(\fc1_bias_Addr_A[10] [1]),
        .I3(\fc1_bias_Addr_A[10] [3]),
        .I4(\fc1_bias_Addr_A[10] [4]),
        .O(k_2_fu_73_p2[4]));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \k_2_reg_105[5]_i_1 
       (.I0(\fc1_bias_Addr_A[10] [3]),
        .I1(\fc1_bias_Addr_A[10] [1]),
        .I2(\fc1_bias_Addr_A[10] [0]),
        .I3(\fc1_bias_Addr_A[10] [2]),
        .I4(\fc1_bias_Addr_A[10] [4]),
        .I5(\fc1_bias_Addr_A[10] [5]),
        .O(k_2_fu_73_p2[5]));
  LUT2 #(
    .INIT(4'h6)) 
    \k_2_reg_105[6]_i_1 
       (.I0(\k_2_reg_105[8]_i_2_n_4 ),
        .I1(\fc1_bias_Addr_A[10] [6]),
        .O(k_2_fu_73_p2[6]));
  (* SOFT_HLUTNM = "soft_lutpair101" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \k_2_reg_105[7]_i_1 
       (.I0(\k_2_reg_105[8]_i_2_n_4 ),
        .I1(\fc1_bias_Addr_A[10] [6]),
        .I2(\fc1_bias_Addr_A[10] [7]),
        .O(k_2_fu_73_p2[7]));
  (* SOFT_HLUTNM = "soft_lutpair101" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \k_2_reg_105[8]_i_1 
       (.I0(\fc1_bias_Addr_A[10] [6]),
        .I1(\k_2_reg_105[8]_i_2_n_4 ),
        .I2(\fc1_bias_Addr_A[10] [7]),
        .I3(\fc1_bias_Addr_A[10] [8]),
        .O(k_2_fu_73_p2[8]));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \k_2_reg_105[8]_i_2 
       (.I0(\fc1_bias_Addr_A[10] [5]),
        .I1(\fc1_bias_Addr_A[10] [3]),
        .I2(\fc1_bias_Addr_A[10] [1]),
        .I3(\fc1_bias_Addr_A[10] [0]),
        .I4(\fc1_bias_Addr_A[10] [2]),
        .I5(\fc1_bias_Addr_A[10] [4]),
        .O(\k_2_reg_105[8]_i_2_n_4 ));
  FDRE \k_2_reg_105_reg[0] 
       (.C(ap_clk),
        .CE(fc1_bias_EN_A),
        .D(k_2_fu_73_p2[0]),
        .Q(k_2_reg_105[0]),
        .R(1'b0));
  FDRE \k_2_reg_105_reg[1] 
       (.C(ap_clk),
        .CE(fc1_bias_EN_A),
        .D(k_2_fu_73_p2[1]),
        .Q(k_2_reg_105[1]),
        .R(1'b0));
  FDRE \k_2_reg_105_reg[2] 
       (.C(ap_clk),
        .CE(fc1_bias_EN_A),
        .D(k_2_fu_73_p2[2]),
        .Q(k_2_reg_105[2]),
        .R(1'b0));
  FDRE \k_2_reg_105_reg[3] 
       (.C(ap_clk),
        .CE(fc1_bias_EN_A),
        .D(k_2_fu_73_p2[3]),
        .Q(k_2_reg_105[3]),
        .R(1'b0));
  FDRE \k_2_reg_105_reg[4] 
       (.C(ap_clk),
        .CE(fc1_bias_EN_A),
        .D(k_2_fu_73_p2[4]),
        .Q(k_2_reg_105[4]),
        .R(1'b0));
  FDRE \k_2_reg_105_reg[5] 
       (.C(ap_clk),
        .CE(fc1_bias_EN_A),
        .D(k_2_fu_73_p2[5]),
        .Q(k_2_reg_105[5]),
        .R(1'b0));
  FDRE \k_2_reg_105_reg[6] 
       (.C(ap_clk),
        .CE(fc1_bias_EN_A),
        .D(k_2_fu_73_p2[6]),
        .Q(k_2_reg_105[6]),
        .R(1'b0));
  FDRE \k_2_reg_105_reg[7] 
       (.C(ap_clk),
        .CE(fc1_bias_EN_A),
        .D(k_2_fu_73_p2[7]),
        .Q(k_2_reg_105[7]),
        .R(1'b0));
  FDRE \k_2_reg_105_reg[8] 
       (.C(ap_clk),
        .CE(fc1_bias_EN_A),
        .D(k_2_fu_73_p2[8]),
        .Q(k_2_reg_105[8]),
        .R(1'b0));
  LUT3 #(
    .INIT(8'h08)) 
    \k_reg_56[8]_i_1 
       (.I0(\ap_CS_fsm_reg_n_4_[0] ),
        .I1(grp_Fc1_40_400_fu_117_ap_start_reg),
        .I2(grp_Fc1_40_400_fu_117_output_r_we0),
        .O(k_reg_56));
  FDRE \k_reg_56_reg[0] 
       (.C(ap_clk),
        .CE(grp_Fc1_40_400_fu_117_output_r_we0),
        .D(k_2_reg_105[0]),
        .Q(\fc1_bias_Addr_A[10] [0]),
        .R(k_reg_56));
  FDRE \k_reg_56_reg[1] 
       (.C(ap_clk),
        .CE(grp_Fc1_40_400_fu_117_output_r_we0),
        .D(k_2_reg_105[1]),
        .Q(\fc1_bias_Addr_A[10] [1]),
        .R(k_reg_56));
  FDRE \k_reg_56_reg[2] 
       (.C(ap_clk),
        .CE(grp_Fc1_40_400_fu_117_output_r_we0),
        .D(k_2_reg_105[2]),
        .Q(\fc1_bias_Addr_A[10] [2]),
        .R(k_reg_56));
  FDRE \k_reg_56_reg[3] 
       (.C(ap_clk),
        .CE(grp_Fc1_40_400_fu_117_output_r_we0),
        .D(k_2_reg_105[3]),
        .Q(\fc1_bias_Addr_A[10] [3]),
        .R(k_reg_56));
  FDRE \k_reg_56_reg[4] 
       (.C(ap_clk),
        .CE(grp_Fc1_40_400_fu_117_output_r_we0),
        .D(k_2_reg_105[4]),
        .Q(\fc1_bias_Addr_A[10] [4]),
        .R(k_reg_56));
  FDRE \k_reg_56_reg[5] 
       (.C(ap_clk),
        .CE(grp_Fc1_40_400_fu_117_output_r_we0),
        .D(k_2_reg_105[5]),
        .Q(\fc1_bias_Addr_A[10] [5]),
        .R(k_reg_56));
  FDRE \k_reg_56_reg[6] 
       (.C(ap_clk),
        .CE(grp_Fc1_40_400_fu_117_output_r_we0),
        .D(k_2_reg_105[6]),
        .Q(\fc1_bias_Addr_A[10] [6]),
        .R(k_reg_56));
  FDRE \k_reg_56_reg[7] 
       (.C(ap_clk),
        .CE(grp_Fc1_40_400_fu_117_output_r_we0),
        .D(k_2_reg_105[7]),
        .Q(\fc1_bias_Addr_A[10] [7]),
        .R(k_reg_56));
  FDRE \k_reg_56_reg[8] 
       (.C(ap_clk),
        .CE(grp_Fc1_40_400_fu_117_output_r_we0),
        .D(k_2_reg_105[8]),
        .Q(\fc1_bias_Addr_A[10] [8]),
        .R(k_reg_56));
  LUT4 #(
    .INIT(16'hB888)) 
    ram_reg_i_1
       (.I0(grp_Fc1_40_400_fu_117_output_r_we0),
        .I1(Q[1]),
        .I2(Q[2]),
        .I3(\ap_CS_fsm_reg[3]_0 ),
        .O(fc1_output_ce0));
  LUT3 #(
    .INIT(8'hB8)) 
    ram_reg_i_10
       (.I0(tmp_reg_110_reg[0]),
        .I1(Q[1]),
        .I2(\i_reg_137_reg[8] [0]),
        .O(ADDRARDADDR[0]));
  LUT2 #(
    .INIT(4'h8)) 
    ram_reg_i_11
       (.I0(Q[1]),
        .I1(grp_Fc1_40_400_fu_117_output_r_we0),
        .O(WEA));
  LUT3 #(
    .INIT(8'hB8)) 
    ram_reg_i_2
       (.I0(tmp_reg_110_reg[8]),
        .I1(Q[1]),
        .I2(\i_reg_137_reg[8] [8]),
        .O(ADDRARDADDR[8]));
  LUT3 #(
    .INIT(8'hB8)) 
    ram_reg_i_3
       (.I0(tmp_reg_110_reg[7]),
        .I1(Q[1]),
        .I2(\i_reg_137_reg[8] [7]),
        .O(ADDRARDADDR[7]));
  LUT3 #(
    .INIT(8'hB8)) 
    ram_reg_i_4
       (.I0(tmp_reg_110_reg[6]),
        .I1(Q[1]),
        .I2(\i_reg_137_reg[8] [6]),
        .O(ADDRARDADDR[6]));
  LUT3 #(
    .INIT(8'hB8)) 
    ram_reg_i_5
       (.I0(tmp_reg_110_reg[5]),
        .I1(Q[1]),
        .I2(\i_reg_137_reg[8] [5]),
        .O(ADDRARDADDR[5]));
  LUT3 #(
    .INIT(8'hB8)) 
    ram_reg_i_6
       (.I0(tmp_reg_110_reg[4]),
        .I1(Q[1]),
        .I2(\i_reg_137_reg[8] [4]),
        .O(ADDRARDADDR[4]));
  LUT3 #(
    .INIT(8'hB8)) 
    ram_reg_i_7
       (.I0(tmp_reg_110_reg[3]),
        .I1(Q[1]),
        .I2(\i_reg_137_reg[8] [3]),
        .O(ADDRARDADDR[3]));
  LUT3 #(
    .INIT(8'hB8)) 
    ram_reg_i_8
       (.I0(tmp_reg_110_reg[2]),
        .I1(Q[1]),
        .I2(\i_reg_137_reg[8] [2]),
        .O(ADDRARDADDR[2]));
  LUT3 #(
    .INIT(8'hB8)) 
    ram_reg_i_9
       (.I0(tmp_reg_110_reg[1]),
        .I1(Q[1]),
        .I2(\i_reg_137_reg[8] [1]),
        .O(ADDRARDADDR[1]));
  LUT2 #(
    .INIT(4'h2)) 
    \tmp_1_reg_120[30]_i_1 
       (.I0(ap_CS_fsm_state3),
        .I1(tmp_s_fu_88_p2_carry__2_n_4),
        .O(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[0] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[0]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[0]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[10] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[10]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[10]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[11] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[11]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[11]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[12] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[12]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[12]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[13] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[13]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[13]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[14] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[14]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[14]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[15] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[15]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[15]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[16] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[16]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[16]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[17] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[17]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[17]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[18] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[18]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[18]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[19] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[19]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[19]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[1] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[1]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[1]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[20] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[20]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[20]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[21] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[21]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[21]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[22] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[22]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[22]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[23] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[23]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[23]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[24] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[24]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[24]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[25] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[25]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[25]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[26] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[26]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[26]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[27] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[27]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[27]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[28] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[28]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[28]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[29] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[29]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[29]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[2] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[2]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[2]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[30] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[30]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[30]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[3] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[3]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[3]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[4] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[4]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[4]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[5] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[5]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[5]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[6] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[6]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[6]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[7] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[7]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[7]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[8] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[8]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[8]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  FDRE \tmp_1_reg_120_reg[9] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(fc1_bias_Dout_A[9]),
        .Q(grp_Fc1_40_400_fu_117_output_r_d0[9]),
        .R(\tmp_1_reg_120[30]_i_1_n_4 ));
  LUT5 #(
    .INIT(32'hAAA8AAAA)) 
    \tmp_reg_110[8]_i_1 
       (.I0(fc1_bias_EN_A),
        .I1(\fc1_bias_Addr_A[10] [2]),
        .I2(\fc1_bias_Addr_A[10] [1]),
        .I3(\fc1_bias_Addr_A[10] [0]),
        .I4(\tmp_reg_110[8]_i_2_n_4 ),
        .O(tmp_reg_110_reg0));
  LUT6 #(
    .INIT(64'h0002000000000000)) 
    \tmp_reg_110[8]_i_2 
       (.I0(\fc1_bias_Addr_A[10] [4]),
        .I1(\fc1_bias_Addr_A[10] [3]),
        .I2(\fc1_bias_Addr_A[10] [5]),
        .I3(\fc1_bias_Addr_A[10] [6]),
        .I4(\fc1_bias_Addr_A[10] [8]),
        .I5(\fc1_bias_Addr_A[10] [7]),
        .O(\tmp_reg_110[8]_i_2_n_4 ));
  FDRE \tmp_reg_110_reg[0] 
       (.C(ap_clk),
        .CE(tmp_reg_110_reg0),
        .D(\fc1_bias_Addr_A[10] [0]),
        .Q(tmp_reg_110_reg[0]),
        .R(1'b0));
  FDRE \tmp_reg_110_reg[1] 
       (.C(ap_clk),
        .CE(tmp_reg_110_reg0),
        .D(\fc1_bias_Addr_A[10] [1]),
        .Q(tmp_reg_110_reg[1]),
        .R(1'b0));
  FDRE \tmp_reg_110_reg[2] 
       (.C(ap_clk),
        .CE(tmp_reg_110_reg0),
        .D(\fc1_bias_Addr_A[10] [2]),
        .Q(tmp_reg_110_reg[2]),
        .R(1'b0));
  FDRE \tmp_reg_110_reg[3] 
       (.C(ap_clk),
        .CE(tmp_reg_110_reg0),
        .D(\fc1_bias_Addr_A[10] [3]),
        .Q(tmp_reg_110_reg[3]),
        .R(1'b0));
  FDRE \tmp_reg_110_reg[4] 
       (.C(ap_clk),
        .CE(tmp_reg_110_reg0),
        .D(\fc1_bias_Addr_A[10] [4]),
        .Q(tmp_reg_110_reg[4]),
        .R(1'b0));
  FDRE \tmp_reg_110_reg[5] 
       (.C(ap_clk),
        .CE(tmp_reg_110_reg0),
        .D(\fc1_bias_Addr_A[10] [5]),
        .Q(tmp_reg_110_reg[5]),
        .R(1'b0));
  FDRE \tmp_reg_110_reg[6] 
       (.C(ap_clk),
        .CE(tmp_reg_110_reg0),
        .D(\fc1_bias_Addr_A[10] [6]),
        .Q(tmp_reg_110_reg[6]),
        .R(1'b0));
  FDRE \tmp_reg_110_reg[7] 
       (.C(ap_clk),
        .CE(tmp_reg_110_reg0),
        .D(\fc1_bias_Addr_A[10] [7]),
        .Q(tmp_reg_110_reg[7]),
        .R(1'b0));
  FDRE \tmp_reg_110_reg[8] 
       (.C(ap_clk),
        .CE(tmp_reg_110_reg0),
        .D(\fc1_bias_Addr_A[10] [8]),
        .Q(tmp_reg_110_reg[8]),
        .R(1'b0));
  CARRY4 tmp_s_fu_88_p2_carry
       (.CI(1'b0),
        .CO({tmp_s_fu_88_p2_carry_n_4,tmp_s_fu_88_p2_carry_n_5,tmp_s_fu_88_p2_carry_n_6,tmp_s_fu_88_p2_carry_n_7}),
        .CYINIT(1'b0),
        .DI({tmp_s_fu_88_p2_carry_i_1_n_4,tmp_s_fu_88_p2_carry_i_2_n_4,tmp_s_fu_88_p2_carry_i_3_n_4,tmp_s_fu_88_p2_carry_i_4_n_4}),
        .O(NLW_tmp_s_fu_88_p2_carry_O_UNCONNECTED[3:0]),
        .S({tmp_s_fu_88_p2_carry_i_5_n_4,tmp_s_fu_88_p2_carry_i_6_n_4,tmp_s_fu_88_p2_carry_i_7_n_4,tmp_s_fu_88_p2_carry_i_8_n_4}));
  CARRY4 tmp_s_fu_88_p2_carry__0
       (.CI(tmp_s_fu_88_p2_carry_n_4),
        .CO({tmp_s_fu_88_p2_carry__0_n_4,tmp_s_fu_88_p2_carry__0_n_5,tmp_s_fu_88_p2_carry__0_n_6,tmp_s_fu_88_p2_carry__0_n_7}),
        .CYINIT(1'b0),
        .DI({tmp_s_fu_88_p2_carry__0_i_1_n_4,tmp_s_fu_88_p2_carry__0_i_2_n_4,tmp_s_fu_88_p2_carry__0_i_3_n_4,tmp_s_fu_88_p2_carry__0_i_4_n_4}),
        .O(NLW_tmp_s_fu_88_p2_carry__0_O_UNCONNECTED[3:0]),
        .S({tmp_s_fu_88_p2_carry__0_i_5_n_4,tmp_s_fu_88_p2_carry__0_i_6_n_4,tmp_s_fu_88_p2_carry__0_i_7_n_4,tmp_s_fu_88_p2_carry__0_i_8_n_4}));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_88_p2_carry__0_i_1
       (.I0(fc1_bias_Dout_A[14]),
        .I1(fc1_bias_Dout_A[15]),
        .O(tmp_s_fu_88_p2_carry__0_i_1_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_88_p2_carry__0_i_2
       (.I0(fc1_bias_Dout_A[12]),
        .I1(fc1_bias_Dout_A[13]),
        .O(tmp_s_fu_88_p2_carry__0_i_2_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_88_p2_carry__0_i_3
       (.I0(fc1_bias_Dout_A[10]),
        .I1(fc1_bias_Dout_A[11]),
        .O(tmp_s_fu_88_p2_carry__0_i_3_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_88_p2_carry__0_i_4
       (.I0(fc1_bias_Dout_A[8]),
        .I1(fc1_bias_Dout_A[9]),
        .O(tmp_s_fu_88_p2_carry__0_i_4_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_88_p2_carry__0_i_5
       (.I0(fc1_bias_Dout_A[14]),
        .I1(fc1_bias_Dout_A[15]),
        .O(tmp_s_fu_88_p2_carry__0_i_5_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_88_p2_carry__0_i_6
       (.I0(fc1_bias_Dout_A[12]),
        .I1(fc1_bias_Dout_A[13]),
        .O(tmp_s_fu_88_p2_carry__0_i_6_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_88_p2_carry__0_i_7
       (.I0(fc1_bias_Dout_A[10]),
        .I1(fc1_bias_Dout_A[11]),
        .O(tmp_s_fu_88_p2_carry__0_i_7_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_88_p2_carry__0_i_8
       (.I0(fc1_bias_Dout_A[8]),
        .I1(fc1_bias_Dout_A[9]),
        .O(tmp_s_fu_88_p2_carry__0_i_8_n_4));
  CARRY4 tmp_s_fu_88_p2_carry__1
       (.CI(tmp_s_fu_88_p2_carry__0_n_4),
        .CO({tmp_s_fu_88_p2_carry__1_n_4,tmp_s_fu_88_p2_carry__1_n_5,tmp_s_fu_88_p2_carry__1_n_6,tmp_s_fu_88_p2_carry__1_n_7}),
        .CYINIT(1'b0),
        .DI({tmp_s_fu_88_p2_carry__1_i_1_n_4,tmp_s_fu_88_p2_carry__1_i_2_n_4,tmp_s_fu_88_p2_carry__1_i_3_n_4,tmp_s_fu_88_p2_carry__1_i_4_n_4}),
        .O(NLW_tmp_s_fu_88_p2_carry__1_O_UNCONNECTED[3:0]),
        .S({tmp_s_fu_88_p2_carry__1_i_5_n_4,tmp_s_fu_88_p2_carry__1_i_6_n_4,tmp_s_fu_88_p2_carry__1_i_7_n_4,tmp_s_fu_88_p2_carry__1_i_8_n_4}));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_88_p2_carry__1_i_1
       (.I0(fc1_bias_Dout_A[22]),
        .I1(fc1_bias_Dout_A[23]),
        .O(tmp_s_fu_88_p2_carry__1_i_1_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_88_p2_carry__1_i_2
       (.I0(fc1_bias_Dout_A[20]),
        .I1(fc1_bias_Dout_A[21]),
        .O(tmp_s_fu_88_p2_carry__1_i_2_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_88_p2_carry__1_i_3
       (.I0(fc1_bias_Dout_A[18]),
        .I1(fc1_bias_Dout_A[19]),
        .O(tmp_s_fu_88_p2_carry__1_i_3_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_88_p2_carry__1_i_4
       (.I0(fc1_bias_Dout_A[16]),
        .I1(fc1_bias_Dout_A[17]),
        .O(tmp_s_fu_88_p2_carry__1_i_4_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_88_p2_carry__1_i_5
       (.I0(fc1_bias_Dout_A[22]),
        .I1(fc1_bias_Dout_A[23]),
        .O(tmp_s_fu_88_p2_carry__1_i_5_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_88_p2_carry__1_i_6
       (.I0(fc1_bias_Dout_A[20]),
        .I1(fc1_bias_Dout_A[21]),
        .O(tmp_s_fu_88_p2_carry__1_i_6_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_88_p2_carry__1_i_7
       (.I0(fc1_bias_Dout_A[18]),
        .I1(fc1_bias_Dout_A[19]),
        .O(tmp_s_fu_88_p2_carry__1_i_7_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_88_p2_carry__1_i_8
       (.I0(fc1_bias_Dout_A[16]),
        .I1(fc1_bias_Dout_A[17]),
        .O(tmp_s_fu_88_p2_carry__1_i_8_n_4));
  CARRY4 tmp_s_fu_88_p2_carry__2
       (.CI(tmp_s_fu_88_p2_carry__1_n_4),
        .CO({tmp_s_fu_88_p2_carry__2_n_4,tmp_s_fu_88_p2_carry__2_n_5,tmp_s_fu_88_p2_carry__2_n_6,tmp_s_fu_88_p2_carry__2_n_7}),
        .CYINIT(1'b0),
        .DI({tmp_s_fu_88_p2_carry__2_i_1_n_4,tmp_s_fu_88_p2_carry__2_i_2_n_4,tmp_s_fu_88_p2_carry__2_i_3_n_4,tmp_s_fu_88_p2_carry__2_i_4_n_4}),
        .O(NLW_tmp_s_fu_88_p2_carry__2_O_UNCONNECTED[3:0]),
        .S({tmp_s_fu_88_p2_carry__2_i_5_n_4,tmp_s_fu_88_p2_carry__2_i_6_n_4,tmp_s_fu_88_p2_carry__2_i_7_n_4,tmp_s_fu_88_p2_carry__2_i_8_n_4}));
  LUT2 #(
    .INIT(4'h2)) 
    tmp_s_fu_88_p2_carry__2_i_1
       (.I0(fc1_bias_Dout_A[30]),
        .I1(fc1_bias_Dout_A[31]),
        .O(tmp_s_fu_88_p2_carry__2_i_1_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_88_p2_carry__2_i_2
       (.I0(fc1_bias_Dout_A[28]),
        .I1(fc1_bias_Dout_A[29]),
        .O(tmp_s_fu_88_p2_carry__2_i_2_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_88_p2_carry__2_i_3
       (.I0(fc1_bias_Dout_A[26]),
        .I1(fc1_bias_Dout_A[27]),
        .O(tmp_s_fu_88_p2_carry__2_i_3_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_88_p2_carry__2_i_4
       (.I0(fc1_bias_Dout_A[24]),
        .I1(fc1_bias_Dout_A[25]),
        .O(tmp_s_fu_88_p2_carry__2_i_4_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_88_p2_carry__2_i_5
       (.I0(fc1_bias_Dout_A[30]),
        .I1(fc1_bias_Dout_A[31]),
        .O(tmp_s_fu_88_p2_carry__2_i_5_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_88_p2_carry__2_i_6
       (.I0(fc1_bias_Dout_A[28]),
        .I1(fc1_bias_Dout_A[29]),
        .O(tmp_s_fu_88_p2_carry__2_i_6_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_88_p2_carry__2_i_7
       (.I0(fc1_bias_Dout_A[26]),
        .I1(fc1_bias_Dout_A[27]),
        .O(tmp_s_fu_88_p2_carry__2_i_7_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_88_p2_carry__2_i_8
       (.I0(fc1_bias_Dout_A[24]),
        .I1(fc1_bias_Dout_A[25]),
        .O(tmp_s_fu_88_p2_carry__2_i_8_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_88_p2_carry_i_1
       (.I0(fc1_bias_Dout_A[6]),
        .I1(fc1_bias_Dout_A[7]),
        .O(tmp_s_fu_88_p2_carry_i_1_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_88_p2_carry_i_2
       (.I0(fc1_bias_Dout_A[4]),
        .I1(fc1_bias_Dout_A[5]),
        .O(tmp_s_fu_88_p2_carry_i_2_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_88_p2_carry_i_3
       (.I0(fc1_bias_Dout_A[2]),
        .I1(fc1_bias_Dout_A[3]),
        .O(tmp_s_fu_88_p2_carry_i_3_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_88_p2_carry_i_4
       (.I0(fc1_bias_Dout_A[0]),
        .I1(fc1_bias_Dout_A[1]),
        .O(tmp_s_fu_88_p2_carry_i_4_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_88_p2_carry_i_5
       (.I0(fc1_bias_Dout_A[6]),
        .I1(fc1_bias_Dout_A[7]),
        .O(tmp_s_fu_88_p2_carry_i_5_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_88_p2_carry_i_6
       (.I0(fc1_bias_Dout_A[4]),
        .I1(fc1_bias_Dout_A[5]),
        .O(tmp_s_fu_88_p2_carry_i_6_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_88_p2_carry_i_7
       (.I0(fc1_bias_Dout_A[2]),
        .I1(fc1_bias_Dout_A[3]),
        .O(tmp_s_fu_88_p2_carry_i_7_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_88_p2_carry_i_8
       (.I0(fc1_bias_Dout_A[0]),
        .I1(fc1_bias_Dout_A[1]),
        .O(tmp_s_fu_88_p2_carry_i_8_n_4));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Fc2_400_10
   (D,
    ap_done,
    \output_r_WEN_A[0] ,
    output_r_EN_A,
    \i_3_reg_284_reg[8]_0 ,
    \fc2_bias_Addr_A[5] ,
    output_r_Din_A,
    fc2_kernel_Addr_A,
    grp_Fc2_400_10_fu_92_ap_start_reg_reg,
    output_r_Addr_A,
    ap_clk,
    fc1_output_q0,
    fc2_kernel_Dout_A,
    Q,
    ap_start,
    grp_Fc2_400_10_fu_92_ap_start_reg,
    \ap_CS_fsm_reg[0]_0 ,
    fc2_bias_Dout_A,
    ap_rst_n);
  output [1:0]D;
  output ap_done;
  output \output_r_WEN_A[0] ;
  output [1:0]output_r_EN_A;
  output [8:0]\i_3_reg_284_reg[8]_0 ;
  output [3:0]\fc2_bias_Addr_A[5] ;
  output [30:0]output_r_Din_A;
  output [11:0]fc2_kernel_Addr_A;
  output grp_Fc2_400_10_fu_92_ap_start_reg_reg;
  output [3:0]output_r_Addr_A;
  input ap_clk;
  input [30:0]fc1_output_q0;
  input [31:0]fc2_kernel_Dout_A;
  input [2:0]Q;
  input ap_start;
  input grp_Fc2_400_10_fu_92_ap_start_reg;
  input \ap_CS_fsm_reg[0]_0 ;
  input [31:0]fc2_bias_Dout_A;
  input ap_rst_n;

  wire [1:0]D;
  wire [2:0]Q;
  wire [45:16]\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 ;
  wire \ap_CS_fsm[0]_i_2_n_4 ;
  wire \ap_CS_fsm_reg[0]_0 ;
  wire \ap_CS_fsm_reg_n_4_[0] ;
  wire \ap_CS_fsm_reg_n_4_[5] ;
  wire ap_CS_fsm_state3;
  wire ap_CS_fsm_state5;
  wire ap_CS_fsm_state7;
  wire ap_CS_fsm_state8;
  wire [4:0]ap_NS_fsm;
  wire ap_clk;
  wire ap_done;
  wire ap_rst_n;
  wire ap_start;
  wire [30:0]fc1_output_q0;
  wire [3:0]\fc2_bias_Addr_A[5] ;
  wire [31:0]fc2_bias_Dout_A;
  wire [11:0]fc2_kernel_Addr_A;
  wire \fc2_kernel_Addr_A[10]_INST_0_i_1_n_4 ;
  wire \fc2_kernel_Addr_A[10]_INST_0_n_5 ;
  wire \fc2_kernel_Addr_A[10]_INST_0_n_6 ;
  wire \fc2_kernel_Addr_A[10]_INST_0_n_7 ;
  wire \fc2_kernel_Addr_A[2]_INST_0_i_1_n_4 ;
  wire \fc2_kernel_Addr_A[2]_INST_0_i_2_n_4 ;
  wire \fc2_kernel_Addr_A[2]_INST_0_i_3_n_4 ;
  wire \fc2_kernel_Addr_A[2]_INST_0_i_4_n_4 ;
  wire \fc2_kernel_Addr_A[2]_INST_0_n_4 ;
  wire \fc2_kernel_Addr_A[2]_INST_0_n_5 ;
  wire \fc2_kernel_Addr_A[2]_INST_0_n_6 ;
  wire \fc2_kernel_Addr_A[2]_INST_0_n_7 ;
  wire \fc2_kernel_Addr_A[6]_INST_0_i_1_n_4 ;
  wire \fc2_kernel_Addr_A[6]_INST_0_i_2_n_4 ;
  wire \fc2_kernel_Addr_A[6]_INST_0_i_3_n_4 ;
  wire \fc2_kernel_Addr_A[6]_INST_0_i_4_n_4 ;
  wire \fc2_kernel_Addr_A[6]_INST_0_n_4 ;
  wire \fc2_kernel_Addr_A[6]_INST_0_n_5 ;
  wire \fc2_kernel_Addr_A[6]_INST_0_n_6 ;
  wire \fc2_kernel_Addr_A[6]_INST_0_n_7 ;
  wire [31:0]fc2_kernel_Dout_A;
  wire grp_Fc2_400_10_fu_92_ap_ready;
  wire grp_Fc2_400_10_fu_92_ap_start_reg;
  wire grp_Fc2_400_10_fu_92_ap_start_reg_reg;
  wire [8:0]i_3_fu_177_p2;
  wire [8:0]i_3_reg_284;
  wire \i_3_reg_284[8]_i_2_n_4 ;
  wire [8:0]\i_3_reg_284_reg[8]_0 ;
  wire i_reg_137;
  wire [3:0]k_1_fu_160_p2;
  wire [3:0]k_1_reg_261;
  wire k_reg_104;
  wire lenet_cnn_mul_31ncud_U34_n_34;
  wire lenet_cnn_mul_31ncud_U34_n_35;
  wire [11:3]next_mul_fu_148_p2;
  wire next_mul_fu_148_p2_carry__0_i_1_n_4;
  wire next_mul_fu_148_p2_carry__0_i_2_n_4;
  wire next_mul_fu_148_p2_carry__0_n_4;
  wire next_mul_fu_148_p2_carry__0_n_5;
  wire next_mul_fu_148_p2_carry__0_n_6;
  wire next_mul_fu_148_p2_carry__0_n_7;
  wire next_mul_fu_148_p2_carry_i_1_n_4;
  wire next_mul_fu_148_p2_carry_n_4;
  wire next_mul_fu_148_p2_carry_n_5;
  wire next_mul_fu_148_p2_carry_n_6;
  wire next_mul_fu_148_p2_carry_n_7;
  wire [11:3]next_mul_reg_253;
  wire [3:0]output_r_Addr_A;
  wire [30:0]output_r_Din_A;
  wire [1:0]output_r_EN_A;
  wire \output_r_WEN_A[0] ;
  wire \output_r_WEN_A[0]_INST_0_i_1_n_4 ;
  wire [11:3]phi_mul_reg_115;
  wire \sum1_reg_127[0]_i_2_n_4 ;
  wire \sum1_reg_127[0]_i_3_n_4 ;
  wire \sum1_reg_127[0]_i_4_n_4 ;
  wire \sum1_reg_127[0]_i_5_n_4 ;
  wire \sum1_reg_127[0]_i_6_n_4 ;
  wire \sum1_reg_127[0]_i_7_n_4 ;
  wire \sum1_reg_127[0]_i_8_n_4 ;
  wire \sum1_reg_127[0]_i_9_n_4 ;
  wire \sum1_reg_127[12]_i_2_n_4 ;
  wire \sum1_reg_127[12]_i_3_n_4 ;
  wire \sum1_reg_127[12]_i_4_n_4 ;
  wire \sum1_reg_127[12]_i_5_n_4 ;
  wire \sum1_reg_127[12]_i_6_n_4 ;
  wire \sum1_reg_127[12]_i_7_n_4 ;
  wire \sum1_reg_127[12]_i_8_n_4 ;
  wire \sum1_reg_127[12]_i_9_n_4 ;
  wire \sum1_reg_127[16]_i_2_n_4 ;
  wire \sum1_reg_127[16]_i_3_n_4 ;
  wire \sum1_reg_127[16]_i_4_n_4 ;
  wire \sum1_reg_127[16]_i_5_n_4 ;
  wire \sum1_reg_127[16]_i_6_n_4 ;
  wire \sum1_reg_127[16]_i_7_n_4 ;
  wire \sum1_reg_127[16]_i_8_n_4 ;
  wire \sum1_reg_127[16]_i_9_n_4 ;
  wire \sum1_reg_127[20]_i_2_n_4 ;
  wire \sum1_reg_127[20]_i_3_n_4 ;
  wire \sum1_reg_127[20]_i_4_n_4 ;
  wire \sum1_reg_127[20]_i_5_n_4 ;
  wire \sum1_reg_127[20]_i_6_n_4 ;
  wire \sum1_reg_127[20]_i_7_n_4 ;
  wire \sum1_reg_127[20]_i_8_n_4 ;
  wire \sum1_reg_127[20]_i_9_n_4 ;
  wire \sum1_reg_127[24]_i_2_n_4 ;
  wire \sum1_reg_127[24]_i_3_n_4 ;
  wire \sum1_reg_127[24]_i_4_n_4 ;
  wire \sum1_reg_127[24]_i_5_n_4 ;
  wire \sum1_reg_127[24]_i_6_n_4 ;
  wire \sum1_reg_127[24]_i_7_n_4 ;
  wire \sum1_reg_127[24]_i_8_n_4 ;
  wire \sum1_reg_127[24]_i_9_n_4 ;
  wire \sum1_reg_127[28]_i_2_n_4 ;
  wire \sum1_reg_127[28]_i_3_n_4 ;
  wire \sum1_reg_127[28]_i_4_n_4 ;
  wire \sum1_reg_127[28]_i_5_n_4 ;
  wire \sum1_reg_127[28]_i_6_n_4 ;
  wire \sum1_reg_127[28]_i_7_n_4 ;
  wire \sum1_reg_127[28]_i_8_n_4 ;
  wire \sum1_reg_127[4]_i_2_n_4 ;
  wire \sum1_reg_127[4]_i_3_n_4 ;
  wire \sum1_reg_127[4]_i_4_n_4 ;
  wire \sum1_reg_127[4]_i_5_n_4 ;
  wire \sum1_reg_127[4]_i_6_n_4 ;
  wire \sum1_reg_127[4]_i_7_n_4 ;
  wire \sum1_reg_127[4]_i_8_n_4 ;
  wire \sum1_reg_127[4]_i_9_n_4 ;
  wire \sum1_reg_127[8]_i_2_n_4 ;
  wire \sum1_reg_127[8]_i_3_n_4 ;
  wire \sum1_reg_127[8]_i_4_n_4 ;
  wire \sum1_reg_127[8]_i_5_n_4 ;
  wire \sum1_reg_127[8]_i_6_n_4 ;
  wire \sum1_reg_127[8]_i_7_n_4 ;
  wire \sum1_reg_127[8]_i_8_n_4 ;
  wire \sum1_reg_127[8]_i_9_n_4 ;
  wire [31:0]sum1_reg_127_reg;
  wire \sum1_reg_127_reg[0]_i_1_n_10 ;
  wire \sum1_reg_127_reg[0]_i_1_n_11 ;
  wire \sum1_reg_127_reg[0]_i_1_n_4 ;
  wire \sum1_reg_127_reg[0]_i_1_n_5 ;
  wire \sum1_reg_127_reg[0]_i_1_n_6 ;
  wire \sum1_reg_127_reg[0]_i_1_n_7 ;
  wire \sum1_reg_127_reg[0]_i_1_n_8 ;
  wire \sum1_reg_127_reg[0]_i_1_n_9 ;
  wire \sum1_reg_127_reg[12]_i_1_n_10 ;
  wire \sum1_reg_127_reg[12]_i_1_n_11 ;
  wire \sum1_reg_127_reg[12]_i_1_n_4 ;
  wire \sum1_reg_127_reg[12]_i_1_n_5 ;
  wire \sum1_reg_127_reg[12]_i_1_n_6 ;
  wire \sum1_reg_127_reg[12]_i_1_n_7 ;
  wire \sum1_reg_127_reg[12]_i_1_n_8 ;
  wire \sum1_reg_127_reg[12]_i_1_n_9 ;
  wire \sum1_reg_127_reg[16]_i_1_n_10 ;
  wire \sum1_reg_127_reg[16]_i_1_n_11 ;
  wire \sum1_reg_127_reg[16]_i_1_n_4 ;
  wire \sum1_reg_127_reg[16]_i_1_n_5 ;
  wire \sum1_reg_127_reg[16]_i_1_n_6 ;
  wire \sum1_reg_127_reg[16]_i_1_n_7 ;
  wire \sum1_reg_127_reg[16]_i_1_n_8 ;
  wire \sum1_reg_127_reg[16]_i_1_n_9 ;
  wire \sum1_reg_127_reg[20]_i_1_n_10 ;
  wire \sum1_reg_127_reg[20]_i_1_n_11 ;
  wire \sum1_reg_127_reg[20]_i_1_n_4 ;
  wire \sum1_reg_127_reg[20]_i_1_n_5 ;
  wire \sum1_reg_127_reg[20]_i_1_n_6 ;
  wire \sum1_reg_127_reg[20]_i_1_n_7 ;
  wire \sum1_reg_127_reg[20]_i_1_n_8 ;
  wire \sum1_reg_127_reg[20]_i_1_n_9 ;
  wire \sum1_reg_127_reg[24]_i_1_n_10 ;
  wire \sum1_reg_127_reg[24]_i_1_n_11 ;
  wire \sum1_reg_127_reg[24]_i_1_n_4 ;
  wire \sum1_reg_127_reg[24]_i_1_n_5 ;
  wire \sum1_reg_127_reg[24]_i_1_n_6 ;
  wire \sum1_reg_127_reg[24]_i_1_n_7 ;
  wire \sum1_reg_127_reg[24]_i_1_n_8 ;
  wire \sum1_reg_127_reg[24]_i_1_n_9 ;
  wire \sum1_reg_127_reg[28]_i_1_n_10 ;
  wire \sum1_reg_127_reg[28]_i_1_n_11 ;
  wire \sum1_reg_127_reg[28]_i_1_n_5 ;
  wire \sum1_reg_127_reg[28]_i_1_n_6 ;
  wire \sum1_reg_127_reg[28]_i_1_n_7 ;
  wire \sum1_reg_127_reg[28]_i_1_n_8 ;
  wire \sum1_reg_127_reg[28]_i_1_n_9 ;
  wire \sum1_reg_127_reg[4]_i_1_n_10 ;
  wire \sum1_reg_127_reg[4]_i_1_n_11 ;
  wire \sum1_reg_127_reg[4]_i_1_n_4 ;
  wire \sum1_reg_127_reg[4]_i_1_n_5 ;
  wire \sum1_reg_127_reg[4]_i_1_n_6 ;
  wire \sum1_reg_127_reg[4]_i_1_n_7 ;
  wire \sum1_reg_127_reg[4]_i_1_n_8 ;
  wire \sum1_reg_127_reg[4]_i_1_n_9 ;
  wire \sum1_reg_127_reg[8]_i_1_n_10 ;
  wire \sum1_reg_127_reg[8]_i_1_n_11 ;
  wire \sum1_reg_127_reg[8]_i_1_n_4 ;
  wire \sum1_reg_127_reg[8]_i_1_n_5 ;
  wire \sum1_reg_127_reg[8]_i_1_n_6 ;
  wire \sum1_reg_127_reg[8]_i_1_n_7 ;
  wire \sum1_reg_127_reg[8]_i_1_n_8 ;
  wire \sum1_reg_127_reg[8]_i_1_n_9 ;
  wire [31:0]tmp_3_i_reg_319;
  wire tmp_reg_266_reg0;
  wire tmp_s_fu_207_p2_carry__0_i_1_n_4;
  wire tmp_s_fu_207_p2_carry__0_i_2_n_4;
  wire tmp_s_fu_207_p2_carry__0_i_3_n_4;
  wire tmp_s_fu_207_p2_carry__0_i_4_n_4;
  wire tmp_s_fu_207_p2_carry__0_i_5_n_4;
  wire tmp_s_fu_207_p2_carry__0_i_6_n_4;
  wire tmp_s_fu_207_p2_carry__0_i_7_n_4;
  wire tmp_s_fu_207_p2_carry__0_i_8_n_4;
  wire tmp_s_fu_207_p2_carry__0_n_4;
  wire tmp_s_fu_207_p2_carry__0_n_5;
  wire tmp_s_fu_207_p2_carry__0_n_6;
  wire tmp_s_fu_207_p2_carry__0_n_7;
  wire tmp_s_fu_207_p2_carry__1_i_1_n_4;
  wire tmp_s_fu_207_p2_carry__1_i_2_n_4;
  wire tmp_s_fu_207_p2_carry__1_i_3_n_4;
  wire tmp_s_fu_207_p2_carry__1_i_4_n_4;
  wire tmp_s_fu_207_p2_carry__1_i_5_n_4;
  wire tmp_s_fu_207_p2_carry__1_i_6_n_4;
  wire tmp_s_fu_207_p2_carry__1_i_7_n_4;
  wire tmp_s_fu_207_p2_carry__1_i_8_n_4;
  wire tmp_s_fu_207_p2_carry__1_n_4;
  wire tmp_s_fu_207_p2_carry__1_n_5;
  wire tmp_s_fu_207_p2_carry__1_n_6;
  wire tmp_s_fu_207_p2_carry__1_n_7;
  wire tmp_s_fu_207_p2_carry__2_i_1_n_4;
  wire tmp_s_fu_207_p2_carry__2_i_2_n_4;
  wire tmp_s_fu_207_p2_carry__2_i_3_n_4;
  wire tmp_s_fu_207_p2_carry__2_i_4_n_4;
  wire tmp_s_fu_207_p2_carry__2_i_5_n_4;
  wire tmp_s_fu_207_p2_carry__2_i_6_n_4;
  wire tmp_s_fu_207_p2_carry__2_n_5;
  wire tmp_s_fu_207_p2_carry__2_n_6;
  wire tmp_s_fu_207_p2_carry__2_n_7;
  wire tmp_s_fu_207_p2_carry_i_1_n_4;
  wire tmp_s_fu_207_p2_carry_i_2_n_4;
  wire tmp_s_fu_207_p2_carry_i_3_n_4;
  wire tmp_s_fu_207_p2_carry_i_4_n_4;
  wire tmp_s_fu_207_p2_carry_i_5_n_4;
  wire tmp_s_fu_207_p2_carry_i_6_n_4;
  wire tmp_s_fu_207_p2_carry_i_7_n_4;
  wire tmp_s_fu_207_p2_carry_i_8_n_4;
  wire tmp_s_fu_207_p2_carry_i_9_n_4;
  wire tmp_s_fu_207_p2_carry_n_4;
  wire tmp_s_fu_207_p2_carry_n_5;
  wire tmp_s_fu_207_p2_carry_n_6;
  wire tmp_s_fu_207_p2_carry_n_7;
  wire [3:3]\NLW_fc2_kernel_Addr_A[10]_INST_0_CO_UNCONNECTED ;
  wire [3:0]NLW_next_mul_fu_148_p2_carry__1_CO_UNCONNECTED;
  wire [3:1]NLW_next_mul_fu_148_p2_carry__1_O_UNCONNECTED;
  wire [3:3]\NLW_sum1_reg_127_reg[28]_i_1_CO_UNCONNECTED ;
  wire [3:0]NLW_tmp_s_fu_207_p2_carry_O_UNCONNECTED;
  wire [3:0]NLW_tmp_s_fu_207_p2_carry__0_O_UNCONNECTED;
  wire [3:0]NLW_tmp_s_fu_207_p2_carry__1_O_UNCONNECTED;
  wire [3:3]NLW_tmp_s_fu_207_p2_carry__2_CO_UNCONNECTED;
  wire [3:0]NLW_tmp_s_fu_207_p2_carry__2_O_UNCONNECTED;

  (* SOFT_HLUTNM = "soft_lutpair106" *) 
  LUT4 #(
    .INIT(16'h88F8)) 
    \ap_CS_fsm[0]_i_1__1 
       (.I0(ap_done),
        .I1(Q[2]),
        .I2(Q[0]),
        .I3(ap_start),
        .O(D[0]));
  LUT6 #(
    .INIT(64'h55005500550055C0)) 
    \ap_CS_fsm[0]_i_1__2 
       (.I0(grp_Fc2_400_10_fu_92_ap_start_reg),
        .I1(grp_Fc2_400_10_fu_92_ap_ready),
        .I2(\ap_CS_fsm[0]_i_2_n_4 ),
        .I3(\ap_CS_fsm_reg_n_4_[0] ),
        .I4(ap_CS_fsm_state3),
        .I5(output_r_EN_A[1]),
        .O(ap_NS_fsm[0]));
  LUT4 #(
    .INIT(16'h0001)) 
    \ap_CS_fsm[0]_i_2 
       (.I0(ap_CS_fsm_state8),
        .I1(ap_CS_fsm_state7),
        .I2(\ap_CS_fsm_reg_n_4_[5] ),
        .I3(ap_CS_fsm_state5),
        .O(\ap_CS_fsm[0]_i_2_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair108" *) 
  LUT4 #(
    .INIT(16'hAAC0)) 
    \ap_CS_fsm[1]_i_1__2 
       (.I0(grp_Fc2_400_10_fu_92_ap_start_reg),
        .I1(\output_r_WEN_A[0] ),
        .I2(output_r_EN_A[1]),
        .I3(\ap_CS_fsm_reg_n_4_[0] ),
        .O(ap_NS_fsm[1]));
  (* SOFT_HLUTNM = "soft_lutpair104" *) 
  LUT5 #(
    .INIT(32'hAA8AAAAA)) 
    \ap_CS_fsm[2]_i_1__0 
       (.I0(output_r_EN_A[0]),
        .I1(\fc2_bias_Addr_A[5] [0]),
        .I2(\fc2_bias_Addr_A[5] [1]),
        .I3(\fc2_bias_Addr_A[5] [2]),
        .I4(\fc2_bias_Addr_A[5] [3]),
        .O(ap_NS_fsm[2]));
  (* SOFT_HLUTNM = "soft_lutpair106" *) 
  LUT3 #(
    .INIT(8'hF4)) 
    \ap_CS_fsm[3]_i_1__0 
       (.I0(ap_done),
        .I1(Q[2]),
        .I2(Q[1]),
        .O(D[1]));
  LUT2 #(
    .INIT(4'hE)) 
    \ap_CS_fsm[3]_i_1__2 
       (.I0(ap_CS_fsm_state8),
        .I1(ap_CS_fsm_state3),
        .O(ap_NS_fsm[3]));
  (* SOFT_HLUTNM = "soft_lutpair108" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \ap_CS_fsm[4]_i_1 
       (.I0(output_r_EN_A[1]),
        .I1(\output_r_WEN_A[0] ),
        .O(ap_NS_fsm[4]));
  (* FSM_ENCODING = "none" *) 
  FDSE #(
    .INIT(1'b1)) 
    \ap_CS_fsm_reg[0] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[0]),
        .Q(\ap_CS_fsm_reg_n_4_[0] ),
        .S(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[1] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[1]),
        .Q(output_r_EN_A[0]),
        .R(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[2] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[2]),
        .Q(ap_CS_fsm_state3),
        .R(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[3] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[3]),
        .Q(output_r_EN_A[1]),
        .R(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[4] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[4]),
        .Q(ap_CS_fsm_state5),
        .R(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[5] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_state5),
        .Q(\ap_CS_fsm_reg_n_4_[5] ),
        .R(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[6] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\ap_CS_fsm_reg_n_4_[5] ),
        .Q(ap_CS_fsm_state7),
        .R(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[7] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_state7),
        .Q(ap_CS_fsm_state8),
        .R(ap_rst_n));
  LUT5 #(
    .INIT(32'h0000AA20)) 
    ap_ready_INST_0
       (.I0(Q[2]),
        .I1(grp_Fc2_400_10_fu_92_ap_start_reg),
        .I2(\ap_CS_fsm_reg_n_4_[0] ),
        .I3(grp_Fc2_400_10_fu_92_ap_ready),
        .I4(\ap_CS_fsm_reg[0]_0 ),
        .O(ap_done));
  (* SOFT_HLUTNM = "soft_lutpair104" *) 
  LUT5 #(
    .INIT(32'h00200000)) 
    ap_ready_INST_0_i_1
       (.I0(\fc2_bias_Addr_A[5] [3]),
        .I1(\fc2_bias_Addr_A[5] [2]),
        .I2(\fc2_bias_Addr_A[5] [1]),
        .I3(\fc2_bias_Addr_A[5] [0]),
        .I4(output_r_EN_A[0]),
        .O(grp_Fc2_400_10_fu_92_ap_ready));
  CARRY4 \fc2_kernel_Addr_A[10]_INST_0 
       (.CI(\fc2_kernel_Addr_A[6]_INST_0_n_4 ),
        .CO({\NLW_fc2_kernel_Addr_A[10]_INST_0_CO_UNCONNECTED [3],\fc2_kernel_Addr_A[10]_INST_0_n_5 ,\fc2_kernel_Addr_A[10]_INST_0_n_6 ,\fc2_kernel_Addr_A[10]_INST_0_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,phi_mul_reg_115[8]}),
        .O(fc2_kernel_Addr_A[11:8]),
        .S({phi_mul_reg_115[11:9],\fc2_kernel_Addr_A[10]_INST_0_i_1_n_4 }));
  LUT2 #(
    .INIT(4'h6)) 
    \fc2_kernel_Addr_A[10]_INST_0_i_1 
       (.I0(phi_mul_reg_115[8]),
        .I1(\i_3_reg_284_reg[8]_0 [8]),
        .O(\fc2_kernel_Addr_A[10]_INST_0_i_1_n_4 ));
  CARRY4 \fc2_kernel_Addr_A[2]_INST_0 
       (.CI(1'b0),
        .CO({\fc2_kernel_Addr_A[2]_INST_0_n_4 ,\fc2_kernel_Addr_A[2]_INST_0_n_5 ,\fc2_kernel_Addr_A[2]_INST_0_n_6 ,\fc2_kernel_Addr_A[2]_INST_0_n_7 }),
        .CYINIT(1'b0),
        .DI({phi_mul_reg_115[3],1'b0,1'b0,1'b0}),
        .O(fc2_kernel_Addr_A[3:0]),
        .S({\fc2_kernel_Addr_A[2]_INST_0_i_1_n_4 ,\fc2_kernel_Addr_A[2]_INST_0_i_2_n_4 ,\fc2_kernel_Addr_A[2]_INST_0_i_3_n_4 ,\fc2_kernel_Addr_A[2]_INST_0_i_4_n_4 }));
  LUT2 #(
    .INIT(4'h6)) 
    \fc2_kernel_Addr_A[2]_INST_0_i_1 
       (.I0(phi_mul_reg_115[3]),
        .I1(\i_3_reg_284_reg[8]_0 [3]),
        .O(\fc2_kernel_Addr_A[2]_INST_0_i_1_n_4 ));
  LUT1 #(
    .INIT(2'h2)) 
    \fc2_kernel_Addr_A[2]_INST_0_i_2 
       (.I0(\i_3_reg_284_reg[8]_0 [2]),
        .O(\fc2_kernel_Addr_A[2]_INST_0_i_2_n_4 ));
  LUT1 #(
    .INIT(2'h2)) 
    \fc2_kernel_Addr_A[2]_INST_0_i_3 
       (.I0(\i_3_reg_284_reg[8]_0 [1]),
        .O(\fc2_kernel_Addr_A[2]_INST_0_i_3_n_4 ));
  LUT1 #(
    .INIT(2'h2)) 
    \fc2_kernel_Addr_A[2]_INST_0_i_4 
       (.I0(\i_3_reg_284_reg[8]_0 [0]),
        .O(\fc2_kernel_Addr_A[2]_INST_0_i_4_n_4 ));
  CARRY4 \fc2_kernel_Addr_A[6]_INST_0 
       (.CI(\fc2_kernel_Addr_A[2]_INST_0_n_4 ),
        .CO({\fc2_kernel_Addr_A[6]_INST_0_n_4 ,\fc2_kernel_Addr_A[6]_INST_0_n_5 ,\fc2_kernel_Addr_A[6]_INST_0_n_6 ,\fc2_kernel_Addr_A[6]_INST_0_n_7 }),
        .CYINIT(1'b0),
        .DI(phi_mul_reg_115[7:4]),
        .O(fc2_kernel_Addr_A[7:4]),
        .S({\fc2_kernel_Addr_A[6]_INST_0_i_1_n_4 ,\fc2_kernel_Addr_A[6]_INST_0_i_2_n_4 ,\fc2_kernel_Addr_A[6]_INST_0_i_3_n_4 ,\fc2_kernel_Addr_A[6]_INST_0_i_4_n_4 }));
  LUT2 #(
    .INIT(4'h6)) 
    \fc2_kernel_Addr_A[6]_INST_0_i_1 
       (.I0(phi_mul_reg_115[7]),
        .I1(\i_3_reg_284_reg[8]_0 [7]),
        .O(\fc2_kernel_Addr_A[6]_INST_0_i_1_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \fc2_kernel_Addr_A[6]_INST_0_i_2 
       (.I0(phi_mul_reg_115[6]),
        .I1(\i_3_reg_284_reg[8]_0 [6]),
        .O(\fc2_kernel_Addr_A[6]_INST_0_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \fc2_kernel_Addr_A[6]_INST_0_i_3 
       (.I0(phi_mul_reg_115[5]),
        .I1(\i_3_reg_284_reg[8]_0 [5]),
        .O(\fc2_kernel_Addr_A[6]_INST_0_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \fc2_kernel_Addr_A[6]_INST_0_i_4 
       (.I0(phi_mul_reg_115[4]),
        .I1(\i_3_reg_284_reg[8]_0 [4]),
        .O(\fc2_kernel_Addr_A[6]_INST_0_i_4_n_4 ));
  LUT3 #(
    .INIT(8'hBA)) 
    grp_Fc2_400_10_fu_92_ap_start_reg_i_1
       (.I0(Q[1]),
        .I1(grp_Fc2_400_10_fu_92_ap_ready),
        .I2(grp_Fc2_400_10_fu_92_ap_start_reg),
        .O(grp_Fc2_400_10_fu_92_ap_start_reg_reg));
  LUT1 #(
    .INIT(2'h1)) 
    \i_3_reg_284[0]_i_1 
       (.I0(\i_3_reg_284_reg[8]_0 [0]),
        .O(i_3_fu_177_p2[0]));
  (* SOFT_HLUTNM = "soft_lutpair109" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \i_3_reg_284[1]_i_1 
       (.I0(\i_3_reg_284_reg[8]_0 [0]),
        .I1(\i_3_reg_284_reg[8]_0 [1]),
        .O(i_3_fu_177_p2[1]));
  (* SOFT_HLUTNM = "soft_lutpair109" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \i_3_reg_284[2]_i_1 
       (.I0(\i_3_reg_284_reg[8]_0 [0]),
        .I1(\i_3_reg_284_reg[8]_0 [1]),
        .I2(\i_3_reg_284_reg[8]_0 [2]),
        .O(i_3_fu_177_p2[2]));
  (* SOFT_HLUTNM = "soft_lutpair103" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \i_3_reg_284[3]_i_1 
       (.I0(\i_3_reg_284_reg[8]_0 [1]),
        .I1(\i_3_reg_284_reg[8]_0 [0]),
        .I2(\i_3_reg_284_reg[8]_0 [2]),
        .I3(\i_3_reg_284_reg[8]_0 [3]),
        .O(i_3_fu_177_p2[3]));
  (* SOFT_HLUTNM = "soft_lutpair103" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \i_3_reg_284[4]_i_1 
       (.I0(\i_3_reg_284_reg[8]_0 [2]),
        .I1(\i_3_reg_284_reg[8]_0 [0]),
        .I2(\i_3_reg_284_reg[8]_0 [1]),
        .I3(\i_3_reg_284_reg[8]_0 [3]),
        .I4(\i_3_reg_284_reg[8]_0 [4]),
        .O(i_3_fu_177_p2[4]));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \i_3_reg_284[5]_i_1 
       (.I0(\i_3_reg_284_reg[8]_0 [3]),
        .I1(\i_3_reg_284_reg[8]_0 [1]),
        .I2(\i_3_reg_284_reg[8]_0 [0]),
        .I3(\i_3_reg_284_reg[8]_0 [2]),
        .I4(\i_3_reg_284_reg[8]_0 [4]),
        .I5(\i_3_reg_284_reg[8]_0 [5]),
        .O(i_3_fu_177_p2[5]));
  LUT2 #(
    .INIT(4'h6)) 
    \i_3_reg_284[6]_i_1 
       (.I0(\i_3_reg_284[8]_i_2_n_4 ),
        .I1(\i_3_reg_284_reg[8]_0 [6]),
        .O(i_3_fu_177_p2[6]));
  (* SOFT_HLUTNM = "soft_lutpair105" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \i_3_reg_284[7]_i_1 
       (.I0(\i_3_reg_284[8]_i_2_n_4 ),
        .I1(\i_3_reg_284_reg[8]_0 [6]),
        .I2(\i_3_reg_284_reg[8]_0 [7]),
        .O(i_3_fu_177_p2[7]));
  (* SOFT_HLUTNM = "soft_lutpair105" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \i_3_reg_284[8]_i_1 
       (.I0(\i_3_reg_284_reg[8]_0 [6]),
        .I1(\i_3_reg_284[8]_i_2_n_4 ),
        .I2(\i_3_reg_284_reg[8]_0 [7]),
        .I3(\i_3_reg_284_reg[8]_0 [8]),
        .O(i_3_fu_177_p2[8]));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \i_3_reg_284[8]_i_2 
       (.I0(\i_3_reg_284_reg[8]_0 [5]),
        .I1(\i_3_reg_284_reg[8]_0 [3]),
        .I2(\i_3_reg_284_reg[8]_0 [1]),
        .I3(\i_3_reg_284_reg[8]_0 [0]),
        .I4(\i_3_reg_284_reg[8]_0 [2]),
        .I5(\i_3_reg_284_reg[8]_0 [4]),
        .O(\i_3_reg_284[8]_i_2_n_4 ));
  FDRE \i_3_reg_284_reg[0] 
       (.C(ap_clk),
        .CE(output_r_EN_A[1]),
        .D(i_3_fu_177_p2[0]),
        .Q(i_3_reg_284[0]),
        .R(1'b0));
  FDRE \i_3_reg_284_reg[1] 
       (.C(ap_clk),
        .CE(output_r_EN_A[1]),
        .D(i_3_fu_177_p2[1]),
        .Q(i_3_reg_284[1]),
        .R(1'b0));
  FDRE \i_3_reg_284_reg[2] 
       (.C(ap_clk),
        .CE(output_r_EN_A[1]),
        .D(i_3_fu_177_p2[2]),
        .Q(i_3_reg_284[2]),
        .R(1'b0));
  FDRE \i_3_reg_284_reg[3] 
       (.C(ap_clk),
        .CE(output_r_EN_A[1]),
        .D(i_3_fu_177_p2[3]),
        .Q(i_3_reg_284[3]),
        .R(1'b0));
  FDRE \i_3_reg_284_reg[4] 
       (.C(ap_clk),
        .CE(output_r_EN_A[1]),
        .D(i_3_fu_177_p2[4]),
        .Q(i_3_reg_284[4]),
        .R(1'b0));
  FDRE \i_3_reg_284_reg[5] 
       (.C(ap_clk),
        .CE(output_r_EN_A[1]),
        .D(i_3_fu_177_p2[5]),
        .Q(i_3_reg_284[5]),
        .R(1'b0));
  FDRE \i_3_reg_284_reg[6] 
       (.C(ap_clk),
        .CE(output_r_EN_A[1]),
        .D(i_3_fu_177_p2[6]),
        .Q(i_3_reg_284[6]),
        .R(1'b0));
  FDRE \i_3_reg_284_reg[7] 
       (.C(ap_clk),
        .CE(output_r_EN_A[1]),
        .D(i_3_fu_177_p2[7]),
        .Q(i_3_reg_284[7]),
        .R(1'b0));
  FDRE \i_3_reg_284_reg[8] 
       (.C(ap_clk),
        .CE(output_r_EN_A[1]),
        .D(i_3_fu_177_p2[8]),
        .Q(i_3_reg_284[8]),
        .R(1'b0));
  LUT2 #(
    .INIT(4'h2)) 
    \i_reg_137[8]_i_1 
       (.I0(ap_CS_fsm_state3),
        .I1(ap_CS_fsm_state8),
        .O(i_reg_137));
  FDRE \i_reg_137_reg[0] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state8),
        .D(i_3_reg_284[0]),
        .Q(\i_3_reg_284_reg[8]_0 [0]),
        .R(i_reg_137));
  FDRE \i_reg_137_reg[1] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state8),
        .D(i_3_reg_284[1]),
        .Q(\i_3_reg_284_reg[8]_0 [1]),
        .R(i_reg_137));
  FDRE \i_reg_137_reg[2] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state8),
        .D(i_3_reg_284[2]),
        .Q(\i_3_reg_284_reg[8]_0 [2]),
        .R(i_reg_137));
  FDRE \i_reg_137_reg[3] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state8),
        .D(i_3_reg_284[3]),
        .Q(\i_3_reg_284_reg[8]_0 [3]),
        .R(i_reg_137));
  FDRE \i_reg_137_reg[4] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state8),
        .D(i_3_reg_284[4]),
        .Q(\i_3_reg_284_reg[8]_0 [4]),
        .R(i_reg_137));
  FDRE \i_reg_137_reg[5] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state8),
        .D(i_3_reg_284[5]),
        .Q(\i_3_reg_284_reg[8]_0 [5]),
        .R(i_reg_137));
  FDRE \i_reg_137_reg[6] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state8),
        .D(i_3_reg_284[6]),
        .Q(\i_3_reg_284_reg[8]_0 [6]),
        .R(i_reg_137));
  FDRE \i_reg_137_reg[7] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state8),
        .D(i_3_reg_284[7]),
        .Q(\i_3_reg_284_reg[8]_0 [7]),
        .R(i_reg_137));
  FDRE \i_reg_137_reg[8] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state8),
        .D(i_3_reg_284[8]),
        .Q(\i_3_reg_284_reg[8]_0 [8]),
        .R(i_reg_137));
  (* SOFT_HLUTNM = "soft_lutpair110" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \k_1_reg_261[0]_i_1 
       (.I0(\fc2_bias_Addr_A[5] [0]),
        .O(k_1_fu_160_p2[0]));
  (* SOFT_HLUTNM = "soft_lutpair110" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \k_1_reg_261[1]_i_1 
       (.I0(\fc2_bias_Addr_A[5] [0]),
        .I1(\fc2_bias_Addr_A[5] [1]),
        .O(k_1_fu_160_p2[1]));
  (* SOFT_HLUTNM = "soft_lutpair107" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \k_1_reg_261[2]_i_1 
       (.I0(\fc2_bias_Addr_A[5] [0]),
        .I1(\fc2_bias_Addr_A[5] [1]),
        .I2(\fc2_bias_Addr_A[5] [2]),
        .O(k_1_fu_160_p2[2]));
  (* SOFT_HLUTNM = "soft_lutpair107" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \k_1_reg_261[3]_i_1 
       (.I0(\fc2_bias_Addr_A[5] [1]),
        .I1(\fc2_bias_Addr_A[5] [0]),
        .I2(\fc2_bias_Addr_A[5] [2]),
        .I3(\fc2_bias_Addr_A[5] [3]),
        .O(k_1_fu_160_p2[3]));
  FDRE \k_1_reg_261_reg[0] 
       (.C(ap_clk),
        .CE(output_r_EN_A[0]),
        .D(k_1_fu_160_p2[0]),
        .Q(k_1_reg_261[0]),
        .R(1'b0));
  FDRE \k_1_reg_261_reg[1] 
       (.C(ap_clk),
        .CE(output_r_EN_A[0]),
        .D(k_1_fu_160_p2[1]),
        .Q(k_1_reg_261[1]),
        .R(1'b0));
  FDRE \k_1_reg_261_reg[2] 
       (.C(ap_clk),
        .CE(output_r_EN_A[0]),
        .D(k_1_fu_160_p2[2]),
        .Q(k_1_reg_261[2]),
        .R(1'b0));
  FDRE \k_1_reg_261_reg[3] 
       (.C(ap_clk),
        .CE(output_r_EN_A[0]),
        .D(k_1_fu_160_p2[3]),
        .Q(k_1_reg_261[3]),
        .R(1'b0));
  LUT3 #(
    .INIT(8'h08)) 
    \k_reg_104[3]_i_1 
       (.I0(grp_Fc2_400_10_fu_92_ap_start_reg),
        .I1(\ap_CS_fsm_reg_n_4_[0] ),
        .I2(\output_r_WEN_A[0] ),
        .O(k_reg_104));
  FDRE \k_reg_104_reg[0] 
       (.C(ap_clk),
        .CE(\output_r_WEN_A[0] ),
        .D(k_1_reg_261[0]),
        .Q(\fc2_bias_Addr_A[5] [0]),
        .R(k_reg_104));
  FDRE \k_reg_104_reg[1] 
       (.C(ap_clk),
        .CE(\output_r_WEN_A[0] ),
        .D(k_1_reg_261[1]),
        .Q(\fc2_bias_Addr_A[5] [1]),
        .R(k_reg_104));
  FDRE \k_reg_104_reg[2] 
       (.C(ap_clk),
        .CE(\output_r_WEN_A[0] ),
        .D(k_1_reg_261[2]),
        .Q(\fc2_bias_Addr_A[5] [2]),
        .R(k_reg_104));
  FDRE \k_reg_104_reg[3] 
       (.C(ap_clk),
        .CE(\output_r_WEN_A[0] ),
        .D(k_1_reg_261[3]),
        .Q(\fc2_bias_Addr_A[5] [3]),
        .R(k_reg_104));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_lenet_cnn_mul_31ncud lenet_cnn_mul_31ncud_U34
       (.D({\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 ,lenet_cnn_mul_31ncud_U34_n_34,lenet_cnn_mul_31ncud_U34_n_35}),
        .Q(ap_CS_fsm_state5),
        .ap_clk(ap_clk),
        .fc1_output_q0(fc1_output_q0),
        .fc2_kernel_Dout_A(fc2_kernel_Dout_A));
  CARRY4 next_mul_fu_148_p2_carry
       (.CI(1'b0),
        .CO({next_mul_fu_148_p2_carry_n_4,next_mul_fu_148_p2_carry_n_5,next_mul_fu_148_p2_carry_n_6,next_mul_fu_148_p2_carry_n_7}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,phi_mul_reg_115[4],1'b0}),
        .O(next_mul_fu_148_p2[6:3]),
        .S({phi_mul_reg_115[6:5],next_mul_fu_148_p2_carry_i_1_n_4,phi_mul_reg_115[3]}));
  CARRY4 next_mul_fu_148_p2_carry__0
       (.CI(next_mul_fu_148_p2_carry_n_4),
        .CO({next_mul_fu_148_p2_carry__0_n_4,next_mul_fu_148_p2_carry__0_n_5,next_mul_fu_148_p2_carry__0_n_6,next_mul_fu_148_p2_carry__0_n_7}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,phi_mul_reg_115[8:7]}),
        .O(next_mul_fu_148_p2[10:7]),
        .S({phi_mul_reg_115[10:9],next_mul_fu_148_p2_carry__0_i_1_n_4,next_mul_fu_148_p2_carry__0_i_2_n_4}));
  LUT1 #(
    .INIT(2'h1)) 
    next_mul_fu_148_p2_carry__0_i_1
       (.I0(phi_mul_reg_115[8]),
        .O(next_mul_fu_148_p2_carry__0_i_1_n_4));
  LUT1 #(
    .INIT(2'h1)) 
    next_mul_fu_148_p2_carry__0_i_2
       (.I0(phi_mul_reg_115[7]),
        .O(next_mul_fu_148_p2_carry__0_i_2_n_4));
  CARRY4 next_mul_fu_148_p2_carry__1
       (.CI(next_mul_fu_148_p2_carry__0_n_4),
        .CO(NLW_next_mul_fu_148_p2_carry__1_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({NLW_next_mul_fu_148_p2_carry__1_O_UNCONNECTED[3:1],next_mul_fu_148_p2[11]}),
        .S({1'b0,1'b0,1'b0,phi_mul_reg_115[11]}));
  LUT1 #(
    .INIT(2'h1)) 
    next_mul_fu_148_p2_carry_i_1
       (.I0(phi_mul_reg_115[4]),
        .O(next_mul_fu_148_p2_carry_i_1_n_4));
  FDRE \next_mul_reg_253_reg[10] 
       (.C(ap_clk),
        .CE(output_r_EN_A[0]),
        .D(next_mul_fu_148_p2[10]),
        .Q(next_mul_reg_253[10]),
        .R(1'b0));
  FDRE \next_mul_reg_253_reg[11] 
       (.C(ap_clk),
        .CE(output_r_EN_A[0]),
        .D(next_mul_fu_148_p2[11]),
        .Q(next_mul_reg_253[11]),
        .R(1'b0));
  FDRE \next_mul_reg_253_reg[3] 
       (.C(ap_clk),
        .CE(output_r_EN_A[0]),
        .D(next_mul_fu_148_p2[3]),
        .Q(next_mul_reg_253[3]),
        .R(1'b0));
  FDRE \next_mul_reg_253_reg[4] 
       (.C(ap_clk),
        .CE(output_r_EN_A[0]),
        .D(next_mul_fu_148_p2[4]),
        .Q(next_mul_reg_253[4]),
        .R(1'b0));
  FDRE \next_mul_reg_253_reg[5] 
       (.C(ap_clk),
        .CE(output_r_EN_A[0]),
        .D(next_mul_fu_148_p2[5]),
        .Q(next_mul_reg_253[5]),
        .R(1'b0));
  FDRE \next_mul_reg_253_reg[6] 
       (.C(ap_clk),
        .CE(output_r_EN_A[0]),
        .D(next_mul_fu_148_p2[6]),
        .Q(next_mul_reg_253[6]),
        .R(1'b0));
  FDRE \next_mul_reg_253_reg[7] 
       (.C(ap_clk),
        .CE(output_r_EN_A[0]),
        .D(next_mul_fu_148_p2[7]),
        .Q(next_mul_reg_253[7]),
        .R(1'b0));
  FDRE \next_mul_reg_253_reg[8] 
       (.C(ap_clk),
        .CE(output_r_EN_A[0]),
        .D(next_mul_fu_148_p2[8]),
        .Q(next_mul_reg_253[8]),
        .R(1'b0));
  FDRE \next_mul_reg_253_reg[9] 
       (.C(ap_clk),
        .CE(output_r_EN_A[0]),
        .D(next_mul_fu_148_p2[9]),
        .Q(next_mul_reg_253[9]),
        .R(1'b0));
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[0]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[0]),
        .O(output_r_Din_A[0]));
  (* SOFT_HLUTNM = "soft_lutpair122" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[10]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[10]),
        .O(output_r_Din_A[10]));
  (* SOFT_HLUTNM = "soft_lutpair121" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[11]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[11]),
        .O(output_r_Din_A[11]));
  (* SOFT_HLUTNM = "soft_lutpair120" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[12]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[12]),
        .O(output_r_Din_A[12]));
  (* SOFT_HLUTNM = "soft_lutpair119" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[13]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[13]),
        .O(output_r_Din_A[13]));
  (* SOFT_HLUTNM = "soft_lutpair119" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[14]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[14]),
        .O(output_r_Din_A[14]));
  (* SOFT_HLUTNM = "soft_lutpair114" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[15]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[15]),
        .O(output_r_Din_A[15]));
  (* SOFT_HLUTNM = "soft_lutpair112" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[16]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[16]),
        .O(output_r_Din_A[16]));
  (* SOFT_HLUTNM = "soft_lutpair118" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[17]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[17]),
        .O(output_r_Din_A[17]));
  (* SOFT_HLUTNM = "soft_lutpair118" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[18]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[18]),
        .O(output_r_Din_A[18]));
  (* SOFT_HLUTNM = "soft_lutpair117" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[19]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[19]),
        .O(output_r_Din_A[19]));
  (* SOFT_HLUTNM = "soft_lutpair125" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[1]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[1]),
        .O(output_r_Din_A[1]));
  (* SOFT_HLUTNM = "soft_lutpair117" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[20]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[20]),
        .O(output_r_Din_A[20]));
  (* SOFT_HLUTNM = "soft_lutpair116" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[21]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[21]),
        .O(output_r_Din_A[21]));
  (* SOFT_HLUTNM = "soft_lutpair116" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[22]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[22]),
        .O(output_r_Din_A[22]));
  (* SOFT_HLUTNM = "soft_lutpair115" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[23]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[23]),
        .O(output_r_Din_A[23]));
  (* SOFT_HLUTNM = "soft_lutpair115" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[24]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[24]),
        .O(output_r_Din_A[24]));
  (* SOFT_HLUTNM = "soft_lutpair114" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[25]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[25]),
        .O(output_r_Din_A[25]));
  (* SOFT_HLUTNM = "soft_lutpair113" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[26]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[26]),
        .O(output_r_Din_A[26]));
  (* SOFT_HLUTNM = "soft_lutpair111" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[27]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[27]),
        .O(output_r_Din_A[27]));
  (* SOFT_HLUTNM = "soft_lutpair113" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[28]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[28]),
        .O(output_r_Din_A[28]));
  (* SOFT_HLUTNM = "soft_lutpair112" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[29]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[29]),
        .O(output_r_Din_A[29]));
  (* SOFT_HLUTNM = "soft_lutpair125" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[2]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[2]),
        .O(output_r_Din_A[2]));
  (* SOFT_HLUTNM = "soft_lutpair111" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[30]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[30]),
        .O(output_r_Din_A[30]));
  (* SOFT_HLUTNM = "soft_lutpair124" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[3]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[3]),
        .O(output_r_Din_A[3]));
  (* SOFT_HLUTNM = "soft_lutpair124" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[4]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[4]),
        .O(output_r_Din_A[4]));
  (* SOFT_HLUTNM = "soft_lutpair123" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[5]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[5]),
        .O(output_r_Din_A[5]));
  (* SOFT_HLUTNM = "soft_lutpair121" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[6]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[6]),
        .O(output_r_Din_A[6]));
  (* SOFT_HLUTNM = "soft_lutpair120" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[7]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[7]),
        .O(output_r_Din_A[7]));
  (* SOFT_HLUTNM = "soft_lutpair123" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[8]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[8]),
        .O(output_r_Din_A[8]));
  (* SOFT_HLUTNM = "soft_lutpair122" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \output_r_Din_A[9]_INST_0 
       (.I0(tmp_s_fu_207_p2_carry__2_n_5),
        .I1(sum1_reg_127_reg[9]),
        .O(output_r_Din_A[9]));
  LUT5 #(
    .INIT(32'h00000002)) 
    \output_r_WEN_A[0]_INST_0 
       (.I0(\output_r_WEN_A[0]_INST_0_i_1_n_4 ),
        .I1(\i_3_reg_284_reg[8]_0 [2]),
        .I2(\i_3_reg_284_reg[8]_0 [3]),
        .I3(\i_3_reg_284_reg[8]_0 [0]),
        .I4(\i_3_reg_284_reg[8]_0 [1]),
        .O(\output_r_WEN_A[0] ));
  LUT6 #(
    .INIT(64'h0020000000000000)) 
    \output_r_WEN_A[0]_INST_0_i_1 
       (.I0(\i_3_reg_284_reg[8]_0 [4]),
        .I1(\i_3_reg_284_reg[8]_0 [5]),
        .I2(\i_3_reg_284_reg[8]_0 [7]),
        .I3(\i_3_reg_284_reg[8]_0 [6]),
        .I4(output_r_EN_A[1]),
        .I5(\i_3_reg_284_reg[8]_0 [8]),
        .O(\output_r_WEN_A[0]_INST_0_i_1_n_4 ));
  FDRE \phi_mul_reg_115_reg[10] 
       (.C(ap_clk),
        .CE(\output_r_WEN_A[0] ),
        .D(next_mul_reg_253[10]),
        .Q(phi_mul_reg_115[10]),
        .R(k_reg_104));
  FDRE \phi_mul_reg_115_reg[11] 
       (.C(ap_clk),
        .CE(\output_r_WEN_A[0] ),
        .D(next_mul_reg_253[11]),
        .Q(phi_mul_reg_115[11]),
        .R(k_reg_104));
  FDRE \phi_mul_reg_115_reg[3] 
       (.C(ap_clk),
        .CE(\output_r_WEN_A[0] ),
        .D(next_mul_reg_253[3]),
        .Q(phi_mul_reg_115[3]),
        .R(k_reg_104));
  FDRE \phi_mul_reg_115_reg[4] 
       (.C(ap_clk),
        .CE(\output_r_WEN_A[0] ),
        .D(next_mul_reg_253[4]),
        .Q(phi_mul_reg_115[4]),
        .R(k_reg_104));
  FDRE \phi_mul_reg_115_reg[5] 
       (.C(ap_clk),
        .CE(\output_r_WEN_A[0] ),
        .D(next_mul_reg_253[5]),
        .Q(phi_mul_reg_115[5]),
        .R(k_reg_104));
  FDRE \phi_mul_reg_115_reg[6] 
       (.C(ap_clk),
        .CE(\output_r_WEN_A[0] ),
        .D(next_mul_reg_253[6]),
        .Q(phi_mul_reg_115[6]),
        .R(k_reg_104));
  FDRE \phi_mul_reg_115_reg[7] 
       (.C(ap_clk),
        .CE(\output_r_WEN_A[0] ),
        .D(next_mul_reg_253[7]),
        .Q(phi_mul_reg_115[7]),
        .R(k_reg_104));
  FDRE \phi_mul_reg_115_reg[8] 
       (.C(ap_clk),
        .CE(\output_r_WEN_A[0] ),
        .D(next_mul_reg_253[8]),
        .Q(phi_mul_reg_115[8]),
        .R(k_reg_104));
  FDRE \phi_mul_reg_115_reg[9] 
       (.C(ap_clk),
        .CE(\output_r_WEN_A[0] ),
        .D(next_mul_reg_253[9]),
        .Q(phi_mul_reg_115[9]),
        .R(k_reg_104));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[0]_i_2 
       (.I0(tmp_3_i_reg_319[3]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[0]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[0]_i_3 
       (.I0(tmp_3_i_reg_319[2]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[0]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[0]_i_4 
       (.I0(tmp_3_i_reg_319[1]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[0]_i_4_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[0]_i_5 
       (.I0(tmp_3_i_reg_319[0]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[0]_i_5_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[0]_i_6 
       (.I0(tmp_3_i_reg_319[3]),
        .I1(fc2_bias_Dout_A[3]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[3]),
        .O(\sum1_reg_127[0]_i_6_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[0]_i_7 
       (.I0(tmp_3_i_reg_319[2]),
        .I1(fc2_bias_Dout_A[2]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[2]),
        .O(\sum1_reg_127[0]_i_7_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[0]_i_8 
       (.I0(tmp_3_i_reg_319[1]),
        .I1(fc2_bias_Dout_A[1]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[1]),
        .O(\sum1_reg_127[0]_i_8_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[0]_i_9 
       (.I0(tmp_3_i_reg_319[0]),
        .I1(fc2_bias_Dout_A[0]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[0]),
        .O(\sum1_reg_127[0]_i_9_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[12]_i_2 
       (.I0(tmp_3_i_reg_319[15]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[12]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[12]_i_3 
       (.I0(tmp_3_i_reg_319[14]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[12]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[12]_i_4 
       (.I0(tmp_3_i_reg_319[13]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[12]_i_4_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[12]_i_5 
       (.I0(tmp_3_i_reg_319[12]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[12]_i_5_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[12]_i_6 
       (.I0(tmp_3_i_reg_319[15]),
        .I1(fc2_bias_Dout_A[15]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[15]),
        .O(\sum1_reg_127[12]_i_6_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[12]_i_7 
       (.I0(tmp_3_i_reg_319[14]),
        .I1(fc2_bias_Dout_A[14]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[14]),
        .O(\sum1_reg_127[12]_i_7_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[12]_i_8 
       (.I0(tmp_3_i_reg_319[13]),
        .I1(fc2_bias_Dout_A[13]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[13]),
        .O(\sum1_reg_127[12]_i_8_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[12]_i_9 
       (.I0(tmp_3_i_reg_319[12]),
        .I1(fc2_bias_Dout_A[12]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[12]),
        .O(\sum1_reg_127[12]_i_9_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[16]_i_2 
       (.I0(tmp_3_i_reg_319[19]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[16]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[16]_i_3 
       (.I0(tmp_3_i_reg_319[18]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[16]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[16]_i_4 
       (.I0(tmp_3_i_reg_319[17]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[16]_i_4_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[16]_i_5 
       (.I0(tmp_3_i_reg_319[16]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[16]_i_5_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[16]_i_6 
       (.I0(tmp_3_i_reg_319[19]),
        .I1(fc2_bias_Dout_A[19]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[19]),
        .O(\sum1_reg_127[16]_i_6_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[16]_i_7 
       (.I0(tmp_3_i_reg_319[18]),
        .I1(fc2_bias_Dout_A[18]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[18]),
        .O(\sum1_reg_127[16]_i_7_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[16]_i_8 
       (.I0(tmp_3_i_reg_319[17]),
        .I1(fc2_bias_Dout_A[17]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[17]),
        .O(\sum1_reg_127[16]_i_8_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[16]_i_9 
       (.I0(tmp_3_i_reg_319[16]),
        .I1(fc2_bias_Dout_A[16]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[16]),
        .O(\sum1_reg_127[16]_i_9_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[20]_i_2 
       (.I0(tmp_3_i_reg_319[23]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[20]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[20]_i_3 
       (.I0(tmp_3_i_reg_319[22]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[20]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[20]_i_4 
       (.I0(tmp_3_i_reg_319[21]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[20]_i_4_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[20]_i_5 
       (.I0(tmp_3_i_reg_319[20]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[20]_i_5_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[20]_i_6 
       (.I0(tmp_3_i_reg_319[23]),
        .I1(fc2_bias_Dout_A[23]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[23]),
        .O(\sum1_reg_127[20]_i_6_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[20]_i_7 
       (.I0(tmp_3_i_reg_319[22]),
        .I1(fc2_bias_Dout_A[22]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[22]),
        .O(\sum1_reg_127[20]_i_7_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[20]_i_8 
       (.I0(tmp_3_i_reg_319[21]),
        .I1(fc2_bias_Dout_A[21]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[21]),
        .O(\sum1_reg_127[20]_i_8_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[20]_i_9 
       (.I0(tmp_3_i_reg_319[20]),
        .I1(fc2_bias_Dout_A[20]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[20]),
        .O(\sum1_reg_127[20]_i_9_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[24]_i_2 
       (.I0(tmp_3_i_reg_319[27]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[24]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[24]_i_3 
       (.I0(tmp_3_i_reg_319[26]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[24]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[24]_i_4 
       (.I0(tmp_3_i_reg_319[25]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[24]_i_4_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[24]_i_5 
       (.I0(tmp_3_i_reg_319[24]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[24]_i_5_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[24]_i_6 
       (.I0(tmp_3_i_reg_319[27]),
        .I1(fc2_bias_Dout_A[27]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[27]),
        .O(\sum1_reg_127[24]_i_6_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[24]_i_7 
       (.I0(tmp_3_i_reg_319[26]),
        .I1(fc2_bias_Dout_A[26]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[26]),
        .O(\sum1_reg_127[24]_i_7_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[24]_i_8 
       (.I0(tmp_3_i_reg_319[25]),
        .I1(fc2_bias_Dout_A[25]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[25]),
        .O(\sum1_reg_127[24]_i_8_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[24]_i_9 
       (.I0(tmp_3_i_reg_319[24]),
        .I1(fc2_bias_Dout_A[24]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[24]),
        .O(\sum1_reg_127[24]_i_9_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[28]_i_2 
       (.I0(tmp_3_i_reg_319[30]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[28]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[28]_i_3 
       (.I0(tmp_3_i_reg_319[29]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[28]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[28]_i_4 
       (.I0(tmp_3_i_reg_319[28]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[28]_i_4_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[28]_i_5 
       (.I0(tmp_3_i_reg_319[31]),
        .I1(fc2_bias_Dout_A[31]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[31]),
        .O(\sum1_reg_127[28]_i_5_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[28]_i_6 
       (.I0(tmp_3_i_reg_319[30]),
        .I1(fc2_bias_Dout_A[30]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[30]),
        .O(\sum1_reg_127[28]_i_6_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[28]_i_7 
       (.I0(tmp_3_i_reg_319[29]),
        .I1(fc2_bias_Dout_A[29]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[29]),
        .O(\sum1_reg_127[28]_i_7_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[28]_i_8 
       (.I0(tmp_3_i_reg_319[28]),
        .I1(fc2_bias_Dout_A[28]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[28]),
        .O(\sum1_reg_127[28]_i_8_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[4]_i_2 
       (.I0(tmp_3_i_reg_319[7]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[4]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[4]_i_3 
       (.I0(tmp_3_i_reg_319[6]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[4]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[4]_i_4 
       (.I0(tmp_3_i_reg_319[5]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[4]_i_4_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[4]_i_5 
       (.I0(tmp_3_i_reg_319[4]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[4]_i_5_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[4]_i_6 
       (.I0(tmp_3_i_reg_319[7]),
        .I1(fc2_bias_Dout_A[7]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[7]),
        .O(\sum1_reg_127[4]_i_6_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[4]_i_7 
       (.I0(tmp_3_i_reg_319[6]),
        .I1(fc2_bias_Dout_A[6]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[6]),
        .O(\sum1_reg_127[4]_i_7_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[4]_i_8 
       (.I0(tmp_3_i_reg_319[5]),
        .I1(fc2_bias_Dout_A[5]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[5]),
        .O(\sum1_reg_127[4]_i_8_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[4]_i_9 
       (.I0(tmp_3_i_reg_319[4]),
        .I1(fc2_bias_Dout_A[4]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[4]),
        .O(\sum1_reg_127[4]_i_9_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[8]_i_2 
       (.I0(tmp_3_i_reg_319[11]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[8]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[8]_i_3 
       (.I0(tmp_3_i_reg_319[10]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[8]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[8]_i_4 
       (.I0(tmp_3_i_reg_319[9]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[8]_i_4_n_4 ));
  LUT2 #(
    .INIT(4'h8)) 
    \sum1_reg_127[8]_i_5 
       (.I0(tmp_3_i_reg_319[8]),
        .I1(ap_CS_fsm_state8),
        .O(\sum1_reg_127[8]_i_5_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[8]_i_6 
       (.I0(tmp_3_i_reg_319[11]),
        .I1(fc2_bias_Dout_A[11]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[11]),
        .O(\sum1_reg_127[8]_i_6_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[8]_i_7 
       (.I0(tmp_3_i_reg_319[10]),
        .I1(fc2_bias_Dout_A[10]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[10]),
        .O(\sum1_reg_127[8]_i_7_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[8]_i_8 
       (.I0(tmp_3_i_reg_319[9]),
        .I1(fc2_bias_Dout_A[9]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[9]),
        .O(\sum1_reg_127[8]_i_8_n_4 ));
  LUT4 #(
    .INIT(16'h5CAC)) 
    \sum1_reg_127[8]_i_9 
       (.I0(tmp_3_i_reg_319[8]),
        .I1(fc2_bias_Dout_A[8]),
        .I2(ap_CS_fsm_state8),
        .I3(sum1_reg_127_reg[8]),
        .O(\sum1_reg_127[8]_i_9_n_4 ));
  FDRE \sum1_reg_127_reg[0] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[0]_i_1_n_11 ),
        .Q(sum1_reg_127_reg[0]),
        .R(1'b0));
  CARRY4 \sum1_reg_127_reg[0]_i_1 
       (.CI(1'b0),
        .CO({\sum1_reg_127_reg[0]_i_1_n_4 ,\sum1_reg_127_reg[0]_i_1_n_5 ,\sum1_reg_127_reg[0]_i_1_n_6 ,\sum1_reg_127_reg[0]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({\sum1_reg_127[0]_i_2_n_4 ,\sum1_reg_127[0]_i_3_n_4 ,\sum1_reg_127[0]_i_4_n_4 ,\sum1_reg_127[0]_i_5_n_4 }),
        .O({\sum1_reg_127_reg[0]_i_1_n_8 ,\sum1_reg_127_reg[0]_i_1_n_9 ,\sum1_reg_127_reg[0]_i_1_n_10 ,\sum1_reg_127_reg[0]_i_1_n_11 }),
        .S({\sum1_reg_127[0]_i_6_n_4 ,\sum1_reg_127[0]_i_7_n_4 ,\sum1_reg_127[0]_i_8_n_4 ,\sum1_reg_127[0]_i_9_n_4 }));
  FDRE \sum1_reg_127_reg[10] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[8]_i_1_n_9 ),
        .Q(sum1_reg_127_reg[10]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[11] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[8]_i_1_n_8 ),
        .Q(sum1_reg_127_reg[11]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[12] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[12]_i_1_n_11 ),
        .Q(sum1_reg_127_reg[12]),
        .R(1'b0));
  CARRY4 \sum1_reg_127_reg[12]_i_1 
       (.CI(\sum1_reg_127_reg[8]_i_1_n_4 ),
        .CO({\sum1_reg_127_reg[12]_i_1_n_4 ,\sum1_reg_127_reg[12]_i_1_n_5 ,\sum1_reg_127_reg[12]_i_1_n_6 ,\sum1_reg_127_reg[12]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({\sum1_reg_127[12]_i_2_n_4 ,\sum1_reg_127[12]_i_3_n_4 ,\sum1_reg_127[12]_i_4_n_4 ,\sum1_reg_127[12]_i_5_n_4 }),
        .O({\sum1_reg_127_reg[12]_i_1_n_8 ,\sum1_reg_127_reg[12]_i_1_n_9 ,\sum1_reg_127_reg[12]_i_1_n_10 ,\sum1_reg_127_reg[12]_i_1_n_11 }),
        .S({\sum1_reg_127[12]_i_6_n_4 ,\sum1_reg_127[12]_i_7_n_4 ,\sum1_reg_127[12]_i_8_n_4 ,\sum1_reg_127[12]_i_9_n_4 }));
  FDRE \sum1_reg_127_reg[13] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[12]_i_1_n_10 ),
        .Q(sum1_reg_127_reg[13]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[14] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[12]_i_1_n_9 ),
        .Q(sum1_reg_127_reg[14]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[15] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[12]_i_1_n_8 ),
        .Q(sum1_reg_127_reg[15]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[16] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[16]_i_1_n_11 ),
        .Q(sum1_reg_127_reg[16]),
        .R(1'b0));
  CARRY4 \sum1_reg_127_reg[16]_i_1 
       (.CI(\sum1_reg_127_reg[12]_i_1_n_4 ),
        .CO({\sum1_reg_127_reg[16]_i_1_n_4 ,\sum1_reg_127_reg[16]_i_1_n_5 ,\sum1_reg_127_reg[16]_i_1_n_6 ,\sum1_reg_127_reg[16]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({\sum1_reg_127[16]_i_2_n_4 ,\sum1_reg_127[16]_i_3_n_4 ,\sum1_reg_127[16]_i_4_n_4 ,\sum1_reg_127[16]_i_5_n_4 }),
        .O({\sum1_reg_127_reg[16]_i_1_n_8 ,\sum1_reg_127_reg[16]_i_1_n_9 ,\sum1_reg_127_reg[16]_i_1_n_10 ,\sum1_reg_127_reg[16]_i_1_n_11 }),
        .S({\sum1_reg_127[16]_i_6_n_4 ,\sum1_reg_127[16]_i_7_n_4 ,\sum1_reg_127[16]_i_8_n_4 ,\sum1_reg_127[16]_i_9_n_4 }));
  FDRE \sum1_reg_127_reg[17] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[16]_i_1_n_10 ),
        .Q(sum1_reg_127_reg[17]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[18] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[16]_i_1_n_9 ),
        .Q(sum1_reg_127_reg[18]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[19] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[16]_i_1_n_8 ),
        .Q(sum1_reg_127_reg[19]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[1] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[0]_i_1_n_10 ),
        .Q(sum1_reg_127_reg[1]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[20] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[20]_i_1_n_11 ),
        .Q(sum1_reg_127_reg[20]),
        .R(1'b0));
  CARRY4 \sum1_reg_127_reg[20]_i_1 
       (.CI(\sum1_reg_127_reg[16]_i_1_n_4 ),
        .CO({\sum1_reg_127_reg[20]_i_1_n_4 ,\sum1_reg_127_reg[20]_i_1_n_5 ,\sum1_reg_127_reg[20]_i_1_n_6 ,\sum1_reg_127_reg[20]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({\sum1_reg_127[20]_i_2_n_4 ,\sum1_reg_127[20]_i_3_n_4 ,\sum1_reg_127[20]_i_4_n_4 ,\sum1_reg_127[20]_i_5_n_4 }),
        .O({\sum1_reg_127_reg[20]_i_1_n_8 ,\sum1_reg_127_reg[20]_i_1_n_9 ,\sum1_reg_127_reg[20]_i_1_n_10 ,\sum1_reg_127_reg[20]_i_1_n_11 }),
        .S({\sum1_reg_127[20]_i_6_n_4 ,\sum1_reg_127[20]_i_7_n_4 ,\sum1_reg_127[20]_i_8_n_4 ,\sum1_reg_127[20]_i_9_n_4 }));
  FDRE \sum1_reg_127_reg[21] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[20]_i_1_n_10 ),
        .Q(sum1_reg_127_reg[21]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[22] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[20]_i_1_n_9 ),
        .Q(sum1_reg_127_reg[22]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[23] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[20]_i_1_n_8 ),
        .Q(sum1_reg_127_reg[23]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[24] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[24]_i_1_n_11 ),
        .Q(sum1_reg_127_reg[24]),
        .R(1'b0));
  CARRY4 \sum1_reg_127_reg[24]_i_1 
       (.CI(\sum1_reg_127_reg[20]_i_1_n_4 ),
        .CO({\sum1_reg_127_reg[24]_i_1_n_4 ,\sum1_reg_127_reg[24]_i_1_n_5 ,\sum1_reg_127_reg[24]_i_1_n_6 ,\sum1_reg_127_reg[24]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({\sum1_reg_127[24]_i_2_n_4 ,\sum1_reg_127[24]_i_3_n_4 ,\sum1_reg_127[24]_i_4_n_4 ,\sum1_reg_127[24]_i_5_n_4 }),
        .O({\sum1_reg_127_reg[24]_i_1_n_8 ,\sum1_reg_127_reg[24]_i_1_n_9 ,\sum1_reg_127_reg[24]_i_1_n_10 ,\sum1_reg_127_reg[24]_i_1_n_11 }),
        .S({\sum1_reg_127[24]_i_6_n_4 ,\sum1_reg_127[24]_i_7_n_4 ,\sum1_reg_127[24]_i_8_n_4 ,\sum1_reg_127[24]_i_9_n_4 }));
  FDRE \sum1_reg_127_reg[25] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[24]_i_1_n_10 ),
        .Q(sum1_reg_127_reg[25]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[26] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[24]_i_1_n_9 ),
        .Q(sum1_reg_127_reg[26]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[27] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[24]_i_1_n_8 ),
        .Q(sum1_reg_127_reg[27]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[28] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[28]_i_1_n_11 ),
        .Q(sum1_reg_127_reg[28]),
        .R(1'b0));
  CARRY4 \sum1_reg_127_reg[28]_i_1 
       (.CI(\sum1_reg_127_reg[24]_i_1_n_4 ),
        .CO({\NLW_sum1_reg_127_reg[28]_i_1_CO_UNCONNECTED [3],\sum1_reg_127_reg[28]_i_1_n_5 ,\sum1_reg_127_reg[28]_i_1_n_6 ,\sum1_reg_127_reg[28]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,\sum1_reg_127[28]_i_2_n_4 ,\sum1_reg_127[28]_i_3_n_4 ,\sum1_reg_127[28]_i_4_n_4 }),
        .O({\sum1_reg_127_reg[28]_i_1_n_8 ,\sum1_reg_127_reg[28]_i_1_n_9 ,\sum1_reg_127_reg[28]_i_1_n_10 ,\sum1_reg_127_reg[28]_i_1_n_11 }),
        .S({\sum1_reg_127[28]_i_5_n_4 ,\sum1_reg_127[28]_i_6_n_4 ,\sum1_reg_127[28]_i_7_n_4 ,\sum1_reg_127[28]_i_8_n_4 }));
  FDRE \sum1_reg_127_reg[29] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[28]_i_1_n_10 ),
        .Q(sum1_reg_127_reg[29]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[2] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[0]_i_1_n_9 ),
        .Q(sum1_reg_127_reg[2]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[30] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[28]_i_1_n_9 ),
        .Q(sum1_reg_127_reg[30]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[31] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[28]_i_1_n_8 ),
        .Q(sum1_reg_127_reg[31]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[3] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[0]_i_1_n_8 ),
        .Q(sum1_reg_127_reg[3]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[4] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[4]_i_1_n_11 ),
        .Q(sum1_reg_127_reg[4]),
        .R(1'b0));
  CARRY4 \sum1_reg_127_reg[4]_i_1 
       (.CI(\sum1_reg_127_reg[0]_i_1_n_4 ),
        .CO({\sum1_reg_127_reg[4]_i_1_n_4 ,\sum1_reg_127_reg[4]_i_1_n_5 ,\sum1_reg_127_reg[4]_i_1_n_6 ,\sum1_reg_127_reg[4]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({\sum1_reg_127[4]_i_2_n_4 ,\sum1_reg_127[4]_i_3_n_4 ,\sum1_reg_127[4]_i_4_n_4 ,\sum1_reg_127[4]_i_5_n_4 }),
        .O({\sum1_reg_127_reg[4]_i_1_n_8 ,\sum1_reg_127_reg[4]_i_1_n_9 ,\sum1_reg_127_reg[4]_i_1_n_10 ,\sum1_reg_127_reg[4]_i_1_n_11 }),
        .S({\sum1_reg_127[4]_i_6_n_4 ,\sum1_reg_127[4]_i_7_n_4 ,\sum1_reg_127[4]_i_8_n_4 ,\sum1_reg_127[4]_i_9_n_4 }));
  FDRE \sum1_reg_127_reg[5] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[4]_i_1_n_10 ),
        .Q(sum1_reg_127_reg[5]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[6] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[4]_i_1_n_9 ),
        .Q(sum1_reg_127_reg[6]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[7] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[4]_i_1_n_8 ),
        .Q(sum1_reg_127_reg[7]),
        .R(1'b0));
  FDRE \sum1_reg_127_reg[8] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[8]_i_1_n_11 ),
        .Q(sum1_reg_127_reg[8]),
        .R(1'b0));
  CARRY4 \sum1_reg_127_reg[8]_i_1 
       (.CI(\sum1_reg_127_reg[4]_i_1_n_4 ),
        .CO({\sum1_reg_127_reg[8]_i_1_n_4 ,\sum1_reg_127_reg[8]_i_1_n_5 ,\sum1_reg_127_reg[8]_i_1_n_6 ,\sum1_reg_127_reg[8]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({\sum1_reg_127[8]_i_2_n_4 ,\sum1_reg_127[8]_i_3_n_4 ,\sum1_reg_127[8]_i_4_n_4 ,\sum1_reg_127[8]_i_5_n_4 }),
        .O({\sum1_reg_127_reg[8]_i_1_n_8 ,\sum1_reg_127_reg[8]_i_1_n_9 ,\sum1_reg_127_reg[8]_i_1_n_10 ,\sum1_reg_127_reg[8]_i_1_n_11 }),
        .S({\sum1_reg_127[8]_i_6_n_4 ,\sum1_reg_127[8]_i_7_n_4 ,\sum1_reg_127[8]_i_8_n_4 ,\sum1_reg_127[8]_i_9_n_4 }));
  FDRE \sum1_reg_127_reg[9] 
       (.C(ap_clk),
        .CE(ap_NS_fsm[3]),
        .D(\sum1_reg_127_reg[8]_i_1_n_10 ),
        .Q(sum1_reg_127_reg[9]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[0] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(lenet_cnn_mul_31ncud_U34_n_35),
        .Q(tmp_3_i_reg_319[0]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[10] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [24]),
        .Q(tmp_3_i_reg_319[10]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[11] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [25]),
        .Q(tmp_3_i_reg_319[11]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[12] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [26]),
        .Q(tmp_3_i_reg_319[12]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[13] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [27]),
        .Q(tmp_3_i_reg_319[13]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[14] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [28]),
        .Q(tmp_3_i_reg_319[14]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[15] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [29]),
        .Q(tmp_3_i_reg_319[15]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[16] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [30]),
        .Q(tmp_3_i_reg_319[16]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[17] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [31]),
        .Q(tmp_3_i_reg_319[17]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[18] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [32]),
        .Q(tmp_3_i_reg_319[18]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[19] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [33]),
        .Q(tmp_3_i_reg_319[19]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[1] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(lenet_cnn_mul_31ncud_U34_n_34),
        .Q(tmp_3_i_reg_319[1]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[20] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [34]),
        .Q(tmp_3_i_reg_319[20]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[21] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [35]),
        .Q(tmp_3_i_reg_319[21]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[22] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [36]),
        .Q(tmp_3_i_reg_319[22]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[23] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [37]),
        .Q(tmp_3_i_reg_319[23]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[24] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [38]),
        .Q(tmp_3_i_reg_319[24]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[25] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [39]),
        .Q(tmp_3_i_reg_319[25]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[26] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [40]),
        .Q(tmp_3_i_reg_319[26]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[27] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [41]),
        .Q(tmp_3_i_reg_319[27]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[28] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [42]),
        .Q(tmp_3_i_reg_319[28]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[29] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [43]),
        .Q(tmp_3_i_reg_319[29]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[2] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [16]),
        .Q(tmp_3_i_reg_319[2]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[30] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [44]),
        .Q(tmp_3_i_reg_319[30]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[31] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [45]),
        .Q(tmp_3_i_reg_319[31]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[3] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [17]),
        .Q(tmp_3_i_reg_319[3]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[4] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [18]),
        .Q(tmp_3_i_reg_319[4]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[5] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [19]),
        .Q(tmp_3_i_reg_319[5]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[6] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [20]),
        .Q(tmp_3_i_reg_319[6]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[7] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [21]),
        .Q(tmp_3_i_reg_319[7]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[8] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [22]),
        .Q(tmp_3_i_reg_319[8]),
        .R(1'b0));
  FDRE \tmp_3_i_reg_319_reg[9] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state7),
        .D(\a0_lenet_cnn_mul_31ncud_MulnS_1_U/p_reg__0 [23]),
        .Q(tmp_3_i_reg_319[9]),
        .R(1'b0));
  LUT5 #(
    .INIT(32'hAAAAA2AA)) 
    \tmp_reg_266[3]_i_1 
       (.I0(output_r_EN_A[0]),
        .I1(\fc2_bias_Addr_A[5] [3]),
        .I2(\fc2_bias_Addr_A[5] [2]),
        .I3(\fc2_bias_Addr_A[5] [1]),
        .I4(\fc2_bias_Addr_A[5] [0]),
        .O(tmp_reg_266_reg0));
  FDRE \tmp_reg_266_reg[0] 
       (.C(ap_clk),
        .CE(tmp_reg_266_reg0),
        .D(\fc2_bias_Addr_A[5] [0]),
        .Q(output_r_Addr_A[0]),
        .R(1'b0));
  FDRE \tmp_reg_266_reg[1] 
       (.C(ap_clk),
        .CE(tmp_reg_266_reg0),
        .D(\fc2_bias_Addr_A[5] [1]),
        .Q(output_r_Addr_A[1]),
        .R(1'b0));
  FDRE \tmp_reg_266_reg[2] 
       (.C(ap_clk),
        .CE(tmp_reg_266_reg0),
        .D(\fc2_bias_Addr_A[5] [2]),
        .Q(output_r_Addr_A[2]),
        .R(1'b0));
  FDRE \tmp_reg_266_reg[3] 
       (.C(ap_clk),
        .CE(tmp_reg_266_reg0),
        .D(\fc2_bias_Addr_A[5] [3]),
        .Q(output_r_Addr_A[3]),
        .R(1'b0));
  CARRY4 tmp_s_fu_207_p2_carry
       (.CI(1'b0),
        .CO({tmp_s_fu_207_p2_carry_n_4,tmp_s_fu_207_p2_carry_n_5,tmp_s_fu_207_p2_carry_n_6,tmp_s_fu_207_p2_carry_n_7}),
        .CYINIT(tmp_s_fu_207_p2_carry_i_1_n_4),
        .DI({tmp_s_fu_207_p2_carry_i_2_n_4,tmp_s_fu_207_p2_carry_i_3_n_4,tmp_s_fu_207_p2_carry_i_4_n_4,tmp_s_fu_207_p2_carry_i_5_n_4}),
        .O(NLW_tmp_s_fu_207_p2_carry_O_UNCONNECTED[3:0]),
        .S({tmp_s_fu_207_p2_carry_i_6_n_4,tmp_s_fu_207_p2_carry_i_7_n_4,tmp_s_fu_207_p2_carry_i_8_n_4,tmp_s_fu_207_p2_carry_i_9_n_4}));
  CARRY4 tmp_s_fu_207_p2_carry__0
       (.CI(tmp_s_fu_207_p2_carry_n_4),
        .CO({tmp_s_fu_207_p2_carry__0_n_4,tmp_s_fu_207_p2_carry__0_n_5,tmp_s_fu_207_p2_carry__0_n_6,tmp_s_fu_207_p2_carry__0_n_7}),
        .CYINIT(1'b0),
        .DI({tmp_s_fu_207_p2_carry__0_i_1_n_4,tmp_s_fu_207_p2_carry__0_i_2_n_4,tmp_s_fu_207_p2_carry__0_i_3_n_4,tmp_s_fu_207_p2_carry__0_i_4_n_4}),
        .O(NLW_tmp_s_fu_207_p2_carry__0_O_UNCONNECTED[3:0]),
        .S({tmp_s_fu_207_p2_carry__0_i_5_n_4,tmp_s_fu_207_p2_carry__0_i_6_n_4,tmp_s_fu_207_p2_carry__0_i_7_n_4,tmp_s_fu_207_p2_carry__0_i_8_n_4}));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_207_p2_carry__0_i_1
       (.I0(sum1_reg_127_reg[16]),
        .I1(sum1_reg_127_reg[17]),
        .O(tmp_s_fu_207_p2_carry__0_i_1_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_207_p2_carry__0_i_2
       (.I0(sum1_reg_127_reg[14]),
        .I1(sum1_reg_127_reg[15]),
        .O(tmp_s_fu_207_p2_carry__0_i_2_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_207_p2_carry__0_i_3
       (.I0(sum1_reg_127_reg[12]),
        .I1(sum1_reg_127_reg[13]),
        .O(tmp_s_fu_207_p2_carry__0_i_3_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_207_p2_carry__0_i_4
       (.I0(sum1_reg_127_reg[10]),
        .I1(sum1_reg_127_reg[11]),
        .O(tmp_s_fu_207_p2_carry__0_i_4_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_207_p2_carry__0_i_5
       (.I0(sum1_reg_127_reg[17]),
        .I1(sum1_reg_127_reg[16]),
        .O(tmp_s_fu_207_p2_carry__0_i_5_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_207_p2_carry__0_i_6
       (.I0(sum1_reg_127_reg[15]),
        .I1(sum1_reg_127_reg[14]),
        .O(tmp_s_fu_207_p2_carry__0_i_6_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_207_p2_carry__0_i_7
       (.I0(sum1_reg_127_reg[13]),
        .I1(sum1_reg_127_reg[12]),
        .O(tmp_s_fu_207_p2_carry__0_i_7_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_207_p2_carry__0_i_8
       (.I0(sum1_reg_127_reg[11]),
        .I1(sum1_reg_127_reg[10]),
        .O(tmp_s_fu_207_p2_carry__0_i_8_n_4));
  CARRY4 tmp_s_fu_207_p2_carry__1
       (.CI(tmp_s_fu_207_p2_carry__0_n_4),
        .CO({tmp_s_fu_207_p2_carry__1_n_4,tmp_s_fu_207_p2_carry__1_n_5,tmp_s_fu_207_p2_carry__1_n_6,tmp_s_fu_207_p2_carry__1_n_7}),
        .CYINIT(1'b0),
        .DI({tmp_s_fu_207_p2_carry__1_i_1_n_4,tmp_s_fu_207_p2_carry__1_i_2_n_4,tmp_s_fu_207_p2_carry__1_i_3_n_4,tmp_s_fu_207_p2_carry__1_i_4_n_4}),
        .O(NLW_tmp_s_fu_207_p2_carry__1_O_UNCONNECTED[3:0]),
        .S({tmp_s_fu_207_p2_carry__1_i_5_n_4,tmp_s_fu_207_p2_carry__1_i_6_n_4,tmp_s_fu_207_p2_carry__1_i_7_n_4,tmp_s_fu_207_p2_carry__1_i_8_n_4}));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_207_p2_carry__1_i_1
       (.I0(sum1_reg_127_reg[24]),
        .I1(sum1_reg_127_reg[25]),
        .O(tmp_s_fu_207_p2_carry__1_i_1_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_207_p2_carry__1_i_2
       (.I0(sum1_reg_127_reg[22]),
        .I1(sum1_reg_127_reg[23]),
        .O(tmp_s_fu_207_p2_carry__1_i_2_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_207_p2_carry__1_i_3
       (.I0(sum1_reg_127_reg[20]),
        .I1(sum1_reg_127_reg[21]),
        .O(tmp_s_fu_207_p2_carry__1_i_3_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_207_p2_carry__1_i_4
       (.I0(sum1_reg_127_reg[18]),
        .I1(sum1_reg_127_reg[19]),
        .O(tmp_s_fu_207_p2_carry__1_i_4_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_207_p2_carry__1_i_5
       (.I0(sum1_reg_127_reg[25]),
        .I1(sum1_reg_127_reg[24]),
        .O(tmp_s_fu_207_p2_carry__1_i_5_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_207_p2_carry__1_i_6
       (.I0(sum1_reg_127_reg[23]),
        .I1(sum1_reg_127_reg[22]),
        .O(tmp_s_fu_207_p2_carry__1_i_6_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_207_p2_carry__1_i_7
       (.I0(sum1_reg_127_reg[21]),
        .I1(sum1_reg_127_reg[20]),
        .O(tmp_s_fu_207_p2_carry__1_i_7_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_207_p2_carry__1_i_8
       (.I0(sum1_reg_127_reg[19]),
        .I1(sum1_reg_127_reg[18]),
        .O(tmp_s_fu_207_p2_carry__1_i_8_n_4));
  CARRY4 tmp_s_fu_207_p2_carry__2
       (.CI(tmp_s_fu_207_p2_carry__1_n_4),
        .CO({NLW_tmp_s_fu_207_p2_carry__2_CO_UNCONNECTED[3],tmp_s_fu_207_p2_carry__2_n_5,tmp_s_fu_207_p2_carry__2_n_6,tmp_s_fu_207_p2_carry__2_n_7}),
        .CYINIT(1'b0),
        .DI({1'b0,tmp_s_fu_207_p2_carry__2_i_1_n_4,tmp_s_fu_207_p2_carry__2_i_2_n_4,tmp_s_fu_207_p2_carry__2_i_3_n_4}),
        .O(NLW_tmp_s_fu_207_p2_carry__2_O_UNCONNECTED[3:0]),
        .S({1'b0,tmp_s_fu_207_p2_carry__2_i_4_n_4,tmp_s_fu_207_p2_carry__2_i_5_n_4,tmp_s_fu_207_p2_carry__2_i_6_n_4}));
  LUT2 #(
    .INIT(4'h2)) 
    tmp_s_fu_207_p2_carry__2_i_1
       (.I0(sum1_reg_127_reg[30]),
        .I1(sum1_reg_127_reg[31]),
        .O(tmp_s_fu_207_p2_carry__2_i_1_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_207_p2_carry__2_i_2
       (.I0(sum1_reg_127_reg[28]),
        .I1(sum1_reg_127_reg[29]),
        .O(tmp_s_fu_207_p2_carry__2_i_2_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_207_p2_carry__2_i_3
       (.I0(sum1_reg_127_reg[26]),
        .I1(sum1_reg_127_reg[27]),
        .O(tmp_s_fu_207_p2_carry__2_i_3_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_207_p2_carry__2_i_4
       (.I0(sum1_reg_127_reg[31]),
        .I1(sum1_reg_127_reg[30]),
        .O(tmp_s_fu_207_p2_carry__2_i_4_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_207_p2_carry__2_i_5
       (.I0(sum1_reg_127_reg[29]),
        .I1(sum1_reg_127_reg[28]),
        .O(tmp_s_fu_207_p2_carry__2_i_5_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_207_p2_carry__2_i_6
       (.I0(sum1_reg_127_reg[27]),
        .I1(sum1_reg_127_reg[26]),
        .O(tmp_s_fu_207_p2_carry__2_i_6_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_207_p2_carry_i_1
       (.I0(sum1_reg_127_reg[1]),
        .I1(sum1_reg_127_reg[0]),
        .O(tmp_s_fu_207_p2_carry_i_1_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_207_p2_carry_i_2
       (.I0(sum1_reg_127_reg[8]),
        .I1(sum1_reg_127_reg[9]),
        .O(tmp_s_fu_207_p2_carry_i_2_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_207_p2_carry_i_3
       (.I0(sum1_reg_127_reg[6]),
        .I1(sum1_reg_127_reg[7]),
        .O(tmp_s_fu_207_p2_carry_i_3_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_207_p2_carry_i_4
       (.I0(sum1_reg_127_reg[4]),
        .I1(sum1_reg_127_reg[5]),
        .O(tmp_s_fu_207_p2_carry_i_4_n_4));
  LUT2 #(
    .INIT(4'hE)) 
    tmp_s_fu_207_p2_carry_i_5
       (.I0(sum1_reg_127_reg[2]),
        .I1(sum1_reg_127_reg[3]),
        .O(tmp_s_fu_207_p2_carry_i_5_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_207_p2_carry_i_6
       (.I0(sum1_reg_127_reg[9]),
        .I1(sum1_reg_127_reg[8]),
        .O(tmp_s_fu_207_p2_carry_i_6_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_207_p2_carry_i_7
       (.I0(sum1_reg_127_reg[7]),
        .I1(sum1_reg_127_reg[6]),
        .O(tmp_s_fu_207_p2_carry_i_7_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_207_p2_carry_i_8
       (.I0(sum1_reg_127_reg[5]),
        .I1(sum1_reg_127_reg[4]),
        .O(tmp_s_fu_207_p2_carry_i_8_n_4));
  LUT2 #(
    .INIT(4'h1)) 
    tmp_s_fu_207_p2_carry_i_9
       (.I0(sum1_reg_127_reg[3]),
        .I1(sum1_reg_127_reg[2]),
        .O(tmp_s_fu_207_p2_carry_i_9_n_4));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Pool1_24x24x20_2x2x2
   (\ap_CS_fsm_reg[3]_0 ,
    grp_Pool1_24x24x20_2x2x2_fu_86_ap_start_reg_reg,
    grp_Pool1_24x24x20_2x2x2_fu_86_ap_start_reg,
    grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_ready,
    Q,
    grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg,
    \ap_CS_fsm_reg[2]_0 ,
    ap_rst_n,
    ap_clk);
  output \ap_CS_fsm_reg[3]_0 ;
  output grp_Pool1_24x24x20_2x2x2_fu_86_ap_start_reg_reg;
  input grp_Pool1_24x24x20_2x2x2_fu_86_ap_start_reg;
  input grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_ready;
  input [0:0]Q;
  input grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg;
  input [0:0]\ap_CS_fsm_reg[2]_0 ;
  input ap_rst_n;
  input ap_clk;

  wire [0:0]Q;
  wire [0:0]\ap_CS_fsm_reg[2]_0 ;
  wire \ap_CS_fsm_reg[3]_0 ;
  wire \ap_CS_fsm_reg_n_4_[0] ;
  wire ap_CS_fsm_state10;
  wire ap_CS_fsm_state2;
  wire ap_CS_fsm_state3;
  wire ap_CS_fsm_state4;
  wire ap_CS_fsm_state5;
  wire ap_CS_fsm_state6;
  wire ap_CS_fsm_state7;
  wire ap_CS_fsm_state8;
  wire ap_CS_fsm_state9;
  wire [9:0]ap_NS_fsm;
  wire ap_NS_fsm12_out;
  wire ap_NS_fsm14_out;
  wire ap_clk;
  wire ap_rst_n;
  wire grp_Pool1_24x24x20_2x2x2_fu_86_ap_ready;
  wire grp_Pool1_24x24x20_2x2x2_fu_86_ap_start_reg;
  wire grp_Pool1_24x24x20_2x2x2_fu_86_ap_start_reg_reg;
  wire grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_ready;
  wire grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg;
  wire [2:0]i_2_reg_627;
  wire \i_2_reg_627[0]_i_1_n_4 ;
  wire \i_2_reg_627[1]_i_1_n_4 ;
  wire \i_2_reg_627[2]_i_1_n_4 ;
  wire \i_reg_160[0]_i_1_n_4 ;
  wire \i_reg_160[1]_i_1_n_4 ;
  wire \i_reg_160[2]_i_1_n_4 ;
  wire \i_reg_160_reg_n_4_[0] ;
  wire \i_reg_160_reg_n_4_[1] ;
  wire \i_reg_160_reg_n_4_[2] ;
  wire [9:5]p_shl2_cast_fu_207_p1;
  wire [3:2]tmp_27_fu_287_p4;
  wire tmp_42_reg_6320;
  wire [4:1]x_2_fu_342_p2;
  wire x_reg_1250;
  wire \x_reg_125_reg_n_4_[1] ;
  wire \x_reg_125_reg_n_4_[2] ;
  wire [4:1]y_2_fu_495_p2;
  wire [4:1]y_2_reg_637;
  wire [4:1]y_reg_137;
  wire y_reg_1370;
  wire [4:0]z_2_fu_193_p2;
  wire [4:0]z_2_reg_526;
  wire z_reg_114;

  (* SOFT_HLUTNM = "soft_lutpair130" *) 
  LUT4 #(
    .INIT(16'h88F8)) 
    \ap_CS_fsm[0]_i_1__0 
       (.I0(grp_Pool1_24x24x20_2x2x2_fu_86_ap_ready),
        .I1(ap_CS_fsm_state2),
        .I2(\ap_CS_fsm_reg_n_4_[0] ),
        .I3(grp_Pool1_24x24x20_2x2x2_fu_86_ap_start_reg),
        .O(ap_NS_fsm[0]));
  LUT5 #(
    .INIT(32'hFF808080)) 
    \ap_CS_fsm[1]_i_1__1 
       (.I0(ap_CS_fsm_state3),
        .I1(tmp_27_fu_287_p4[2]),
        .I2(tmp_27_fu_287_p4[3]),
        .I3(\ap_CS_fsm_reg_n_4_[0] ),
        .I4(grp_Pool1_24x24x20_2x2x2_fu_86_ap_start_reg),
        .O(ap_NS_fsm[1]));
  (* SOFT_HLUTNM = "soft_lutpair126" *) 
  LUT5 #(
    .INIT(32'h80FF8080)) 
    \ap_CS_fsm[2]_i_1__5 
       (.I0(ap_CS_fsm_state4),
        .I1(y_reg_137[4]),
        .I2(y_reg_137[3]),
        .I3(grp_Pool1_24x24x20_2x2x2_fu_86_ap_ready),
        .I4(ap_CS_fsm_state2),
        .O(ap_NS_fsm[2]));
  LUT4 #(
    .INIT(16'hFF2A)) 
    \ap_CS_fsm[3]_i_1 
       (.I0(ap_CS_fsm_state3),
        .I1(tmp_27_fu_287_p4[2]),
        .I2(tmp_27_fu_287_p4[3]),
        .I3(ap_CS_fsm_state10),
        .O(ap_NS_fsm[3]));
  (* SOFT_HLUTNM = "soft_lutpair126" *) 
  LUT3 #(
    .INIT(8'h70)) 
    \ap_CS_fsm[4]_i_1__1 
       (.I0(y_reg_137[3]),
        .I1(y_reg_137[4]),
        .I2(ap_CS_fsm_state4),
        .O(ap_NS_fsm[4]));
  LUT2 #(
    .INIT(4'hE)) 
    \ap_CS_fsm[7]_i_1 
       (.I0(ap_CS_fsm_state7),
        .I1(ap_CS_fsm_state9),
        .O(ap_NS_fsm[7]));
  (* SOFT_HLUTNM = "soft_lutpair128" *) 
  LUT4 #(
    .INIT(16'hFB00)) 
    \ap_CS_fsm[8]_i_1 
       (.I0(\i_reg_160_reg_n_4_[1] ),
        .I1(\i_reg_160_reg_n_4_[2] ),
        .I2(\i_reg_160_reg_n_4_[0] ),
        .I3(ap_CS_fsm_state8),
        .O(ap_NS_fsm[8]));
  (* SOFT_HLUTNM = "soft_lutpair128" *) 
  LUT4 #(
    .INIT(16'h0400)) 
    \ap_CS_fsm[9]_i_1 
       (.I0(\i_reg_160_reg_n_4_[1] ),
        .I1(\i_reg_160_reg_n_4_[2] ),
        .I2(\i_reg_160_reg_n_4_[0] ),
        .I3(ap_CS_fsm_state8),
        .O(ap_NS_fsm[9]));
  (* FSM_ENCODING = "none" *) 
  FDSE #(
    .INIT(1'b1)) 
    \ap_CS_fsm_reg[0] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[0]),
        .Q(\ap_CS_fsm_reg_n_4_[0] ),
        .S(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[1] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[1]),
        .Q(ap_CS_fsm_state2),
        .R(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[2] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[2]),
        .Q(ap_CS_fsm_state3),
        .R(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[3] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[3]),
        .Q(ap_CS_fsm_state4),
        .R(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[4] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[4]),
        .Q(ap_CS_fsm_state5),
        .R(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[5] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_state5),
        .Q(ap_CS_fsm_state6),
        .R(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[6] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_state6),
        .Q(ap_CS_fsm_state7),
        .R(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[7] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[7]),
        .Q(ap_CS_fsm_state8),
        .R(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[8] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[8]),
        .Q(ap_CS_fsm_state9),
        .R(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[9] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[9]),
        .Q(ap_CS_fsm_state10),
        .R(ap_rst_n));
  LUT6 #(
    .INIT(64'h51FF51FF515151FF)) 
    ap_ready_INST_0_i_2
       (.I0(grp_Pool1_24x24x20_2x2x2_fu_86_ap_ready),
        .I1(\ap_CS_fsm_reg_n_4_[0] ),
        .I2(grp_Pool1_24x24x20_2x2x2_fu_86_ap_start_reg),
        .I3(grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_ready),
        .I4(Q),
        .I5(grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg),
        .O(\ap_CS_fsm_reg[3]_0 ));
  LUT6 #(
    .INIT(64'h0000020000000000)) 
    ap_ready_INST_0_i_3
       (.I0(p_shl2_cast_fu_207_p1[9]),
        .I1(p_shl2_cast_fu_207_p1[8]),
        .I2(p_shl2_cast_fu_207_p1[6]),
        .I3(p_shl2_cast_fu_207_p1[7]),
        .I4(p_shl2_cast_fu_207_p1[5]),
        .I5(ap_CS_fsm_state2),
        .O(grp_Pool1_24x24x20_2x2x2_fu_86_ap_ready));
  (* SOFT_HLUTNM = "soft_lutpair130" *) 
  LUT3 #(
    .INIT(8'hBA)) 
    grp_Pool1_24x24x20_2x2x2_fu_86_ap_start_reg_i_1
       (.I0(\ap_CS_fsm_reg[2]_0 ),
        .I1(grp_Pool1_24x24x20_2x2x2_fu_86_ap_ready),
        .I2(grp_Pool1_24x24x20_2x2x2_fu_86_ap_start_reg),
        .O(grp_Pool1_24x24x20_2x2x2_fu_86_ap_start_reg_reg));
  LUT5 #(
    .INIT(32'h77772202)) 
    \i_2_reg_627[0]_i_1 
       (.I0(ap_CS_fsm_state8),
        .I1(\i_reg_160_reg_n_4_[0] ),
        .I2(\i_reg_160_reg_n_4_[2] ),
        .I3(\i_reg_160_reg_n_4_[1] ),
        .I4(i_2_reg_627[0]),
        .O(\i_2_reg_627[0]_i_1_n_4 ));
  LUT5 #(
    .INIT(32'h77FD2288)) 
    \i_2_reg_627[1]_i_1 
       (.I0(ap_CS_fsm_state8),
        .I1(\i_reg_160_reg_n_4_[0] ),
        .I2(\i_reg_160_reg_n_4_[2] ),
        .I3(\i_reg_160_reg_n_4_[1] ),
        .I4(i_2_reg_627[1]),
        .O(\i_2_reg_627[1]_i_1_n_4 ));
  LUT5 #(
    .INIT(32'h7DF52880)) 
    \i_2_reg_627[2]_i_1 
       (.I0(ap_CS_fsm_state8),
        .I1(\i_reg_160_reg_n_4_[0] ),
        .I2(\i_reg_160_reg_n_4_[2] ),
        .I3(\i_reg_160_reg_n_4_[1] ),
        .I4(i_2_reg_627[2]),
        .O(\i_2_reg_627[2]_i_1_n_4 ));
  FDRE \i_2_reg_627_reg[0] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\i_2_reg_627[0]_i_1_n_4 ),
        .Q(i_2_reg_627[0]),
        .R(1'b0));
  FDRE \i_2_reg_627_reg[1] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\i_2_reg_627[1]_i_1_n_4 ),
        .Q(i_2_reg_627[1]),
        .R(1'b0));
  FDRE \i_2_reg_627_reg[2] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\i_2_reg_627[2]_i_1_n_4 ),
        .Q(i_2_reg_627[2]),
        .R(1'b0));
  LUT4 #(
    .INIT(16'hCFCA)) 
    \i_reg_160[0]_i_1 
       (.I0(\i_reg_160_reg_n_4_[0] ),
        .I1(i_2_reg_627[0]),
        .I2(ap_CS_fsm_state9),
        .I3(ap_CS_fsm_state7),
        .O(\i_reg_160[0]_i_1_n_4 ));
  LUT4 #(
    .INIT(16'hC0CA)) 
    \i_reg_160[1]_i_1 
       (.I0(\i_reg_160_reg_n_4_[1] ),
        .I1(i_2_reg_627[1]),
        .I2(ap_CS_fsm_state9),
        .I3(ap_CS_fsm_state7),
        .O(\i_reg_160[1]_i_1_n_4 ));
  LUT4 #(
    .INIT(16'hC0CA)) 
    \i_reg_160[2]_i_1 
       (.I0(\i_reg_160_reg_n_4_[2] ),
        .I1(i_2_reg_627[2]),
        .I2(ap_CS_fsm_state9),
        .I3(ap_CS_fsm_state7),
        .O(\i_reg_160[2]_i_1_n_4 ));
  FDRE \i_reg_160_reg[0] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\i_reg_160[0]_i_1_n_4 ),
        .Q(\i_reg_160_reg_n_4_[0] ),
        .R(1'b0));
  FDRE \i_reg_160_reg[1] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\i_reg_160[1]_i_1_n_4 ),
        .Q(\i_reg_160_reg_n_4_[1] ),
        .R(1'b0));
  FDRE \i_reg_160_reg[2] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\i_reg_160[2]_i_1_n_4 ),
        .Q(\i_reg_160_reg_n_4_[2] ),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair133" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \x_reg_125[1]_i_1 
       (.I0(\x_reg_125_reg_n_4_[1] ),
        .O(x_2_fu_342_p2[1]));
  (* SOFT_HLUTNM = "soft_lutpair133" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \x_reg_125[2]_i_1 
       (.I0(\x_reg_125_reg_n_4_[1] ),
        .I1(\x_reg_125_reg_n_4_[2] ),
        .O(x_2_fu_342_p2[2]));
  (* SOFT_HLUTNM = "soft_lutpair129" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \x_reg_125[3]_i_1 
       (.I0(\x_reg_125_reg_n_4_[1] ),
        .I1(\x_reg_125_reg_n_4_[2] ),
        .I2(tmp_27_fu_287_p4[2]),
        .O(x_2_fu_342_p2[3]));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAA2AAAA)) 
    \x_reg_125[4]_i_1 
       (.I0(ap_CS_fsm_state2),
        .I1(p_shl2_cast_fu_207_p1[9]),
        .I2(p_shl2_cast_fu_207_p1[8]),
        .I3(p_shl2_cast_fu_207_p1[6]),
        .I4(p_shl2_cast_fu_207_p1[7]),
        .I5(p_shl2_cast_fu_207_p1[5]),
        .O(x_reg_1250));
  LUT3 #(
    .INIT(8'h80)) 
    \x_reg_125[4]_i_2 
       (.I0(ap_CS_fsm_state4),
        .I1(y_reg_137[4]),
        .I2(y_reg_137[3]),
        .O(ap_NS_fsm12_out));
  (* SOFT_HLUTNM = "soft_lutpair129" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \x_reg_125[4]_i_3 
       (.I0(\x_reg_125_reg_n_4_[2] ),
        .I1(\x_reg_125_reg_n_4_[1] ),
        .I2(tmp_27_fu_287_p4[2]),
        .I3(tmp_27_fu_287_p4[3]),
        .O(x_2_fu_342_p2[4]));
  FDRE \x_reg_125_reg[1] 
       (.C(ap_clk),
        .CE(ap_NS_fsm12_out),
        .D(x_2_fu_342_p2[1]),
        .Q(\x_reg_125_reg_n_4_[1] ),
        .R(x_reg_1250));
  FDRE \x_reg_125_reg[2] 
       (.C(ap_clk),
        .CE(ap_NS_fsm12_out),
        .D(x_2_fu_342_p2[2]),
        .Q(\x_reg_125_reg_n_4_[2] ),
        .R(x_reg_1250));
  FDRE \x_reg_125_reg[3] 
       (.C(ap_clk),
        .CE(ap_NS_fsm12_out),
        .D(x_2_fu_342_p2[3]),
        .Q(tmp_27_fu_287_p4[2]),
        .R(x_reg_1250));
  FDRE \x_reg_125_reg[4] 
       (.C(ap_clk),
        .CE(ap_NS_fsm12_out),
        .D(x_2_fu_342_p2[4]),
        .Q(tmp_27_fu_287_p4[3]),
        .R(x_reg_1250));
  (* SOFT_HLUTNM = "soft_lutpair134" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \y_2_reg_637[1]_i_1 
       (.I0(y_reg_137[1]),
        .O(y_2_fu_495_p2[1]));
  (* SOFT_HLUTNM = "soft_lutpair134" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \y_2_reg_637[2]_i_1 
       (.I0(y_reg_137[1]),
        .I1(y_reg_137[2]),
        .O(y_2_fu_495_p2[2]));
  (* SOFT_HLUTNM = "soft_lutpair131" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \y_2_reg_637[3]_i_1 
       (.I0(y_reg_137[1]),
        .I1(y_reg_137[2]),
        .I2(y_reg_137[3]),
        .O(y_2_fu_495_p2[3]));
  LUT4 #(
    .INIT(16'h0400)) 
    \y_2_reg_637[4]_i_1 
       (.I0(\i_reg_160_reg_n_4_[0] ),
        .I1(\i_reg_160_reg_n_4_[2] ),
        .I2(\i_reg_160_reg_n_4_[1] ),
        .I3(ap_CS_fsm_state8),
        .O(tmp_42_reg_6320));
  (* SOFT_HLUTNM = "soft_lutpair131" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \y_2_reg_637[4]_i_2 
       (.I0(y_reg_137[2]),
        .I1(y_reg_137[1]),
        .I2(y_reg_137[3]),
        .I3(y_reg_137[4]),
        .O(y_2_fu_495_p2[4]));
  FDRE \y_2_reg_637_reg[1] 
       (.C(ap_clk),
        .CE(tmp_42_reg_6320),
        .D(y_2_fu_495_p2[1]),
        .Q(y_2_reg_637[1]),
        .R(1'b0));
  FDRE \y_2_reg_637_reg[2] 
       (.C(ap_clk),
        .CE(tmp_42_reg_6320),
        .D(y_2_fu_495_p2[2]),
        .Q(y_2_reg_637[2]),
        .R(1'b0));
  FDRE \y_2_reg_637_reg[3] 
       (.C(ap_clk),
        .CE(tmp_42_reg_6320),
        .D(y_2_fu_495_p2[3]),
        .Q(y_2_reg_637[3]),
        .R(1'b0));
  FDRE \y_2_reg_637_reg[4] 
       (.C(ap_clk),
        .CE(tmp_42_reg_6320),
        .D(y_2_fu_495_p2[4]),
        .Q(y_2_reg_637[4]),
        .R(1'b0));
  LUT3 #(
    .INIT(8'h70)) 
    \y_reg_137[4]_i_1 
       (.I0(tmp_27_fu_287_p4[2]),
        .I1(tmp_27_fu_287_p4[3]),
        .I2(ap_CS_fsm_state3),
        .O(y_reg_1370));
  FDRE \y_reg_137_reg[1] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state10),
        .D(y_2_reg_637[1]),
        .Q(y_reg_137[1]),
        .R(y_reg_1370));
  FDRE \y_reg_137_reg[2] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state10),
        .D(y_2_reg_637[2]),
        .Q(y_reg_137[2]),
        .R(y_reg_1370));
  FDRE \y_reg_137_reg[3] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state10),
        .D(y_2_reg_637[3]),
        .Q(y_reg_137[3]),
        .R(y_reg_1370));
  FDRE \y_reg_137_reg[4] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state10),
        .D(y_2_reg_637[4]),
        .Q(y_reg_137[4]),
        .R(y_reg_1370));
  LUT1 #(
    .INIT(2'h1)) 
    \z_2_reg_526[0]_i_1 
       (.I0(p_shl2_cast_fu_207_p1[5]),
        .O(z_2_fu_193_p2[0]));
  (* SOFT_HLUTNM = "soft_lutpair132" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \z_2_reg_526[1]_i_1 
       (.I0(p_shl2_cast_fu_207_p1[5]),
        .I1(p_shl2_cast_fu_207_p1[6]),
        .O(z_2_fu_193_p2[1]));
  (* SOFT_HLUTNM = "soft_lutpair132" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \z_2_reg_526[2]_i_1 
       (.I0(p_shl2_cast_fu_207_p1[5]),
        .I1(p_shl2_cast_fu_207_p1[6]),
        .I2(p_shl2_cast_fu_207_p1[7]),
        .O(z_2_fu_193_p2[2]));
  (* SOFT_HLUTNM = "soft_lutpair127" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \z_2_reg_526[3]_i_1 
       (.I0(p_shl2_cast_fu_207_p1[6]),
        .I1(p_shl2_cast_fu_207_p1[5]),
        .I2(p_shl2_cast_fu_207_p1[7]),
        .I3(p_shl2_cast_fu_207_p1[8]),
        .O(z_2_fu_193_p2[3]));
  (* SOFT_HLUTNM = "soft_lutpair127" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \z_2_reg_526[4]_i_1 
       (.I0(p_shl2_cast_fu_207_p1[7]),
        .I1(p_shl2_cast_fu_207_p1[5]),
        .I2(p_shl2_cast_fu_207_p1[6]),
        .I3(p_shl2_cast_fu_207_p1[8]),
        .I4(p_shl2_cast_fu_207_p1[9]),
        .O(z_2_fu_193_p2[4]));
  FDRE \z_2_reg_526_reg[0] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state2),
        .D(z_2_fu_193_p2[0]),
        .Q(z_2_reg_526[0]),
        .R(1'b0));
  FDRE \z_2_reg_526_reg[1] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state2),
        .D(z_2_fu_193_p2[1]),
        .Q(z_2_reg_526[1]),
        .R(1'b0));
  FDRE \z_2_reg_526_reg[2] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state2),
        .D(z_2_fu_193_p2[2]),
        .Q(z_2_reg_526[2]),
        .R(1'b0));
  FDRE \z_2_reg_526_reg[3] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state2),
        .D(z_2_fu_193_p2[3]),
        .Q(z_2_reg_526[3]),
        .R(1'b0));
  FDRE \z_2_reg_526_reg[4] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state2),
        .D(z_2_fu_193_p2[4]),
        .Q(z_2_reg_526[4]),
        .R(1'b0));
  LUT5 #(
    .INIT(32'h08888888)) 
    \z_reg_114[4]_i_1 
       (.I0(grp_Pool1_24x24x20_2x2x2_fu_86_ap_start_reg),
        .I1(\ap_CS_fsm_reg_n_4_[0] ),
        .I2(tmp_27_fu_287_p4[3]),
        .I3(tmp_27_fu_287_p4[2]),
        .I4(ap_CS_fsm_state3),
        .O(z_reg_114));
  LUT3 #(
    .INIT(8'h80)) 
    \z_reg_114[4]_i_2 
       (.I0(ap_CS_fsm_state3),
        .I1(tmp_27_fu_287_p4[2]),
        .I2(tmp_27_fu_287_p4[3]),
        .O(ap_NS_fsm14_out));
  FDRE \z_reg_114_reg[0] 
       (.C(ap_clk),
        .CE(ap_NS_fsm14_out),
        .D(z_2_reg_526[0]),
        .Q(p_shl2_cast_fu_207_p1[5]),
        .R(z_reg_114));
  FDRE \z_reg_114_reg[1] 
       (.C(ap_clk),
        .CE(ap_NS_fsm14_out),
        .D(z_2_reg_526[1]),
        .Q(p_shl2_cast_fu_207_p1[6]),
        .R(z_reg_114));
  FDRE \z_reg_114_reg[2] 
       (.C(ap_clk),
        .CE(ap_NS_fsm14_out),
        .D(z_2_reg_526[2]),
        .Q(p_shl2_cast_fu_207_p1[7]),
        .R(z_reg_114));
  FDRE \z_reg_114_reg[3] 
       (.C(ap_clk),
        .CE(ap_NS_fsm14_out),
        .D(z_2_reg_526[3]),
        .Q(p_shl2_cast_fu_207_p1[8]),
        .R(z_reg_114));
  FDRE \z_reg_114_reg[4] 
       (.C(ap_clk),
        .CE(ap_NS_fsm14_out),
        .D(z_2_reg_526[4]),
        .Q(p_shl2_cast_fu_207_p1[9]),
        .R(z_reg_114));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Pool2_8x8x40_2x2x40_s
   (grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_ready,
    Q,
    grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg_reg,
    grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg,
    \ap_CS_fsm_reg[2]_0 ,
    ap_clk,
    ap_rst_n);
  output grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_ready;
  output [0:0]Q;
  output grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg_reg;
  input grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg;
  input [0:0]\ap_CS_fsm_reg[2]_0 ;
  input ap_clk;
  input ap_rst_n;

  wire [0:0]Q;
  wire [0:0]\ap_CS_fsm_reg[2]_0 ;
  wire ap_CS_fsm_state2;
  wire ap_CS_fsm_state3;
  wire ap_CS_fsm_state4;
  wire ap_CS_fsm_state5;
  wire ap_CS_fsm_state6;
  wire [6:0]ap_NS_fsm;
  wire ap_NS_fsm11_out;
  wire ap_clk;
  wire ap_rst_n;
  wire exitcond1_fu_185_p2__6;
  wire grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_ready;
  wire grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg;
  wire grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg_reg;
  wire [9:4]grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0;
  wire grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_ce0;
  wire grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_we0;
  wire \i_reg_158[0]_i_1_n_4 ;
  wire \i_reg_158[1]_i_1_n_4 ;
  wire \i_reg_158[2]_i_1_n_4 ;
  wire \i_reg_158_reg_n_4_[0] ;
  wire \i_reg_158_reg_n_4_[1] ;
  wire \i_reg_158_reg_n_4_[2] ;
  wire x_reg_1240;
  wire \x_reg_124[1]_i_1_n_4 ;
  wire \x_reg_124[2]_i_1_n_4 ;
  wire \x_reg_124[3]_i_1_n_4 ;
  wire [3:3]x_reg_124_reg__0;
  wire \x_reg_124_reg_n_4_[1] ;
  wire \x_reg_124_reg_n_4_[2] ;
  wire \y_reg_136[1]_i_1_n_4 ;
  wire \y_reg_136[2]_i_1_n_4 ;
  wire \y_reg_136[3]_i_1_n_4 ;
  wire [3:3]y_reg_136_reg__0;
  wire \y_reg_136_reg_n_4_[1] ;
  wire \y_reg_136_reg_n_4_[2] ;
  wire [5:0]z_1_fu_191_p2;
  wire [5:0]z_1_reg_432;
  wire z_reg_112;

  (* SOFT_HLUTNM = "soft_lutpair141" *) 
  LUT4 #(
    .INIT(16'h88F8)) 
    \ap_CS_fsm[0]_i_1__3 
       (.I0(grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_ready),
        .I1(ap_CS_fsm_state2),
        .I2(Q),
        .I3(grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg),
        .O(ap_NS_fsm[0]));
  LUT4 #(
    .INIT(16'hF888)) 
    \ap_CS_fsm[1]_i_1__3 
       (.I0(ap_CS_fsm_state3),
        .I1(x_reg_124_reg__0),
        .I2(Q),
        .I3(grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg),
        .O(ap_NS_fsm[1]));
  (* SOFT_HLUTNM = "soft_lutpair140" *) 
  LUT4 #(
    .INIT(16'h8F88)) 
    \ap_CS_fsm[2]_i_1__1 
       (.I0(ap_CS_fsm_state4),
        .I1(y_reg_136_reg__0),
        .I2(grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_ready),
        .I3(ap_CS_fsm_state2),
        .O(ap_NS_fsm[2]));
  LUT6 #(
    .INIT(64'h04000400FFFF0400)) 
    \ap_CS_fsm[3]_i_1__1 
       (.I0(\i_reg_158_reg_n_4_[0] ),
        .I1(\i_reg_158_reg_n_4_[2] ),
        .I2(\i_reg_158_reg_n_4_[1] ),
        .I3(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_ce0),
        .I4(ap_CS_fsm_state3),
        .I5(x_reg_124_reg__0),
        .O(ap_NS_fsm[3]));
  (* SOFT_HLUTNM = "soft_lutpair140" *) 
  LUT2 #(
    .INIT(4'h4)) 
    \ap_CS_fsm[4]_i_1__0 
       (.I0(y_reg_136_reg__0),
        .I1(ap_CS_fsm_state4),
        .O(ap_NS_fsm[4]));
  (* SOFT_HLUTNM = "soft_lutpair136" *) 
  LUT5 #(
    .INIT(32'hFFFFFB00)) 
    \ap_CS_fsm[6]_i_1 
       (.I0(\i_reg_158_reg_n_4_[0] ),
        .I1(\i_reg_158_reg_n_4_[2] ),
        .I2(\i_reg_158_reg_n_4_[1] ),
        .I3(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_ce0),
        .I4(ap_CS_fsm_state6),
        .O(ap_NS_fsm[6]));
  (* FSM_ENCODING = "none" *) 
  FDSE #(
    .INIT(1'b1)) 
    \ap_CS_fsm_reg[0] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[0]),
        .Q(Q),
        .S(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[1] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[1]),
        .Q(ap_CS_fsm_state2),
        .R(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[2] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[2]),
        .Q(ap_CS_fsm_state3),
        .R(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[3] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[3]),
        .Q(ap_CS_fsm_state4),
        .R(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[4] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[4]),
        .Q(ap_CS_fsm_state5),
        .R(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[5] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_state5),
        .Q(ap_CS_fsm_state6),
        .R(ap_rst_n));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[6] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[6]),
        .Q(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_ce0),
        .R(ap_rst_n));
  (* SOFT_HLUTNM = "soft_lutpair138" *) 
  LUT2 #(
    .INIT(4'h8)) 
    ap_ready_INST_0_i_4
       (.I0(exitcond1_fu_185_p2__6),
        .I1(ap_CS_fsm_state2),
        .O(grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_ready));
  (* SOFT_HLUTNM = "soft_lutpair141" *) 
  LUT3 #(
    .INIT(8'hBA)) 
    grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg_i_1
       (.I0(\ap_CS_fsm_reg[2]_0 ),
        .I1(grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_ready),
        .I2(grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg),
        .O(grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg_reg));
  (* SOFT_HLUTNM = "soft_lutpair135" *) 
  LUT5 #(
    .INIT(32'h77776646)) 
    \i_reg_158[0]_i_1 
       (.I0(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_ce0),
        .I1(\i_reg_158_reg_n_4_[0] ),
        .I2(\i_reg_158_reg_n_4_[2] ),
        .I3(\i_reg_158_reg_n_4_[1] ),
        .I4(ap_CS_fsm_state6),
        .O(\i_reg_158[0]_i_1_n_4 ));
  LUT4 #(
    .INIT(16'h2878)) 
    \i_reg_158[1]_i_1 
       (.I0(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_ce0),
        .I1(\i_reg_158_reg_n_4_[0] ),
        .I2(\i_reg_158_reg_n_4_[1] ),
        .I3(ap_CS_fsm_state6),
        .O(\i_reg_158[1]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair135" *) 
  LUT5 #(
    .INIT(32'h288078F0)) 
    \i_reg_158[2]_i_1 
       (.I0(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_ce0),
        .I1(\i_reg_158_reg_n_4_[0] ),
        .I2(\i_reg_158_reg_n_4_[2] ),
        .I3(\i_reg_158_reg_n_4_[1] ),
        .I4(ap_CS_fsm_state6),
        .O(\i_reg_158[2]_i_1_n_4 ));
  FDRE \i_reg_158_reg[0] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\i_reg_158[0]_i_1_n_4 ),
        .Q(\i_reg_158_reg_n_4_[0] ),
        .R(1'b0));
  FDRE \i_reg_158_reg[1] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\i_reg_158[1]_i_1_n_4 ),
        .Q(\i_reg_158_reg_n_4_[1] ),
        .R(1'b0));
  FDRE \i_reg_158_reg[2] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\i_reg_158[2]_i_1_n_4 ),
        .Q(\i_reg_158_reg_n_4_[2] ),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair138" *) 
  LUT5 #(
    .INIT(32'h6A006A6A)) 
    \x_reg_124[1]_i_1 
       (.I0(\x_reg_124_reg_n_4_[1] ),
        .I1(ap_CS_fsm_state4),
        .I2(y_reg_136_reg__0),
        .I3(exitcond1_fu_185_p2__6),
        .I4(ap_CS_fsm_state2),
        .O(\x_reg_124[1]_i_1_n_4 ));
  LUT6 #(
    .INIT(64'h6AAA00006AAA6AAA)) 
    \x_reg_124[2]_i_1 
       (.I0(\x_reg_124_reg_n_4_[2] ),
        .I1(y_reg_136_reg__0),
        .I2(ap_CS_fsm_state4),
        .I3(\x_reg_124_reg_n_4_[1] ),
        .I4(exitcond1_fu_185_p2__6),
        .I5(ap_CS_fsm_state2),
        .O(\x_reg_124[2]_i_1_n_4 ));
  LUT6 #(
    .INIT(64'h0000000200000000)) 
    \x_reg_124[2]_i_2 
       (.I0(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[7]),
        .I1(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[6]),
        .I2(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[4]),
        .I3(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[5]),
        .I4(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[8]),
        .I5(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[9]),
        .O(exitcond1_fu_185_p2__6));
  LUT6 #(
    .INIT(64'h000000006AAAAAAA)) 
    \x_reg_124[3]_i_1 
       (.I0(x_reg_124_reg__0),
        .I1(y_reg_136_reg__0),
        .I2(ap_CS_fsm_state4),
        .I3(\x_reg_124_reg_n_4_[2] ),
        .I4(\x_reg_124_reg_n_4_[1] ),
        .I5(x_reg_1240),
        .O(\x_reg_124[3]_i_1_n_4 ));
  LUT2 #(
    .INIT(4'h2)) 
    \x_reg_124[3]_i_2 
       (.I0(ap_CS_fsm_state2),
        .I1(exitcond1_fu_185_p2__6),
        .O(x_reg_1240));
  FDRE \x_reg_124_reg[1] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\x_reg_124[1]_i_1_n_4 ),
        .Q(\x_reg_124_reg_n_4_[1] ),
        .R(1'b0));
  FDRE \x_reg_124_reg[2] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\x_reg_124[2]_i_1_n_4 ),
        .Q(\x_reg_124_reg_n_4_[2] ),
        .R(1'b0));
  FDRE \x_reg_124_reg[3] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\x_reg_124[3]_i_1_n_4 ),
        .Q(x_reg_124_reg__0),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair137" *) 
  LUT4 #(
    .INIT(16'h6066)) 
    \y_reg_136[1]_i_1 
       (.I0(\y_reg_136_reg_n_4_[1] ),
        .I1(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_we0),
        .I2(x_reg_124_reg__0),
        .I3(ap_CS_fsm_state3),
        .O(\y_reg_136[1]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair137" *) 
  LUT5 #(
    .INIT(32'h6A006A6A)) 
    \y_reg_136[2]_i_1 
       (.I0(\y_reg_136_reg_n_4_[2] ),
        .I1(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_we0),
        .I2(\y_reg_136_reg_n_4_[1] ),
        .I3(x_reg_124_reg__0),
        .I4(ap_CS_fsm_state3),
        .O(\y_reg_136[2]_i_1_n_4 ));
  LUT6 #(
    .INIT(64'h6AAA00006AAA6AAA)) 
    \y_reg_136[3]_i_1 
       (.I0(y_reg_136_reg__0),
        .I1(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_we0),
        .I2(\y_reg_136_reg_n_4_[2] ),
        .I3(\y_reg_136_reg_n_4_[1] ),
        .I4(x_reg_124_reg__0),
        .I5(ap_CS_fsm_state3),
        .O(\y_reg_136[3]_i_1_n_4 ));
  (* SOFT_HLUTNM = "soft_lutpair136" *) 
  LUT4 #(
    .INIT(16'h0400)) 
    \y_reg_136[3]_i_2 
       (.I0(\i_reg_158_reg_n_4_[0] ),
        .I1(\i_reg_158_reg_n_4_[2] ),
        .I2(\i_reg_158_reg_n_4_[1] ),
        .I3(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_ce0),
        .O(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_we0));
  FDRE \y_reg_136_reg[1] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\y_reg_136[1]_i_1_n_4 ),
        .Q(\y_reg_136_reg_n_4_[1] ),
        .R(1'b0));
  FDRE \y_reg_136_reg[2] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\y_reg_136[2]_i_1_n_4 ),
        .Q(\y_reg_136_reg_n_4_[2] ),
        .R(1'b0));
  FDRE \y_reg_136_reg[3] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\y_reg_136[3]_i_1_n_4 ),
        .Q(y_reg_136_reg__0),
        .R(1'b0));
  LUT1 #(
    .INIT(2'h1)) 
    \z_1_reg_432[0]_i_1 
       (.I0(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[4]),
        .O(z_1_fu_191_p2[0]));
  (* SOFT_HLUTNM = "soft_lutpair142" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \z_1_reg_432[1]_i_1 
       (.I0(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[4]),
        .I1(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[5]),
        .O(z_1_fu_191_p2[1]));
  (* SOFT_HLUTNM = "soft_lutpair142" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \z_1_reg_432[2]_i_1 
       (.I0(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[4]),
        .I1(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[5]),
        .I2(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[6]),
        .O(z_1_fu_191_p2[2]));
  (* SOFT_HLUTNM = "soft_lutpair139" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \z_1_reg_432[3]_i_1 
       (.I0(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[5]),
        .I1(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[4]),
        .I2(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[6]),
        .I3(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[7]),
        .O(z_1_fu_191_p2[3]));
  (* SOFT_HLUTNM = "soft_lutpair139" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \z_1_reg_432[4]_i_1 
       (.I0(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[6]),
        .I1(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[4]),
        .I2(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[5]),
        .I3(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[7]),
        .I4(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[8]),
        .O(z_1_fu_191_p2[4]));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \z_1_reg_432[5]_i_1 
       (.I0(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[7]),
        .I1(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[5]),
        .I2(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[4]),
        .I3(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[6]),
        .I4(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[8]),
        .I5(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[9]),
        .O(z_1_fu_191_p2[5]));
  FDRE \z_1_reg_432_reg[0] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state2),
        .D(z_1_fu_191_p2[0]),
        .Q(z_1_reg_432[0]),
        .R(1'b0));
  FDRE \z_1_reg_432_reg[1] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state2),
        .D(z_1_fu_191_p2[1]),
        .Q(z_1_reg_432[1]),
        .R(1'b0));
  FDRE \z_1_reg_432_reg[2] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state2),
        .D(z_1_fu_191_p2[2]),
        .Q(z_1_reg_432[2]),
        .R(1'b0));
  FDRE \z_1_reg_432_reg[3] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state2),
        .D(z_1_fu_191_p2[3]),
        .Q(z_1_reg_432[3]),
        .R(1'b0));
  FDRE \z_1_reg_432_reg[4] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state2),
        .D(z_1_fu_191_p2[4]),
        .Q(z_1_reg_432[4]),
        .R(1'b0));
  FDRE \z_1_reg_432_reg[5] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state2),
        .D(z_1_fu_191_p2[5]),
        .Q(z_1_reg_432[5]),
        .R(1'b0));
  LUT4 #(
    .INIT(16'h0888)) 
    \z_reg_112[5]_i_1 
       (.I0(grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg),
        .I1(Q),
        .I2(x_reg_124_reg__0),
        .I3(ap_CS_fsm_state3),
        .O(z_reg_112));
  LUT2 #(
    .INIT(4'h8)) 
    \z_reg_112[5]_i_2 
       (.I0(ap_CS_fsm_state3),
        .I1(x_reg_124_reg__0),
        .O(ap_NS_fsm11_out));
  FDRE \z_reg_112_reg[0] 
       (.C(ap_clk),
        .CE(ap_NS_fsm11_out),
        .D(z_1_reg_432[0]),
        .Q(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[4]),
        .R(z_reg_112));
  FDRE \z_reg_112_reg[1] 
       (.C(ap_clk),
        .CE(ap_NS_fsm11_out),
        .D(z_1_reg_432[1]),
        .Q(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[5]),
        .R(z_reg_112));
  FDRE \z_reg_112_reg[2] 
       (.C(ap_clk),
        .CE(ap_NS_fsm11_out),
        .D(z_1_reg_432[2]),
        .Q(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[6]),
        .R(z_reg_112));
  FDRE \z_reg_112_reg[3] 
       (.C(ap_clk),
        .CE(ap_NS_fsm11_out),
        .D(z_1_reg_432[3]),
        .Q(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[7]),
        .R(z_reg_112));
  FDRE \z_reg_112_reg[4] 
       (.C(ap_clk),
        .CE(ap_NS_fsm11_out),
        .D(z_1_reg_432[4]),
        .Q(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[8]),
        .R(z_reg_112));
  FDRE \z_reg_112_reg[5] 
       (.C(ap_clk),
        .CE(ap_NS_fsm11_out),
        .D(z_1_reg_432[5]),
        .Q(grp_Pool2_8x8x40_2x2x40_s_fu_103_output_r_address0[9]),
        .R(z_reg_112));
endmodule

(* ap_ST_fsm_state1 = "4'b0001" *) (* ap_ST_fsm_state2 = "4'b0010" *) (* ap_ST_fsm_state3 = "4'b0100" *) 
(* ap_ST_fsm_state4 = "4'b1000" *) (* hls_module = "yes" *) 
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_lenet_cnn
   (ap_clk,
    ap_rst_n,
    ap_start,
    ap_done,
    ap_idle,
    ap_ready,
    input_r_Addr_A,
    input_r_EN_A,
    input_r_WEN_A,
    input_r_Din_A,
    input_r_Dout_A,
    input_r_Clk_A,
    input_r_Rst_A,
    conv1_kernel_Addr_A,
    conv1_kernel_EN_A,
    conv1_kernel_WEN_A,
    conv1_kernel_Din_A,
    conv1_kernel_Dout_A,
    conv1_kernel_Clk_A,
    conv1_kernel_Rst_A,
    conv1_bias_Addr_A,
    conv1_bias_EN_A,
    conv1_bias_WEN_A,
    conv1_bias_Din_A,
    conv1_bias_Dout_A,
    conv1_bias_Clk_A,
    conv1_bias_Rst_A,
    conv2_bias_Addr_A,
    conv2_bias_EN_A,
    conv2_bias_WEN_A,
    conv2_bias_Din_A,
    conv2_bias_Dout_A,
    conv2_bias_Clk_A,
    conv2_bias_Rst_A,
    fc1_bias_Addr_A,
    fc1_bias_EN_A,
    fc1_bias_WEN_A,
    fc1_bias_Din_A,
    fc1_bias_Dout_A,
    fc1_bias_Clk_A,
    fc1_bias_Rst_A,
    fc2_kernel_Addr_A,
    fc2_kernel_EN_A,
    fc2_kernel_WEN_A,
    fc2_kernel_Din_A,
    fc2_kernel_Dout_A,
    fc2_kernel_Clk_A,
    fc2_kernel_Rst_A,
    fc2_bias_Addr_A,
    fc2_bias_EN_A,
    fc2_bias_WEN_A,
    fc2_bias_Din_A,
    fc2_bias_Dout_A,
    fc2_bias_Clk_A,
    fc2_bias_Rst_A,
    output_r_Addr_A,
    output_r_EN_A,
    output_r_WEN_A,
    output_r_Din_A,
    output_r_Dout_A,
    output_r_Clk_A,
    output_r_Rst_A);
  input ap_clk;
  input ap_rst_n;
  input ap_start;
  output ap_done;
  output ap_idle;
  output ap_ready;
  output [31:0]input_r_Addr_A;
  output input_r_EN_A;
  output [3:0]input_r_WEN_A;
  output [31:0]input_r_Din_A;
  input [31:0]input_r_Dout_A;
  output input_r_Clk_A;
  output input_r_Rst_A;
  output [31:0]conv1_kernel_Addr_A;
  output conv1_kernel_EN_A;
  output [3:0]conv1_kernel_WEN_A;
  output [31:0]conv1_kernel_Din_A;
  input [31:0]conv1_kernel_Dout_A;
  output conv1_kernel_Clk_A;
  output conv1_kernel_Rst_A;
  output [31:0]conv1_bias_Addr_A;
  output conv1_bias_EN_A;
  output [3:0]conv1_bias_WEN_A;
  output [31:0]conv1_bias_Din_A;
  input [31:0]conv1_bias_Dout_A;
  output conv1_bias_Clk_A;
  output conv1_bias_Rst_A;
  output [31:0]conv2_bias_Addr_A;
  output conv2_bias_EN_A;
  output [3:0]conv2_bias_WEN_A;
  output [31:0]conv2_bias_Din_A;
  input [31:0]conv2_bias_Dout_A;
  output conv2_bias_Clk_A;
  output conv2_bias_Rst_A;
  output [31:0]fc1_bias_Addr_A;
  output fc1_bias_EN_A;
  output [3:0]fc1_bias_WEN_A;
  output [31:0]fc1_bias_Din_A;
  input [31:0]fc1_bias_Dout_A;
  output fc1_bias_Clk_A;
  output fc1_bias_Rst_A;
  output [31:0]fc2_kernel_Addr_A;
  output fc2_kernel_EN_A;
  output [3:0]fc2_kernel_WEN_A;
  output [31:0]fc2_kernel_Din_A;
  input [31:0]fc2_kernel_Dout_A;
  output fc2_kernel_Clk_A;
  output fc2_kernel_Rst_A;
  output [31:0]fc2_bias_Addr_A;
  output fc2_bias_EN_A;
  output [3:0]fc2_bias_WEN_A;
  output [31:0]fc2_bias_Din_A;
  input [31:0]fc2_bias_Dout_A;
  output fc2_bias_Clk_A;
  output fc2_bias_Rst_A;
  output [31:0]output_r_Addr_A;
  output output_r_EN_A;
  output [3:0]output_r_WEN_A;
  output [31:0]output_r_Din_A;
  input [31:0]output_r_Dout_A;
  output output_r_Clk_A;
  output output_r_Rst_A;

  wire \<const0> ;
  wire \ap_CS_fsm_reg_n_4_[0] ;
  wire ap_CS_fsm_state2;
  wire ap_CS_fsm_state3;
  wire ap_CS_fsm_state4;
  wire [3:0]ap_NS_fsm;
  wire ap_clk;
  wire ap_done;
  wire ap_idle;
  wire ap_rst_n;
  wire ap_start;
  wire [6:2]\^conv1_bias_Addr_A ;
  wire conv1_bias_EN_A;
  wire [11:2]\^conv1_kernel_Addr_A ;
  wire conv1_kernel_EN_A;
  wire [7:2]\^conv2_bias_Addr_A ;
  wire conv2_bias_EN_A;
  wire [10:2]\^fc1_bias_Addr_A ;
  wire [31:0]fc1_bias_Dout_A;
  wire fc1_bias_EN_A;
  wire [8:0]fc1_output_address0;
  wire fc1_output_ce0;
  wire [30:0]fc1_output_q0;
  wire fc1_output_we0;
  wire [5:2]\^fc2_bias_Addr_A ;
  wire [31:0]fc2_bias_Dout_A;
  wire fc2_bias_EN_A;
  wire [13:2]\^fc2_kernel_Addr_A ;
  wire [31:0]fc2_kernel_Dout_A;
  wire grp_Conv1_28x28x1_5x5x20_fu_74_ap_start_reg;
  wire grp_Conv1_28x28x1_5x5x20_fu_74_n_11;
  wire grp_Conv1_28x28x1_5x5x20_fu_74_n_4;
  wire grp_Conv2_12x12x20_5x5x4_fu_109_ap_ready;
  wire grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg;
  wire grp_Conv2_12x12x20_5x5x4_fu_109_n_13;
  wire grp_Conv2_12x12x20_5x5x4_fu_109_n_5;
  wire grp_Fc1_40_400_fu_117_ap_start_reg;
  wire grp_Fc1_40_400_fu_117_n_27;
  wire [30:0]grp_Fc1_40_400_fu_117_output_r_d0;
  wire grp_Fc2_400_10_fu_92_ap_start_reg;
  wire grp_Fc2_400_10_fu_92_n_66;
  wire grp_Pool1_24x24x20_2x2x2_fu_86_ap_start_reg;
  wire grp_Pool1_24x24x20_2x2x2_fu_86_n_4;
  wire grp_Pool1_24x24x20_2x2x2_fu_86_n_5;
  wire grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_ready;
  wire grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg;
  wire grp_Pool2_8x8x40_2x2x40_s_fu_103_n_5;
  wire grp_Pool2_8x8x40_2x2x40_s_fu_103_n_6;
  wire [8:0]i_reg_137;
  wire [12:2]\^input_r_Addr_A ;
  wire [5:2]\^output_r_Addr_A ;
  wire [30:0]\^output_r_Din_A ;
  wire output_r_EN_A;
  wire output_r_Rst_A;
  wire [0:0]\^output_r_WEN_A ;

  assign ap_ready = ap_done;
  assign conv1_bias_Addr_A[31] = \<const0> ;
  assign conv1_bias_Addr_A[30] = \<const0> ;
  assign conv1_bias_Addr_A[29] = \<const0> ;
  assign conv1_bias_Addr_A[28] = \<const0> ;
  assign conv1_bias_Addr_A[27] = \<const0> ;
  assign conv1_bias_Addr_A[26] = \<const0> ;
  assign conv1_bias_Addr_A[25] = \<const0> ;
  assign conv1_bias_Addr_A[24] = \<const0> ;
  assign conv1_bias_Addr_A[23] = \<const0> ;
  assign conv1_bias_Addr_A[22] = \<const0> ;
  assign conv1_bias_Addr_A[21] = \<const0> ;
  assign conv1_bias_Addr_A[20] = \<const0> ;
  assign conv1_bias_Addr_A[19] = \<const0> ;
  assign conv1_bias_Addr_A[18] = \<const0> ;
  assign conv1_bias_Addr_A[17] = \<const0> ;
  assign conv1_bias_Addr_A[16] = \<const0> ;
  assign conv1_bias_Addr_A[15] = \<const0> ;
  assign conv1_bias_Addr_A[14] = \<const0> ;
  assign conv1_bias_Addr_A[13] = \<const0> ;
  assign conv1_bias_Addr_A[12] = \<const0> ;
  assign conv1_bias_Addr_A[11] = \<const0> ;
  assign conv1_bias_Addr_A[10] = \<const0> ;
  assign conv1_bias_Addr_A[9] = \<const0> ;
  assign conv1_bias_Addr_A[8] = \<const0> ;
  assign conv1_bias_Addr_A[7] = \<const0> ;
  assign conv1_bias_Addr_A[6:2] = \^conv1_bias_Addr_A [6:2];
  assign conv1_bias_Addr_A[1] = \<const0> ;
  assign conv1_bias_Addr_A[0] = \<const0> ;
  assign conv1_bias_Clk_A = ap_clk;
  assign conv1_bias_Din_A[31] = \<const0> ;
  assign conv1_bias_Din_A[30] = \<const0> ;
  assign conv1_bias_Din_A[29] = \<const0> ;
  assign conv1_bias_Din_A[28] = \<const0> ;
  assign conv1_bias_Din_A[27] = \<const0> ;
  assign conv1_bias_Din_A[26] = \<const0> ;
  assign conv1_bias_Din_A[25] = \<const0> ;
  assign conv1_bias_Din_A[24] = \<const0> ;
  assign conv1_bias_Din_A[23] = \<const0> ;
  assign conv1_bias_Din_A[22] = \<const0> ;
  assign conv1_bias_Din_A[21] = \<const0> ;
  assign conv1_bias_Din_A[20] = \<const0> ;
  assign conv1_bias_Din_A[19] = \<const0> ;
  assign conv1_bias_Din_A[18] = \<const0> ;
  assign conv1_bias_Din_A[17] = \<const0> ;
  assign conv1_bias_Din_A[16] = \<const0> ;
  assign conv1_bias_Din_A[15] = \<const0> ;
  assign conv1_bias_Din_A[14] = \<const0> ;
  assign conv1_bias_Din_A[13] = \<const0> ;
  assign conv1_bias_Din_A[12] = \<const0> ;
  assign conv1_bias_Din_A[11] = \<const0> ;
  assign conv1_bias_Din_A[10] = \<const0> ;
  assign conv1_bias_Din_A[9] = \<const0> ;
  assign conv1_bias_Din_A[8] = \<const0> ;
  assign conv1_bias_Din_A[7] = \<const0> ;
  assign conv1_bias_Din_A[6] = \<const0> ;
  assign conv1_bias_Din_A[5] = \<const0> ;
  assign conv1_bias_Din_A[4] = \<const0> ;
  assign conv1_bias_Din_A[3] = \<const0> ;
  assign conv1_bias_Din_A[2] = \<const0> ;
  assign conv1_bias_Din_A[1] = \<const0> ;
  assign conv1_bias_Din_A[0] = \<const0> ;
  assign conv1_bias_Rst_A = output_r_Rst_A;
  assign conv1_bias_WEN_A[3] = \<const0> ;
  assign conv1_bias_WEN_A[2] = \<const0> ;
  assign conv1_bias_WEN_A[1] = \<const0> ;
  assign conv1_bias_WEN_A[0] = \<const0> ;
  assign conv1_kernel_Addr_A[31] = \^conv1_kernel_Addr_A [11];
  assign conv1_kernel_Addr_A[30] = \^conv1_kernel_Addr_A [11];
  assign conv1_kernel_Addr_A[29] = \^conv1_kernel_Addr_A [11];
  assign conv1_kernel_Addr_A[28] = \^conv1_kernel_Addr_A [11];
  assign conv1_kernel_Addr_A[27] = \^conv1_kernel_Addr_A [11];
  assign conv1_kernel_Addr_A[26] = \^conv1_kernel_Addr_A [11];
  assign conv1_kernel_Addr_A[25] = \^conv1_kernel_Addr_A [11];
  assign conv1_kernel_Addr_A[24] = \^conv1_kernel_Addr_A [11];
  assign conv1_kernel_Addr_A[23] = \^conv1_kernel_Addr_A [11];
  assign conv1_kernel_Addr_A[22] = \^conv1_kernel_Addr_A [11];
  assign conv1_kernel_Addr_A[21] = \^conv1_kernel_Addr_A [11];
  assign conv1_kernel_Addr_A[20] = \^conv1_kernel_Addr_A [11];
  assign conv1_kernel_Addr_A[19] = \^conv1_kernel_Addr_A [11];
  assign conv1_kernel_Addr_A[18] = \^conv1_kernel_Addr_A [11];
  assign conv1_kernel_Addr_A[17] = \^conv1_kernel_Addr_A [11];
  assign conv1_kernel_Addr_A[16] = \^conv1_kernel_Addr_A [11];
  assign conv1_kernel_Addr_A[15] = \^conv1_kernel_Addr_A [11];
  assign conv1_kernel_Addr_A[14] = \^conv1_kernel_Addr_A [11];
  assign conv1_kernel_Addr_A[13] = \^conv1_kernel_Addr_A [11];
  assign conv1_kernel_Addr_A[12] = \^conv1_kernel_Addr_A [11];
  assign conv1_kernel_Addr_A[11:2] = \^conv1_kernel_Addr_A [11:2];
  assign conv1_kernel_Addr_A[1] = \<const0> ;
  assign conv1_kernel_Addr_A[0] = \<const0> ;
  assign conv1_kernel_Clk_A = ap_clk;
  assign conv1_kernel_Din_A[31] = \<const0> ;
  assign conv1_kernel_Din_A[30] = \<const0> ;
  assign conv1_kernel_Din_A[29] = \<const0> ;
  assign conv1_kernel_Din_A[28] = \<const0> ;
  assign conv1_kernel_Din_A[27] = \<const0> ;
  assign conv1_kernel_Din_A[26] = \<const0> ;
  assign conv1_kernel_Din_A[25] = \<const0> ;
  assign conv1_kernel_Din_A[24] = \<const0> ;
  assign conv1_kernel_Din_A[23] = \<const0> ;
  assign conv1_kernel_Din_A[22] = \<const0> ;
  assign conv1_kernel_Din_A[21] = \<const0> ;
  assign conv1_kernel_Din_A[20] = \<const0> ;
  assign conv1_kernel_Din_A[19] = \<const0> ;
  assign conv1_kernel_Din_A[18] = \<const0> ;
  assign conv1_kernel_Din_A[17] = \<const0> ;
  assign conv1_kernel_Din_A[16] = \<const0> ;
  assign conv1_kernel_Din_A[15] = \<const0> ;
  assign conv1_kernel_Din_A[14] = \<const0> ;
  assign conv1_kernel_Din_A[13] = \<const0> ;
  assign conv1_kernel_Din_A[12] = \<const0> ;
  assign conv1_kernel_Din_A[11] = \<const0> ;
  assign conv1_kernel_Din_A[10] = \<const0> ;
  assign conv1_kernel_Din_A[9] = \<const0> ;
  assign conv1_kernel_Din_A[8] = \<const0> ;
  assign conv1_kernel_Din_A[7] = \<const0> ;
  assign conv1_kernel_Din_A[6] = \<const0> ;
  assign conv1_kernel_Din_A[5] = \<const0> ;
  assign conv1_kernel_Din_A[4] = \<const0> ;
  assign conv1_kernel_Din_A[3] = \<const0> ;
  assign conv1_kernel_Din_A[2] = \<const0> ;
  assign conv1_kernel_Din_A[1] = \<const0> ;
  assign conv1_kernel_Din_A[0] = \<const0> ;
  assign conv1_kernel_Rst_A = output_r_Rst_A;
  assign conv1_kernel_WEN_A[3] = \<const0> ;
  assign conv1_kernel_WEN_A[2] = \<const0> ;
  assign conv1_kernel_WEN_A[1] = \<const0> ;
  assign conv1_kernel_WEN_A[0] = \<const0> ;
  assign conv2_bias_Addr_A[31] = \<const0> ;
  assign conv2_bias_Addr_A[30] = \<const0> ;
  assign conv2_bias_Addr_A[29] = \<const0> ;
  assign conv2_bias_Addr_A[28] = \<const0> ;
  assign conv2_bias_Addr_A[27] = \<const0> ;
  assign conv2_bias_Addr_A[26] = \<const0> ;
  assign conv2_bias_Addr_A[25] = \<const0> ;
  assign conv2_bias_Addr_A[24] = \<const0> ;
  assign conv2_bias_Addr_A[23] = \<const0> ;
  assign conv2_bias_Addr_A[22] = \<const0> ;
  assign conv2_bias_Addr_A[21] = \<const0> ;
  assign conv2_bias_Addr_A[20] = \<const0> ;
  assign conv2_bias_Addr_A[19] = \<const0> ;
  assign conv2_bias_Addr_A[18] = \<const0> ;
  assign conv2_bias_Addr_A[17] = \<const0> ;
  assign conv2_bias_Addr_A[16] = \<const0> ;
  assign conv2_bias_Addr_A[15] = \<const0> ;
  assign conv2_bias_Addr_A[14] = \<const0> ;
  assign conv2_bias_Addr_A[13] = \<const0> ;
  assign conv2_bias_Addr_A[12] = \<const0> ;
  assign conv2_bias_Addr_A[11] = \<const0> ;
  assign conv2_bias_Addr_A[10] = \<const0> ;
  assign conv2_bias_Addr_A[9] = \<const0> ;
  assign conv2_bias_Addr_A[8] = \<const0> ;
  assign conv2_bias_Addr_A[7:2] = \^conv2_bias_Addr_A [7:2];
  assign conv2_bias_Addr_A[1] = \<const0> ;
  assign conv2_bias_Addr_A[0] = \<const0> ;
  assign conv2_bias_Clk_A = ap_clk;
  assign conv2_bias_Din_A[31] = \<const0> ;
  assign conv2_bias_Din_A[30] = \<const0> ;
  assign conv2_bias_Din_A[29] = \<const0> ;
  assign conv2_bias_Din_A[28] = \<const0> ;
  assign conv2_bias_Din_A[27] = \<const0> ;
  assign conv2_bias_Din_A[26] = \<const0> ;
  assign conv2_bias_Din_A[25] = \<const0> ;
  assign conv2_bias_Din_A[24] = \<const0> ;
  assign conv2_bias_Din_A[23] = \<const0> ;
  assign conv2_bias_Din_A[22] = \<const0> ;
  assign conv2_bias_Din_A[21] = \<const0> ;
  assign conv2_bias_Din_A[20] = \<const0> ;
  assign conv2_bias_Din_A[19] = \<const0> ;
  assign conv2_bias_Din_A[18] = \<const0> ;
  assign conv2_bias_Din_A[17] = \<const0> ;
  assign conv2_bias_Din_A[16] = \<const0> ;
  assign conv2_bias_Din_A[15] = \<const0> ;
  assign conv2_bias_Din_A[14] = \<const0> ;
  assign conv2_bias_Din_A[13] = \<const0> ;
  assign conv2_bias_Din_A[12] = \<const0> ;
  assign conv2_bias_Din_A[11] = \<const0> ;
  assign conv2_bias_Din_A[10] = \<const0> ;
  assign conv2_bias_Din_A[9] = \<const0> ;
  assign conv2_bias_Din_A[8] = \<const0> ;
  assign conv2_bias_Din_A[7] = \<const0> ;
  assign conv2_bias_Din_A[6] = \<const0> ;
  assign conv2_bias_Din_A[5] = \<const0> ;
  assign conv2_bias_Din_A[4] = \<const0> ;
  assign conv2_bias_Din_A[3] = \<const0> ;
  assign conv2_bias_Din_A[2] = \<const0> ;
  assign conv2_bias_Din_A[1] = \<const0> ;
  assign conv2_bias_Din_A[0] = \<const0> ;
  assign conv2_bias_Rst_A = output_r_Rst_A;
  assign conv2_bias_WEN_A[3] = \<const0> ;
  assign conv2_bias_WEN_A[2] = \<const0> ;
  assign conv2_bias_WEN_A[1] = \<const0> ;
  assign conv2_bias_WEN_A[0] = \<const0> ;
  assign fc1_bias_Addr_A[31] = \<const0> ;
  assign fc1_bias_Addr_A[30] = \<const0> ;
  assign fc1_bias_Addr_A[29] = \<const0> ;
  assign fc1_bias_Addr_A[28] = \<const0> ;
  assign fc1_bias_Addr_A[27] = \<const0> ;
  assign fc1_bias_Addr_A[26] = \<const0> ;
  assign fc1_bias_Addr_A[25] = \<const0> ;
  assign fc1_bias_Addr_A[24] = \<const0> ;
  assign fc1_bias_Addr_A[23] = \<const0> ;
  assign fc1_bias_Addr_A[22] = \<const0> ;
  assign fc1_bias_Addr_A[21] = \<const0> ;
  assign fc1_bias_Addr_A[20] = \<const0> ;
  assign fc1_bias_Addr_A[19] = \<const0> ;
  assign fc1_bias_Addr_A[18] = \<const0> ;
  assign fc1_bias_Addr_A[17] = \<const0> ;
  assign fc1_bias_Addr_A[16] = \<const0> ;
  assign fc1_bias_Addr_A[15] = \<const0> ;
  assign fc1_bias_Addr_A[14] = \<const0> ;
  assign fc1_bias_Addr_A[13] = \<const0> ;
  assign fc1_bias_Addr_A[12] = \<const0> ;
  assign fc1_bias_Addr_A[11] = \<const0> ;
  assign fc1_bias_Addr_A[10:2] = \^fc1_bias_Addr_A [10:2];
  assign fc1_bias_Addr_A[1] = \<const0> ;
  assign fc1_bias_Addr_A[0] = \<const0> ;
  assign fc1_bias_Clk_A = ap_clk;
  assign fc1_bias_Din_A[31] = \<const0> ;
  assign fc1_bias_Din_A[30] = \<const0> ;
  assign fc1_bias_Din_A[29] = \<const0> ;
  assign fc1_bias_Din_A[28] = \<const0> ;
  assign fc1_bias_Din_A[27] = \<const0> ;
  assign fc1_bias_Din_A[26] = \<const0> ;
  assign fc1_bias_Din_A[25] = \<const0> ;
  assign fc1_bias_Din_A[24] = \<const0> ;
  assign fc1_bias_Din_A[23] = \<const0> ;
  assign fc1_bias_Din_A[22] = \<const0> ;
  assign fc1_bias_Din_A[21] = \<const0> ;
  assign fc1_bias_Din_A[20] = \<const0> ;
  assign fc1_bias_Din_A[19] = \<const0> ;
  assign fc1_bias_Din_A[18] = \<const0> ;
  assign fc1_bias_Din_A[17] = \<const0> ;
  assign fc1_bias_Din_A[16] = \<const0> ;
  assign fc1_bias_Din_A[15] = \<const0> ;
  assign fc1_bias_Din_A[14] = \<const0> ;
  assign fc1_bias_Din_A[13] = \<const0> ;
  assign fc1_bias_Din_A[12] = \<const0> ;
  assign fc1_bias_Din_A[11] = \<const0> ;
  assign fc1_bias_Din_A[10] = \<const0> ;
  assign fc1_bias_Din_A[9] = \<const0> ;
  assign fc1_bias_Din_A[8] = \<const0> ;
  assign fc1_bias_Din_A[7] = \<const0> ;
  assign fc1_bias_Din_A[6] = \<const0> ;
  assign fc1_bias_Din_A[5] = \<const0> ;
  assign fc1_bias_Din_A[4] = \<const0> ;
  assign fc1_bias_Din_A[3] = \<const0> ;
  assign fc1_bias_Din_A[2] = \<const0> ;
  assign fc1_bias_Din_A[1] = \<const0> ;
  assign fc1_bias_Din_A[0] = \<const0> ;
  assign fc1_bias_Rst_A = output_r_Rst_A;
  assign fc1_bias_WEN_A[3] = \<const0> ;
  assign fc1_bias_WEN_A[2] = \<const0> ;
  assign fc1_bias_WEN_A[1] = \<const0> ;
  assign fc1_bias_WEN_A[0] = \<const0> ;
  assign fc2_bias_Addr_A[31] = \<const0> ;
  assign fc2_bias_Addr_A[30] = \<const0> ;
  assign fc2_bias_Addr_A[29] = \<const0> ;
  assign fc2_bias_Addr_A[28] = \<const0> ;
  assign fc2_bias_Addr_A[27] = \<const0> ;
  assign fc2_bias_Addr_A[26] = \<const0> ;
  assign fc2_bias_Addr_A[25] = \<const0> ;
  assign fc2_bias_Addr_A[24] = \<const0> ;
  assign fc2_bias_Addr_A[23] = \<const0> ;
  assign fc2_bias_Addr_A[22] = \<const0> ;
  assign fc2_bias_Addr_A[21] = \<const0> ;
  assign fc2_bias_Addr_A[20] = \<const0> ;
  assign fc2_bias_Addr_A[19] = \<const0> ;
  assign fc2_bias_Addr_A[18] = \<const0> ;
  assign fc2_bias_Addr_A[17] = \<const0> ;
  assign fc2_bias_Addr_A[16] = \<const0> ;
  assign fc2_bias_Addr_A[15] = \<const0> ;
  assign fc2_bias_Addr_A[14] = \<const0> ;
  assign fc2_bias_Addr_A[13] = \<const0> ;
  assign fc2_bias_Addr_A[12] = \<const0> ;
  assign fc2_bias_Addr_A[11] = \<const0> ;
  assign fc2_bias_Addr_A[10] = \<const0> ;
  assign fc2_bias_Addr_A[9] = \<const0> ;
  assign fc2_bias_Addr_A[8] = \<const0> ;
  assign fc2_bias_Addr_A[7] = \<const0> ;
  assign fc2_bias_Addr_A[6] = \<const0> ;
  assign fc2_bias_Addr_A[5:2] = \^fc2_bias_Addr_A [5:2];
  assign fc2_bias_Addr_A[1] = \<const0> ;
  assign fc2_bias_Addr_A[0] = \<const0> ;
  assign fc2_bias_Clk_A = ap_clk;
  assign fc2_bias_Din_A[31] = \<const0> ;
  assign fc2_bias_Din_A[30] = \<const0> ;
  assign fc2_bias_Din_A[29] = \<const0> ;
  assign fc2_bias_Din_A[28] = \<const0> ;
  assign fc2_bias_Din_A[27] = \<const0> ;
  assign fc2_bias_Din_A[26] = \<const0> ;
  assign fc2_bias_Din_A[25] = \<const0> ;
  assign fc2_bias_Din_A[24] = \<const0> ;
  assign fc2_bias_Din_A[23] = \<const0> ;
  assign fc2_bias_Din_A[22] = \<const0> ;
  assign fc2_bias_Din_A[21] = \<const0> ;
  assign fc2_bias_Din_A[20] = \<const0> ;
  assign fc2_bias_Din_A[19] = \<const0> ;
  assign fc2_bias_Din_A[18] = \<const0> ;
  assign fc2_bias_Din_A[17] = \<const0> ;
  assign fc2_bias_Din_A[16] = \<const0> ;
  assign fc2_bias_Din_A[15] = \<const0> ;
  assign fc2_bias_Din_A[14] = \<const0> ;
  assign fc2_bias_Din_A[13] = \<const0> ;
  assign fc2_bias_Din_A[12] = \<const0> ;
  assign fc2_bias_Din_A[11] = \<const0> ;
  assign fc2_bias_Din_A[10] = \<const0> ;
  assign fc2_bias_Din_A[9] = \<const0> ;
  assign fc2_bias_Din_A[8] = \<const0> ;
  assign fc2_bias_Din_A[7] = \<const0> ;
  assign fc2_bias_Din_A[6] = \<const0> ;
  assign fc2_bias_Din_A[5] = \<const0> ;
  assign fc2_bias_Din_A[4] = \<const0> ;
  assign fc2_bias_Din_A[3] = \<const0> ;
  assign fc2_bias_Din_A[2] = \<const0> ;
  assign fc2_bias_Din_A[1] = \<const0> ;
  assign fc2_bias_Din_A[0] = \<const0> ;
  assign fc2_bias_Rst_A = output_r_Rst_A;
  assign fc2_bias_WEN_A[3] = \<const0> ;
  assign fc2_bias_WEN_A[2] = \<const0> ;
  assign fc2_bias_WEN_A[1] = \<const0> ;
  assign fc2_bias_WEN_A[0] = \<const0> ;
  assign fc2_kernel_Addr_A[31] = \<const0> ;
  assign fc2_kernel_Addr_A[30] = \<const0> ;
  assign fc2_kernel_Addr_A[29] = \<const0> ;
  assign fc2_kernel_Addr_A[28] = \<const0> ;
  assign fc2_kernel_Addr_A[27] = \<const0> ;
  assign fc2_kernel_Addr_A[26] = \<const0> ;
  assign fc2_kernel_Addr_A[25] = \<const0> ;
  assign fc2_kernel_Addr_A[24] = \<const0> ;
  assign fc2_kernel_Addr_A[23] = \<const0> ;
  assign fc2_kernel_Addr_A[22] = \<const0> ;
  assign fc2_kernel_Addr_A[21] = \<const0> ;
  assign fc2_kernel_Addr_A[20] = \<const0> ;
  assign fc2_kernel_Addr_A[19] = \<const0> ;
  assign fc2_kernel_Addr_A[18] = \<const0> ;
  assign fc2_kernel_Addr_A[17] = \<const0> ;
  assign fc2_kernel_Addr_A[16] = \<const0> ;
  assign fc2_kernel_Addr_A[15] = \<const0> ;
  assign fc2_kernel_Addr_A[14] = \<const0> ;
  assign fc2_kernel_Addr_A[13:2] = \^fc2_kernel_Addr_A [13:2];
  assign fc2_kernel_Addr_A[1] = \<const0> ;
  assign fc2_kernel_Addr_A[0] = \<const0> ;
  assign fc2_kernel_Clk_A = ap_clk;
  assign fc2_kernel_Din_A[31] = \<const0> ;
  assign fc2_kernel_Din_A[30] = \<const0> ;
  assign fc2_kernel_Din_A[29] = \<const0> ;
  assign fc2_kernel_Din_A[28] = \<const0> ;
  assign fc2_kernel_Din_A[27] = \<const0> ;
  assign fc2_kernel_Din_A[26] = \<const0> ;
  assign fc2_kernel_Din_A[25] = \<const0> ;
  assign fc2_kernel_Din_A[24] = \<const0> ;
  assign fc2_kernel_Din_A[23] = \<const0> ;
  assign fc2_kernel_Din_A[22] = \<const0> ;
  assign fc2_kernel_Din_A[21] = \<const0> ;
  assign fc2_kernel_Din_A[20] = \<const0> ;
  assign fc2_kernel_Din_A[19] = \<const0> ;
  assign fc2_kernel_Din_A[18] = \<const0> ;
  assign fc2_kernel_Din_A[17] = \<const0> ;
  assign fc2_kernel_Din_A[16] = \<const0> ;
  assign fc2_kernel_Din_A[15] = \<const0> ;
  assign fc2_kernel_Din_A[14] = \<const0> ;
  assign fc2_kernel_Din_A[13] = \<const0> ;
  assign fc2_kernel_Din_A[12] = \<const0> ;
  assign fc2_kernel_Din_A[11] = \<const0> ;
  assign fc2_kernel_Din_A[10] = \<const0> ;
  assign fc2_kernel_Din_A[9] = \<const0> ;
  assign fc2_kernel_Din_A[8] = \<const0> ;
  assign fc2_kernel_Din_A[7] = \<const0> ;
  assign fc2_kernel_Din_A[6] = \<const0> ;
  assign fc2_kernel_Din_A[5] = \<const0> ;
  assign fc2_kernel_Din_A[4] = \<const0> ;
  assign fc2_kernel_Din_A[3] = \<const0> ;
  assign fc2_kernel_Din_A[2] = \<const0> ;
  assign fc2_kernel_Din_A[1] = \<const0> ;
  assign fc2_kernel_Din_A[0] = \<const0> ;
  assign fc2_kernel_EN_A = output_r_EN_A;
  assign fc2_kernel_Rst_A = output_r_Rst_A;
  assign fc2_kernel_WEN_A[3] = \<const0> ;
  assign fc2_kernel_WEN_A[2] = \<const0> ;
  assign fc2_kernel_WEN_A[1] = \<const0> ;
  assign fc2_kernel_WEN_A[0] = \<const0> ;
  assign input_r_Addr_A[31] = \<const0> ;
  assign input_r_Addr_A[30] = \<const0> ;
  assign input_r_Addr_A[29] = \<const0> ;
  assign input_r_Addr_A[28] = \<const0> ;
  assign input_r_Addr_A[27] = \<const0> ;
  assign input_r_Addr_A[26] = \<const0> ;
  assign input_r_Addr_A[25] = \<const0> ;
  assign input_r_Addr_A[24] = \<const0> ;
  assign input_r_Addr_A[23] = \<const0> ;
  assign input_r_Addr_A[22] = \<const0> ;
  assign input_r_Addr_A[21] = \<const0> ;
  assign input_r_Addr_A[20] = \<const0> ;
  assign input_r_Addr_A[19] = \<const0> ;
  assign input_r_Addr_A[18] = \<const0> ;
  assign input_r_Addr_A[17] = \<const0> ;
  assign input_r_Addr_A[16] = \<const0> ;
  assign input_r_Addr_A[15] = \<const0> ;
  assign input_r_Addr_A[14] = \<const0> ;
  assign input_r_Addr_A[13] = \<const0> ;
  assign input_r_Addr_A[12:2] = \^input_r_Addr_A [12:2];
  assign input_r_Addr_A[1] = \<const0> ;
  assign input_r_Addr_A[0] = \<const0> ;
  assign input_r_Clk_A = ap_clk;
  assign input_r_Din_A[31] = \<const0> ;
  assign input_r_Din_A[30] = \<const0> ;
  assign input_r_Din_A[29] = \<const0> ;
  assign input_r_Din_A[28] = \<const0> ;
  assign input_r_Din_A[27] = \<const0> ;
  assign input_r_Din_A[26] = \<const0> ;
  assign input_r_Din_A[25] = \<const0> ;
  assign input_r_Din_A[24] = \<const0> ;
  assign input_r_Din_A[23] = \<const0> ;
  assign input_r_Din_A[22] = \<const0> ;
  assign input_r_Din_A[21] = \<const0> ;
  assign input_r_Din_A[20] = \<const0> ;
  assign input_r_Din_A[19] = \<const0> ;
  assign input_r_Din_A[18] = \<const0> ;
  assign input_r_Din_A[17] = \<const0> ;
  assign input_r_Din_A[16] = \<const0> ;
  assign input_r_Din_A[15] = \<const0> ;
  assign input_r_Din_A[14] = \<const0> ;
  assign input_r_Din_A[13] = \<const0> ;
  assign input_r_Din_A[12] = \<const0> ;
  assign input_r_Din_A[11] = \<const0> ;
  assign input_r_Din_A[10] = \<const0> ;
  assign input_r_Din_A[9] = \<const0> ;
  assign input_r_Din_A[8] = \<const0> ;
  assign input_r_Din_A[7] = \<const0> ;
  assign input_r_Din_A[6] = \<const0> ;
  assign input_r_Din_A[5] = \<const0> ;
  assign input_r_Din_A[4] = \<const0> ;
  assign input_r_Din_A[3] = \<const0> ;
  assign input_r_Din_A[2] = \<const0> ;
  assign input_r_Din_A[1] = \<const0> ;
  assign input_r_Din_A[0] = \<const0> ;
  assign input_r_EN_A = conv1_kernel_EN_A;
  assign input_r_Rst_A = output_r_Rst_A;
  assign input_r_WEN_A[3] = \<const0> ;
  assign input_r_WEN_A[2] = \<const0> ;
  assign input_r_WEN_A[1] = \<const0> ;
  assign input_r_WEN_A[0] = \<const0> ;
  assign output_r_Addr_A[31] = \<const0> ;
  assign output_r_Addr_A[30] = \<const0> ;
  assign output_r_Addr_A[29] = \<const0> ;
  assign output_r_Addr_A[28] = \<const0> ;
  assign output_r_Addr_A[27] = \<const0> ;
  assign output_r_Addr_A[26] = \<const0> ;
  assign output_r_Addr_A[25] = \<const0> ;
  assign output_r_Addr_A[24] = \<const0> ;
  assign output_r_Addr_A[23] = \<const0> ;
  assign output_r_Addr_A[22] = \<const0> ;
  assign output_r_Addr_A[21] = \<const0> ;
  assign output_r_Addr_A[20] = \<const0> ;
  assign output_r_Addr_A[19] = \<const0> ;
  assign output_r_Addr_A[18] = \<const0> ;
  assign output_r_Addr_A[17] = \<const0> ;
  assign output_r_Addr_A[16] = \<const0> ;
  assign output_r_Addr_A[15] = \<const0> ;
  assign output_r_Addr_A[14] = \<const0> ;
  assign output_r_Addr_A[13] = \<const0> ;
  assign output_r_Addr_A[12] = \<const0> ;
  assign output_r_Addr_A[11] = \<const0> ;
  assign output_r_Addr_A[10] = \<const0> ;
  assign output_r_Addr_A[9] = \<const0> ;
  assign output_r_Addr_A[8] = \<const0> ;
  assign output_r_Addr_A[7] = \<const0> ;
  assign output_r_Addr_A[6] = \<const0> ;
  assign output_r_Addr_A[5:2] = \^output_r_Addr_A [5:2];
  assign output_r_Addr_A[1] = \<const0> ;
  assign output_r_Addr_A[0] = \<const0> ;
  assign output_r_Clk_A = ap_clk;
  assign output_r_Din_A[31] = \<const0> ;
  assign output_r_Din_A[30:0] = \^output_r_Din_A [30:0];
  assign output_r_WEN_A[3] = \^output_r_WEN_A [0];
  assign output_r_WEN_A[2] = \^output_r_WEN_A [0];
  assign output_r_WEN_A[1] = \^output_r_WEN_A [0];
  assign output_r_WEN_A[0] = \^output_r_WEN_A [0];
  GND GND
       (.G(\<const0> ));
  (* FSM_ENCODING = "none" *) 
  FDSE #(
    .INIT(1'b1)) 
    \ap_CS_fsm_reg[0] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[0]),
        .Q(\ap_CS_fsm_reg_n_4_[0] ),
        .S(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[1] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[1]),
        .Q(ap_CS_fsm_state2),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[2] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[2]),
        .Q(ap_CS_fsm_state3),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[3] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[3]),
        .Q(ap_CS_fsm_state4),
        .R(output_r_Rst_A));
  LUT2 #(
    .INIT(4'h2)) 
    ap_idle_INST_0
       (.I0(\ap_CS_fsm_reg_n_4_[0] ),
        .I1(ap_start),
        .O(ap_idle));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_lenet_cnn_fc1_outhbi fc1_output_U
       (.ADDRARDADDR(fc1_output_address0),
        .WEA(fc1_output_we0),
        .ap_clk(ap_clk),
        .fc1_output_ce0(fc1_output_ce0),
        .fc1_output_q0(fc1_output_q0),
        .grp_Fc1_40_400_fu_117_output_r_d0(grp_Fc1_40_400_fu_117_output_r_d0));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv1_28x28x1_5x5x20 grp_Conv1_28x28x1_5x5x20_fu_74
       (.Q({grp_Conv2_12x12x20_5x5x4_fu_109_ap_ready,grp_Conv2_12x12x20_5x5x4_fu_109_n_5}),
        .\ap_CS_fsm_reg[0]_0 (\ap_CS_fsm_reg_n_4_[0] ),
        .\ap_CS_fsm_reg[2]_0 (grp_Conv1_28x28x1_5x5x20_fu_74_n_4),
        .ap_clk(ap_clk),
        .ap_rst_n(ap_rst_n),
        .ap_start(ap_start),
        .bias_Addr_A(\^conv1_bias_Addr_A ),
        .conv1_bias_EN_A(conv1_bias_EN_A),
        .conv1_kernel_Addr_A(\^conv1_kernel_Addr_A ),
        .conv1_kernel_EN_A(conv1_kernel_EN_A),
        .grp_Conv1_28x28x1_5x5x20_fu_74_ap_start_reg(grp_Conv1_28x28x1_5x5x20_fu_74_ap_start_reg),
        .grp_Conv1_28x28x1_5x5x20_fu_74_ap_start_reg_reg(grp_Conv1_28x28x1_5x5x20_fu_74_n_11),
        .grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg(grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg),
        .input_r_Addr_A(\^input_r_Addr_A ),
        .output_r_Rst_A(output_r_Rst_A));
  FDRE #(
    .INIT(1'b0)) 
    grp_Conv1_28x28x1_5x5x20_fu_74_ap_start_reg_reg
       (.C(ap_clk),
        .CE(1'b1),
        .D(grp_Conv1_28x28x1_5x5x20_fu_74_n_11),
        .Q(grp_Conv1_28x28x1_5x5x20_fu_74_ap_start_reg),
        .R(output_r_Rst_A));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x4 grp_Conv2_12x12x20_5x5x4_fu_109
       (.Q({grp_Conv2_12x12x20_5x5x4_fu_109_ap_ready,grp_Conv2_12x12x20_5x5x4_fu_109_n_5}),
        .\ap_CS_fsm_reg[0]_0 (\ap_CS_fsm_reg_n_4_[0] ),
        .ap_clk(ap_clk),
        .ap_rst_n(ap_rst_n),
        .ap_rst_n_0(output_r_Rst_A),
        .ap_start(ap_start),
        .conv2_bias_Addr_A(\^conv2_bias_Addr_A ),
        .conv2_bias_EN_A(conv2_bias_EN_A),
        .grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg(grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg),
        .grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg_reg(grp_Conv2_12x12x20_5x5x4_fu_109_n_13));
  FDRE #(
    .INIT(1'b0)) 
    grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg_reg
       (.C(ap_clk),
        .CE(1'b1),
        .D(grp_Conv2_12x12x20_5x5x4_fu_109_n_13),
        .Q(grp_Conv2_12x12x20_5x5x4_fu_109_ap_start_reg),
        .R(output_r_Rst_A));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Fc1_40_400 grp_Fc1_40_400_fu_117
       (.ADDRARDADDR(fc1_output_address0),
        .D(ap_NS_fsm[2:1]),
        .Q({ap_CS_fsm_state4,ap_CS_fsm_state2,\ap_CS_fsm_reg_n_4_[0] }),
        .WEA(fc1_output_we0),
        .\ap_CS_fsm_reg[26] (grp_Conv1_28x28x1_5x5x20_fu_74_n_4),
        .\ap_CS_fsm_reg[3]_0 (output_r_EN_A),
        .ap_clk(ap_clk),
        .ap_rst_n(output_r_Rst_A),
        .ap_start(ap_start),
        .\fc1_bias_Addr_A[10] (\^fc1_bias_Addr_A ),
        .fc1_bias_Dout_A(fc1_bias_Dout_A),
        .fc1_bias_EN_A(fc1_bias_EN_A),
        .fc1_output_ce0(fc1_output_ce0),
        .grp_Fc1_40_400_fu_117_ap_start_reg(grp_Fc1_40_400_fu_117_ap_start_reg),
        .grp_Fc1_40_400_fu_117_ap_start_reg_reg(grp_Fc1_40_400_fu_117_n_27),
        .grp_Fc1_40_400_fu_117_output_r_d0(grp_Fc1_40_400_fu_117_output_r_d0),
        .\i_reg_137_reg[8] (i_reg_137));
  FDRE #(
    .INIT(1'b0)) 
    grp_Fc1_40_400_fu_117_ap_start_reg_reg
       (.C(ap_clk),
        .CE(1'b1),
        .D(grp_Fc1_40_400_fu_117_n_27),
        .Q(grp_Fc1_40_400_fu_117_ap_start_reg),
        .R(output_r_Rst_A));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Fc2_400_10 grp_Fc2_400_10_fu_92
       (.D({ap_NS_fsm[3],ap_NS_fsm[0]}),
        .Q({ap_CS_fsm_state4,ap_CS_fsm_state3,\ap_CS_fsm_reg_n_4_[0] }),
        .\ap_CS_fsm_reg[0]_0 (grp_Pool1_24x24x20_2x2x2_fu_86_n_4),
        .ap_clk(ap_clk),
        .ap_done(ap_done),
        .ap_rst_n(output_r_Rst_A),
        .ap_start(ap_start),
        .fc1_output_q0(fc1_output_q0),
        .\fc2_bias_Addr_A[5] (\^fc2_bias_Addr_A ),
        .fc2_bias_Dout_A(fc2_bias_Dout_A),
        .fc2_kernel_Addr_A(\^fc2_kernel_Addr_A ),
        .fc2_kernel_Dout_A(fc2_kernel_Dout_A),
        .grp_Fc2_400_10_fu_92_ap_start_reg(grp_Fc2_400_10_fu_92_ap_start_reg),
        .grp_Fc2_400_10_fu_92_ap_start_reg_reg(grp_Fc2_400_10_fu_92_n_66),
        .\i_3_reg_284_reg[8]_0 (i_reg_137),
        .output_r_Addr_A(\^output_r_Addr_A ),
        .output_r_Din_A(\^output_r_Din_A ),
        .output_r_EN_A({output_r_EN_A,fc2_bias_EN_A}),
        .\output_r_WEN_A[0] (\^output_r_WEN_A ));
  FDRE #(
    .INIT(1'b0)) 
    grp_Fc2_400_10_fu_92_ap_start_reg_reg
       (.C(ap_clk),
        .CE(1'b1),
        .D(grp_Fc2_400_10_fu_92_n_66),
        .Q(grp_Fc2_400_10_fu_92_ap_start_reg),
        .R(output_r_Rst_A));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Pool1_24x24x20_2x2x2 grp_Pool1_24x24x20_2x2x2_fu_86
       (.Q(grp_Pool2_8x8x40_2x2x40_s_fu_103_n_5),
        .\ap_CS_fsm_reg[2]_0 (ap_CS_fsm_state3),
        .\ap_CS_fsm_reg[3]_0 (grp_Pool1_24x24x20_2x2x2_fu_86_n_4),
        .ap_clk(ap_clk),
        .ap_rst_n(output_r_Rst_A),
        .grp_Pool1_24x24x20_2x2x2_fu_86_ap_start_reg(grp_Pool1_24x24x20_2x2x2_fu_86_ap_start_reg),
        .grp_Pool1_24x24x20_2x2x2_fu_86_ap_start_reg_reg(grp_Pool1_24x24x20_2x2x2_fu_86_n_5),
        .grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_ready(grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_ready),
        .grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg(grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg));
  FDRE #(
    .INIT(1'b0)) 
    grp_Pool1_24x24x20_2x2x2_fu_86_ap_start_reg_reg
       (.C(ap_clk),
        .CE(1'b1),
        .D(grp_Pool1_24x24x20_2x2x2_fu_86_n_5),
        .Q(grp_Pool1_24x24x20_2x2x2_fu_86_ap_start_reg),
        .R(output_r_Rst_A));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Pool2_8x8x40_2x2x40_s grp_Pool2_8x8x40_2x2x40_s_fu_103
       (.Q(grp_Pool2_8x8x40_2x2x40_s_fu_103_n_5),
        .\ap_CS_fsm_reg[2]_0 (ap_CS_fsm_state3),
        .ap_clk(ap_clk),
        .ap_rst_n(output_r_Rst_A),
        .grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_ready(grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_ready),
        .grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg(grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg),
        .grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg_reg(grp_Pool2_8x8x40_2x2x40_s_fu_103_n_6));
  FDRE #(
    .INIT(1'b0)) 
    grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg_reg
       (.C(ap_clk),
        .CE(1'b1),
        .D(grp_Pool2_8x8x40_2x2x40_s_fu_103_n_6),
        .Q(grp_Pool2_8x8x40_2x2x40_s_fu_103_ap_start_reg),
        .R(output_r_Rst_A));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_lenet_cnn_fc1_outhbi
   (fc1_output_q0,
    ap_clk,
    fc1_output_ce0,
    ADDRARDADDR,
    grp_Fc1_40_400_fu_117_output_r_d0,
    WEA);
  output [30:0]fc1_output_q0;
  input ap_clk;
  input fc1_output_ce0;
  input [8:0]ADDRARDADDR;
  input [30:0]grp_Fc1_40_400_fu_117_output_r_d0;
  input [0:0]WEA;

  wire [8:0]ADDRARDADDR;
  wire [0:0]WEA;
  wire ap_clk;
  wire fc1_output_ce0;
  wire [30:0]fc1_output_q0;
  wire [30:0]grp_Fc1_40_400_fu_117_output_r_d0;

  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_lenet_cnn_fc1_outhbi_ram a0_lenet_cnn_fc1_outhbi_ram_U
       (.ADDRARDADDR(ADDRARDADDR),
        .WEA(WEA),
        .ap_clk(ap_clk),
        .fc1_output_ce0(fc1_output_ce0),
        .fc1_output_q0(fc1_output_q0),
        .grp_Fc1_40_400_fu_117_output_r_d0(grp_Fc1_40_400_fu_117_output_r_d0));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_lenet_cnn_fc1_outhbi_ram
   (fc1_output_q0,
    ap_clk,
    fc1_output_ce0,
    ADDRARDADDR,
    grp_Fc1_40_400_fu_117_output_r_d0,
    WEA);
  output [30:0]fc1_output_q0;
  input ap_clk;
  input fc1_output_ce0;
  input [8:0]ADDRARDADDR;
  input [30:0]grp_Fc1_40_400_fu_117_output_r_d0;
  input [0:0]WEA;

  wire [8:0]ADDRARDADDR;
  wire [0:0]WEA;
  wire ap_clk;
  wire fc1_output_ce0;
  wire [30:0]fc1_output_q0;
  wire [30:0]grp_Fc1_40_400_fu_117_output_r_d0;
  wire [15:13]NLW_ram_reg_DOBDO_UNCONNECTED;
  wire [1:0]NLW_ram_reg_DOPBDOP_UNCONNECTED;

  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p2_d16" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d13" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "12400" *) 
  (* RTL_RAM_NAME = "ram" *) 
  (* bram_addr_begin = "0" *) 
  (* bram_addr_end = "399" *) 
  (* bram_ext_slice_begin = "18" *) 
  (* bram_ext_slice_end = "30" *) 
  (* bram_slice_begin = "0" *) 
  (* bram_slice_end = "17" *) 
  RAMB18E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .INIT_A(18'h00000),
    .INIT_B(18'h00000),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(18),
    .READ_WIDTH_B(18),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(18'h00000),
    .SRVAL_B(18'h00000),
    .WRITE_MODE_A("WRITE_FIRST"),
    .WRITE_MODE_B("WRITE_FIRST"),
    .WRITE_WIDTH_A(18),
    .WRITE_WIDTH_B(18)) 
    ram_reg
       (.ADDRARDADDR({1'b0,ADDRARDADDR,1'b1,1'b1,1'b1,1'b1}),
        .ADDRBWRADDR({1'b1,ADDRARDADDR,1'b1,1'b1,1'b1,1'b1}),
        .CLKARDCLK(ap_clk),
        .CLKBWRCLK(ap_clk),
        .DIADI(grp_Fc1_40_400_fu_117_output_r_d0[15:0]),
        .DIBDI({1'b1,1'b1,1'b1,grp_Fc1_40_400_fu_117_output_r_d0[30:18]}),
        .DIPADIP(grp_Fc1_40_400_fu_117_output_r_d0[17:16]),
        .DIPBDIP({1'b1,1'b1}),
        .DOADO(fc1_output_q0[15:0]),
        .DOBDO({NLW_ram_reg_DOBDO_UNCONNECTED[15:13],fc1_output_q0[30:18]}),
        .DOPADOP(fc1_output_q0[17:16]),
        .DOPBDOP(NLW_ram_reg_DOPBDOP_UNCONNECTED[1:0]),
        .ENARDEN(fc1_output_ce0),
        .ENBWREN(fc1_output_ce0),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(1'b0),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .WEA({WEA,WEA}),
        .WEBWE({1'b0,1'b0,WEA,WEA}));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_lenet_cnn_mul_31ncud
   (D,
    Q,
    ap_clk,
    fc1_output_q0,
    fc2_kernel_Dout_A);
  output [31:0]D;
  input [0:0]Q;
  input ap_clk;
  input [30:0]fc1_output_q0;
  input [31:0]fc2_kernel_Dout_A;

  wire [31:0]D;
  wire [0:0]Q;
  wire ap_clk;
  wire [30:0]fc1_output_q0;
  wire [31:0]fc2_kernel_Dout_A;

  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_lenet_cnn_mul_31ncud_MulnS_1 a0_lenet_cnn_mul_31ncud_MulnS_1_U
       (.D(D),
        .Q(Q),
        .ap_clk(ap_clk),
        .fc1_output_q0(fc1_output_q0),
        .fc2_kernel_Dout_A(fc2_kernel_Dout_A));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_lenet_cnn_mul_31ncud_MulnS_1
   (D,
    Q,
    ap_clk,
    fc1_output_q0,
    fc2_kernel_Dout_A);
  output [31:0]D;
  input [0:0]Q;
  input ap_clk;
  input [30:0]fc1_output_q0;
  input [31:0]fc2_kernel_Dout_A;

  wire [31:0]D;
  wire [0:0]Q;
  wire ap_clk;
  wire [30:0]fc1_output_q0;
  wire [31:0]fc2_kernel_Dout_A;
  wire \p_reg[16]__0_n_4 ;
  wire p_reg__0_n_100;
  wire p_reg__0_n_101;
  wire p_reg__0_n_102;
  wire p_reg__0_n_103;
  wire p_reg__0_n_104;
  wire p_reg__0_n_105;
  wire p_reg__0_n_106;
  wire p_reg__0_n_107;
  wire p_reg__0_n_108;
  wire p_reg__0_n_109;
  wire p_reg__0_n_62;
  wire p_reg__0_n_63;
  wire p_reg__0_n_64;
  wire p_reg__0_n_65;
  wire p_reg__0_n_66;
  wire p_reg__0_n_67;
  wire p_reg__0_n_68;
  wire p_reg__0_n_69;
  wire p_reg__0_n_70;
  wire p_reg__0_n_71;
  wire p_reg__0_n_72;
  wire p_reg__0_n_73;
  wire p_reg__0_n_74;
  wire p_reg__0_n_75;
  wire p_reg__0_n_76;
  wire p_reg__0_n_77;
  wire p_reg__0_n_78;
  wire p_reg__0_n_79;
  wire p_reg__0_n_80;
  wire p_reg__0_n_81;
  wire p_reg__0_n_82;
  wire p_reg__0_n_83;
  wire p_reg__0_n_84;
  wire p_reg__0_n_85;
  wire p_reg__0_n_86;
  wire p_reg__0_n_87;
  wire p_reg__0_n_88;
  wire p_reg__0_n_89;
  wire p_reg__0_n_90;
  wire p_reg__0_n_91;
  wire p_reg__0_n_92;
  wire p_reg__0_n_93;
  wire p_reg__0_n_94;
  wire p_reg__0_n_95;
  wire p_reg__0_n_96;
  wire p_reg__0_n_97;
  wire p_reg__0_n_98;
  wire p_reg__0_n_99;
  wire p_reg__2_n_100;
  wire p_reg__2_n_101;
  wire p_reg__2_n_102;
  wire p_reg__2_n_103;
  wire p_reg__2_n_104;
  wire p_reg__2_n_105;
  wire p_reg__2_n_106;
  wire p_reg__2_n_107;
  wire p_reg__2_n_108;
  wire p_reg__2_n_109;
  wire p_reg__2_n_62;
  wire p_reg__2_n_63;
  wire p_reg__2_n_64;
  wire p_reg__2_n_65;
  wire p_reg__2_n_66;
  wire p_reg__2_n_67;
  wire p_reg__2_n_68;
  wire p_reg__2_n_69;
  wire p_reg__2_n_70;
  wire p_reg__2_n_71;
  wire p_reg__2_n_72;
  wire p_reg__2_n_73;
  wire p_reg__2_n_74;
  wire p_reg__2_n_75;
  wire p_reg__2_n_76;
  wire p_reg__2_n_77;
  wire p_reg__2_n_78;
  wire p_reg__2_n_79;
  wire p_reg__2_n_80;
  wire p_reg__2_n_81;
  wire p_reg__2_n_82;
  wire p_reg__2_n_83;
  wire p_reg__2_n_84;
  wire p_reg__2_n_85;
  wire p_reg__2_n_86;
  wire p_reg__2_n_87;
  wire p_reg__2_n_88;
  wire p_reg__2_n_89;
  wire p_reg__2_n_90;
  wire p_reg__2_n_91;
  wire p_reg__2_n_92;
  wire p_reg__2_n_93;
  wire p_reg__2_n_94;
  wire p_reg__2_n_95;
  wire p_reg__2_n_96;
  wire p_reg__2_n_97;
  wire p_reg__2_n_98;
  wire p_reg__2_n_99;
  wire \p_reg_n_4_[0] ;
  wire \p_reg_n_4_[10] ;
  wire \p_reg_n_4_[11] ;
  wire \p_reg_n_4_[12] ;
  wire \p_reg_n_4_[13] ;
  wire \p_reg_n_4_[14] ;
  wire \p_reg_n_4_[15] ;
  wire \p_reg_n_4_[16] ;
  wire \p_reg_n_4_[1] ;
  wire \p_reg_n_4_[2] ;
  wire \p_reg_n_4_[3] ;
  wire \p_reg_n_4_[4] ;
  wire \p_reg_n_4_[5] ;
  wire \p_reg_n_4_[6] ;
  wire \p_reg_n_4_[7] ;
  wire \p_reg_n_4_[8] ;
  wire \p_reg_n_4_[9] ;
  wire \tmp_3_i_reg_319[13]_i_2_n_4 ;
  wire \tmp_3_i_reg_319[13]_i_3_n_4 ;
  wire \tmp_3_i_reg_319[13]_i_4_n_4 ;
  wire \tmp_3_i_reg_319[13]_i_5_n_4 ;
  wire \tmp_3_i_reg_319[17]_i_2_n_4 ;
  wire \tmp_3_i_reg_319[17]_i_3_n_4 ;
  wire \tmp_3_i_reg_319[17]_i_4_n_4 ;
  wire \tmp_3_i_reg_319[17]_i_5_n_4 ;
  wire \tmp_3_i_reg_319[21]_i_2_n_4 ;
  wire \tmp_3_i_reg_319[21]_i_3_n_4 ;
  wire \tmp_3_i_reg_319[21]_i_4_n_4 ;
  wire \tmp_3_i_reg_319[21]_i_5_n_4 ;
  wire \tmp_3_i_reg_319[25]_i_2_n_4 ;
  wire \tmp_3_i_reg_319[25]_i_3_n_4 ;
  wire \tmp_3_i_reg_319[25]_i_4_n_4 ;
  wire \tmp_3_i_reg_319[25]_i_5_n_4 ;
  wire \tmp_3_i_reg_319[29]_i_2_n_4 ;
  wire \tmp_3_i_reg_319[29]_i_3_n_4 ;
  wire \tmp_3_i_reg_319[29]_i_4_n_4 ;
  wire \tmp_3_i_reg_319[29]_i_5_n_4 ;
  wire \tmp_3_i_reg_319[31]_i_2_n_4 ;
  wire \tmp_3_i_reg_319[31]_i_3_n_4 ;
  wire \tmp_3_i_reg_319[5]_i_2_n_4 ;
  wire \tmp_3_i_reg_319[5]_i_3_n_4 ;
  wire \tmp_3_i_reg_319[5]_i_4_n_4 ;
  wire \tmp_3_i_reg_319[9]_i_2_n_4 ;
  wire \tmp_3_i_reg_319[9]_i_3_n_4 ;
  wire \tmp_3_i_reg_319[9]_i_4_n_4 ;
  wire \tmp_3_i_reg_319[9]_i_5_n_4 ;
  wire \tmp_3_i_reg_319_reg[13]_i_1_n_4 ;
  wire \tmp_3_i_reg_319_reg[13]_i_1_n_5 ;
  wire \tmp_3_i_reg_319_reg[13]_i_1_n_6 ;
  wire \tmp_3_i_reg_319_reg[13]_i_1_n_7 ;
  wire \tmp_3_i_reg_319_reg[17]_i_1_n_4 ;
  wire \tmp_3_i_reg_319_reg[17]_i_1_n_5 ;
  wire \tmp_3_i_reg_319_reg[17]_i_1_n_6 ;
  wire \tmp_3_i_reg_319_reg[17]_i_1_n_7 ;
  wire \tmp_3_i_reg_319_reg[21]_i_1_n_4 ;
  wire \tmp_3_i_reg_319_reg[21]_i_1_n_5 ;
  wire \tmp_3_i_reg_319_reg[21]_i_1_n_6 ;
  wire \tmp_3_i_reg_319_reg[21]_i_1_n_7 ;
  wire \tmp_3_i_reg_319_reg[25]_i_1_n_4 ;
  wire \tmp_3_i_reg_319_reg[25]_i_1_n_5 ;
  wire \tmp_3_i_reg_319_reg[25]_i_1_n_6 ;
  wire \tmp_3_i_reg_319_reg[25]_i_1_n_7 ;
  wire \tmp_3_i_reg_319_reg[29]_i_1_n_4 ;
  wire \tmp_3_i_reg_319_reg[29]_i_1_n_5 ;
  wire \tmp_3_i_reg_319_reg[29]_i_1_n_6 ;
  wire \tmp_3_i_reg_319_reg[29]_i_1_n_7 ;
  wire \tmp_3_i_reg_319_reg[31]_i_1_n_7 ;
  wire \tmp_3_i_reg_319_reg[5]_i_1_n_4 ;
  wire \tmp_3_i_reg_319_reg[5]_i_1_n_5 ;
  wire \tmp_3_i_reg_319_reg[5]_i_1_n_6 ;
  wire \tmp_3_i_reg_319_reg[5]_i_1_n_7 ;
  wire \tmp_3_i_reg_319_reg[9]_i_1_n_4 ;
  wire \tmp_3_i_reg_319_reg[9]_i_1_n_5 ;
  wire \tmp_3_i_reg_319_reg[9]_i_1_n_6 ;
  wire \tmp_3_i_reg_319_reg[9]_i_1_n_7 ;
  wire tmp_product__0_n_100;
  wire tmp_product__0_n_101;
  wire tmp_product__0_n_102;
  wire tmp_product__0_n_103;
  wire tmp_product__0_n_104;
  wire tmp_product__0_n_105;
  wire tmp_product__0_n_106;
  wire tmp_product__0_n_107;
  wire tmp_product__0_n_108;
  wire tmp_product__0_n_109;
  wire tmp_product__0_n_110;
  wire tmp_product__0_n_111;
  wire tmp_product__0_n_112;
  wire tmp_product__0_n_113;
  wire tmp_product__0_n_114;
  wire tmp_product__0_n_115;
  wire tmp_product__0_n_116;
  wire tmp_product__0_n_117;
  wire tmp_product__0_n_118;
  wire tmp_product__0_n_119;
  wire tmp_product__0_n_120;
  wire tmp_product__0_n_121;
  wire tmp_product__0_n_122;
  wire tmp_product__0_n_123;
  wire tmp_product__0_n_124;
  wire tmp_product__0_n_125;
  wire tmp_product__0_n_126;
  wire tmp_product__0_n_127;
  wire tmp_product__0_n_128;
  wire tmp_product__0_n_129;
  wire tmp_product__0_n_130;
  wire tmp_product__0_n_131;
  wire tmp_product__0_n_132;
  wire tmp_product__0_n_133;
  wire tmp_product__0_n_134;
  wire tmp_product__0_n_135;
  wire tmp_product__0_n_136;
  wire tmp_product__0_n_137;
  wire tmp_product__0_n_138;
  wire tmp_product__0_n_139;
  wire tmp_product__0_n_140;
  wire tmp_product__0_n_141;
  wire tmp_product__0_n_142;
  wire tmp_product__0_n_143;
  wire tmp_product__0_n_144;
  wire tmp_product__0_n_145;
  wire tmp_product__0_n_146;
  wire tmp_product__0_n_147;
  wire tmp_product__0_n_148;
  wire tmp_product__0_n_149;
  wire tmp_product__0_n_150;
  wire tmp_product__0_n_151;
  wire tmp_product__0_n_152;
  wire tmp_product__0_n_153;
  wire tmp_product__0_n_154;
  wire tmp_product__0_n_155;
  wire tmp_product__0_n_156;
  wire tmp_product__0_n_157;
  wire tmp_product__0_n_28;
  wire tmp_product__0_n_29;
  wire tmp_product__0_n_30;
  wire tmp_product__0_n_31;
  wire tmp_product__0_n_32;
  wire tmp_product__0_n_33;
  wire tmp_product__0_n_34;
  wire tmp_product__0_n_35;
  wire tmp_product__0_n_36;
  wire tmp_product__0_n_37;
  wire tmp_product__0_n_38;
  wire tmp_product__0_n_39;
  wire tmp_product__0_n_40;
  wire tmp_product__0_n_41;
  wire tmp_product__0_n_42;
  wire tmp_product__0_n_43;
  wire tmp_product__0_n_44;
  wire tmp_product__0_n_45;
  wire tmp_product__0_n_46;
  wire tmp_product__0_n_47;
  wire tmp_product__0_n_48;
  wire tmp_product__0_n_49;
  wire tmp_product__0_n_50;
  wire tmp_product__0_n_51;
  wire tmp_product__0_n_52;
  wire tmp_product__0_n_53;
  wire tmp_product__0_n_54;
  wire tmp_product__0_n_55;
  wire tmp_product__0_n_56;
  wire tmp_product__0_n_57;
  wire tmp_product__0_n_62;
  wire tmp_product__0_n_63;
  wire tmp_product__0_n_64;
  wire tmp_product__0_n_65;
  wire tmp_product__0_n_66;
  wire tmp_product__0_n_67;
  wire tmp_product__0_n_68;
  wire tmp_product__0_n_69;
  wire tmp_product__0_n_70;
  wire tmp_product__0_n_71;
  wire tmp_product__0_n_72;
  wire tmp_product__0_n_73;
  wire tmp_product__0_n_74;
  wire tmp_product__0_n_75;
  wire tmp_product__0_n_76;
  wire tmp_product__0_n_77;
  wire tmp_product__0_n_78;
  wire tmp_product__0_n_79;
  wire tmp_product__0_n_80;
  wire tmp_product__0_n_81;
  wire tmp_product__0_n_82;
  wire tmp_product__0_n_83;
  wire tmp_product__0_n_84;
  wire tmp_product__0_n_85;
  wire tmp_product__0_n_86;
  wire tmp_product__0_n_87;
  wire tmp_product__0_n_88;
  wire tmp_product__0_n_89;
  wire tmp_product__0_n_90;
  wire tmp_product__0_n_91;
  wire tmp_product__0_n_92;
  wire tmp_product__0_n_93;
  wire tmp_product__0_n_94;
  wire tmp_product__0_n_95;
  wire tmp_product__0_n_96;
  wire tmp_product__0_n_97;
  wire tmp_product__0_n_98;
  wire tmp_product__0_n_99;
  wire tmp_product_n_100;
  wire tmp_product_n_101;
  wire tmp_product_n_102;
  wire tmp_product_n_103;
  wire tmp_product_n_104;
  wire tmp_product_n_105;
  wire tmp_product_n_106;
  wire tmp_product_n_107;
  wire tmp_product_n_108;
  wire tmp_product_n_109;
  wire tmp_product_n_110;
  wire tmp_product_n_111;
  wire tmp_product_n_112;
  wire tmp_product_n_113;
  wire tmp_product_n_114;
  wire tmp_product_n_115;
  wire tmp_product_n_116;
  wire tmp_product_n_117;
  wire tmp_product_n_118;
  wire tmp_product_n_119;
  wire tmp_product_n_120;
  wire tmp_product_n_121;
  wire tmp_product_n_122;
  wire tmp_product_n_123;
  wire tmp_product_n_124;
  wire tmp_product_n_125;
  wire tmp_product_n_126;
  wire tmp_product_n_127;
  wire tmp_product_n_128;
  wire tmp_product_n_129;
  wire tmp_product_n_130;
  wire tmp_product_n_131;
  wire tmp_product_n_132;
  wire tmp_product_n_133;
  wire tmp_product_n_134;
  wire tmp_product_n_135;
  wire tmp_product_n_136;
  wire tmp_product_n_137;
  wire tmp_product_n_138;
  wire tmp_product_n_139;
  wire tmp_product_n_140;
  wire tmp_product_n_141;
  wire tmp_product_n_142;
  wire tmp_product_n_143;
  wire tmp_product_n_144;
  wire tmp_product_n_145;
  wire tmp_product_n_146;
  wire tmp_product_n_147;
  wire tmp_product_n_148;
  wire tmp_product_n_149;
  wire tmp_product_n_150;
  wire tmp_product_n_151;
  wire tmp_product_n_152;
  wire tmp_product_n_153;
  wire tmp_product_n_154;
  wire tmp_product_n_155;
  wire tmp_product_n_156;
  wire tmp_product_n_157;
  wire tmp_product_n_62;
  wire tmp_product_n_63;
  wire tmp_product_n_64;
  wire tmp_product_n_65;
  wire tmp_product_n_66;
  wire tmp_product_n_67;
  wire tmp_product_n_68;
  wire tmp_product_n_69;
  wire tmp_product_n_70;
  wire tmp_product_n_71;
  wire tmp_product_n_72;
  wire tmp_product_n_73;
  wire tmp_product_n_74;
  wire tmp_product_n_75;
  wire tmp_product_n_76;
  wire tmp_product_n_77;
  wire tmp_product_n_78;
  wire tmp_product_n_79;
  wire tmp_product_n_80;
  wire tmp_product_n_81;
  wire tmp_product_n_82;
  wire tmp_product_n_83;
  wire tmp_product_n_84;
  wire tmp_product_n_85;
  wire tmp_product_n_86;
  wire tmp_product_n_87;
  wire tmp_product_n_88;
  wire tmp_product_n_89;
  wire tmp_product_n_90;
  wire tmp_product_n_91;
  wire tmp_product_n_92;
  wire tmp_product_n_93;
  wire tmp_product_n_94;
  wire tmp_product_n_95;
  wire tmp_product_n_96;
  wire tmp_product_n_97;
  wire tmp_product_n_98;
  wire tmp_product_n_99;
  wire NLW_p_reg__0_CARRYCASCOUT_UNCONNECTED;
  wire NLW_p_reg__0_MULTSIGNOUT_UNCONNECTED;
  wire NLW_p_reg__0_OVERFLOW_UNCONNECTED;
  wire NLW_p_reg__0_PATTERNBDETECT_UNCONNECTED;
  wire NLW_p_reg__0_PATTERNDETECT_UNCONNECTED;
  wire NLW_p_reg__0_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_p_reg__0_ACOUT_UNCONNECTED;
  wire [17:0]NLW_p_reg__0_BCOUT_UNCONNECTED;
  wire [3:0]NLW_p_reg__0_CARRYOUT_UNCONNECTED;
  wire [47:0]NLW_p_reg__0_PCOUT_UNCONNECTED;
  wire NLW_p_reg__2_CARRYCASCOUT_UNCONNECTED;
  wire NLW_p_reg__2_MULTSIGNOUT_UNCONNECTED;
  wire NLW_p_reg__2_OVERFLOW_UNCONNECTED;
  wire NLW_p_reg__2_PATTERNBDETECT_UNCONNECTED;
  wire NLW_p_reg__2_PATTERNDETECT_UNCONNECTED;
  wire NLW_p_reg__2_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_p_reg__2_ACOUT_UNCONNECTED;
  wire [17:0]NLW_p_reg__2_BCOUT_UNCONNECTED;
  wire [3:0]NLW_p_reg__2_CARRYOUT_UNCONNECTED;
  wire [47:0]NLW_p_reg__2_PCOUT_UNCONNECTED;
  wire [3:1]\NLW_tmp_3_i_reg_319_reg[31]_i_1_CO_UNCONNECTED ;
  wire [3:2]\NLW_tmp_3_i_reg_319_reg[31]_i_1_O_UNCONNECTED ;
  wire NLW_tmp_product_CARRYCASCOUT_UNCONNECTED;
  wire NLW_tmp_product_MULTSIGNOUT_UNCONNECTED;
  wire NLW_tmp_product_OVERFLOW_UNCONNECTED;
  wire NLW_tmp_product_PATTERNBDETECT_UNCONNECTED;
  wire NLW_tmp_product_PATTERNDETECT_UNCONNECTED;
  wire NLW_tmp_product_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_tmp_product_ACOUT_UNCONNECTED;
  wire [17:0]NLW_tmp_product_BCOUT_UNCONNECTED;
  wire [3:0]NLW_tmp_product_CARRYOUT_UNCONNECTED;
  wire NLW_tmp_product__0_CARRYCASCOUT_UNCONNECTED;
  wire NLW_tmp_product__0_MULTSIGNOUT_UNCONNECTED;
  wire NLW_tmp_product__0_OVERFLOW_UNCONNECTED;
  wire NLW_tmp_product__0_PATTERNBDETECT_UNCONNECTED;
  wire NLW_tmp_product__0_PATTERNDETECT_UNCONNECTED;
  wire NLW_tmp_product__0_UNDERFLOW_UNCONNECTED;
  wire [17:0]NLW_tmp_product__0_BCOUT_UNCONNECTED;
  wire [3:0]NLW_tmp_product__0_CARRYOUT_UNCONNECTED;

  FDRE \p_reg[0] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(tmp_product_n_109),
        .Q(\p_reg_n_4_[0] ),
        .R(1'b0));
  FDRE \p_reg[10] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(tmp_product_n_99),
        .Q(\p_reg_n_4_[10] ),
        .R(1'b0));
  FDRE \p_reg[11] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(tmp_product_n_98),
        .Q(\p_reg_n_4_[11] ),
        .R(1'b0));
  FDRE \p_reg[12] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(tmp_product_n_97),
        .Q(\p_reg_n_4_[12] ),
        .R(1'b0));
  FDRE \p_reg[13] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(tmp_product_n_96),
        .Q(\p_reg_n_4_[13] ),
        .R(1'b0));
  FDRE \p_reg[14] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(tmp_product_n_95),
        .Q(\p_reg_n_4_[14] ),
        .R(1'b0));
  FDRE \p_reg[14]__0 
       (.C(ap_clk),
        .CE(1'b1),
        .D(tmp_product__0_n_95),
        .Q(D[0]),
        .R(1'b0));
  FDRE \p_reg[15] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(tmp_product_n_94),
        .Q(\p_reg_n_4_[15] ),
        .R(1'b0));
  FDRE \p_reg[15]__0 
       (.C(ap_clk),
        .CE(1'b1),
        .D(tmp_product__0_n_94),
        .Q(D[1]),
        .R(1'b0));
  FDRE \p_reg[16] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(tmp_product_n_93),
        .Q(\p_reg_n_4_[16] ),
        .R(1'b0));
  FDRE \p_reg[16]__0 
       (.C(ap_clk),
        .CE(1'b1),
        .D(tmp_product__0_n_93),
        .Q(\p_reg[16]__0_n_4 ),
        .R(1'b0));
  FDRE \p_reg[1] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(tmp_product_n_108),
        .Q(\p_reg_n_4_[1] ),
        .R(1'b0));
  FDRE \p_reg[2] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(tmp_product_n_107),
        .Q(\p_reg_n_4_[2] ),
        .R(1'b0));
  FDRE \p_reg[3] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(tmp_product_n_106),
        .Q(\p_reg_n_4_[3] ),
        .R(1'b0));
  FDRE \p_reg[4] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(tmp_product_n_105),
        .Q(\p_reg_n_4_[4] ),
        .R(1'b0));
  FDRE \p_reg[5] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(tmp_product_n_104),
        .Q(\p_reg_n_4_[5] ),
        .R(1'b0));
  FDRE \p_reg[6] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(tmp_product_n_103),
        .Q(\p_reg_n_4_[6] ),
        .R(1'b0));
  FDRE \p_reg[7] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(tmp_product_n_102),
        .Q(\p_reg_n_4_[7] ),
        .R(1'b0));
  FDRE \p_reg[8] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(tmp_product_n_101),
        .Q(\p_reg_n_4_[8] ),
        .R(1'b0));
  FDRE \p_reg[9] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(tmp_product_n_100),
        .Q(\p_reg_n_4_[9] ),
        .R(1'b0));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-10 {cell *THIS*} {string 15x15 4}}" *) 
  DSP48E1 #(
    .ACASCREG(1),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(1),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(1),
    .BREG(1),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(1),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    p_reg__0
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,fc1_output_q0[30:17]}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_p_reg__0_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({fc2_kernel_Dout_A[31],fc2_kernel_Dout_A[31],fc2_kernel_Dout_A[31],fc2_kernel_Dout_A[31:17]}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_p_reg__0_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_p_reg__0_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_p_reg__0_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(Q),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(Q),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b1),
        .CLK(ap_clk),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_p_reg__0_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b1,1'b0,1'b1,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_p_reg__0_OVERFLOW_UNCONNECTED),
        .P({p_reg__0_n_62,p_reg__0_n_63,p_reg__0_n_64,p_reg__0_n_65,p_reg__0_n_66,p_reg__0_n_67,p_reg__0_n_68,p_reg__0_n_69,p_reg__0_n_70,p_reg__0_n_71,p_reg__0_n_72,p_reg__0_n_73,p_reg__0_n_74,p_reg__0_n_75,p_reg__0_n_76,p_reg__0_n_77,p_reg__0_n_78,p_reg__0_n_79,p_reg__0_n_80,p_reg__0_n_81,p_reg__0_n_82,p_reg__0_n_83,p_reg__0_n_84,p_reg__0_n_85,p_reg__0_n_86,p_reg__0_n_87,p_reg__0_n_88,p_reg__0_n_89,p_reg__0_n_90,p_reg__0_n_91,p_reg__0_n_92,p_reg__0_n_93,p_reg__0_n_94,p_reg__0_n_95,p_reg__0_n_96,p_reg__0_n_97,p_reg__0_n_98,p_reg__0_n_99,p_reg__0_n_100,p_reg__0_n_101,p_reg__0_n_102,p_reg__0_n_103,p_reg__0_n_104,p_reg__0_n_105,p_reg__0_n_106,p_reg__0_n_107,p_reg__0_n_108,p_reg__0_n_109}),
        .PATTERNBDETECT(NLW_p_reg__0_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_p_reg__0_PATTERNDETECT_UNCONNECTED),
        .PCIN({tmp_product_n_110,tmp_product_n_111,tmp_product_n_112,tmp_product_n_113,tmp_product_n_114,tmp_product_n_115,tmp_product_n_116,tmp_product_n_117,tmp_product_n_118,tmp_product_n_119,tmp_product_n_120,tmp_product_n_121,tmp_product_n_122,tmp_product_n_123,tmp_product_n_124,tmp_product_n_125,tmp_product_n_126,tmp_product_n_127,tmp_product_n_128,tmp_product_n_129,tmp_product_n_130,tmp_product_n_131,tmp_product_n_132,tmp_product_n_133,tmp_product_n_134,tmp_product_n_135,tmp_product_n_136,tmp_product_n_137,tmp_product_n_138,tmp_product_n_139,tmp_product_n_140,tmp_product_n_141,tmp_product_n_142,tmp_product_n_143,tmp_product_n_144,tmp_product_n_145,tmp_product_n_146,tmp_product_n_147,tmp_product_n_148,tmp_product_n_149,tmp_product_n_150,tmp_product_n_151,tmp_product_n_152,tmp_product_n_153,tmp_product_n_154,tmp_product_n_155,tmp_product_n_156,tmp_product_n_157}),
        .PCOUT(NLW_p_reg__0_PCOUT_UNCONNECTED[47:0]),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_p_reg__0_UNDERFLOW_UNCONNECTED));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-10 {cell *THIS*} {string 18x15 4}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("CASCADE"),
    .BCASCREG(1),
    .BREG(1),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(1),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    p_reg__2
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACIN({tmp_product__0_n_28,tmp_product__0_n_29,tmp_product__0_n_30,tmp_product__0_n_31,tmp_product__0_n_32,tmp_product__0_n_33,tmp_product__0_n_34,tmp_product__0_n_35,tmp_product__0_n_36,tmp_product__0_n_37,tmp_product__0_n_38,tmp_product__0_n_39,tmp_product__0_n_40,tmp_product__0_n_41,tmp_product__0_n_42,tmp_product__0_n_43,tmp_product__0_n_44,tmp_product__0_n_45,tmp_product__0_n_46,tmp_product__0_n_47,tmp_product__0_n_48,tmp_product__0_n_49,tmp_product__0_n_50,tmp_product__0_n_51,tmp_product__0_n_52,tmp_product__0_n_53,tmp_product__0_n_54,tmp_product__0_n_55,tmp_product__0_n_56,tmp_product__0_n_57}),
        .ACOUT(NLW_p_reg__2_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({fc2_kernel_Dout_A[31],fc2_kernel_Dout_A[31],fc2_kernel_Dout_A[31],fc2_kernel_Dout_A[31:17]}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_p_reg__2_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_p_reg__2_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_p_reg__2_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(Q),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b1),
        .CLK(ap_clk),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_p_reg__2_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b1,1'b0,1'b1,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_p_reg__2_OVERFLOW_UNCONNECTED),
        .P({p_reg__2_n_62,p_reg__2_n_63,p_reg__2_n_64,p_reg__2_n_65,p_reg__2_n_66,p_reg__2_n_67,p_reg__2_n_68,p_reg__2_n_69,p_reg__2_n_70,p_reg__2_n_71,p_reg__2_n_72,p_reg__2_n_73,p_reg__2_n_74,p_reg__2_n_75,p_reg__2_n_76,p_reg__2_n_77,p_reg__2_n_78,p_reg__2_n_79,p_reg__2_n_80,p_reg__2_n_81,p_reg__2_n_82,p_reg__2_n_83,p_reg__2_n_84,p_reg__2_n_85,p_reg__2_n_86,p_reg__2_n_87,p_reg__2_n_88,p_reg__2_n_89,p_reg__2_n_90,p_reg__2_n_91,p_reg__2_n_92,p_reg__2_n_93,p_reg__2_n_94,p_reg__2_n_95,p_reg__2_n_96,p_reg__2_n_97,p_reg__2_n_98,p_reg__2_n_99,p_reg__2_n_100,p_reg__2_n_101,p_reg__2_n_102,p_reg__2_n_103,p_reg__2_n_104,p_reg__2_n_105,p_reg__2_n_106,p_reg__2_n_107,p_reg__2_n_108,p_reg__2_n_109}),
        .PATTERNBDETECT(NLW_p_reg__2_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_p_reg__2_PATTERNDETECT_UNCONNECTED),
        .PCIN({tmp_product__0_n_110,tmp_product__0_n_111,tmp_product__0_n_112,tmp_product__0_n_113,tmp_product__0_n_114,tmp_product__0_n_115,tmp_product__0_n_116,tmp_product__0_n_117,tmp_product__0_n_118,tmp_product__0_n_119,tmp_product__0_n_120,tmp_product__0_n_121,tmp_product__0_n_122,tmp_product__0_n_123,tmp_product__0_n_124,tmp_product__0_n_125,tmp_product__0_n_126,tmp_product__0_n_127,tmp_product__0_n_128,tmp_product__0_n_129,tmp_product__0_n_130,tmp_product__0_n_131,tmp_product__0_n_132,tmp_product__0_n_133,tmp_product__0_n_134,tmp_product__0_n_135,tmp_product__0_n_136,tmp_product__0_n_137,tmp_product__0_n_138,tmp_product__0_n_139,tmp_product__0_n_140,tmp_product__0_n_141,tmp_product__0_n_142,tmp_product__0_n_143,tmp_product__0_n_144,tmp_product__0_n_145,tmp_product__0_n_146,tmp_product__0_n_147,tmp_product__0_n_148,tmp_product__0_n_149,tmp_product__0_n_150,tmp_product__0_n_151,tmp_product__0_n_152,tmp_product__0_n_153,tmp_product__0_n_154,tmp_product__0_n_155,tmp_product__0_n_156,tmp_product__0_n_157}),
        .PCOUT(NLW_p_reg__2_PCOUT_UNCONNECTED[47:0]),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_p_reg__2_UNDERFLOW_UNCONNECTED));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[13]_i_2 
       (.I0(p_reg__2_n_99),
        .I1(\p_reg_n_4_[10] ),
        .O(\tmp_3_i_reg_319[13]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[13]_i_3 
       (.I0(p_reg__2_n_100),
        .I1(\p_reg_n_4_[9] ),
        .O(\tmp_3_i_reg_319[13]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[13]_i_4 
       (.I0(p_reg__2_n_101),
        .I1(\p_reg_n_4_[8] ),
        .O(\tmp_3_i_reg_319[13]_i_4_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[13]_i_5 
       (.I0(p_reg__2_n_102),
        .I1(\p_reg_n_4_[7] ),
        .O(\tmp_3_i_reg_319[13]_i_5_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[17]_i_2 
       (.I0(p_reg__2_n_95),
        .I1(\p_reg_n_4_[14] ),
        .O(\tmp_3_i_reg_319[17]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[17]_i_3 
       (.I0(p_reg__2_n_96),
        .I1(\p_reg_n_4_[13] ),
        .O(\tmp_3_i_reg_319[17]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[17]_i_4 
       (.I0(p_reg__2_n_97),
        .I1(\p_reg_n_4_[12] ),
        .O(\tmp_3_i_reg_319[17]_i_4_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[17]_i_5 
       (.I0(p_reg__2_n_98),
        .I1(\p_reg_n_4_[11] ),
        .O(\tmp_3_i_reg_319[17]_i_5_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[21]_i_2 
       (.I0(p_reg__2_n_91),
        .I1(p_reg__0_n_108),
        .O(\tmp_3_i_reg_319[21]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[21]_i_3 
       (.I0(p_reg__2_n_92),
        .I1(p_reg__0_n_109),
        .O(\tmp_3_i_reg_319[21]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[21]_i_4 
       (.I0(p_reg__2_n_93),
        .I1(\p_reg_n_4_[16] ),
        .O(\tmp_3_i_reg_319[21]_i_4_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[21]_i_5 
       (.I0(p_reg__2_n_94),
        .I1(\p_reg_n_4_[15] ),
        .O(\tmp_3_i_reg_319[21]_i_5_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[25]_i_2 
       (.I0(p_reg__2_n_87),
        .I1(p_reg__0_n_104),
        .O(\tmp_3_i_reg_319[25]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[25]_i_3 
       (.I0(p_reg__2_n_88),
        .I1(p_reg__0_n_105),
        .O(\tmp_3_i_reg_319[25]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[25]_i_4 
       (.I0(p_reg__2_n_89),
        .I1(p_reg__0_n_106),
        .O(\tmp_3_i_reg_319[25]_i_4_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[25]_i_5 
       (.I0(p_reg__2_n_90),
        .I1(p_reg__0_n_107),
        .O(\tmp_3_i_reg_319[25]_i_5_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[29]_i_2 
       (.I0(p_reg__2_n_83),
        .I1(p_reg__0_n_100),
        .O(\tmp_3_i_reg_319[29]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[29]_i_3 
       (.I0(p_reg__2_n_84),
        .I1(p_reg__0_n_101),
        .O(\tmp_3_i_reg_319[29]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[29]_i_4 
       (.I0(p_reg__2_n_85),
        .I1(p_reg__0_n_102),
        .O(\tmp_3_i_reg_319[29]_i_4_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[29]_i_5 
       (.I0(p_reg__2_n_86),
        .I1(p_reg__0_n_103),
        .O(\tmp_3_i_reg_319[29]_i_5_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[31]_i_2 
       (.I0(p_reg__2_n_81),
        .I1(p_reg__0_n_98),
        .O(\tmp_3_i_reg_319[31]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[31]_i_3 
       (.I0(p_reg__2_n_82),
        .I1(p_reg__0_n_99),
        .O(\tmp_3_i_reg_319[31]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[5]_i_2 
       (.I0(p_reg__2_n_107),
        .I1(\p_reg_n_4_[2] ),
        .O(\tmp_3_i_reg_319[5]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[5]_i_3 
       (.I0(p_reg__2_n_108),
        .I1(\p_reg_n_4_[1] ),
        .O(\tmp_3_i_reg_319[5]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[5]_i_4 
       (.I0(p_reg__2_n_109),
        .I1(\p_reg_n_4_[0] ),
        .O(\tmp_3_i_reg_319[5]_i_4_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[9]_i_2 
       (.I0(p_reg__2_n_103),
        .I1(\p_reg_n_4_[6] ),
        .O(\tmp_3_i_reg_319[9]_i_2_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[9]_i_3 
       (.I0(p_reg__2_n_104),
        .I1(\p_reg_n_4_[5] ),
        .O(\tmp_3_i_reg_319[9]_i_3_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[9]_i_4 
       (.I0(p_reg__2_n_105),
        .I1(\p_reg_n_4_[4] ),
        .O(\tmp_3_i_reg_319[9]_i_4_n_4 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_3_i_reg_319[9]_i_5 
       (.I0(p_reg__2_n_106),
        .I1(\p_reg_n_4_[3] ),
        .O(\tmp_3_i_reg_319[9]_i_5_n_4 ));
  CARRY4 \tmp_3_i_reg_319_reg[13]_i_1 
       (.CI(\tmp_3_i_reg_319_reg[9]_i_1_n_4 ),
        .CO({\tmp_3_i_reg_319_reg[13]_i_1_n_4 ,\tmp_3_i_reg_319_reg[13]_i_1_n_5 ,\tmp_3_i_reg_319_reg[13]_i_1_n_6 ,\tmp_3_i_reg_319_reg[13]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({p_reg__2_n_99,p_reg__2_n_100,p_reg__2_n_101,p_reg__2_n_102}),
        .O(D[13:10]),
        .S({\tmp_3_i_reg_319[13]_i_2_n_4 ,\tmp_3_i_reg_319[13]_i_3_n_4 ,\tmp_3_i_reg_319[13]_i_4_n_4 ,\tmp_3_i_reg_319[13]_i_5_n_4 }));
  CARRY4 \tmp_3_i_reg_319_reg[17]_i_1 
       (.CI(\tmp_3_i_reg_319_reg[13]_i_1_n_4 ),
        .CO({\tmp_3_i_reg_319_reg[17]_i_1_n_4 ,\tmp_3_i_reg_319_reg[17]_i_1_n_5 ,\tmp_3_i_reg_319_reg[17]_i_1_n_6 ,\tmp_3_i_reg_319_reg[17]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({p_reg__2_n_95,p_reg__2_n_96,p_reg__2_n_97,p_reg__2_n_98}),
        .O(D[17:14]),
        .S({\tmp_3_i_reg_319[17]_i_2_n_4 ,\tmp_3_i_reg_319[17]_i_3_n_4 ,\tmp_3_i_reg_319[17]_i_4_n_4 ,\tmp_3_i_reg_319[17]_i_5_n_4 }));
  CARRY4 \tmp_3_i_reg_319_reg[21]_i_1 
       (.CI(\tmp_3_i_reg_319_reg[17]_i_1_n_4 ),
        .CO({\tmp_3_i_reg_319_reg[21]_i_1_n_4 ,\tmp_3_i_reg_319_reg[21]_i_1_n_5 ,\tmp_3_i_reg_319_reg[21]_i_1_n_6 ,\tmp_3_i_reg_319_reg[21]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({p_reg__2_n_91,p_reg__2_n_92,p_reg__2_n_93,p_reg__2_n_94}),
        .O(D[21:18]),
        .S({\tmp_3_i_reg_319[21]_i_2_n_4 ,\tmp_3_i_reg_319[21]_i_3_n_4 ,\tmp_3_i_reg_319[21]_i_4_n_4 ,\tmp_3_i_reg_319[21]_i_5_n_4 }));
  CARRY4 \tmp_3_i_reg_319_reg[25]_i_1 
       (.CI(\tmp_3_i_reg_319_reg[21]_i_1_n_4 ),
        .CO({\tmp_3_i_reg_319_reg[25]_i_1_n_4 ,\tmp_3_i_reg_319_reg[25]_i_1_n_5 ,\tmp_3_i_reg_319_reg[25]_i_1_n_6 ,\tmp_3_i_reg_319_reg[25]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({p_reg__2_n_87,p_reg__2_n_88,p_reg__2_n_89,p_reg__2_n_90}),
        .O(D[25:22]),
        .S({\tmp_3_i_reg_319[25]_i_2_n_4 ,\tmp_3_i_reg_319[25]_i_3_n_4 ,\tmp_3_i_reg_319[25]_i_4_n_4 ,\tmp_3_i_reg_319[25]_i_5_n_4 }));
  CARRY4 \tmp_3_i_reg_319_reg[29]_i_1 
       (.CI(\tmp_3_i_reg_319_reg[25]_i_1_n_4 ),
        .CO({\tmp_3_i_reg_319_reg[29]_i_1_n_4 ,\tmp_3_i_reg_319_reg[29]_i_1_n_5 ,\tmp_3_i_reg_319_reg[29]_i_1_n_6 ,\tmp_3_i_reg_319_reg[29]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({p_reg__2_n_83,p_reg__2_n_84,p_reg__2_n_85,p_reg__2_n_86}),
        .O(D[29:26]),
        .S({\tmp_3_i_reg_319[29]_i_2_n_4 ,\tmp_3_i_reg_319[29]_i_3_n_4 ,\tmp_3_i_reg_319[29]_i_4_n_4 ,\tmp_3_i_reg_319[29]_i_5_n_4 }));
  CARRY4 \tmp_3_i_reg_319_reg[31]_i_1 
       (.CI(\tmp_3_i_reg_319_reg[29]_i_1_n_4 ),
        .CO({\NLW_tmp_3_i_reg_319_reg[31]_i_1_CO_UNCONNECTED [3:1],\tmp_3_i_reg_319_reg[31]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,p_reg__2_n_82}),
        .O({\NLW_tmp_3_i_reg_319_reg[31]_i_1_O_UNCONNECTED [3:2],D[31:30]}),
        .S({1'b0,1'b0,\tmp_3_i_reg_319[31]_i_2_n_4 ,\tmp_3_i_reg_319[31]_i_3_n_4 }));
  CARRY4 \tmp_3_i_reg_319_reg[5]_i_1 
       (.CI(1'b0),
        .CO({\tmp_3_i_reg_319_reg[5]_i_1_n_4 ,\tmp_3_i_reg_319_reg[5]_i_1_n_5 ,\tmp_3_i_reg_319_reg[5]_i_1_n_6 ,\tmp_3_i_reg_319_reg[5]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({p_reg__2_n_107,p_reg__2_n_108,p_reg__2_n_109,1'b0}),
        .O(D[5:2]),
        .S({\tmp_3_i_reg_319[5]_i_2_n_4 ,\tmp_3_i_reg_319[5]_i_3_n_4 ,\tmp_3_i_reg_319[5]_i_4_n_4 ,\p_reg[16]__0_n_4 }));
  CARRY4 \tmp_3_i_reg_319_reg[9]_i_1 
       (.CI(\tmp_3_i_reg_319_reg[5]_i_1_n_4 ),
        .CO({\tmp_3_i_reg_319_reg[9]_i_1_n_4 ,\tmp_3_i_reg_319_reg[9]_i_1_n_5 ,\tmp_3_i_reg_319_reg[9]_i_1_n_6 ,\tmp_3_i_reg_319_reg[9]_i_1_n_7 }),
        .CYINIT(1'b0),
        .DI({p_reg__2_n_103,p_reg__2_n_104,p_reg__2_n_105,p_reg__2_n_106}),
        .O(D[9:6]),
        .S({\tmp_3_i_reg_319[9]_i_2_n_4 ,\tmp_3_i_reg_319[9]_i_3_n_4 ,\tmp_3_i_reg_319[9]_i_4_n_4 ,\tmp_3_i_reg_319[9]_i_5_n_4 }));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-10 {cell *THIS*} {string 15x18 4}}" *) 
  DSP48E1 #(
    .ACASCREG(1),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(1),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(1),
    .BREG(1),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(0),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    tmp_product
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,fc2_kernel_Dout_A[16:0]}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_tmp_product_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({1'b0,1'b0,1'b0,1'b0,fc1_output_q0[30:17]}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_tmp_product_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_tmp_product_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_tmp_product_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(Q),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(Q),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b0),
        .CLK(ap_clk),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_tmp_product_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b0,1'b0,1'b0,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_tmp_product_OVERFLOW_UNCONNECTED),
        .P({tmp_product_n_62,tmp_product_n_63,tmp_product_n_64,tmp_product_n_65,tmp_product_n_66,tmp_product_n_67,tmp_product_n_68,tmp_product_n_69,tmp_product_n_70,tmp_product_n_71,tmp_product_n_72,tmp_product_n_73,tmp_product_n_74,tmp_product_n_75,tmp_product_n_76,tmp_product_n_77,tmp_product_n_78,tmp_product_n_79,tmp_product_n_80,tmp_product_n_81,tmp_product_n_82,tmp_product_n_83,tmp_product_n_84,tmp_product_n_85,tmp_product_n_86,tmp_product_n_87,tmp_product_n_88,tmp_product_n_89,tmp_product_n_90,tmp_product_n_91,tmp_product_n_92,tmp_product_n_93,tmp_product_n_94,tmp_product_n_95,tmp_product_n_96,tmp_product_n_97,tmp_product_n_98,tmp_product_n_99,tmp_product_n_100,tmp_product_n_101,tmp_product_n_102,tmp_product_n_103,tmp_product_n_104,tmp_product_n_105,tmp_product_n_106,tmp_product_n_107,tmp_product_n_108,tmp_product_n_109}),
        .PATTERNBDETECT(NLW_tmp_product_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_tmp_product_PATTERNDETECT_UNCONNECTED),
        .PCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .PCOUT({tmp_product_n_110,tmp_product_n_111,tmp_product_n_112,tmp_product_n_113,tmp_product_n_114,tmp_product_n_115,tmp_product_n_116,tmp_product_n_117,tmp_product_n_118,tmp_product_n_119,tmp_product_n_120,tmp_product_n_121,tmp_product_n_122,tmp_product_n_123,tmp_product_n_124,tmp_product_n_125,tmp_product_n_126,tmp_product_n_127,tmp_product_n_128,tmp_product_n_129,tmp_product_n_130,tmp_product_n_131,tmp_product_n_132,tmp_product_n_133,tmp_product_n_134,tmp_product_n_135,tmp_product_n_136,tmp_product_n_137,tmp_product_n_138,tmp_product_n_139,tmp_product_n_140,tmp_product_n_141,tmp_product_n_142,tmp_product_n_143,tmp_product_n_144,tmp_product_n_145,tmp_product_n_146,tmp_product_n_147,tmp_product_n_148,tmp_product_n_149,tmp_product_n_150,tmp_product_n_151,tmp_product_n_152,tmp_product_n_153,tmp_product_n_154,tmp_product_n_155,tmp_product_n_156,tmp_product_n_157}),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_tmp_product_UNDERFLOW_UNCONNECTED));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-10 {cell *THIS*} {string 18x18 4}}" *) 
  DSP48E1 #(
    .ACASCREG(1),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(1),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(1),
    .BREG(1),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(1),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(0),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    tmp_product__0
       (.A({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,fc1_output_q0[16:0]}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT({tmp_product__0_n_28,tmp_product__0_n_29,tmp_product__0_n_30,tmp_product__0_n_31,tmp_product__0_n_32,tmp_product__0_n_33,tmp_product__0_n_34,tmp_product__0_n_35,tmp_product__0_n_36,tmp_product__0_n_37,tmp_product__0_n_38,tmp_product__0_n_39,tmp_product__0_n_40,tmp_product__0_n_41,tmp_product__0_n_42,tmp_product__0_n_43,tmp_product__0_n_44,tmp_product__0_n_45,tmp_product__0_n_46,tmp_product__0_n_47,tmp_product__0_n_48,tmp_product__0_n_49,tmp_product__0_n_50,tmp_product__0_n_51,tmp_product__0_n_52,tmp_product__0_n_53,tmp_product__0_n_54,tmp_product__0_n_55,tmp_product__0_n_56,tmp_product__0_n_57}),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({1'b0,fc2_kernel_Dout_A[16:0]}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_tmp_product__0_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_tmp_product__0_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_tmp_product__0_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(Q),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(Q),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(1'b0),
        .CLK(ap_clk),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_tmp_product__0_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b0,1'b0,1'b0,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_tmp_product__0_OVERFLOW_UNCONNECTED),
        .P({tmp_product__0_n_62,tmp_product__0_n_63,tmp_product__0_n_64,tmp_product__0_n_65,tmp_product__0_n_66,tmp_product__0_n_67,tmp_product__0_n_68,tmp_product__0_n_69,tmp_product__0_n_70,tmp_product__0_n_71,tmp_product__0_n_72,tmp_product__0_n_73,tmp_product__0_n_74,tmp_product__0_n_75,tmp_product__0_n_76,tmp_product__0_n_77,tmp_product__0_n_78,tmp_product__0_n_79,tmp_product__0_n_80,tmp_product__0_n_81,tmp_product__0_n_82,tmp_product__0_n_83,tmp_product__0_n_84,tmp_product__0_n_85,tmp_product__0_n_86,tmp_product__0_n_87,tmp_product__0_n_88,tmp_product__0_n_89,tmp_product__0_n_90,tmp_product__0_n_91,tmp_product__0_n_92,tmp_product__0_n_93,tmp_product__0_n_94,tmp_product__0_n_95,tmp_product__0_n_96,tmp_product__0_n_97,tmp_product__0_n_98,tmp_product__0_n_99,tmp_product__0_n_100,tmp_product__0_n_101,tmp_product__0_n_102,tmp_product__0_n_103,tmp_product__0_n_104,tmp_product__0_n_105,tmp_product__0_n_106,tmp_product__0_n_107,tmp_product__0_n_108,tmp_product__0_n_109}),
        .PATTERNBDETECT(NLW_tmp_product__0_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_tmp_product__0_PATTERNDETECT_UNCONNECTED),
        .PCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .PCOUT({tmp_product__0_n_110,tmp_product__0_n_111,tmp_product__0_n_112,tmp_product__0_n_113,tmp_product__0_n_114,tmp_product__0_n_115,tmp_product__0_n_116,tmp_product__0_n_117,tmp_product__0_n_118,tmp_product__0_n_119,tmp_product__0_n_120,tmp_product__0_n_121,tmp_product__0_n_122,tmp_product__0_n_123,tmp_product__0_n_124,tmp_product__0_n_125,tmp_product__0_n_126,tmp_product__0_n_127,tmp_product__0_n_128,tmp_product__0_n_129,tmp_product__0_n_130,tmp_product__0_n_131,tmp_product__0_n_132,tmp_product__0_n_133,tmp_product__0_n_134,tmp_product__0_n_135,tmp_product__0_n_136,tmp_product__0_n_137,tmp_product__0_n_138,tmp_product__0_n_139,tmp_product__0_n_140,tmp_product__0_n_141,tmp_product__0_n_142,tmp_product__0_n_143,tmp_product__0_n_144,tmp_product__0_n_145,tmp_product__0_n_146,tmp_product__0_n_147,tmp_product__0_n_148,tmp_product__0_n_149,tmp_product__0_n_150,tmp_product__0_n_151,tmp_product__0_n_152,tmp_product__0_n_153,tmp_product__0_n_154,tmp_product__0_n_155,tmp_product__0_n_156,tmp_product__0_n_157}),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_tmp_product__0_UNDERFLOW_UNCONNECTED));
endmodule

(* CHECK_LICENSE_TYPE = "zed_lenet_cnn_1_0,a0_lenet_cnn,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "HLS" *) 
(* X_CORE_INFO = "a0_lenet_cnn,Vivado 2018.2" *) (* hls_module = "yes" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (ap_clk,
    ap_rst_n,
    ap_start,
    ap_done,
    ap_idle,
    ap_ready,
    input_r_Clk_A,
    input_r_Rst_A,
    input_r_EN_A,
    input_r_WEN_A,
    input_r_Addr_A,
    input_r_Din_A,
    input_r_Dout_A,
    conv1_kernel_Clk_A,
    conv1_kernel_Rst_A,
    conv1_kernel_EN_A,
    conv1_kernel_WEN_A,
    conv1_kernel_Addr_A,
    conv1_kernel_Din_A,
    conv1_kernel_Dout_A,
    conv1_bias_Clk_A,
    conv1_bias_Rst_A,
    conv1_bias_EN_A,
    conv1_bias_WEN_A,
    conv1_bias_Addr_A,
    conv1_bias_Din_A,
    conv1_bias_Dout_A,
    conv2_bias_Clk_A,
    conv2_bias_Rst_A,
    conv2_bias_EN_A,
    conv2_bias_WEN_A,
    conv2_bias_Addr_A,
    conv2_bias_Din_A,
    conv2_bias_Dout_A,
    fc1_bias_Clk_A,
    fc1_bias_Rst_A,
    fc1_bias_EN_A,
    fc1_bias_WEN_A,
    fc1_bias_Addr_A,
    fc1_bias_Din_A,
    fc1_bias_Dout_A,
    fc2_kernel_Clk_A,
    fc2_kernel_Rst_A,
    fc2_kernel_EN_A,
    fc2_kernel_WEN_A,
    fc2_kernel_Addr_A,
    fc2_kernel_Din_A,
    fc2_kernel_Dout_A,
    fc2_bias_Clk_A,
    fc2_bias_Rst_A,
    fc2_bias_EN_A,
    fc2_bias_WEN_A,
    fc2_bias_Addr_A,
    fc2_bias_Din_A,
    fc2_bias_Dout_A,
    output_r_Clk_A,
    output_r_Rst_A,
    output_r_EN_A,
    output_r_WEN_A,
    output_r_Addr_A,
    output_r_Din_A,
    output_r_Dout_A);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 ap_clk CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME ap_clk, ASSOCIATED_RESET ap_rst_n, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}}}, FREQ_HZ 100000000, PHASE 0.000, CLK_DOMAIN /clk_wiz_0_clk_out1" *) input ap_clk;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 ap_rst_n RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME ap_rst_n, POLARITY ACTIVE_LOW, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}}}" *) input ap_rst_n;
  (* X_INTERFACE_INFO = "xilinx.com:interface:acc_handshake:1.0 ap_ctrl start" *) input ap_start;
  (* X_INTERFACE_INFO = "xilinx.com:interface:acc_handshake:1.0 ap_ctrl done" *) output ap_done;
  (* X_INTERFACE_INFO = "xilinx.com:interface:acc_handshake:1.0 ap_ctrl idle" *) output ap_idle;
  (* X_INTERFACE_INFO = "xilinx.com:interface:acc_handshake:1.0 ap_ctrl ready" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME ap_ctrl, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {start {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} done {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} idle {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ready {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}}}" *) output ap_ready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 input_r_PORTA CLK" *) output input_r_Clk_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 input_r_PORTA RST" *) output input_r_Rst_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 input_r_PORTA EN" *) output input_r_EN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 input_r_PORTA WE" *) output [3:0]input_r_WEN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 input_r_PORTA ADDR" *) output [31:0]input_r_Addr_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 input_r_PORTA DIN" *) output [31:0]input_r_Din_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 input_r_PORTA DOUT" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME input_r_PORTA, MEM_WIDTH 32, MEM_SIZE 3136, MASTER_TYPE BRAM_CTRL, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {EN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ADDR {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} WE {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 4} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} DIN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}} DOUT {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}}, MEM_ECC NONE" *) input [31:0]input_r_Dout_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 conv1_kernel_PORTA CLK" *) output conv1_kernel_Clk_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 conv1_kernel_PORTA RST" *) output conv1_kernel_Rst_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 conv1_kernel_PORTA EN" *) output conv1_kernel_EN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 conv1_kernel_PORTA WE" *) output [3:0]conv1_kernel_WEN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 conv1_kernel_PORTA ADDR" *) output [31:0]conv1_kernel_Addr_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 conv1_kernel_PORTA DIN" *) output [31:0]conv1_kernel_Din_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 conv1_kernel_PORTA DOUT" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME conv1_kernel_PORTA, MEM_WIDTH 32, MEM_SIZE 2000, MASTER_TYPE BRAM_CTRL, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {EN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ADDR {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} WE {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 4} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} DIN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}} DOUT {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}}, MEM_ECC NONE" *) input [31:0]conv1_kernel_Dout_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 conv1_bias_PORTA CLK" *) output conv1_bias_Clk_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 conv1_bias_PORTA RST" *) output conv1_bias_Rst_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 conv1_bias_PORTA EN" *) output conv1_bias_EN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 conv1_bias_PORTA WE" *) output [3:0]conv1_bias_WEN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 conv1_bias_PORTA ADDR" *) output [31:0]conv1_bias_Addr_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 conv1_bias_PORTA DIN" *) output [31:0]conv1_bias_Din_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 conv1_bias_PORTA DOUT" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME conv1_bias_PORTA, MEM_WIDTH 32, MEM_SIZE 80, MASTER_TYPE BRAM_CTRL, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {EN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ADDR {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} WE {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 4} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} DIN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}} DOUT {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}}, MEM_ECC NONE" *) input [31:0]conv1_bias_Dout_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 conv2_bias_PORTA CLK" *) output conv2_bias_Clk_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 conv2_bias_PORTA RST" *) output conv2_bias_Rst_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 conv2_bias_PORTA EN" *) output conv2_bias_EN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 conv2_bias_PORTA WE" *) output [3:0]conv2_bias_WEN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 conv2_bias_PORTA ADDR" *) output [31:0]conv2_bias_Addr_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 conv2_bias_PORTA DIN" *) output [31:0]conv2_bias_Din_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 conv2_bias_PORTA DOUT" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME conv2_bias_PORTA, MEM_WIDTH 32, MEM_SIZE 160, MASTER_TYPE BRAM_CTRL, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {EN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ADDR {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} WE {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 4} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} DIN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}} DOUT {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}}, MEM_ECC NONE" *) input [31:0]conv2_bias_Dout_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 fc1_bias_PORTA CLK" *) output fc1_bias_Clk_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 fc1_bias_PORTA RST" *) output fc1_bias_Rst_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 fc1_bias_PORTA EN" *) output fc1_bias_EN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 fc1_bias_PORTA WE" *) output [3:0]fc1_bias_WEN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 fc1_bias_PORTA ADDR" *) output [31:0]fc1_bias_Addr_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 fc1_bias_PORTA DIN" *) output [31:0]fc1_bias_Din_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 fc1_bias_PORTA DOUT" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME fc1_bias_PORTA, MEM_WIDTH 32, MEM_SIZE 1600, MASTER_TYPE BRAM_CTRL, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {EN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ADDR {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} WE {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 4} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} DIN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}} DOUT {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}}, MEM_ECC NONE" *) input [31:0]fc1_bias_Dout_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 fc2_kernel_PORTA CLK" *) output fc2_kernel_Clk_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 fc2_kernel_PORTA RST" *) output fc2_kernel_Rst_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 fc2_kernel_PORTA EN" *) output fc2_kernel_EN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 fc2_kernel_PORTA WE" *) output [3:0]fc2_kernel_WEN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 fc2_kernel_PORTA ADDR" *) output [31:0]fc2_kernel_Addr_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 fc2_kernel_PORTA DIN" *) output [31:0]fc2_kernel_Din_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 fc2_kernel_PORTA DOUT" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME fc2_kernel_PORTA, MEM_WIDTH 32, MEM_SIZE 16000, MASTER_TYPE BRAM_CTRL, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {EN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ADDR {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} WE {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 4} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} DIN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}} DOUT {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}}, MEM_ECC NONE" *) input [31:0]fc2_kernel_Dout_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 fc2_bias_PORTA CLK" *) output fc2_bias_Clk_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 fc2_bias_PORTA RST" *) output fc2_bias_Rst_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 fc2_bias_PORTA EN" *) output fc2_bias_EN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 fc2_bias_PORTA WE" *) output [3:0]fc2_bias_WEN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 fc2_bias_PORTA ADDR" *) output [31:0]fc2_bias_Addr_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 fc2_bias_PORTA DIN" *) output [31:0]fc2_bias_Din_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 fc2_bias_PORTA DOUT" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME fc2_bias_PORTA, MEM_WIDTH 32, MEM_SIZE 40, MASTER_TYPE BRAM_CTRL, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {EN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ADDR {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} WE {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 4} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} DIN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}} DOUT {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}}, MEM_ECC NONE" *) input [31:0]fc2_bias_Dout_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 output_r_PORTA CLK" *) output output_r_Clk_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 output_r_PORTA RST" *) output output_r_Rst_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 output_r_PORTA EN" *) output output_r_EN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 output_r_PORTA WE" *) output [3:0]output_r_WEN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 output_r_PORTA ADDR" *) output [31:0]output_r_Addr_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 output_r_PORTA DIN" *) output [31:0]output_r_Din_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 output_r_PORTA DOUT" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME output_r_PORTA, MEM_WIDTH 32, MEM_SIZE 40, MASTER_TYPE BRAM_CTRL, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {EN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ADDR {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} WE {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 4} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} DIN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}} DOUT {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}}, MEM_ECC NONE" *) input [31:0]output_r_Dout_A;

  wire ap_clk;
  wire ap_done;
  wire ap_idle;
  wire ap_ready;
  wire ap_rst_n;
  wire ap_start;
  wire [31:0]conv1_bias_Addr_A;
  wire conv1_bias_Clk_A;
  wire [31:0]conv1_bias_Din_A;
  wire [31:0]conv1_bias_Dout_A;
  wire conv1_bias_EN_A;
  wire conv1_bias_Rst_A;
  wire [3:0]conv1_bias_WEN_A;
  wire [31:0]conv1_kernel_Addr_A;
  wire conv1_kernel_Clk_A;
  wire [31:0]conv1_kernel_Din_A;
  wire [31:0]conv1_kernel_Dout_A;
  wire conv1_kernel_EN_A;
  wire conv1_kernel_Rst_A;
  wire [3:0]conv1_kernel_WEN_A;
  wire [31:0]conv2_bias_Addr_A;
  wire conv2_bias_Clk_A;
  wire [31:0]conv2_bias_Din_A;
  wire [31:0]conv2_bias_Dout_A;
  wire conv2_bias_EN_A;
  wire conv2_bias_Rst_A;
  wire [3:0]conv2_bias_WEN_A;
  wire [31:0]fc1_bias_Addr_A;
  wire fc1_bias_Clk_A;
  wire [31:0]fc1_bias_Din_A;
  wire [31:0]fc1_bias_Dout_A;
  wire fc1_bias_EN_A;
  wire fc1_bias_Rst_A;
  wire [3:0]fc1_bias_WEN_A;
  wire [31:0]fc2_bias_Addr_A;
  wire fc2_bias_Clk_A;
  wire [31:0]fc2_bias_Din_A;
  wire [31:0]fc2_bias_Dout_A;
  wire fc2_bias_EN_A;
  wire fc2_bias_Rst_A;
  wire [3:0]fc2_bias_WEN_A;
  wire [31:0]fc2_kernel_Addr_A;
  wire fc2_kernel_Clk_A;
  wire [31:0]fc2_kernel_Din_A;
  wire [31:0]fc2_kernel_Dout_A;
  wire fc2_kernel_EN_A;
  wire fc2_kernel_Rst_A;
  wire [3:0]fc2_kernel_WEN_A;
  wire [31:0]input_r_Addr_A;
  wire input_r_Clk_A;
  wire [31:0]input_r_Din_A;
  wire [31:0]input_r_Dout_A;
  wire input_r_EN_A;
  wire input_r_Rst_A;
  wire [3:0]input_r_WEN_A;
  wire [31:0]output_r_Addr_A;
  wire output_r_Clk_A;
  wire [31:0]output_r_Din_A;
  wire [31:0]output_r_Dout_A;
  wire output_r_EN_A;
  wire output_r_Rst_A;
  wire [3:0]output_r_WEN_A;

  (* SDX_KERNEL = "true" *) 
  (* SDX_KERNEL_SYNTH_INST = "inst" *) 
  (* SDX_KERNEL_TYPE = "hls" *) 
  (* ap_ST_fsm_state1 = "4'b0001" *) 
  (* ap_ST_fsm_state2 = "4'b0010" *) 
  (* ap_ST_fsm_state3 = "4'b0100" *) 
  (* ap_ST_fsm_state4 = "4'b1000" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_lenet_cnn inst
       (.ap_clk(ap_clk),
        .ap_done(ap_done),
        .ap_idle(ap_idle),
        .ap_ready(ap_ready),
        .ap_rst_n(ap_rst_n),
        .ap_start(ap_start),
        .conv1_bias_Addr_A(conv1_bias_Addr_A),
        .conv1_bias_Clk_A(conv1_bias_Clk_A),
        .conv1_bias_Din_A(conv1_bias_Din_A),
        .conv1_bias_Dout_A(conv1_bias_Dout_A),
        .conv1_bias_EN_A(conv1_bias_EN_A),
        .conv1_bias_Rst_A(conv1_bias_Rst_A),
        .conv1_bias_WEN_A(conv1_bias_WEN_A),
        .conv1_kernel_Addr_A(conv1_kernel_Addr_A),
        .conv1_kernel_Clk_A(conv1_kernel_Clk_A),
        .conv1_kernel_Din_A(conv1_kernel_Din_A),
        .conv1_kernel_Dout_A(conv1_kernel_Dout_A),
        .conv1_kernel_EN_A(conv1_kernel_EN_A),
        .conv1_kernel_Rst_A(conv1_kernel_Rst_A),
        .conv1_kernel_WEN_A(conv1_kernel_WEN_A),
        .conv2_bias_Addr_A(conv2_bias_Addr_A),
        .conv2_bias_Clk_A(conv2_bias_Clk_A),
        .conv2_bias_Din_A(conv2_bias_Din_A),
        .conv2_bias_Dout_A(conv2_bias_Dout_A),
        .conv2_bias_EN_A(conv2_bias_EN_A),
        .conv2_bias_Rst_A(conv2_bias_Rst_A),
        .conv2_bias_WEN_A(conv2_bias_WEN_A),
        .fc1_bias_Addr_A(fc1_bias_Addr_A),
        .fc1_bias_Clk_A(fc1_bias_Clk_A),
        .fc1_bias_Din_A(fc1_bias_Din_A),
        .fc1_bias_Dout_A(fc1_bias_Dout_A),
        .fc1_bias_EN_A(fc1_bias_EN_A),
        .fc1_bias_Rst_A(fc1_bias_Rst_A),
        .fc1_bias_WEN_A(fc1_bias_WEN_A),
        .fc2_bias_Addr_A(fc2_bias_Addr_A),
        .fc2_bias_Clk_A(fc2_bias_Clk_A),
        .fc2_bias_Din_A(fc2_bias_Din_A),
        .fc2_bias_Dout_A(fc2_bias_Dout_A),
        .fc2_bias_EN_A(fc2_bias_EN_A),
        .fc2_bias_Rst_A(fc2_bias_Rst_A),
        .fc2_bias_WEN_A(fc2_bias_WEN_A),
        .fc2_kernel_Addr_A(fc2_kernel_Addr_A),
        .fc2_kernel_Clk_A(fc2_kernel_Clk_A),
        .fc2_kernel_Din_A(fc2_kernel_Din_A),
        .fc2_kernel_Dout_A(fc2_kernel_Dout_A),
        .fc2_kernel_EN_A(fc2_kernel_EN_A),
        .fc2_kernel_Rst_A(fc2_kernel_Rst_A),
        .fc2_kernel_WEN_A(fc2_kernel_WEN_A),
        .input_r_Addr_A(input_r_Addr_A),
        .input_r_Clk_A(input_r_Clk_A),
        .input_r_Din_A(input_r_Din_A),
        .input_r_Dout_A(input_r_Dout_A),
        .input_r_EN_A(input_r_EN_A),
        .input_r_Rst_A(input_r_Rst_A),
        .input_r_WEN_A(input_r_WEN_A),
        .output_r_Addr_A(output_r_Addr_A),
        .output_r_Clk_A(output_r_Clk_A),
        .output_r_Din_A(output_r_Din_A),
        .output_r_Dout_A(output_r_Dout_A),
        .output_r_EN_A(output_r_EN_A),
        .output_r_Rst_A(output_r_Rst_A),
        .output_r_WEN_A(output_r_WEN_A));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

endmodule
`endif
