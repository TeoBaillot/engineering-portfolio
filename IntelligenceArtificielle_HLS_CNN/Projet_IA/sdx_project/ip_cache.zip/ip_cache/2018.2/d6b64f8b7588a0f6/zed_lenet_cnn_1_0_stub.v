// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2018.2 (lin64) Build 2258646 Thu Jun 14 20:02:38 MDT 2018
// Date        : Wed Dec 17 16:21:10 2025
// Host        : PCII-REF running 64-bit Ubuntu 22.04.5 LTS
// Command     : write_verilog -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ zed_lenet_cnn_1_0_stub.v
// Design      : zed_lenet_cnn_1_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg484-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "a0_lenet_cnn,Vivado 2018.2" *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix(ap_clk, ap_rst_n, ap_start, ap_done, ap_idle, 
  ap_ready, input_r_Clk_A, input_r_Rst_A, input_r_EN_A, input_r_WEN_A, input_r_Addr_A, 
  input_r_Din_A, input_r_Dout_A, conv1_kernel_Clk_A, conv1_kernel_Rst_A, conv1_kernel_EN_A, 
  conv1_kernel_WEN_A, conv1_kernel_Addr_A, conv1_kernel_Din_A, conv1_kernel_Dout_A, 
  conv1_bias_Clk_A, conv1_bias_Rst_A, conv1_bias_EN_A, conv1_bias_WEN_A, conv1_bias_Addr_A, 
  conv1_bias_Din_A, conv1_bias_Dout_A, conv2_bias_Clk_A, conv2_bias_Rst_A, conv2_bias_EN_A, 
  conv2_bias_WEN_A, conv2_bias_Addr_A, conv2_bias_Din_A, conv2_bias_Dout_A, fc1_bias_Clk_A, 
  fc1_bias_Rst_A, fc1_bias_EN_A, fc1_bias_WEN_A, fc1_bias_Addr_A, fc1_bias_Din_A, 
  fc1_bias_Dout_A, fc2_kernel_Clk_A, fc2_kernel_Rst_A, fc2_kernel_EN_A, fc2_kernel_WEN_A, 
  fc2_kernel_Addr_A, fc2_kernel_Din_A, fc2_kernel_Dout_A, fc2_bias_Clk_A, fc2_bias_Rst_A, 
  fc2_bias_EN_A, fc2_bias_WEN_A, fc2_bias_Addr_A, fc2_bias_Din_A, fc2_bias_Dout_A, 
  output_r_Clk_A, output_r_Rst_A, output_r_EN_A, output_r_WEN_A, output_r_Addr_A, 
  output_r_Din_A, output_r_Dout_A)
/* synthesis syn_black_box black_box_pad_pin="ap_clk,ap_rst_n,ap_start,ap_done,ap_idle,ap_ready,input_r_Clk_A,input_r_Rst_A,input_r_EN_A,input_r_WEN_A[3:0],input_r_Addr_A[31:0],input_r_Din_A[31:0],input_r_Dout_A[31:0],conv1_kernel_Clk_A,conv1_kernel_Rst_A,conv1_kernel_EN_A,conv1_kernel_WEN_A[3:0],conv1_kernel_Addr_A[31:0],conv1_kernel_Din_A[31:0],conv1_kernel_Dout_A[31:0],conv1_bias_Clk_A,conv1_bias_Rst_A,conv1_bias_EN_A,conv1_bias_WEN_A[3:0],conv1_bias_Addr_A[31:0],conv1_bias_Din_A[31:0],conv1_bias_Dout_A[31:0],conv2_bias_Clk_A,conv2_bias_Rst_A,conv2_bias_EN_A,conv2_bias_WEN_A[3:0],conv2_bias_Addr_A[31:0],conv2_bias_Din_A[31:0],conv2_bias_Dout_A[31:0],fc1_bias_Clk_A,fc1_bias_Rst_A,fc1_bias_EN_A,fc1_bias_WEN_A[3:0],fc1_bias_Addr_A[31:0],fc1_bias_Din_A[31:0],fc1_bias_Dout_A[31:0],fc2_kernel_Clk_A,fc2_kernel_Rst_A,fc2_kernel_EN_A,fc2_kernel_WEN_A[3:0],fc2_kernel_Addr_A[31:0],fc2_kernel_Din_A[31:0],fc2_kernel_Dout_A[31:0],fc2_bias_Clk_A,fc2_bias_Rst_A,fc2_bias_EN_A,fc2_bias_WEN_A[3:0],fc2_bias_Addr_A[31:0],fc2_bias_Din_A[31:0],fc2_bias_Dout_A[31:0],output_r_Clk_A,output_r_Rst_A,output_r_EN_A,output_r_WEN_A[3:0],output_r_Addr_A[31:0],output_r_Din_A[31:0],output_r_Dout_A[31:0]" */;
  input ap_clk;
  input ap_rst_n;
  input ap_start;
  output ap_done;
  output ap_idle;
  output ap_ready;
  output input_r_Clk_A;
  output input_r_Rst_A;
  output input_r_EN_A;
  output [3:0]input_r_WEN_A;
  output [31:0]input_r_Addr_A;
  output [31:0]input_r_Din_A;
  input [31:0]input_r_Dout_A;
  output conv1_kernel_Clk_A;
  output conv1_kernel_Rst_A;
  output conv1_kernel_EN_A;
  output [3:0]conv1_kernel_WEN_A;
  output [31:0]conv1_kernel_Addr_A;
  output [31:0]conv1_kernel_Din_A;
  input [31:0]conv1_kernel_Dout_A;
  output conv1_bias_Clk_A;
  output conv1_bias_Rst_A;
  output conv1_bias_EN_A;
  output [3:0]conv1_bias_WEN_A;
  output [31:0]conv1_bias_Addr_A;
  output [31:0]conv1_bias_Din_A;
  input [31:0]conv1_bias_Dout_A;
  output conv2_bias_Clk_A;
  output conv2_bias_Rst_A;
  output conv2_bias_EN_A;
  output [3:0]conv2_bias_WEN_A;
  output [31:0]conv2_bias_Addr_A;
  output [31:0]conv2_bias_Din_A;
  input [31:0]conv2_bias_Dout_A;
  output fc1_bias_Clk_A;
  output fc1_bias_Rst_A;
  output fc1_bias_EN_A;
  output [3:0]fc1_bias_WEN_A;
  output [31:0]fc1_bias_Addr_A;
  output [31:0]fc1_bias_Din_A;
  input [31:0]fc1_bias_Dout_A;
  output fc2_kernel_Clk_A;
  output fc2_kernel_Rst_A;
  output fc2_kernel_EN_A;
  output [3:0]fc2_kernel_WEN_A;
  output [31:0]fc2_kernel_Addr_A;
  output [31:0]fc2_kernel_Din_A;
  input [31:0]fc2_kernel_Dout_A;
  output fc2_bias_Clk_A;
  output fc2_bias_Rst_A;
  output fc2_bias_EN_A;
  output [3:0]fc2_bias_WEN_A;
  output [31:0]fc2_bias_Addr_A;
  output [31:0]fc2_bias_Din_A;
  input [31:0]fc2_bias_Dout_A;
  output output_r_Clk_A;
  output output_r_Rst_A;
  output output_r_EN_A;
  output [3:0]output_r_WEN_A;
  output [31:0]output_r_Addr_A;
  output [31:0]output_r_Din_A;
  input [31:0]output_r_Dout_A;
endmodule
