-- Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2018.2 (lin64) Build 2258646 Thu Jun 14 20:02:38 MDT 2018
-- Date        : Wed Dec 17 17:30:05 2025
-- Host        : PCII-REF running 64-bit Ubuntu 22.04.5 LTS
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ zed_Conv2_12x12x20_5x5x40_1_0_1_0_sim_netlist.vhdl
-- Design      : zed_Conv2_12x12x20_5x5x40_1_0_1_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg484-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0 is
  port (
    ap_clk : in STD_LOGIC;
    ap_rst_n : in STD_LOGIC;
    ap_start : in STD_LOGIC;
    ap_done : out STD_LOGIC;
    ap_idle : out STD_LOGIC;
    ap_ready : out STD_LOGIC;
    input_r_Addr_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    input_r_EN_A : out STD_LOGIC;
    input_r_WEN_A : out STD_LOGIC_VECTOR ( 3 downto 0 );
    input_r_Din_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    input_r_Dout_A : in STD_LOGIC_VECTOR ( 31 downto 0 );
    input_r_Clk_A : out STD_LOGIC;
    input_r_Rst_A : out STD_LOGIC;
    bias_Addr_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    bias_EN_A : out STD_LOGIC;
    bias_WEN_A : out STD_LOGIC_VECTOR ( 3 downto 0 );
    bias_Din_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    bias_Dout_A : in STD_LOGIC_VECTOR ( 31 downto 0 );
    bias_Clk_A : out STD_LOGIC;
    bias_Rst_A : out STD_LOGIC;
    output_r_Addr_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    output_r_EN_A : out STD_LOGIC;
    output_r_WEN_A : out STD_LOGIC_VECTOR ( 3 downto 0 );
    output_r_Din_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    output_r_Dout_A : in STD_LOGIC_VECTOR ( 31 downto 0 );
    output_r_Clk_A : out STD_LOGIC;
    output_r_Rst_A : out STD_LOGIC
  );
  attribute ap_ST_fsm_state1 : string;
  attribute ap_ST_fsm_state1 of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0 : entity is "6'b000001";
  attribute ap_ST_fsm_state2 : string;
  attribute ap_ST_fsm_state2 of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0 : entity is "6'b000010";
  attribute ap_ST_fsm_state3 : string;
  attribute ap_ST_fsm_state3 of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0 : entity is "6'b000100";
  attribute ap_ST_fsm_state4 : string;
  attribute ap_ST_fsm_state4 of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0 : entity is "6'b001000";
  attribute ap_ST_fsm_state5 : string;
  attribute ap_ST_fsm_state5 of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0 : entity is "6'b010000";
  attribute ap_ST_fsm_state6 : string;
  attribute ap_ST_fsm_state6 of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0 : entity is "6'b100000";
  attribute hls_module : string;
  attribute hls_module of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0 : entity is "yes";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0 is
  signal \<const0>\ : STD_LOGIC;
  signal \ap_CS_fsm[4]_i_1_n_0\ : STD_LOGIC;
  signal \ap_CS_fsm_reg_n_0_[0]\ : STD_LOGIC;
  signal ap_CS_fsm_state2 : STD_LOGIC;
  signal ap_CS_fsm_state3 : STD_LOGIC;
  signal ap_CS_fsm_state5 : STD_LOGIC;
  signal ap_NS_fsm : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal ap_NS_fsm1 : STD_LOGIC;
  signal ap_NS_fsm10_out : STD_LOGIC;
  signal \^ap_clk\ : STD_LOGIC;
  signal \^ap_done\ : STD_LOGIC;
  signal \^bias_addr_a\ : STD_LOGIC_VECTOR ( 7 downto 2 );
  signal \^bias_en_a\ : STD_LOGIC;
  signal exitcond5_fu_116_p2 : STD_LOGIC;
  signal filter_index_1_fu_122_p2 : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal filter_index_1_reg_224 : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal filter_index_reg_83 : STD_LOGIC;
  signal \filter_index_reg_83_reg_n_0_[0]\ : STD_LOGIC;
  signal \filter_index_reg_83_reg_n_0_[1]\ : STD_LOGIC;
  signal \filter_index_reg_83_reg_n_0_[2]\ : STD_LOGIC;
  signal \filter_index_reg_83_reg_n_0_[3]\ : STD_LOGIC;
  signal \filter_index_reg_83_reg_n_0_[4]\ : STD_LOGIC;
  signal \filter_index_reg_83_reg_n_0_[5]\ : STD_LOGIC;
  signal \^input_r_rst_a\ : STD_LOGIC;
  signal \^output_r_addr_a\ : STD_LOGIC_VECTOR ( 14 downto 2 );
  signal \^output_r_din_a\ : STD_LOGIC_VECTOR ( 30 downto 0 );
  signal \^output_r_wen_a\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal p_0_in : STD_LOGIC;
  signal \res_1_reg_265[30]_i_10_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_11_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_13_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_14_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_15_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_16_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_17_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_18_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_19_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_1_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_20_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_22_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_23_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_24_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_25_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_26_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_27_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_28_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_29_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_30_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_31_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_32_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_33_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_34_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_35_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_36_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_37_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_4_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_5_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_6_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_7_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_8_n_0\ : STD_LOGIC;
  signal \res_1_reg_265[30]_i_9_n_0\ : STD_LOGIC;
  signal \res_1_reg_265_reg[30]_i_12_n_0\ : STD_LOGIC;
  signal \res_1_reg_265_reg[30]_i_12_n_1\ : STD_LOGIC;
  signal \res_1_reg_265_reg[30]_i_12_n_2\ : STD_LOGIC;
  signal \res_1_reg_265_reg[30]_i_12_n_3\ : STD_LOGIC;
  signal \res_1_reg_265_reg[30]_i_21_n_0\ : STD_LOGIC;
  signal \res_1_reg_265_reg[30]_i_21_n_1\ : STD_LOGIC;
  signal \res_1_reg_265_reg[30]_i_21_n_2\ : STD_LOGIC;
  signal \res_1_reg_265_reg[30]_i_21_n_3\ : STD_LOGIC;
  signal \res_1_reg_265_reg[30]_i_2_n_1\ : STD_LOGIC;
  signal \res_1_reg_265_reg[30]_i_2_n_2\ : STD_LOGIC;
  signal \res_1_reg_265_reg[30]_i_2_n_3\ : STD_LOGIC;
  signal \res_1_reg_265_reg[30]_i_3_n_0\ : STD_LOGIC;
  signal \res_1_reg_265_reg[30]_i_3_n_1\ : STD_LOGIC;
  signal \res_1_reg_265_reg[30]_i_3_n_2\ : STD_LOGIC;
  signal \res_1_reg_265_reg[30]_i_3_n_3\ : STD_LOGIC;
  signal tmp_3_fu_161_p2 : STD_LOGIC_VECTOR ( 9 downto 3 );
  signal tmp_6_cast_reg_247 : STD_LOGIC_VECTOR ( 12 downto 3 );
  signal \tmp_6_cast_reg_247[9]_i_2_n_0\ : STD_LOGIC;
  signal \tmp_6_cast_reg_247_reg[12]_i_1_n_3\ : STD_LOGIC;
  signal \tmp_6_cast_reg_247_reg[9]_i_1_n_0\ : STD_LOGIC;
  signal \tmp_6_cast_reg_247_reg[9]_i_1_n_1\ : STD_LOGIC;
  signal \tmp_6_cast_reg_247_reg[9]_i_1_n_2\ : STD_LOGIC;
  signal \tmp_6_cast_reg_247_reg[9]_i_1_n_3\ : STD_LOGIC;
  signal tmp_8_fu_190_p2 : STD_LOGIC_VECTOR ( 12 downto 3 );
  signal tmp_8_reg_2600 : STD_LOGIC;
  signal \tmp_8_reg_260[6]_i_2_n_0\ : STD_LOGIC;
  signal \tmp_8_reg_260_reg[10]_i_1_n_0\ : STD_LOGIC;
  signal \tmp_8_reg_260_reg[10]_i_1_n_1\ : STD_LOGIC;
  signal \tmp_8_reg_260_reg[10]_i_1_n_2\ : STD_LOGIC;
  signal \tmp_8_reg_260_reg[10]_i_1_n_3\ : STD_LOGIC;
  signal \tmp_8_reg_260_reg[12]_i_2_n_3\ : STD_LOGIC;
  signal \tmp_8_reg_260_reg[6]_i_1_n_0\ : STD_LOGIC;
  signal \tmp_8_reg_260_reg[6]_i_1_n_1\ : STD_LOGIC;
  signal \tmp_8_reg_260_reg[6]_i_1_n_2\ : STD_LOGIC;
  signal \tmp_8_reg_260_reg[6]_i_1_n_3\ : STD_LOGIC;
  signal x_1_fu_180_p2 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal x_1_reg_255 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal x_reg_105 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal x_reg_1050 : STD_LOGIC;
  signal y_1_fu_151_p2 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal y_1_reg_242 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal y_reg_94 : STD_LOGIC;
  signal y_reg_940 : STD_LOGIC;
  signal \y_reg_94_reg_n_0_[0]\ : STD_LOGIC;
  signal \y_reg_94_reg_n_0_[1]\ : STD_LOGIC;
  signal \y_reg_94_reg_n_0_[2]\ : STD_LOGIC;
  signal \y_reg_94_reg_n_0_[3]\ : STD_LOGIC;
  signal \NLW_res_1_reg_265_reg[30]_i_12_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_res_1_reg_265_reg[30]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_res_1_reg_265_reg[30]_i_21_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_res_1_reg_265_reg[30]_i_3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_tmp_6_cast_reg_247_reg[12]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_tmp_6_cast_reg_247_reg[12]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_tmp_6_cast_reg_247_reg[9]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_tmp_8_reg_260_reg[12]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_tmp_8_reg_260_reg[12]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_tmp_8_reg_260_reg[6]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \ap_CS_fsm[0]_i_1\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \ap_CS_fsm[1]_i_1\ : label is "soft_lutpair4";
  attribute FSM_ENCODING : string;
  attribute FSM_ENCODING of \ap_CS_fsm_reg[0]\ : label is "none";
  attribute FSM_ENCODING of \ap_CS_fsm_reg[1]\ : label is "none";
  attribute FSM_ENCODING of \ap_CS_fsm_reg[2]\ : label is "none";
  attribute FSM_ENCODING of \ap_CS_fsm_reg[3]\ : label is "none";
  attribute FSM_ENCODING of \ap_CS_fsm_reg[4]\ : label is "none";
  attribute FSM_ENCODING of \ap_CS_fsm_reg[5]\ : label is "none";
  attribute SOFT_HLUTNM of ap_idle_INST_0 : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of ap_ready_INST_0 : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \filter_index_1_reg_224[1]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \filter_index_1_reg_224[2]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \filter_index_1_reg_224[3]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \filter_index_1_reg_224[4]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \x_1_reg_255[0]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \x_1_reg_255[1]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \x_1_reg_255[2]_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \x_1_reg_255[3]_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \y_1_reg_242[0]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \y_1_reg_242[1]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \y_1_reg_242[2]_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \y_1_reg_242[3]_i_1\ : label is "soft_lutpair2";
begin
  \^ap_clk\ <= ap_clk;
  ap_done <= \^ap_done\;
  ap_ready <= \^ap_done\;
  bias_Addr_A(31) <= \<const0>\;
  bias_Addr_A(30) <= \<const0>\;
  bias_Addr_A(29) <= \<const0>\;
  bias_Addr_A(28) <= \<const0>\;
  bias_Addr_A(27) <= \<const0>\;
  bias_Addr_A(26) <= \<const0>\;
  bias_Addr_A(25) <= \<const0>\;
  bias_Addr_A(24) <= \<const0>\;
  bias_Addr_A(23) <= \<const0>\;
  bias_Addr_A(22) <= \<const0>\;
  bias_Addr_A(21) <= \<const0>\;
  bias_Addr_A(20) <= \<const0>\;
  bias_Addr_A(19) <= \<const0>\;
  bias_Addr_A(18) <= \<const0>\;
  bias_Addr_A(17) <= \<const0>\;
  bias_Addr_A(16) <= \<const0>\;
  bias_Addr_A(15) <= \<const0>\;
  bias_Addr_A(14) <= \<const0>\;
  bias_Addr_A(13) <= \<const0>\;
  bias_Addr_A(12) <= \<const0>\;
  bias_Addr_A(11) <= \<const0>\;
  bias_Addr_A(10) <= \<const0>\;
  bias_Addr_A(9) <= \<const0>\;
  bias_Addr_A(8) <= \<const0>\;
  bias_Addr_A(7 downto 2) <= \^bias_addr_a\(7 downto 2);
  bias_Addr_A(1) <= \<const0>\;
  bias_Addr_A(0) <= \<const0>\;
  bias_Clk_A <= \^ap_clk\;
  bias_Din_A(31) <= \<const0>\;
  bias_Din_A(30) <= \<const0>\;
  bias_Din_A(29) <= \<const0>\;
  bias_Din_A(28) <= \<const0>\;
  bias_Din_A(27) <= \<const0>\;
  bias_Din_A(26) <= \<const0>\;
  bias_Din_A(25) <= \<const0>\;
  bias_Din_A(24) <= \<const0>\;
  bias_Din_A(23) <= \<const0>\;
  bias_Din_A(22) <= \<const0>\;
  bias_Din_A(21) <= \<const0>\;
  bias_Din_A(20) <= \<const0>\;
  bias_Din_A(19) <= \<const0>\;
  bias_Din_A(18) <= \<const0>\;
  bias_Din_A(17) <= \<const0>\;
  bias_Din_A(16) <= \<const0>\;
  bias_Din_A(15) <= \<const0>\;
  bias_Din_A(14) <= \<const0>\;
  bias_Din_A(13) <= \<const0>\;
  bias_Din_A(12) <= \<const0>\;
  bias_Din_A(11) <= \<const0>\;
  bias_Din_A(10) <= \<const0>\;
  bias_Din_A(9) <= \<const0>\;
  bias_Din_A(8) <= \<const0>\;
  bias_Din_A(7) <= \<const0>\;
  bias_Din_A(6) <= \<const0>\;
  bias_Din_A(5) <= \<const0>\;
  bias_Din_A(4) <= \<const0>\;
  bias_Din_A(3) <= \<const0>\;
  bias_Din_A(2) <= \<const0>\;
  bias_Din_A(1) <= \<const0>\;
  bias_Din_A(0) <= \<const0>\;
  bias_EN_A <= \^bias_en_a\;
  bias_Rst_A <= \^input_r_rst_a\;
  bias_WEN_A(3) <= \<const0>\;
  bias_WEN_A(2) <= \<const0>\;
  bias_WEN_A(1) <= \<const0>\;
  bias_WEN_A(0) <= \<const0>\;
  input_r_Addr_A(31) <= \<const0>\;
  input_r_Addr_A(30) <= \<const0>\;
  input_r_Addr_A(29) <= \<const0>\;
  input_r_Addr_A(28) <= \<const0>\;
  input_r_Addr_A(27) <= \<const0>\;
  input_r_Addr_A(26) <= \<const0>\;
  input_r_Addr_A(25) <= \<const0>\;
  input_r_Addr_A(24) <= \<const0>\;
  input_r_Addr_A(23) <= \<const0>\;
  input_r_Addr_A(22) <= \<const0>\;
  input_r_Addr_A(21) <= \<const0>\;
  input_r_Addr_A(20) <= \<const0>\;
  input_r_Addr_A(19) <= \<const0>\;
  input_r_Addr_A(18) <= \<const0>\;
  input_r_Addr_A(17) <= \<const0>\;
  input_r_Addr_A(16) <= \<const0>\;
  input_r_Addr_A(15) <= \<const0>\;
  input_r_Addr_A(14) <= \<const0>\;
  input_r_Addr_A(13) <= \<const0>\;
  input_r_Addr_A(12) <= \<const0>\;
  input_r_Addr_A(11) <= \<const0>\;
  input_r_Addr_A(10) <= \<const0>\;
  input_r_Addr_A(9) <= \<const0>\;
  input_r_Addr_A(8) <= \<const0>\;
  input_r_Addr_A(7) <= \<const0>\;
  input_r_Addr_A(6) <= \<const0>\;
  input_r_Addr_A(5) <= \<const0>\;
  input_r_Addr_A(4) <= \<const0>\;
  input_r_Addr_A(3) <= \<const0>\;
  input_r_Addr_A(2) <= \<const0>\;
  input_r_Addr_A(1) <= \<const0>\;
  input_r_Addr_A(0) <= \<const0>\;
  input_r_Clk_A <= \^ap_clk\;
  input_r_Din_A(31) <= \<const0>\;
  input_r_Din_A(30) <= \<const0>\;
  input_r_Din_A(29) <= \<const0>\;
  input_r_Din_A(28) <= \<const0>\;
  input_r_Din_A(27) <= \<const0>\;
  input_r_Din_A(26) <= \<const0>\;
  input_r_Din_A(25) <= \<const0>\;
  input_r_Din_A(24) <= \<const0>\;
  input_r_Din_A(23) <= \<const0>\;
  input_r_Din_A(22) <= \<const0>\;
  input_r_Din_A(21) <= \<const0>\;
  input_r_Din_A(20) <= \<const0>\;
  input_r_Din_A(19) <= \<const0>\;
  input_r_Din_A(18) <= \<const0>\;
  input_r_Din_A(17) <= \<const0>\;
  input_r_Din_A(16) <= \<const0>\;
  input_r_Din_A(15) <= \<const0>\;
  input_r_Din_A(14) <= \<const0>\;
  input_r_Din_A(13) <= \<const0>\;
  input_r_Din_A(12) <= \<const0>\;
  input_r_Din_A(11) <= \<const0>\;
  input_r_Din_A(10) <= \<const0>\;
  input_r_Din_A(9) <= \<const0>\;
  input_r_Din_A(8) <= \<const0>\;
  input_r_Din_A(7) <= \<const0>\;
  input_r_Din_A(6) <= \<const0>\;
  input_r_Din_A(5) <= \<const0>\;
  input_r_Din_A(4) <= \<const0>\;
  input_r_Din_A(3) <= \<const0>\;
  input_r_Din_A(2) <= \<const0>\;
  input_r_Din_A(1) <= \<const0>\;
  input_r_Din_A(0) <= \<const0>\;
  input_r_EN_A <= \<const0>\;
  input_r_Rst_A <= \^input_r_rst_a\;
  input_r_WEN_A(3) <= \<const0>\;
  input_r_WEN_A(2) <= \<const0>\;
  input_r_WEN_A(1) <= \<const0>\;
  input_r_WEN_A(0) <= \<const0>\;
  output_r_Addr_A(31) <= \<const0>\;
  output_r_Addr_A(30) <= \<const0>\;
  output_r_Addr_A(29) <= \<const0>\;
  output_r_Addr_A(28) <= \<const0>\;
  output_r_Addr_A(27) <= \<const0>\;
  output_r_Addr_A(26) <= \<const0>\;
  output_r_Addr_A(25) <= \<const0>\;
  output_r_Addr_A(24) <= \<const0>\;
  output_r_Addr_A(23) <= \<const0>\;
  output_r_Addr_A(22) <= \<const0>\;
  output_r_Addr_A(21) <= \<const0>\;
  output_r_Addr_A(20) <= \<const0>\;
  output_r_Addr_A(19) <= \<const0>\;
  output_r_Addr_A(18) <= \<const0>\;
  output_r_Addr_A(17) <= \<const0>\;
  output_r_Addr_A(16) <= \<const0>\;
  output_r_Addr_A(15) <= \<const0>\;
  output_r_Addr_A(14 downto 2) <= \^output_r_addr_a\(14 downto 2);
  output_r_Addr_A(1) <= \<const0>\;
  output_r_Addr_A(0) <= \<const0>\;
  output_r_Clk_A <= \^ap_clk\;
  output_r_Din_A(31) <= \<const0>\;
  output_r_Din_A(30 downto 0) <= \^output_r_din_a\(30 downto 0);
  output_r_EN_A <= \^output_r_wen_a\(3);
  output_r_Rst_A <= \^input_r_rst_a\;
  output_r_WEN_A(3) <= \^output_r_wen_a\(3);
  output_r_WEN_A(2) <= \^output_r_wen_a\(3);
  output_r_WEN_A(1) <= \^output_r_wen_a\(3);
  output_r_WEN_A(0) <= \^output_r_wen_a\(3);
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
\ap_CS_fsm[0]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"88F8"
    )
        port map (
      I0 => exitcond5_fu_116_p2,
      I1 => ap_CS_fsm_state2,
      I2 => \ap_CS_fsm_reg_n_0_[0]\,
      I3 => ap_start,
      O => ap_NS_fsm(0)
    );
\ap_CS_fsm[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F888"
    )
        port map (
      I0 => \ap_CS_fsm_reg_n_0_[0]\,
      I1 => ap_start,
      I2 => ap_NS_fsm10_out,
      I3 => ap_CS_fsm_state3,
      O => ap_NS_fsm(1)
    );
\ap_CS_fsm[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F444"
    )
        port map (
      I0 => exitcond5_fu_116_p2,
      I1 => ap_CS_fsm_state2,
      I2 => ap_NS_fsm1,
      I3 => \^bias_en_a\,
      O => ap_NS_fsm(2)
    );
\ap_CS_fsm[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFB0000"
    )
        port map (
      I0 => \y_reg_94_reg_n_0_[1]\,
      I1 => \y_reg_94_reg_n_0_[3]\,
      I2 => \y_reg_94_reg_n_0_[2]\,
      I3 => \y_reg_94_reg_n_0_[0]\,
      I4 => ap_CS_fsm_state3,
      I5 => \^output_r_wen_a\(3),
      O => ap_NS_fsm(3)
    );
\ap_CS_fsm[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAA8AA"
    )
        port map (
      I0 => \^bias_en_a\,
      I1 => x_reg_105(0),
      I2 => x_reg_105(2),
      I3 => x_reg_105(3),
      I4 => x_reg_105(1),
      O => \ap_CS_fsm[4]_i_1_n_0\
    );
\ap_CS_fsm_reg[0]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => \^ap_clk\,
      CE => '1',
      D => ap_NS_fsm(0),
      Q => \ap_CS_fsm_reg_n_0_[0]\,
      S => \^input_r_rst_a\
    );
\ap_CS_fsm_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => \^ap_clk\,
      CE => '1',
      D => ap_NS_fsm(1),
      Q => ap_CS_fsm_state2,
      R => \^input_r_rst_a\
    );
\ap_CS_fsm_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => \^ap_clk\,
      CE => '1',
      D => ap_NS_fsm(2),
      Q => ap_CS_fsm_state3,
      R => \^input_r_rst_a\
    );
\ap_CS_fsm_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => \^ap_clk\,
      CE => '1',
      D => ap_NS_fsm(3),
      Q => \^bias_en_a\,
      R => \^input_r_rst_a\
    );
\ap_CS_fsm_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => \^ap_clk\,
      CE => '1',
      D => \ap_CS_fsm[4]_i_1_n_0\,
      Q => ap_CS_fsm_state5,
      R => \^input_r_rst_a\
    );
\ap_CS_fsm_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => \^ap_clk\,
      CE => '1',
      D => ap_CS_fsm_state5,
      Q => \^output_r_wen_a\(3),
      R => \^input_r_rst_a\
    );
ap_idle_INST_0: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \ap_CS_fsm_reg_n_0_[0]\,
      I1 => ap_start,
      O => ap_idle
    );
ap_ready_INST_0: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => exitcond5_fu_116_p2,
      I1 => ap_CS_fsm_state2,
      O => \^ap_done\
    );
ap_ready_INST_0_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000001000"
    )
        port map (
      I0 => \filter_index_reg_83_reg_n_0_[1]\,
      I1 => \filter_index_reg_83_reg_n_0_[4]\,
      I2 => \filter_index_reg_83_reg_n_0_[5]\,
      I3 => \filter_index_reg_83_reg_n_0_[3]\,
      I4 => \filter_index_reg_83_reg_n_0_[0]\,
      I5 => \filter_index_reg_83_reg_n_0_[2]\,
      O => exitcond5_fu_116_p2
    );
\bias_addr_reg_234[5]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => ap_CS_fsm_state2,
      I1 => exitcond5_fu_116_p2,
      O => y_reg_940
    );
\bias_addr_reg_234_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => y_reg_940,
      D => \filter_index_reg_83_reg_n_0_[0]\,
      Q => \^bias_addr_a\(2),
      R => '0'
    );
\bias_addr_reg_234_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => y_reg_940,
      D => \filter_index_reg_83_reg_n_0_[1]\,
      Q => \^bias_addr_a\(3),
      R => '0'
    );
\bias_addr_reg_234_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => y_reg_940,
      D => \filter_index_reg_83_reg_n_0_[2]\,
      Q => \^bias_addr_a\(4),
      R => '0'
    );
\bias_addr_reg_234_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => y_reg_940,
      D => \filter_index_reg_83_reg_n_0_[3]\,
      Q => \^bias_addr_a\(5),
      R => '0'
    );
\bias_addr_reg_234_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => y_reg_940,
      D => \filter_index_reg_83_reg_n_0_[4]\,
      Q => \^bias_addr_a\(6),
      R => '0'
    );
\bias_addr_reg_234_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => y_reg_940,
      D => \filter_index_reg_83_reg_n_0_[5]\,
      Q => \^bias_addr_a\(7),
      R => '0'
    );
\filter_index_1_reg_224[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \filter_index_reg_83_reg_n_0_[0]\,
      O => filter_index_1_fu_122_p2(0)
    );
\filter_index_1_reg_224[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \filter_index_reg_83_reg_n_0_[0]\,
      I1 => \filter_index_reg_83_reg_n_0_[1]\,
      O => filter_index_1_fu_122_p2(1)
    );
\filter_index_1_reg_224[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \filter_index_reg_83_reg_n_0_[0]\,
      I1 => \filter_index_reg_83_reg_n_0_[1]\,
      I2 => \filter_index_reg_83_reg_n_0_[2]\,
      O => filter_index_1_fu_122_p2(2)
    );
\filter_index_1_reg_224[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => \filter_index_reg_83_reg_n_0_[1]\,
      I1 => \filter_index_reg_83_reg_n_0_[0]\,
      I2 => \filter_index_reg_83_reg_n_0_[2]\,
      I3 => \filter_index_reg_83_reg_n_0_[3]\,
      O => filter_index_1_fu_122_p2(3)
    );
\filter_index_1_reg_224[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF8000"
    )
        port map (
      I0 => \filter_index_reg_83_reg_n_0_[2]\,
      I1 => \filter_index_reg_83_reg_n_0_[0]\,
      I2 => \filter_index_reg_83_reg_n_0_[1]\,
      I3 => \filter_index_reg_83_reg_n_0_[3]\,
      I4 => \filter_index_reg_83_reg_n_0_[4]\,
      O => filter_index_1_fu_122_p2(4)
    );
\filter_index_1_reg_224[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFF80000000"
    )
        port map (
      I0 => \filter_index_reg_83_reg_n_0_[3]\,
      I1 => \filter_index_reg_83_reg_n_0_[1]\,
      I2 => \filter_index_reg_83_reg_n_0_[0]\,
      I3 => \filter_index_reg_83_reg_n_0_[2]\,
      I4 => \filter_index_reg_83_reg_n_0_[4]\,
      I5 => \filter_index_reg_83_reg_n_0_[5]\,
      O => filter_index_1_fu_122_p2(5)
    );
\filter_index_1_reg_224_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state2,
      D => filter_index_1_fu_122_p2(0),
      Q => filter_index_1_reg_224(0),
      R => '0'
    );
\filter_index_1_reg_224_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state2,
      D => filter_index_1_fu_122_p2(1),
      Q => filter_index_1_reg_224(1),
      R => '0'
    );
\filter_index_1_reg_224_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state2,
      D => filter_index_1_fu_122_p2(2),
      Q => filter_index_1_reg_224(2),
      R => '0'
    );
\filter_index_1_reg_224_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state2,
      D => filter_index_1_fu_122_p2(3),
      Q => filter_index_1_reg_224(3),
      R => '0'
    );
\filter_index_1_reg_224_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state2,
      D => filter_index_1_fu_122_p2(4),
      Q => filter_index_1_reg_224(4),
      R => '0'
    );
\filter_index_1_reg_224_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state2,
      D => filter_index_1_fu_122_p2(5),
      Q => filter_index_1_reg_224(5),
      R => '0'
    );
\filter_index_reg_83[5]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"08"
    )
        port map (
      I0 => ap_start,
      I1 => \ap_CS_fsm_reg_n_0_[0]\,
      I2 => ap_NS_fsm10_out,
      O => filter_index_reg_83
    );
\filter_index_reg_83[5]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00040000"
    )
        port map (
      I0 => \y_reg_94_reg_n_0_[1]\,
      I1 => \y_reg_94_reg_n_0_[3]\,
      I2 => \y_reg_94_reg_n_0_[2]\,
      I3 => \y_reg_94_reg_n_0_[0]\,
      I4 => ap_CS_fsm_state3,
      O => ap_NS_fsm10_out
    );
\filter_index_reg_83_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_NS_fsm10_out,
      D => filter_index_1_reg_224(0),
      Q => \filter_index_reg_83_reg_n_0_[0]\,
      R => filter_index_reg_83
    );
\filter_index_reg_83_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_NS_fsm10_out,
      D => filter_index_1_reg_224(1),
      Q => \filter_index_reg_83_reg_n_0_[1]\,
      R => filter_index_reg_83
    );
\filter_index_reg_83_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_NS_fsm10_out,
      D => filter_index_1_reg_224(2),
      Q => \filter_index_reg_83_reg_n_0_[2]\,
      R => filter_index_reg_83
    );
\filter_index_reg_83_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_NS_fsm10_out,
      D => filter_index_1_reg_224(3),
      Q => \filter_index_reg_83_reg_n_0_[3]\,
      R => filter_index_reg_83
    );
\filter_index_reg_83_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_NS_fsm10_out,
      D => filter_index_1_reg_224(4),
      Q => \filter_index_reg_83_reg_n_0_[4]\,
      R => filter_index_reg_83
    );
\filter_index_reg_83_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_NS_fsm10_out,
      D => filter_index_1_reg_224(5),
      Q => \filter_index_reg_83_reg_n_0_[5]\,
      R => filter_index_reg_83
    );
output_r_Rst_A_INST_0: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => ap_rst_n,
      O => \^input_r_rst_a\
    );
\res_1_reg_265[30]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => ap_CS_fsm_state5,
      I1 => p_0_in,
      O => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265[30]_i_10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(26),
      I1 => bias_Dout_A(27),
      O => \res_1_reg_265[30]_i_10_n_0\
    );
\res_1_reg_265[30]_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(24),
      I1 => bias_Dout_A(25),
      O => \res_1_reg_265[30]_i_11_n_0\
    );
\res_1_reg_265[30]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(22),
      I1 => bias_Dout_A(23),
      O => \res_1_reg_265[30]_i_13_n_0\
    );
\res_1_reg_265[30]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(20),
      I1 => bias_Dout_A(21),
      O => \res_1_reg_265[30]_i_14_n_0\
    );
\res_1_reg_265[30]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(18),
      I1 => bias_Dout_A(19),
      O => \res_1_reg_265[30]_i_15_n_0\
    );
\res_1_reg_265[30]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(16),
      I1 => bias_Dout_A(17),
      O => \res_1_reg_265[30]_i_16_n_0\
    );
\res_1_reg_265[30]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(22),
      I1 => bias_Dout_A(23),
      O => \res_1_reg_265[30]_i_17_n_0\
    );
\res_1_reg_265[30]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(20),
      I1 => bias_Dout_A(21),
      O => \res_1_reg_265[30]_i_18_n_0\
    );
\res_1_reg_265[30]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(18),
      I1 => bias_Dout_A(19),
      O => \res_1_reg_265[30]_i_19_n_0\
    );
\res_1_reg_265[30]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(16),
      I1 => bias_Dout_A(17),
      O => \res_1_reg_265[30]_i_20_n_0\
    );
\res_1_reg_265[30]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(14),
      I1 => bias_Dout_A(15),
      O => \res_1_reg_265[30]_i_22_n_0\
    );
\res_1_reg_265[30]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(12),
      I1 => bias_Dout_A(13),
      O => \res_1_reg_265[30]_i_23_n_0\
    );
\res_1_reg_265[30]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(10),
      I1 => bias_Dout_A(11),
      O => \res_1_reg_265[30]_i_24_n_0\
    );
\res_1_reg_265[30]_i_25\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(8),
      I1 => bias_Dout_A(9),
      O => \res_1_reg_265[30]_i_25_n_0\
    );
\res_1_reg_265[30]_i_26\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(14),
      I1 => bias_Dout_A(15),
      O => \res_1_reg_265[30]_i_26_n_0\
    );
\res_1_reg_265[30]_i_27\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(12),
      I1 => bias_Dout_A(13),
      O => \res_1_reg_265[30]_i_27_n_0\
    );
\res_1_reg_265[30]_i_28\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(10),
      I1 => bias_Dout_A(11),
      O => \res_1_reg_265[30]_i_28_n_0\
    );
\res_1_reg_265[30]_i_29\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(8),
      I1 => bias_Dout_A(9),
      O => \res_1_reg_265[30]_i_29_n_0\
    );
\res_1_reg_265[30]_i_30\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(6),
      I1 => bias_Dout_A(7),
      O => \res_1_reg_265[30]_i_30_n_0\
    );
\res_1_reg_265[30]_i_31\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(4),
      I1 => bias_Dout_A(5),
      O => \res_1_reg_265[30]_i_31_n_0\
    );
\res_1_reg_265[30]_i_32\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(2),
      I1 => bias_Dout_A(3),
      O => \res_1_reg_265[30]_i_32_n_0\
    );
\res_1_reg_265[30]_i_33\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(0),
      I1 => bias_Dout_A(1),
      O => \res_1_reg_265[30]_i_33_n_0\
    );
\res_1_reg_265[30]_i_34\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(6),
      I1 => bias_Dout_A(7),
      O => \res_1_reg_265[30]_i_34_n_0\
    );
\res_1_reg_265[30]_i_35\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(4),
      I1 => bias_Dout_A(5),
      O => \res_1_reg_265[30]_i_35_n_0\
    );
\res_1_reg_265[30]_i_36\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(2),
      I1 => bias_Dout_A(3),
      O => \res_1_reg_265[30]_i_36_n_0\
    );
\res_1_reg_265[30]_i_37\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(0),
      I1 => bias_Dout_A(1),
      O => \res_1_reg_265[30]_i_37_n_0\
    );
\res_1_reg_265[30]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => bias_Dout_A(30),
      I1 => bias_Dout_A(31),
      O => \res_1_reg_265[30]_i_4_n_0\
    );
\res_1_reg_265[30]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(28),
      I1 => bias_Dout_A(29),
      O => \res_1_reg_265[30]_i_5_n_0\
    );
\res_1_reg_265[30]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(26),
      I1 => bias_Dout_A(27),
      O => \res_1_reg_265[30]_i_6_n_0\
    );
\res_1_reg_265[30]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(24),
      I1 => bias_Dout_A(25),
      O => \res_1_reg_265[30]_i_7_n_0\
    );
\res_1_reg_265[30]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(30),
      I1 => bias_Dout_A(31),
      O => \res_1_reg_265[30]_i_8_n_0\
    );
\res_1_reg_265[30]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(28),
      I1 => bias_Dout_A(29),
      O => \res_1_reg_265[30]_i_9_n_0\
    );
\res_1_reg_265_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(0),
      Q => \^output_r_din_a\(0),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(10),
      Q => \^output_r_din_a\(10),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(11),
      Q => \^output_r_din_a\(11),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(12),
      Q => \^output_r_din_a\(12),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(13),
      Q => \^output_r_din_a\(13),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(14),
      Q => \^output_r_din_a\(14),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(15),
      Q => \^output_r_din_a\(15),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(16),
      Q => \^output_r_din_a\(16),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(17),
      Q => \^output_r_din_a\(17),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(18),
      Q => \^output_r_din_a\(18),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(19),
      Q => \^output_r_din_a\(19),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(1),
      Q => \^output_r_din_a\(1),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(20),
      Q => \^output_r_din_a\(20),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(21),
      Q => \^output_r_din_a\(21),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(22),
      Q => \^output_r_din_a\(22),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(23),
      Q => \^output_r_din_a\(23),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(24),
      Q => \^output_r_din_a\(24),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(25),
      Q => \^output_r_din_a\(25),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(26),
      Q => \^output_r_din_a\(26),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(27),
      Q => \^output_r_din_a\(27),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(28),
      Q => \^output_r_din_a\(28),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(29),
      Q => \^output_r_din_a\(29),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(2),
      Q => \^output_r_din_a\(2),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(30),
      Q => \^output_r_din_a\(30),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[30]_i_12\: unisim.vcomponents.CARRY4
     port map (
      CI => \res_1_reg_265_reg[30]_i_21_n_0\,
      CO(3) => \res_1_reg_265_reg[30]_i_12_n_0\,
      CO(2) => \res_1_reg_265_reg[30]_i_12_n_1\,
      CO(1) => \res_1_reg_265_reg[30]_i_12_n_2\,
      CO(0) => \res_1_reg_265_reg[30]_i_12_n_3\,
      CYINIT => '0',
      DI(3) => \res_1_reg_265[30]_i_22_n_0\,
      DI(2) => \res_1_reg_265[30]_i_23_n_0\,
      DI(1) => \res_1_reg_265[30]_i_24_n_0\,
      DI(0) => \res_1_reg_265[30]_i_25_n_0\,
      O(3 downto 0) => \NLW_res_1_reg_265_reg[30]_i_12_O_UNCONNECTED\(3 downto 0),
      S(3) => \res_1_reg_265[30]_i_26_n_0\,
      S(2) => \res_1_reg_265[30]_i_27_n_0\,
      S(1) => \res_1_reg_265[30]_i_28_n_0\,
      S(0) => \res_1_reg_265[30]_i_29_n_0\
    );
\res_1_reg_265_reg[30]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \res_1_reg_265_reg[30]_i_3_n_0\,
      CO(3) => p_0_in,
      CO(2) => \res_1_reg_265_reg[30]_i_2_n_1\,
      CO(1) => \res_1_reg_265_reg[30]_i_2_n_2\,
      CO(0) => \res_1_reg_265_reg[30]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \res_1_reg_265[30]_i_4_n_0\,
      DI(2) => \res_1_reg_265[30]_i_5_n_0\,
      DI(1) => \res_1_reg_265[30]_i_6_n_0\,
      DI(0) => \res_1_reg_265[30]_i_7_n_0\,
      O(3 downto 0) => \NLW_res_1_reg_265_reg[30]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \res_1_reg_265[30]_i_8_n_0\,
      S(2) => \res_1_reg_265[30]_i_9_n_0\,
      S(1) => \res_1_reg_265[30]_i_10_n_0\,
      S(0) => \res_1_reg_265[30]_i_11_n_0\
    );
\res_1_reg_265_reg[30]_i_21\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \res_1_reg_265_reg[30]_i_21_n_0\,
      CO(2) => \res_1_reg_265_reg[30]_i_21_n_1\,
      CO(1) => \res_1_reg_265_reg[30]_i_21_n_2\,
      CO(0) => \res_1_reg_265_reg[30]_i_21_n_3\,
      CYINIT => '0',
      DI(3) => \res_1_reg_265[30]_i_30_n_0\,
      DI(2) => \res_1_reg_265[30]_i_31_n_0\,
      DI(1) => \res_1_reg_265[30]_i_32_n_0\,
      DI(0) => \res_1_reg_265[30]_i_33_n_0\,
      O(3 downto 0) => \NLW_res_1_reg_265_reg[30]_i_21_O_UNCONNECTED\(3 downto 0),
      S(3) => \res_1_reg_265[30]_i_34_n_0\,
      S(2) => \res_1_reg_265[30]_i_35_n_0\,
      S(1) => \res_1_reg_265[30]_i_36_n_0\,
      S(0) => \res_1_reg_265[30]_i_37_n_0\
    );
\res_1_reg_265_reg[30]_i_3\: unisim.vcomponents.CARRY4
     port map (
      CI => \res_1_reg_265_reg[30]_i_12_n_0\,
      CO(3) => \res_1_reg_265_reg[30]_i_3_n_0\,
      CO(2) => \res_1_reg_265_reg[30]_i_3_n_1\,
      CO(1) => \res_1_reg_265_reg[30]_i_3_n_2\,
      CO(0) => \res_1_reg_265_reg[30]_i_3_n_3\,
      CYINIT => '0',
      DI(3) => \res_1_reg_265[30]_i_13_n_0\,
      DI(2) => \res_1_reg_265[30]_i_14_n_0\,
      DI(1) => \res_1_reg_265[30]_i_15_n_0\,
      DI(0) => \res_1_reg_265[30]_i_16_n_0\,
      O(3 downto 0) => \NLW_res_1_reg_265_reg[30]_i_3_O_UNCONNECTED\(3 downto 0),
      S(3) => \res_1_reg_265[30]_i_17_n_0\,
      S(2) => \res_1_reg_265[30]_i_18_n_0\,
      S(1) => \res_1_reg_265[30]_i_19_n_0\,
      S(0) => \res_1_reg_265[30]_i_20_n_0\
    );
\res_1_reg_265_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(3),
      Q => \^output_r_din_a\(3),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(4),
      Q => \^output_r_din_a\(4),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(5),
      Q => \^output_r_din_a\(5),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(6),
      Q => \^output_r_din_a\(6),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(7),
      Q => \^output_r_din_a\(7),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(8),
      Q => \^output_r_din_a\(8),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\res_1_reg_265_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state5,
      D => bias_Dout_A(9),
      Q => \^output_r_din_a\(9),
      R => \res_1_reg_265[30]_i_1_n_0\
    );
\tmp_6_cast_reg_247[6]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \y_reg_94_reg_n_0_[3]\,
      I1 => \^bias_addr_a\(2),
      O => tmp_3_fu_161_p2(3)
    );
\tmp_6_cast_reg_247[9]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \y_reg_94_reg_n_0_[3]\,
      I1 => \^bias_addr_a\(2),
      O => \tmp_6_cast_reg_247[9]_i_2_n_0\
    );
\tmp_6_cast_reg_247_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => x_reg_1050,
      D => tmp_3_fu_161_p2(7),
      Q => tmp_6_cast_reg_247(10),
      R => '0'
    );
\tmp_6_cast_reg_247_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => x_reg_1050,
      D => tmp_3_fu_161_p2(8),
      Q => tmp_6_cast_reg_247(11),
      R => '0'
    );
\tmp_6_cast_reg_247_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => x_reg_1050,
      D => tmp_3_fu_161_p2(9),
      Q => tmp_6_cast_reg_247(12),
      R => '0'
    );
\tmp_6_cast_reg_247_reg[12]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \tmp_6_cast_reg_247_reg[9]_i_1_n_0\,
      CO(3) => \NLW_tmp_6_cast_reg_247_reg[12]_i_1_CO_UNCONNECTED\(3),
      CO(2) => tmp_3_fu_161_p2(9),
      CO(1) => \NLW_tmp_6_cast_reg_247_reg[12]_i_1_CO_UNCONNECTED\(1),
      CO(0) => \tmp_6_cast_reg_247_reg[12]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 2) => \NLW_tmp_6_cast_reg_247_reg[12]_i_1_O_UNCONNECTED\(3 downto 2),
      O(1 downto 0) => tmp_3_fu_161_p2(8 downto 7),
      S(3 downto 2) => B"01",
      S(1 downto 0) => \^bias_addr_a\(7 downto 6)
    );
\tmp_6_cast_reg_247_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => x_reg_1050,
      D => \y_reg_94_reg_n_0_[0]\,
      Q => tmp_6_cast_reg_247(3),
      R => '0'
    );
\tmp_6_cast_reg_247_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => x_reg_1050,
      D => \y_reg_94_reg_n_0_[1]\,
      Q => tmp_6_cast_reg_247(4),
      R => '0'
    );
\tmp_6_cast_reg_247_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => x_reg_1050,
      D => \y_reg_94_reg_n_0_[2]\,
      Q => tmp_6_cast_reg_247(5),
      R => '0'
    );
\tmp_6_cast_reg_247_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => x_reg_1050,
      D => tmp_3_fu_161_p2(3),
      Q => tmp_6_cast_reg_247(6),
      R => '0'
    );
\tmp_6_cast_reg_247_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => x_reg_1050,
      D => tmp_3_fu_161_p2(4),
      Q => tmp_6_cast_reg_247(7),
      R => '0'
    );
\tmp_6_cast_reg_247_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => x_reg_1050,
      D => tmp_3_fu_161_p2(5),
      Q => tmp_6_cast_reg_247(8),
      R => '0'
    );
\tmp_6_cast_reg_247_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => x_reg_1050,
      D => tmp_3_fu_161_p2(6),
      Q => tmp_6_cast_reg_247(9),
      R => '0'
    );
\tmp_6_cast_reg_247_reg[9]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \tmp_6_cast_reg_247_reg[9]_i_1_n_0\,
      CO(2) => \tmp_6_cast_reg_247_reg[9]_i_1_n_1\,
      CO(1) => \tmp_6_cast_reg_247_reg[9]_i_1_n_2\,
      CO(0) => \tmp_6_cast_reg_247_reg[9]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \y_reg_94_reg_n_0_[3]\,
      O(3 downto 1) => tmp_3_fu_161_p2(6 downto 4),
      O(0) => \NLW_tmp_6_cast_reg_247_reg[9]_i_1_O_UNCONNECTED\(0),
      S(3 downto 1) => \^bias_addr_a\(5 downto 3),
      S(0) => \tmp_6_cast_reg_247[9]_i_2_n_0\
    );
\tmp_8_reg_260[12]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAA8A"
    )
        port map (
      I0 => \^bias_en_a\,
      I1 => x_reg_105(1),
      I2 => x_reg_105(3),
      I3 => x_reg_105(2),
      I4 => x_reg_105(0),
      O => tmp_8_reg_2600
    );
\tmp_8_reg_260[3]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => tmp_6_cast_reg_247(3),
      I1 => x_reg_105(3),
      O => tmp_8_fu_190_p2(3)
    );
\tmp_8_reg_260[6]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => tmp_6_cast_reg_247(3),
      I1 => x_reg_105(3),
      O => \tmp_8_reg_260[6]_i_2_n_0\
    );
\tmp_8_reg_260_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => tmp_8_reg_2600,
      D => x_reg_105(0),
      Q => \^output_r_addr_a\(2),
      R => '0'
    );
\tmp_8_reg_260_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => tmp_8_reg_2600,
      D => tmp_8_fu_190_p2(10),
      Q => \^output_r_addr_a\(12),
      R => '0'
    );
\tmp_8_reg_260_reg[10]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \tmp_8_reg_260_reg[6]_i_1_n_0\,
      CO(3) => \tmp_8_reg_260_reg[10]_i_1_n_0\,
      CO(2) => \tmp_8_reg_260_reg[10]_i_1_n_1\,
      CO(1) => \tmp_8_reg_260_reg[10]_i_1_n_2\,
      CO(0) => \tmp_8_reg_260_reg[10]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => tmp_8_fu_190_p2(10 downto 7),
      S(3 downto 0) => tmp_6_cast_reg_247(10 downto 7)
    );
\tmp_8_reg_260_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => tmp_8_reg_2600,
      D => tmp_8_fu_190_p2(11),
      Q => \^output_r_addr_a\(13),
      R => '0'
    );
\tmp_8_reg_260_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => tmp_8_reg_2600,
      D => tmp_8_fu_190_p2(12),
      Q => \^output_r_addr_a\(14),
      R => '0'
    );
\tmp_8_reg_260_reg[12]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \tmp_8_reg_260_reg[10]_i_1_n_0\,
      CO(3 downto 1) => \NLW_tmp_8_reg_260_reg[12]_i_2_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \tmp_8_reg_260_reg[12]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 2) => \NLW_tmp_8_reg_260_reg[12]_i_2_O_UNCONNECTED\(3 downto 2),
      O(1 downto 0) => tmp_8_fu_190_p2(12 downto 11),
      S(3 downto 2) => B"00",
      S(1 downto 0) => tmp_6_cast_reg_247(12 downto 11)
    );
\tmp_8_reg_260_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => tmp_8_reg_2600,
      D => x_reg_105(1),
      Q => \^output_r_addr_a\(3),
      R => '0'
    );
\tmp_8_reg_260_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => tmp_8_reg_2600,
      D => x_reg_105(2),
      Q => \^output_r_addr_a\(4),
      R => '0'
    );
\tmp_8_reg_260_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => tmp_8_reg_2600,
      D => tmp_8_fu_190_p2(3),
      Q => \^output_r_addr_a\(5),
      R => '0'
    );
\tmp_8_reg_260_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => tmp_8_reg_2600,
      D => tmp_8_fu_190_p2(4),
      Q => \^output_r_addr_a\(6),
      R => '0'
    );
\tmp_8_reg_260_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => tmp_8_reg_2600,
      D => tmp_8_fu_190_p2(5),
      Q => \^output_r_addr_a\(7),
      R => '0'
    );
\tmp_8_reg_260_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => tmp_8_reg_2600,
      D => tmp_8_fu_190_p2(6),
      Q => \^output_r_addr_a\(8),
      R => '0'
    );
\tmp_8_reg_260_reg[6]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \tmp_8_reg_260_reg[6]_i_1_n_0\,
      CO(2) => \tmp_8_reg_260_reg[6]_i_1_n_1\,
      CO(1) => \tmp_8_reg_260_reg[6]_i_1_n_2\,
      CO(0) => \tmp_8_reg_260_reg[6]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => tmp_6_cast_reg_247(3),
      O(3 downto 1) => tmp_8_fu_190_p2(6 downto 4),
      O(0) => \NLW_tmp_8_reg_260_reg[6]_i_1_O_UNCONNECTED\(0),
      S(3 downto 1) => tmp_6_cast_reg_247(6 downto 4),
      S(0) => \tmp_8_reg_260[6]_i_2_n_0\
    );
\tmp_8_reg_260_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => tmp_8_reg_2600,
      D => tmp_8_fu_190_p2(7),
      Q => \^output_r_addr_a\(9),
      R => '0'
    );
\tmp_8_reg_260_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => tmp_8_reg_2600,
      D => tmp_8_fu_190_p2(8),
      Q => \^output_r_addr_a\(10),
      R => '0'
    );
\tmp_8_reg_260_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => tmp_8_reg_2600,
      D => tmp_8_fu_190_p2(9),
      Q => \^output_r_addr_a\(11),
      R => '0'
    );
\x_1_reg_255[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => x_reg_105(0),
      O => x_1_fu_180_p2(0)
    );
\x_1_reg_255[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => x_reg_105(0),
      I1 => x_reg_105(1),
      O => x_1_fu_180_p2(1)
    );
\x_1_reg_255[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => x_reg_105(0),
      I1 => x_reg_105(1),
      I2 => x_reg_105(2),
      O => x_1_fu_180_p2(2)
    );
\x_1_reg_255[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => x_reg_105(1),
      I1 => x_reg_105(0),
      I2 => x_reg_105(2),
      I3 => x_reg_105(3),
      O => x_1_fu_180_p2(3)
    );
\x_1_reg_255_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => \^bias_en_a\,
      D => x_1_fu_180_p2(0),
      Q => x_1_reg_255(0),
      R => '0'
    );
\x_1_reg_255_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => \^bias_en_a\,
      D => x_1_fu_180_p2(1),
      Q => x_1_reg_255(1),
      R => '0'
    );
\x_1_reg_255_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => \^bias_en_a\,
      D => x_1_fu_180_p2(2),
      Q => x_1_reg_255(2),
      R => '0'
    );
\x_1_reg_255_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => \^bias_en_a\,
      D => x_1_fu_180_p2(3),
      Q => x_1_reg_255(3),
      R => '0'
    );
\x_reg_105[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAA8A"
    )
        port map (
      I0 => ap_CS_fsm_state3,
      I1 => \y_reg_94_reg_n_0_[1]\,
      I2 => \y_reg_94_reg_n_0_[3]\,
      I3 => \y_reg_94_reg_n_0_[2]\,
      I4 => \y_reg_94_reg_n_0_[0]\,
      O => x_reg_1050
    );
\x_reg_105_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => \^output_r_wen_a\(3),
      D => x_1_reg_255(0),
      Q => x_reg_105(0),
      R => x_reg_1050
    );
\x_reg_105_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => \^output_r_wen_a\(3),
      D => x_1_reg_255(1),
      Q => x_reg_105(1),
      R => x_reg_1050
    );
\x_reg_105_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => \^output_r_wen_a\(3),
      D => x_1_reg_255(2),
      Q => x_reg_105(2),
      R => x_reg_1050
    );
\x_reg_105_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => \^output_r_wen_a\(3),
      D => x_1_reg_255(3),
      Q => x_reg_105(3),
      R => x_reg_1050
    );
\y_1_reg_242[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \y_reg_94_reg_n_0_[0]\,
      O => y_1_fu_151_p2(0)
    );
\y_1_reg_242[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \y_reg_94_reg_n_0_[0]\,
      I1 => \y_reg_94_reg_n_0_[1]\,
      O => y_1_fu_151_p2(1)
    );
\y_1_reg_242[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \y_reg_94_reg_n_0_[0]\,
      I1 => \y_reg_94_reg_n_0_[1]\,
      I2 => \y_reg_94_reg_n_0_[2]\,
      O => y_1_fu_151_p2(2)
    );
\y_1_reg_242[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => \y_reg_94_reg_n_0_[1]\,
      I1 => \y_reg_94_reg_n_0_[0]\,
      I2 => \y_reg_94_reg_n_0_[2]\,
      I3 => \y_reg_94_reg_n_0_[3]\,
      O => y_1_fu_151_p2(3)
    );
\y_1_reg_242_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state3,
      D => y_1_fu_151_p2(0),
      Q => y_1_reg_242(0),
      R => '0'
    );
\y_1_reg_242_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state3,
      D => y_1_fu_151_p2(1),
      Q => y_1_reg_242(1),
      R => '0'
    );
\y_1_reg_242_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state3,
      D => y_1_fu_151_p2(2),
      Q => y_1_reg_242(2),
      R => '0'
    );
\y_1_reg_242_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_CS_fsm_state3,
      D => y_1_fu_151_p2(3),
      Q => y_1_reg_242(3),
      R => '0'
    );
\y_reg_94[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAA2AAAA"
    )
        port map (
      I0 => y_reg_940,
      I1 => \^bias_en_a\,
      I2 => x_reg_105(0),
      I3 => x_reg_105(2),
      I4 => x_reg_105(3),
      I5 => x_reg_105(1),
      O => y_reg_94
    );
\y_reg_94[3]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00040000"
    )
        port map (
      I0 => x_reg_105(1),
      I1 => x_reg_105(3),
      I2 => x_reg_105(2),
      I3 => x_reg_105(0),
      I4 => \^bias_en_a\,
      O => ap_NS_fsm1
    );
\y_reg_94_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_NS_fsm1,
      D => y_1_reg_242(0),
      Q => \y_reg_94_reg_n_0_[0]\,
      R => y_reg_94
    );
\y_reg_94_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_NS_fsm1,
      D => y_1_reg_242(1),
      Q => \y_reg_94_reg_n_0_[1]\,
      R => y_reg_94
    );
\y_reg_94_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_NS_fsm1,
      D => y_1_reg_242(2),
      Q => \y_reg_94_reg_n_0_[2]\,
      R => y_reg_94
    );
\y_reg_94_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => ap_NS_fsm1,
      D => y_1_reg_242(3),
      Q => \y_reg_94_reg_n_0_[3]\,
      R => y_reg_94
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    ap_clk : in STD_LOGIC;
    ap_rst_n : in STD_LOGIC;
    ap_start : in STD_LOGIC;
    ap_done : out STD_LOGIC;
    ap_idle : out STD_LOGIC;
    ap_ready : out STD_LOGIC;
    input_r_Clk_A : out STD_LOGIC;
    input_r_Rst_A : out STD_LOGIC;
    input_r_EN_A : out STD_LOGIC;
    input_r_WEN_A : out STD_LOGIC_VECTOR ( 3 downto 0 );
    input_r_Addr_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    input_r_Din_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    input_r_Dout_A : in STD_LOGIC_VECTOR ( 31 downto 0 );
    bias_Clk_A : out STD_LOGIC;
    bias_Rst_A : out STD_LOGIC;
    bias_EN_A : out STD_LOGIC;
    bias_WEN_A : out STD_LOGIC_VECTOR ( 3 downto 0 );
    bias_Addr_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    bias_Din_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    bias_Dout_A : in STD_LOGIC_VECTOR ( 31 downto 0 );
    output_r_Clk_A : out STD_LOGIC;
    output_r_Rst_A : out STD_LOGIC;
    output_r_EN_A : out STD_LOGIC;
    output_r_WEN_A : out STD_LOGIC_VECTOR ( 3 downto 0 );
    output_r_Addr_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    output_r_Din_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    output_r_Dout_A : in STD_LOGIC_VECTOR ( 31 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "zed_Conv2_12x12x20_5x5x40_1_0_1_0,a0_Conv2_12x12x20_5x5x40_1_0,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "HLS";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "a0_Conv2_12x12x20_5x5x40_1_0,Vivado 2018.2";
  attribute hls_module : string;
  attribute hls_module of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  attribute SDX_KERNEL : string;
  attribute SDX_KERNEL of inst : label is "true";
  attribute SDX_KERNEL_SYNTH_INST : string;
  attribute SDX_KERNEL_SYNTH_INST of inst : label is "inst";
  attribute SDX_KERNEL_TYPE : string;
  attribute SDX_KERNEL_TYPE of inst : label is "hls";
  attribute ap_ST_fsm_state1 : string;
  attribute ap_ST_fsm_state1 of inst : label is "6'b000001";
  attribute ap_ST_fsm_state2 : string;
  attribute ap_ST_fsm_state2 of inst : label is "6'b000010";
  attribute ap_ST_fsm_state3 : string;
  attribute ap_ST_fsm_state3 of inst : label is "6'b000100";
  attribute ap_ST_fsm_state4 : string;
  attribute ap_ST_fsm_state4 of inst : label is "6'b001000";
  attribute ap_ST_fsm_state5 : string;
  attribute ap_ST_fsm_state5 of inst : label is "6'b010000";
  attribute ap_ST_fsm_state6 : string;
  attribute ap_ST_fsm_state6 of inst : label is "6'b100000";
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of ap_clk : signal is "xilinx.com:signal:clock:1.0 ap_clk CLK";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of ap_clk : signal is "XIL_INTERFACENAME ap_clk, ASSOCIATED_RESET ap_rst_n, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}}}, FREQ_HZ 100000000, PHASE 0.000, CLK_DOMAIN /clk_wiz_0_clk_out1";
  attribute X_INTERFACE_INFO of ap_done : signal is "xilinx.com:interface:acc_handshake:1.0 ap_ctrl done";
  attribute X_INTERFACE_INFO of ap_idle : signal is "xilinx.com:interface:acc_handshake:1.0 ap_ctrl idle";
  attribute X_INTERFACE_INFO of ap_ready : signal is "xilinx.com:interface:acc_handshake:1.0 ap_ctrl ready";
  attribute X_INTERFACE_PARAMETER of ap_ready : signal is "XIL_INTERFACENAME ap_ctrl, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {start {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} done {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} idle {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ready {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}}}";
  attribute X_INTERFACE_INFO of ap_rst_n : signal is "xilinx.com:signal:reset:1.0 ap_rst_n RST";
  attribute X_INTERFACE_PARAMETER of ap_rst_n : signal is "XIL_INTERFACENAME ap_rst_n, POLARITY ACTIVE_LOW, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}}}";
  attribute X_INTERFACE_INFO of ap_start : signal is "xilinx.com:interface:acc_handshake:1.0 ap_ctrl start";
  attribute X_INTERFACE_INFO of bias_Clk_A : signal is "xilinx.com:interface:bram:1.0 bias_PORTA CLK";
  attribute X_INTERFACE_INFO of bias_EN_A : signal is "xilinx.com:interface:bram:1.0 bias_PORTA EN";
  attribute X_INTERFACE_INFO of bias_Rst_A : signal is "xilinx.com:interface:bram:1.0 bias_PORTA RST";
  attribute X_INTERFACE_INFO of input_r_Clk_A : signal is "xilinx.com:interface:bram:1.0 input_r_PORTA CLK";
  attribute X_INTERFACE_INFO of input_r_EN_A : signal is "xilinx.com:interface:bram:1.0 input_r_PORTA EN";
  attribute X_INTERFACE_INFO of input_r_Rst_A : signal is "xilinx.com:interface:bram:1.0 input_r_PORTA RST";
  attribute X_INTERFACE_INFO of output_r_Clk_A : signal is "xilinx.com:interface:bram:1.0 output_r_PORTA CLK";
  attribute X_INTERFACE_INFO of output_r_EN_A : signal is "xilinx.com:interface:bram:1.0 output_r_PORTA EN";
  attribute X_INTERFACE_INFO of output_r_Rst_A : signal is "xilinx.com:interface:bram:1.0 output_r_PORTA RST";
  attribute X_INTERFACE_INFO of bias_Addr_A : signal is "xilinx.com:interface:bram:1.0 bias_PORTA ADDR";
  attribute X_INTERFACE_INFO of bias_Din_A : signal is "xilinx.com:interface:bram:1.0 bias_PORTA DIN";
  attribute X_INTERFACE_INFO of bias_Dout_A : signal is "xilinx.com:interface:bram:1.0 bias_PORTA DOUT";
  attribute X_INTERFACE_PARAMETER of bias_Dout_A : signal is "XIL_INTERFACENAME bias_PORTA, MEM_WIDTH 32, MEM_SIZE 160, MASTER_TYPE BRAM_CTRL, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {EN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ADDR {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} WE {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 4} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} DIN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}} DOUT {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}}, MEM_ECC NONE";
  attribute X_INTERFACE_INFO of bias_WEN_A : signal is "xilinx.com:interface:bram:1.0 bias_PORTA WE";
  attribute X_INTERFACE_INFO of input_r_Addr_A : signal is "xilinx.com:interface:bram:1.0 input_r_PORTA ADDR";
  attribute X_INTERFACE_INFO of input_r_Din_A : signal is "xilinx.com:interface:bram:1.0 input_r_PORTA DIN";
  attribute X_INTERFACE_INFO of input_r_Dout_A : signal is "xilinx.com:interface:bram:1.0 input_r_PORTA DOUT";
  attribute X_INTERFACE_PARAMETER of input_r_Dout_A : signal is "XIL_INTERFACENAME input_r_PORTA, MEM_WIDTH 32, MEM_SIZE 11520, MASTER_TYPE BRAM_CTRL, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {EN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ADDR {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} WE {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 4} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} DIN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}} DOUT {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}}, MEM_ECC NONE";
  attribute X_INTERFACE_INFO of input_r_WEN_A : signal is "xilinx.com:interface:bram:1.0 input_r_PORTA WE";
  attribute X_INTERFACE_INFO of output_r_Addr_A : signal is "xilinx.com:interface:bram:1.0 output_r_PORTA ADDR";
  attribute X_INTERFACE_INFO of output_r_Din_A : signal is "xilinx.com:interface:bram:1.0 output_r_PORTA DIN";
  attribute X_INTERFACE_INFO of output_r_Dout_A : signal is "xilinx.com:interface:bram:1.0 output_r_PORTA DOUT";
  attribute X_INTERFACE_PARAMETER of output_r_Dout_A : signal is "XIL_INTERFACENAME output_r_PORTA, MEM_WIDTH 32, MEM_SIZE 10240, MASTER_TYPE BRAM_CTRL, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {EN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ADDR {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} WE {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 4} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} DIN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}} DOUT {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}}, MEM_ECC NONE";
  attribute X_INTERFACE_INFO of output_r_WEN_A : signal is "xilinx.com:interface:bram:1.0 output_r_PORTA WE";
begin
inst: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0
     port map (
      ap_clk => ap_clk,
      ap_done => ap_done,
      ap_idle => ap_idle,
      ap_ready => ap_ready,
      ap_rst_n => ap_rst_n,
      ap_start => ap_start,
      bias_Addr_A(31 downto 0) => bias_Addr_A(31 downto 0),
      bias_Clk_A => bias_Clk_A,
      bias_Din_A(31 downto 0) => bias_Din_A(31 downto 0),
      bias_Dout_A(31 downto 0) => bias_Dout_A(31 downto 0),
      bias_EN_A => bias_EN_A,
      bias_Rst_A => bias_Rst_A,
      bias_WEN_A(3 downto 0) => bias_WEN_A(3 downto 0),
      input_r_Addr_A(31 downto 0) => input_r_Addr_A(31 downto 0),
      input_r_Clk_A => input_r_Clk_A,
      input_r_Din_A(31 downto 0) => input_r_Din_A(31 downto 0),
      input_r_Dout_A(31 downto 0) => input_r_Dout_A(31 downto 0),
      input_r_EN_A => input_r_EN_A,
      input_r_Rst_A => input_r_Rst_A,
      input_r_WEN_A(3 downto 0) => input_r_WEN_A(3 downto 0),
      output_r_Addr_A(31 downto 0) => output_r_Addr_A(31 downto 0),
      output_r_Clk_A => output_r_Clk_A,
      output_r_Din_A(31 downto 0) => output_r_Din_A(31 downto 0),
      output_r_Dout_A(31 downto 0) => output_r_Dout_A(31 downto 0),
      output_r_EN_A => output_r_EN_A,
      output_r_Rst_A => output_r_Rst_A,
      output_r_WEN_A(3 downto 0) => output_r_WEN_A(3 downto 0)
    );
end STRUCTURE;
