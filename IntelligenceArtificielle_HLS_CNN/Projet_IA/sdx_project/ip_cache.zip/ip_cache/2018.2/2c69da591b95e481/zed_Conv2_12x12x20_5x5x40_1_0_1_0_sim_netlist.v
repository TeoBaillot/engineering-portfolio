// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2018.2 (lin64) Build 2258646 Thu Jun 14 20:02:38 MDT 2018
// Date        : Wed Dec 17 17:30:05 2025
// Host        : PCII-REF running 64-bit Ubuntu 22.04.5 LTS
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ zed_Conv2_12x12x20_5x5x40_1_0_1_0_sim_netlist.v
// Design      : zed_Conv2_12x12x20_5x5x40_1_0_1_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg484-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* ap_ST_fsm_state1 = "6'b000001" *) (* ap_ST_fsm_state2 = "6'b000010" *) (* ap_ST_fsm_state3 = "6'b000100" *) 
(* ap_ST_fsm_state4 = "6'b001000" *) (* ap_ST_fsm_state5 = "6'b010000" *) (* ap_ST_fsm_state6 = "6'b100000" *) 
(* hls_module = "yes" *) 
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0
   (ap_clk,
    ap_rst_n,
    ap_start,
    ap_done,
    ap_idle,
    ap_ready,
    input_r_Addr_A,
    input_r_EN_A,
    input_r_WEN_A,
    input_r_Din_A,
    input_r_Dout_A,
    input_r_Clk_A,
    input_r_Rst_A,
    bias_Addr_A,
    bias_EN_A,
    bias_WEN_A,
    bias_Din_A,
    bias_Dout_A,
    bias_Clk_A,
    bias_Rst_A,
    output_r_Addr_A,
    output_r_EN_A,
    output_r_WEN_A,
    output_r_Din_A,
    output_r_Dout_A,
    output_r_Clk_A,
    output_r_Rst_A);
  input ap_clk;
  input ap_rst_n;
  input ap_start;
  output ap_done;
  output ap_idle;
  output ap_ready;
  output [31:0]input_r_Addr_A;
  output input_r_EN_A;
  output [3:0]input_r_WEN_A;
  output [31:0]input_r_Din_A;
  input [31:0]input_r_Dout_A;
  output input_r_Clk_A;
  output input_r_Rst_A;
  output [31:0]bias_Addr_A;
  output bias_EN_A;
  output [3:0]bias_WEN_A;
  output [31:0]bias_Din_A;
  input [31:0]bias_Dout_A;
  output bias_Clk_A;
  output bias_Rst_A;
  output [31:0]output_r_Addr_A;
  output output_r_EN_A;
  output [3:0]output_r_WEN_A;
  output [31:0]output_r_Din_A;
  input [31:0]output_r_Dout_A;
  output output_r_Clk_A;
  output output_r_Rst_A;

  wire \<const0> ;
  wire \ap_CS_fsm[4]_i_1_n_0 ;
  wire \ap_CS_fsm_reg_n_0_[0] ;
  wire ap_CS_fsm_state2;
  wire ap_CS_fsm_state3;
  wire ap_CS_fsm_state5;
  wire [3:0]ap_NS_fsm;
  wire ap_NS_fsm1;
  wire ap_NS_fsm10_out;
  wire ap_clk;
  wire ap_done;
  wire ap_idle;
  wire ap_rst_n;
  wire ap_start;
  wire [7:2]\^bias_Addr_A ;
  wire [31:0]bias_Dout_A;
  wire bias_EN_A;
  wire exitcond5_fu_116_p2;
  wire [5:0]filter_index_1_fu_122_p2;
  wire [5:0]filter_index_1_reg_224;
  wire filter_index_reg_83;
  wire \filter_index_reg_83_reg_n_0_[0] ;
  wire \filter_index_reg_83_reg_n_0_[1] ;
  wire \filter_index_reg_83_reg_n_0_[2] ;
  wire \filter_index_reg_83_reg_n_0_[3] ;
  wire \filter_index_reg_83_reg_n_0_[4] ;
  wire \filter_index_reg_83_reg_n_0_[5] ;
  wire input_r_Rst_A;
  wire [14:2]\^output_r_Addr_A ;
  wire [30:0]\^output_r_Din_A ;
  wire [3:3]\^output_r_WEN_A ;
  wire p_0_in;
  wire \res_1_reg_265[30]_i_10_n_0 ;
  wire \res_1_reg_265[30]_i_11_n_0 ;
  wire \res_1_reg_265[30]_i_13_n_0 ;
  wire \res_1_reg_265[30]_i_14_n_0 ;
  wire \res_1_reg_265[30]_i_15_n_0 ;
  wire \res_1_reg_265[30]_i_16_n_0 ;
  wire \res_1_reg_265[30]_i_17_n_0 ;
  wire \res_1_reg_265[30]_i_18_n_0 ;
  wire \res_1_reg_265[30]_i_19_n_0 ;
  wire \res_1_reg_265[30]_i_1_n_0 ;
  wire \res_1_reg_265[30]_i_20_n_0 ;
  wire \res_1_reg_265[30]_i_22_n_0 ;
  wire \res_1_reg_265[30]_i_23_n_0 ;
  wire \res_1_reg_265[30]_i_24_n_0 ;
  wire \res_1_reg_265[30]_i_25_n_0 ;
  wire \res_1_reg_265[30]_i_26_n_0 ;
  wire \res_1_reg_265[30]_i_27_n_0 ;
  wire \res_1_reg_265[30]_i_28_n_0 ;
  wire \res_1_reg_265[30]_i_29_n_0 ;
  wire \res_1_reg_265[30]_i_30_n_0 ;
  wire \res_1_reg_265[30]_i_31_n_0 ;
  wire \res_1_reg_265[30]_i_32_n_0 ;
  wire \res_1_reg_265[30]_i_33_n_0 ;
  wire \res_1_reg_265[30]_i_34_n_0 ;
  wire \res_1_reg_265[30]_i_35_n_0 ;
  wire \res_1_reg_265[30]_i_36_n_0 ;
  wire \res_1_reg_265[30]_i_37_n_0 ;
  wire \res_1_reg_265[30]_i_4_n_0 ;
  wire \res_1_reg_265[30]_i_5_n_0 ;
  wire \res_1_reg_265[30]_i_6_n_0 ;
  wire \res_1_reg_265[30]_i_7_n_0 ;
  wire \res_1_reg_265[30]_i_8_n_0 ;
  wire \res_1_reg_265[30]_i_9_n_0 ;
  wire \res_1_reg_265_reg[30]_i_12_n_0 ;
  wire \res_1_reg_265_reg[30]_i_12_n_1 ;
  wire \res_1_reg_265_reg[30]_i_12_n_2 ;
  wire \res_1_reg_265_reg[30]_i_12_n_3 ;
  wire \res_1_reg_265_reg[30]_i_21_n_0 ;
  wire \res_1_reg_265_reg[30]_i_21_n_1 ;
  wire \res_1_reg_265_reg[30]_i_21_n_2 ;
  wire \res_1_reg_265_reg[30]_i_21_n_3 ;
  wire \res_1_reg_265_reg[30]_i_2_n_1 ;
  wire \res_1_reg_265_reg[30]_i_2_n_2 ;
  wire \res_1_reg_265_reg[30]_i_2_n_3 ;
  wire \res_1_reg_265_reg[30]_i_3_n_0 ;
  wire \res_1_reg_265_reg[30]_i_3_n_1 ;
  wire \res_1_reg_265_reg[30]_i_3_n_2 ;
  wire \res_1_reg_265_reg[30]_i_3_n_3 ;
  wire [9:3]tmp_3_fu_161_p2;
  wire [12:3]tmp_6_cast_reg_247;
  wire \tmp_6_cast_reg_247[9]_i_2_n_0 ;
  wire \tmp_6_cast_reg_247_reg[12]_i_1_n_3 ;
  wire \tmp_6_cast_reg_247_reg[9]_i_1_n_0 ;
  wire \tmp_6_cast_reg_247_reg[9]_i_1_n_1 ;
  wire \tmp_6_cast_reg_247_reg[9]_i_1_n_2 ;
  wire \tmp_6_cast_reg_247_reg[9]_i_1_n_3 ;
  wire [12:3]tmp_8_fu_190_p2;
  wire tmp_8_reg_2600;
  wire \tmp_8_reg_260[6]_i_2_n_0 ;
  wire \tmp_8_reg_260_reg[10]_i_1_n_0 ;
  wire \tmp_8_reg_260_reg[10]_i_1_n_1 ;
  wire \tmp_8_reg_260_reg[10]_i_1_n_2 ;
  wire \tmp_8_reg_260_reg[10]_i_1_n_3 ;
  wire \tmp_8_reg_260_reg[12]_i_2_n_3 ;
  wire \tmp_8_reg_260_reg[6]_i_1_n_0 ;
  wire \tmp_8_reg_260_reg[6]_i_1_n_1 ;
  wire \tmp_8_reg_260_reg[6]_i_1_n_2 ;
  wire \tmp_8_reg_260_reg[6]_i_1_n_3 ;
  wire [3:0]x_1_fu_180_p2;
  wire [3:0]x_1_reg_255;
  wire [3:0]x_reg_105;
  wire x_reg_1050;
  wire [3:0]y_1_fu_151_p2;
  wire [3:0]y_1_reg_242;
  wire y_reg_94;
  wire y_reg_940;
  wire \y_reg_94_reg_n_0_[0] ;
  wire \y_reg_94_reg_n_0_[1] ;
  wire \y_reg_94_reg_n_0_[2] ;
  wire \y_reg_94_reg_n_0_[3] ;
  wire [3:0]\NLW_res_1_reg_265_reg[30]_i_12_O_UNCONNECTED ;
  wire [3:0]\NLW_res_1_reg_265_reg[30]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_res_1_reg_265_reg[30]_i_21_O_UNCONNECTED ;
  wire [3:0]\NLW_res_1_reg_265_reg[30]_i_3_O_UNCONNECTED ;
  wire [3:1]\NLW_tmp_6_cast_reg_247_reg[12]_i_1_CO_UNCONNECTED ;
  wire [3:2]\NLW_tmp_6_cast_reg_247_reg[12]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_tmp_6_cast_reg_247_reg[9]_i_1_O_UNCONNECTED ;
  wire [3:1]\NLW_tmp_8_reg_260_reg[12]_i_2_CO_UNCONNECTED ;
  wire [3:2]\NLW_tmp_8_reg_260_reg[12]_i_2_O_UNCONNECTED ;
  wire [0:0]\NLW_tmp_8_reg_260_reg[6]_i_1_O_UNCONNECTED ;

  assign ap_ready = ap_done;
  assign bias_Addr_A[31] = \<const0> ;
  assign bias_Addr_A[30] = \<const0> ;
  assign bias_Addr_A[29] = \<const0> ;
  assign bias_Addr_A[28] = \<const0> ;
  assign bias_Addr_A[27] = \<const0> ;
  assign bias_Addr_A[26] = \<const0> ;
  assign bias_Addr_A[25] = \<const0> ;
  assign bias_Addr_A[24] = \<const0> ;
  assign bias_Addr_A[23] = \<const0> ;
  assign bias_Addr_A[22] = \<const0> ;
  assign bias_Addr_A[21] = \<const0> ;
  assign bias_Addr_A[20] = \<const0> ;
  assign bias_Addr_A[19] = \<const0> ;
  assign bias_Addr_A[18] = \<const0> ;
  assign bias_Addr_A[17] = \<const0> ;
  assign bias_Addr_A[16] = \<const0> ;
  assign bias_Addr_A[15] = \<const0> ;
  assign bias_Addr_A[14] = \<const0> ;
  assign bias_Addr_A[13] = \<const0> ;
  assign bias_Addr_A[12] = \<const0> ;
  assign bias_Addr_A[11] = \<const0> ;
  assign bias_Addr_A[10] = \<const0> ;
  assign bias_Addr_A[9] = \<const0> ;
  assign bias_Addr_A[8] = \<const0> ;
  assign bias_Addr_A[7:2] = \^bias_Addr_A [7:2];
  assign bias_Addr_A[1] = \<const0> ;
  assign bias_Addr_A[0] = \<const0> ;
  assign bias_Clk_A = ap_clk;
  assign bias_Din_A[31] = \<const0> ;
  assign bias_Din_A[30] = \<const0> ;
  assign bias_Din_A[29] = \<const0> ;
  assign bias_Din_A[28] = \<const0> ;
  assign bias_Din_A[27] = \<const0> ;
  assign bias_Din_A[26] = \<const0> ;
  assign bias_Din_A[25] = \<const0> ;
  assign bias_Din_A[24] = \<const0> ;
  assign bias_Din_A[23] = \<const0> ;
  assign bias_Din_A[22] = \<const0> ;
  assign bias_Din_A[21] = \<const0> ;
  assign bias_Din_A[20] = \<const0> ;
  assign bias_Din_A[19] = \<const0> ;
  assign bias_Din_A[18] = \<const0> ;
  assign bias_Din_A[17] = \<const0> ;
  assign bias_Din_A[16] = \<const0> ;
  assign bias_Din_A[15] = \<const0> ;
  assign bias_Din_A[14] = \<const0> ;
  assign bias_Din_A[13] = \<const0> ;
  assign bias_Din_A[12] = \<const0> ;
  assign bias_Din_A[11] = \<const0> ;
  assign bias_Din_A[10] = \<const0> ;
  assign bias_Din_A[9] = \<const0> ;
  assign bias_Din_A[8] = \<const0> ;
  assign bias_Din_A[7] = \<const0> ;
  assign bias_Din_A[6] = \<const0> ;
  assign bias_Din_A[5] = \<const0> ;
  assign bias_Din_A[4] = \<const0> ;
  assign bias_Din_A[3] = \<const0> ;
  assign bias_Din_A[2] = \<const0> ;
  assign bias_Din_A[1] = \<const0> ;
  assign bias_Din_A[0] = \<const0> ;
  assign bias_Rst_A = input_r_Rst_A;
  assign bias_WEN_A[3] = \<const0> ;
  assign bias_WEN_A[2] = \<const0> ;
  assign bias_WEN_A[1] = \<const0> ;
  assign bias_WEN_A[0] = \<const0> ;
  assign input_r_Addr_A[31] = \<const0> ;
  assign input_r_Addr_A[30] = \<const0> ;
  assign input_r_Addr_A[29] = \<const0> ;
  assign input_r_Addr_A[28] = \<const0> ;
  assign input_r_Addr_A[27] = \<const0> ;
  assign input_r_Addr_A[26] = \<const0> ;
  assign input_r_Addr_A[25] = \<const0> ;
  assign input_r_Addr_A[24] = \<const0> ;
  assign input_r_Addr_A[23] = \<const0> ;
  assign input_r_Addr_A[22] = \<const0> ;
  assign input_r_Addr_A[21] = \<const0> ;
  assign input_r_Addr_A[20] = \<const0> ;
  assign input_r_Addr_A[19] = \<const0> ;
  assign input_r_Addr_A[18] = \<const0> ;
  assign input_r_Addr_A[17] = \<const0> ;
  assign input_r_Addr_A[16] = \<const0> ;
  assign input_r_Addr_A[15] = \<const0> ;
  assign input_r_Addr_A[14] = \<const0> ;
  assign input_r_Addr_A[13] = \<const0> ;
  assign input_r_Addr_A[12] = \<const0> ;
  assign input_r_Addr_A[11] = \<const0> ;
  assign input_r_Addr_A[10] = \<const0> ;
  assign input_r_Addr_A[9] = \<const0> ;
  assign input_r_Addr_A[8] = \<const0> ;
  assign input_r_Addr_A[7] = \<const0> ;
  assign input_r_Addr_A[6] = \<const0> ;
  assign input_r_Addr_A[5] = \<const0> ;
  assign input_r_Addr_A[4] = \<const0> ;
  assign input_r_Addr_A[3] = \<const0> ;
  assign input_r_Addr_A[2] = \<const0> ;
  assign input_r_Addr_A[1] = \<const0> ;
  assign input_r_Addr_A[0] = \<const0> ;
  assign input_r_Clk_A = ap_clk;
  assign input_r_Din_A[31] = \<const0> ;
  assign input_r_Din_A[30] = \<const0> ;
  assign input_r_Din_A[29] = \<const0> ;
  assign input_r_Din_A[28] = \<const0> ;
  assign input_r_Din_A[27] = \<const0> ;
  assign input_r_Din_A[26] = \<const0> ;
  assign input_r_Din_A[25] = \<const0> ;
  assign input_r_Din_A[24] = \<const0> ;
  assign input_r_Din_A[23] = \<const0> ;
  assign input_r_Din_A[22] = \<const0> ;
  assign input_r_Din_A[21] = \<const0> ;
  assign input_r_Din_A[20] = \<const0> ;
  assign input_r_Din_A[19] = \<const0> ;
  assign input_r_Din_A[18] = \<const0> ;
  assign input_r_Din_A[17] = \<const0> ;
  assign input_r_Din_A[16] = \<const0> ;
  assign input_r_Din_A[15] = \<const0> ;
  assign input_r_Din_A[14] = \<const0> ;
  assign input_r_Din_A[13] = \<const0> ;
  assign input_r_Din_A[12] = \<const0> ;
  assign input_r_Din_A[11] = \<const0> ;
  assign input_r_Din_A[10] = \<const0> ;
  assign input_r_Din_A[9] = \<const0> ;
  assign input_r_Din_A[8] = \<const0> ;
  assign input_r_Din_A[7] = \<const0> ;
  assign input_r_Din_A[6] = \<const0> ;
  assign input_r_Din_A[5] = \<const0> ;
  assign input_r_Din_A[4] = \<const0> ;
  assign input_r_Din_A[3] = \<const0> ;
  assign input_r_Din_A[2] = \<const0> ;
  assign input_r_Din_A[1] = \<const0> ;
  assign input_r_Din_A[0] = \<const0> ;
  assign input_r_EN_A = \<const0> ;
  assign input_r_WEN_A[3] = \<const0> ;
  assign input_r_WEN_A[2] = \<const0> ;
  assign input_r_WEN_A[1] = \<const0> ;
  assign input_r_WEN_A[0] = \<const0> ;
  assign output_r_Addr_A[31] = \<const0> ;
  assign output_r_Addr_A[30] = \<const0> ;
  assign output_r_Addr_A[29] = \<const0> ;
  assign output_r_Addr_A[28] = \<const0> ;
  assign output_r_Addr_A[27] = \<const0> ;
  assign output_r_Addr_A[26] = \<const0> ;
  assign output_r_Addr_A[25] = \<const0> ;
  assign output_r_Addr_A[24] = \<const0> ;
  assign output_r_Addr_A[23] = \<const0> ;
  assign output_r_Addr_A[22] = \<const0> ;
  assign output_r_Addr_A[21] = \<const0> ;
  assign output_r_Addr_A[20] = \<const0> ;
  assign output_r_Addr_A[19] = \<const0> ;
  assign output_r_Addr_A[18] = \<const0> ;
  assign output_r_Addr_A[17] = \<const0> ;
  assign output_r_Addr_A[16] = \<const0> ;
  assign output_r_Addr_A[15] = \<const0> ;
  assign output_r_Addr_A[14:2] = \^output_r_Addr_A [14:2];
  assign output_r_Addr_A[1] = \<const0> ;
  assign output_r_Addr_A[0] = \<const0> ;
  assign output_r_Clk_A = ap_clk;
  assign output_r_Din_A[31] = \<const0> ;
  assign output_r_Din_A[30:0] = \^output_r_Din_A [30:0];
  assign output_r_EN_A = \^output_r_WEN_A [3];
  assign output_r_Rst_A = input_r_Rst_A;
  assign output_r_WEN_A[3] = \^output_r_WEN_A [3];
  assign output_r_WEN_A[2] = \^output_r_WEN_A [3];
  assign output_r_WEN_A[1] = \^output_r_WEN_A [3];
  assign output_r_WEN_A[0] = \^output_r_WEN_A [3];
  GND GND
       (.G(\<const0> ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h88F8)) 
    \ap_CS_fsm[0]_i_1 
       (.I0(exitcond5_fu_116_p2),
        .I1(ap_CS_fsm_state2),
        .I2(\ap_CS_fsm_reg_n_0_[0] ),
        .I3(ap_start),
        .O(ap_NS_fsm[0]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'hF888)) 
    \ap_CS_fsm[1]_i_1 
       (.I0(\ap_CS_fsm_reg_n_0_[0] ),
        .I1(ap_start),
        .I2(ap_NS_fsm10_out),
        .I3(ap_CS_fsm_state3),
        .O(ap_NS_fsm[1]));
  LUT4 #(
    .INIT(16'hF444)) 
    \ap_CS_fsm[2]_i_1 
       (.I0(exitcond5_fu_116_p2),
        .I1(ap_CS_fsm_state2),
        .I2(ap_NS_fsm1),
        .I3(bias_EN_A),
        .O(ap_NS_fsm[2]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFB0000)) 
    \ap_CS_fsm[3]_i_1 
       (.I0(\y_reg_94_reg_n_0_[1] ),
        .I1(\y_reg_94_reg_n_0_[3] ),
        .I2(\y_reg_94_reg_n_0_[2] ),
        .I3(\y_reg_94_reg_n_0_[0] ),
        .I4(ap_CS_fsm_state3),
        .I5(\^output_r_WEN_A ),
        .O(ap_NS_fsm[3]));
  LUT5 #(
    .INIT(32'hAAAAA8AA)) 
    \ap_CS_fsm[4]_i_1 
       (.I0(bias_EN_A),
        .I1(x_reg_105[0]),
        .I2(x_reg_105[2]),
        .I3(x_reg_105[3]),
        .I4(x_reg_105[1]),
        .O(\ap_CS_fsm[4]_i_1_n_0 ));
  (* FSM_ENCODING = "none" *) 
  FDSE #(
    .INIT(1'b1)) 
    \ap_CS_fsm_reg[0] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[0]),
        .Q(\ap_CS_fsm_reg_n_0_[0] ),
        .S(input_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[1] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[1]),
        .Q(ap_CS_fsm_state2),
        .R(input_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[2] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[2]),
        .Q(ap_CS_fsm_state3),
        .R(input_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[3] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[3]),
        .Q(bias_EN_A),
        .R(input_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[4] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\ap_CS_fsm[4]_i_1_n_0 ),
        .Q(ap_CS_fsm_state5),
        .R(input_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[5] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_CS_fsm_state5),
        .Q(\^output_r_WEN_A ),
        .R(input_r_Rst_A));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'h2)) 
    ap_idle_INST_0
       (.I0(\ap_CS_fsm_reg_n_0_[0] ),
        .I1(ap_start),
        .O(ap_idle));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT2 #(
    .INIT(4'h8)) 
    ap_ready_INST_0
       (.I0(exitcond5_fu_116_p2),
        .I1(ap_CS_fsm_state2),
        .O(ap_done));
  LUT6 #(
    .INIT(64'h0000000000001000)) 
    ap_ready_INST_0_i_1
       (.I0(\filter_index_reg_83_reg_n_0_[1] ),
        .I1(\filter_index_reg_83_reg_n_0_[4] ),
        .I2(\filter_index_reg_83_reg_n_0_[5] ),
        .I3(\filter_index_reg_83_reg_n_0_[3] ),
        .I4(\filter_index_reg_83_reg_n_0_[0] ),
        .I5(\filter_index_reg_83_reg_n_0_[2] ),
        .O(exitcond5_fu_116_p2));
  LUT2 #(
    .INIT(4'h2)) 
    \bias_addr_reg_234[5]_i_1 
       (.I0(ap_CS_fsm_state2),
        .I1(exitcond5_fu_116_p2),
        .O(y_reg_940));
  FDRE \bias_addr_reg_234_reg[0] 
       (.C(ap_clk),
        .CE(y_reg_940),
        .D(\filter_index_reg_83_reg_n_0_[0] ),
        .Q(\^bias_Addr_A [2]),
        .R(1'b0));
  FDRE \bias_addr_reg_234_reg[1] 
       (.C(ap_clk),
        .CE(y_reg_940),
        .D(\filter_index_reg_83_reg_n_0_[1] ),
        .Q(\^bias_Addr_A [3]),
        .R(1'b0));
  FDRE \bias_addr_reg_234_reg[2] 
       (.C(ap_clk),
        .CE(y_reg_940),
        .D(\filter_index_reg_83_reg_n_0_[2] ),
        .Q(\^bias_Addr_A [4]),
        .R(1'b0));
  FDRE \bias_addr_reg_234_reg[3] 
       (.C(ap_clk),
        .CE(y_reg_940),
        .D(\filter_index_reg_83_reg_n_0_[3] ),
        .Q(\^bias_Addr_A [5]),
        .R(1'b0));
  FDRE \bias_addr_reg_234_reg[4] 
       (.C(ap_clk),
        .CE(y_reg_940),
        .D(\filter_index_reg_83_reg_n_0_[4] ),
        .Q(\^bias_Addr_A [6]),
        .R(1'b0));
  FDRE \bias_addr_reg_234_reg[5] 
       (.C(ap_clk),
        .CE(y_reg_940),
        .D(\filter_index_reg_83_reg_n_0_[5] ),
        .Q(\^bias_Addr_A [7]),
        .R(1'b0));
  LUT1 #(
    .INIT(2'h1)) 
    \filter_index_1_reg_224[0]_i_1 
       (.I0(\filter_index_reg_83_reg_n_0_[0] ),
        .O(filter_index_1_fu_122_p2[0]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \filter_index_1_reg_224[1]_i_1 
       (.I0(\filter_index_reg_83_reg_n_0_[0] ),
        .I1(\filter_index_reg_83_reg_n_0_[1] ),
        .O(filter_index_1_fu_122_p2[1]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \filter_index_1_reg_224[2]_i_1 
       (.I0(\filter_index_reg_83_reg_n_0_[0] ),
        .I1(\filter_index_reg_83_reg_n_0_[1] ),
        .I2(\filter_index_reg_83_reg_n_0_[2] ),
        .O(filter_index_1_fu_122_p2[2]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \filter_index_1_reg_224[3]_i_1 
       (.I0(\filter_index_reg_83_reg_n_0_[1] ),
        .I1(\filter_index_reg_83_reg_n_0_[0] ),
        .I2(\filter_index_reg_83_reg_n_0_[2] ),
        .I3(\filter_index_reg_83_reg_n_0_[3] ),
        .O(filter_index_1_fu_122_p2[3]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \filter_index_1_reg_224[4]_i_1 
       (.I0(\filter_index_reg_83_reg_n_0_[2] ),
        .I1(\filter_index_reg_83_reg_n_0_[0] ),
        .I2(\filter_index_reg_83_reg_n_0_[1] ),
        .I3(\filter_index_reg_83_reg_n_0_[3] ),
        .I4(\filter_index_reg_83_reg_n_0_[4] ),
        .O(filter_index_1_fu_122_p2[4]));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \filter_index_1_reg_224[5]_i_1 
       (.I0(\filter_index_reg_83_reg_n_0_[3] ),
        .I1(\filter_index_reg_83_reg_n_0_[1] ),
        .I2(\filter_index_reg_83_reg_n_0_[0] ),
        .I3(\filter_index_reg_83_reg_n_0_[2] ),
        .I4(\filter_index_reg_83_reg_n_0_[4] ),
        .I5(\filter_index_reg_83_reg_n_0_[5] ),
        .O(filter_index_1_fu_122_p2[5]));
  FDRE \filter_index_1_reg_224_reg[0] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state2),
        .D(filter_index_1_fu_122_p2[0]),
        .Q(filter_index_1_reg_224[0]),
        .R(1'b0));
  FDRE \filter_index_1_reg_224_reg[1] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state2),
        .D(filter_index_1_fu_122_p2[1]),
        .Q(filter_index_1_reg_224[1]),
        .R(1'b0));
  FDRE \filter_index_1_reg_224_reg[2] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state2),
        .D(filter_index_1_fu_122_p2[2]),
        .Q(filter_index_1_reg_224[2]),
        .R(1'b0));
  FDRE \filter_index_1_reg_224_reg[3] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state2),
        .D(filter_index_1_fu_122_p2[3]),
        .Q(filter_index_1_reg_224[3]),
        .R(1'b0));
  FDRE \filter_index_1_reg_224_reg[4] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state2),
        .D(filter_index_1_fu_122_p2[4]),
        .Q(filter_index_1_reg_224[4]),
        .R(1'b0));
  FDRE \filter_index_1_reg_224_reg[5] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state2),
        .D(filter_index_1_fu_122_p2[5]),
        .Q(filter_index_1_reg_224[5]),
        .R(1'b0));
  LUT3 #(
    .INIT(8'h08)) 
    \filter_index_reg_83[5]_i_1 
       (.I0(ap_start),
        .I1(\ap_CS_fsm_reg_n_0_[0] ),
        .I2(ap_NS_fsm10_out),
        .O(filter_index_reg_83));
  LUT5 #(
    .INIT(32'h00040000)) 
    \filter_index_reg_83[5]_i_2 
       (.I0(\y_reg_94_reg_n_0_[1] ),
        .I1(\y_reg_94_reg_n_0_[3] ),
        .I2(\y_reg_94_reg_n_0_[2] ),
        .I3(\y_reg_94_reg_n_0_[0] ),
        .I4(ap_CS_fsm_state3),
        .O(ap_NS_fsm10_out));
  FDRE \filter_index_reg_83_reg[0] 
       (.C(ap_clk),
        .CE(ap_NS_fsm10_out),
        .D(filter_index_1_reg_224[0]),
        .Q(\filter_index_reg_83_reg_n_0_[0] ),
        .R(filter_index_reg_83));
  FDRE \filter_index_reg_83_reg[1] 
       (.C(ap_clk),
        .CE(ap_NS_fsm10_out),
        .D(filter_index_1_reg_224[1]),
        .Q(\filter_index_reg_83_reg_n_0_[1] ),
        .R(filter_index_reg_83));
  FDRE \filter_index_reg_83_reg[2] 
       (.C(ap_clk),
        .CE(ap_NS_fsm10_out),
        .D(filter_index_1_reg_224[2]),
        .Q(\filter_index_reg_83_reg_n_0_[2] ),
        .R(filter_index_reg_83));
  FDRE \filter_index_reg_83_reg[3] 
       (.C(ap_clk),
        .CE(ap_NS_fsm10_out),
        .D(filter_index_1_reg_224[3]),
        .Q(\filter_index_reg_83_reg_n_0_[3] ),
        .R(filter_index_reg_83));
  FDRE \filter_index_reg_83_reg[4] 
       (.C(ap_clk),
        .CE(ap_NS_fsm10_out),
        .D(filter_index_1_reg_224[4]),
        .Q(\filter_index_reg_83_reg_n_0_[4] ),
        .R(filter_index_reg_83));
  FDRE \filter_index_reg_83_reg[5] 
       (.C(ap_clk),
        .CE(ap_NS_fsm10_out),
        .D(filter_index_1_reg_224[5]),
        .Q(\filter_index_reg_83_reg_n_0_[5] ),
        .R(filter_index_reg_83));
  LUT1 #(
    .INIT(2'h1)) 
    output_r_Rst_A_INST_0
       (.I0(ap_rst_n),
        .O(input_r_Rst_A));
  LUT2 #(
    .INIT(4'h2)) 
    \res_1_reg_265[30]_i_1 
       (.I0(ap_CS_fsm_state5),
        .I1(p_0_in),
        .O(\res_1_reg_265[30]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_265[30]_i_10 
       (.I0(bias_Dout_A[26]),
        .I1(bias_Dout_A[27]),
        .O(\res_1_reg_265[30]_i_10_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_265[30]_i_11 
       (.I0(bias_Dout_A[24]),
        .I1(bias_Dout_A[25]),
        .O(\res_1_reg_265[30]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_265[30]_i_13 
       (.I0(bias_Dout_A[22]),
        .I1(bias_Dout_A[23]),
        .O(\res_1_reg_265[30]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_265[30]_i_14 
       (.I0(bias_Dout_A[20]),
        .I1(bias_Dout_A[21]),
        .O(\res_1_reg_265[30]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_265[30]_i_15 
       (.I0(bias_Dout_A[18]),
        .I1(bias_Dout_A[19]),
        .O(\res_1_reg_265[30]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_265[30]_i_16 
       (.I0(bias_Dout_A[16]),
        .I1(bias_Dout_A[17]),
        .O(\res_1_reg_265[30]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_265[30]_i_17 
       (.I0(bias_Dout_A[22]),
        .I1(bias_Dout_A[23]),
        .O(\res_1_reg_265[30]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_265[30]_i_18 
       (.I0(bias_Dout_A[20]),
        .I1(bias_Dout_A[21]),
        .O(\res_1_reg_265[30]_i_18_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_265[30]_i_19 
       (.I0(bias_Dout_A[18]),
        .I1(bias_Dout_A[19]),
        .O(\res_1_reg_265[30]_i_19_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_265[30]_i_20 
       (.I0(bias_Dout_A[16]),
        .I1(bias_Dout_A[17]),
        .O(\res_1_reg_265[30]_i_20_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_265[30]_i_22 
       (.I0(bias_Dout_A[14]),
        .I1(bias_Dout_A[15]),
        .O(\res_1_reg_265[30]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_265[30]_i_23 
       (.I0(bias_Dout_A[12]),
        .I1(bias_Dout_A[13]),
        .O(\res_1_reg_265[30]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_265[30]_i_24 
       (.I0(bias_Dout_A[10]),
        .I1(bias_Dout_A[11]),
        .O(\res_1_reg_265[30]_i_24_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_265[30]_i_25 
       (.I0(bias_Dout_A[8]),
        .I1(bias_Dout_A[9]),
        .O(\res_1_reg_265[30]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_265[30]_i_26 
       (.I0(bias_Dout_A[14]),
        .I1(bias_Dout_A[15]),
        .O(\res_1_reg_265[30]_i_26_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_265[30]_i_27 
       (.I0(bias_Dout_A[12]),
        .I1(bias_Dout_A[13]),
        .O(\res_1_reg_265[30]_i_27_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_265[30]_i_28 
       (.I0(bias_Dout_A[10]),
        .I1(bias_Dout_A[11]),
        .O(\res_1_reg_265[30]_i_28_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_265[30]_i_29 
       (.I0(bias_Dout_A[8]),
        .I1(bias_Dout_A[9]),
        .O(\res_1_reg_265[30]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_265[30]_i_30 
       (.I0(bias_Dout_A[6]),
        .I1(bias_Dout_A[7]),
        .O(\res_1_reg_265[30]_i_30_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_265[30]_i_31 
       (.I0(bias_Dout_A[4]),
        .I1(bias_Dout_A[5]),
        .O(\res_1_reg_265[30]_i_31_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_265[30]_i_32 
       (.I0(bias_Dout_A[2]),
        .I1(bias_Dout_A[3]),
        .O(\res_1_reg_265[30]_i_32_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_265[30]_i_33 
       (.I0(bias_Dout_A[0]),
        .I1(bias_Dout_A[1]),
        .O(\res_1_reg_265[30]_i_33_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_265[30]_i_34 
       (.I0(bias_Dout_A[6]),
        .I1(bias_Dout_A[7]),
        .O(\res_1_reg_265[30]_i_34_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_265[30]_i_35 
       (.I0(bias_Dout_A[4]),
        .I1(bias_Dout_A[5]),
        .O(\res_1_reg_265[30]_i_35_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_265[30]_i_36 
       (.I0(bias_Dout_A[2]),
        .I1(bias_Dout_A[3]),
        .O(\res_1_reg_265[30]_i_36_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_265[30]_i_37 
       (.I0(bias_Dout_A[0]),
        .I1(bias_Dout_A[1]),
        .O(\res_1_reg_265[30]_i_37_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \res_1_reg_265[30]_i_4 
       (.I0(bias_Dout_A[30]),
        .I1(bias_Dout_A[31]),
        .O(\res_1_reg_265[30]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_265[30]_i_5 
       (.I0(bias_Dout_A[28]),
        .I1(bias_Dout_A[29]),
        .O(\res_1_reg_265[30]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_265[30]_i_6 
       (.I0(bias_Dout_A[26]),
        .I1(bias_Dout_A[27]),
        .O(\res_1_reg_265[30]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_265[30]_i_7 
       (.I0(bias_Dout_A[24]),
        .I1(bias_Dout_A[25]),
        .O(\res_1_reg_265[30]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_265[30]_i_8 
       (.I0(bias_Dout_A[30]),
        .I1(bias_Dout_A[31]),
        .O(\res_1_reg_265[30]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_265[30]_i_9 
       (.I0(bias_Dout_A[28]),
        .I1(bias_Dout_A[29]),
        .O(\res_1_reg_265[30]_i_9_n_0 ));
  FDRE \res_1_reg_265_reg[0] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[0]),
        .Q(\^output_r_Din_A [0]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[10] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[10]),
        .Q(\^output_r_Din_A [10]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[11] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[11]),
        .Q(\^output_r_Din_A [11]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[12] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[12]),
        .Q(\^output_r_Din_A [12]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[13] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[13]),
        .Q(\^output_r_Din_A [13]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[14] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[14]),
        .Q(\^output_r_Din_A [14]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[15] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[15]),
        .Q(\^output_r_Din_A [15]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[16] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[16]),
        .Q(\^output_r_Din_A [16]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[17] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[17]),
        .Q(\^output_r_Din_A [17]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[18] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[18]),
        .Q(\^output_r_Din_A [18]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[19] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[19]),
        .Q(\^output_r_Din_A [19]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[1] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[1]),
        .Q(\^output_r_Din_A [1]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[20] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[20]),
        .Q(\^output_r_Din_A [20]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[21] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[21]),
        .Q(\^output_r_Din_A [21]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[22] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[22]),
        .Q(\^output_r_Din_A [22]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[23] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[23]),
        .Q(\^output_r_Din_A [23]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[24] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[24]),
        .Q(\^output_r_Din_A [24]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[25] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[25]),
        .Q(\^output_r_Din_A [25]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[26] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[26]),
        .Q(\^output_r_Din_A [26]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[27] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[27]),
        .Q(\^output_r_Din_A [27]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[28] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[28]),
        .Q(\^output_r_Din_A [28]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[29] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[29]),
        .Q(\^output_r_Din_A [29]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[2] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[2]),
        .Q(\^output_r_Din_A [2]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[30] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[30]),
        .Q(\^output_r_Din_A [30]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  CARRY4 \res_1_reg_265_reg[30]_i_12 
       (.CI(\res_1_reg_265_reg[30]_i_21_n_0 ),
        .CO({\res_1_reg_265_reg[30]_i_12_n_0 ,\res_1_reg_265_reg[30]_i_12_n_1 ,\res_1_reg_265_reg[30]_i_12_n_2 ,\res_1_reg_265_reg[30]_i_12_n_3 }),
        .CYINIT(1'b0),
        .DI({\res_1_reg_265[30]_i_22_n_0 ,\res_1_reg_265[30]_i_23_n_0 ,\res_1_reg_265[30]_i_24_n_0 ,\res_1_reg_265[30]_i_25_n_0 }),
        .O(\NLW_res_1_reg_265_reg[30]_i_12_O_UNCONNECTED [3:0]),
        .S({\res_1_reg_265[30]_i_26_n_0 ,\res_1_reg_265[30]_i_27_n_0 ,\res_1_reg_265[30]_i_28_n_0 ,\res_1_reg_265[30]_i_29_n_0 }));
  CARRY4 \res_1_reg_265_reg[30]_i_2 
       (.CI(\res_1_reg_265_reg[30]_i_3_n_0 ),
        .CO({p_0_in,\res_1_reg_265_reg[30]_i_2_n_1 ,\res_1_reg_265_reg[30]_i_2_n_2 ,\res_1_reg_265_reg[30]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\res_1_reg_265[30]_i_4_n_0 ,\res_1_reg_265[30]_i_5_n_0 ,\res_1_reg_265[30]_i_6_n_0 ,\res_1_reg_265[30]_i_7_n_0 }),
        .O(\NLW_res_1_reg_265_reg[30]_i_2_O_UNCONNECTED [3:0]),
        .S({\res_1_reg_265[30]_i_8_n_0 ,\res_1_reg_265[30]_i_9_n_0 ,\res_1_reg_265[30]_i_10_n_0 ,\res_1_reg_265[30]_i_11_n_0 }));
  CARRY4 \res_1_reg_265_reg[30]_i_21 
       (.CI(1'b0),
        .CO({\res_1_reg_265_reg[30]_i_21_n_0 ,\res_1_reg_265_reg[30]_i_21_n_1 ,\res_1_reg_265_reg[30]_i_21_n_2 ,\res_1_reg_265_reg[30]_i_21_n_3 }),
        .CYINIT(1'b0),
        .DI({\res_1_reg_265[30]_i_30_n_0 ,\res_1_reg_265[30]_i_31_n_0 ,\res_1_reg_265[30]_i_32_n_0 ,\res_1_reg_265[30]_i_33_n_0 }),
        .O(\NLW_res_1_reg_265_reg[30]_i_21_O_UNCONNECTED [3:0]),
        .S({\res_1_reg_265[30]_i_34_n_0 ,\res_1_reg_265[30]_i_35_n_0 ,\res_1_reg_265[30]_i_36_n_0 ,\res_1_reg_265[30]_i_37_n_0 }));
  CARRY4 \res_1_reg_265_reg[30]_i_3 
       (.CI(\res_1_reg_265_reg[30]_i_12_n_0 ),
        .CO({\res_1_reg_265_reg[30]_i_3_n_0 ,\res_1_reg_265_reg[30]_i_3_n_1 ,\res_1_reg_265_reg[30]_i_3_n_2 ,\res_1_reg_265_reg[30]_i_3_n_3 }),
        .CYINIT(1'b0),
        .DI({\res_1_reg_265[30]_i_13_n_0 ,\res_1_reg_265[30]_i_14_n_0 ,\res_1_reg_265[30]_i_15_n_0 ,\res_1_reg_265[30]_i_16_n_0 }),
        .O(\NLW_res_1_reg_265_reg[30]_i_3_O_UNCONNECTED [3:0]),
        .S({\res_1_reg_265[30]_i_17_n_0 ,\res_1_reg_265[30]_i_18_n_0 ,\res_1_reg_265[30]_i_19_n_0 ,\res_1_reg_265[30]_i_20_n_0 }));
  FDRE \res_1_reg_265_reg[3] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[3]),
        .Q(\^output_r_Din_A [3]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[4] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[4]),
        .Q(\^output_r_Din_A [4]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[5] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[5]),
        .Q(\^output_r_Din_A [5]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[6] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[6]),
        .Q(\^output_r_Din_A [6]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[7] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[7]),
        .Q(\^output_r_Din_A [7]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[8] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[8]),
        .Q(\^output_r_Din_A [8]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  FDRE \res_1_reg_265_reg[9] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state5),
        .D(bias_Dout_A[9]),
        .Q(\^output_r_Din_A [9]),
        .R(\res_1_reg_265[30]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_6_cast_reg_247[6]_i_1 
       (.I0(\y_reg_94_reg_n_0_[3] ),
        .I1(\^bias_Addr_A [2]),
        .O(tmp_3_fu_161_p2[3]));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_6_cast_reg_247[9]_i_2 
       (.I0(\y_reg_94_reg_n_0_[3] ),
        .I1(\^bias_Addr_A [2]),
        .O(\tmp_6_cast_reg_247[9]_i_2_n_0 ));
  FDRE \tmp_6_cast_reg_247_reg[10] 
       (.C(ap_clk),
        .CE(x_reg_1050),
        .D(tmp_3_fu_161_p2[7]),
        .Q(tmp_6_cast_reg_247[10]),
        .R(1'b0));
  FDRE \tmp_6_cast_reg_247_reg[11] 
       (.C(ap_clk),
        .CE(x_reg_1050),
        .D(tmp_3_fu_161_p2[8]),
        .Q(tmp_6_cast_reg_247[11]),
        .R(1'b0));
  FDRE \tmp_6_cast_reg_247_reg[12] 
       (.C(ap_clk),
        .CE(x_reg_1050),
        .D(tmp_3_fu_161_p2[9]),
        .Q(tmp_6_cast_reg_247[12]),
        .R(1'b0));
  CARRY4 \tmp_6_cast_reg_247_reg[12]_i_1 
       (.CI(\tmp_6_cast_reg_247_reg[9]_i_1_n_0 ),
        .CO({\NLW_tmp_6_cast_reg_247_reg[12]_i_1_CO_UNCONNECTED [3],tmp_3_fu_161_p2[9],\NLW_tmp_6_cast_reg_247_reg[12]_i_1_CO_UNCONNECTED [1],\tmp_6_cast_reg_247_reg[12]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_tmp_6_cast_reg_247_reg[12]_i_1_O_UNCONNECTED [3:2],tmp_3_fu_161_p2[8:7]}),
        .S({1'b0,1'b1,\^bias_Addr_A [7:6]}));
  FDRE \tmp_6_cast_reg_247_reg[3] 
       (.C(ap_clk),
        .CE(x_reg_1050),
        .D(\y_reg_94_reg_n_0_[0] ),
        .Q(tmp_6_cast_reg_247[3]),
        .R(1'b0));
  FDRE \tmp_6_cast_reg_247_reg[4] 
       (.C(ap_clk),
        .CE(x_reg_1050),
        .D(\y_reg_94_reg_n_0_[1] ),
        .Q(tmp_6_cast_reg_247[4]),
        .R(1'b0));
  FDRE \tmp_6_cast_reg_247_reg[5] 
       (.C(ap_clk),
        .CE(x_reg_1050),
        .D(\y_reg_94_reg_n_0_[2] ),
        .Q(tmp_6_cast_reg_247[5]),
        .R(1'b0));
  FDRE \tmp_6_cast_reg_247_reg[6] 
       (.C(ap_clk),
        .CE(x_reg_1050),
        .D(tmp_3_fu_161_p2[3]),
        .Q(tmp_6_cast_reg_247[6]),
        .R(1'b0));
  FDRE \tmp_6_cast_reg_247_reg[7] 
       (.C(ap_clk),
        .CE(x_reg_1050),
        .D(tmp_3_fu_161_p2[4]),
        .Q(tmp_6_cast_reg_247[7]),
        .R(1'b0));
  FDRE \tmp_6_cast_reg_247_reg[8] 
       (.C(ap_clk),
        .CE(x_reg_1050),
        .D(tmp_3_fu_161_p2[5]),
        .Q(tmp_6_cast_reg_247[8]),
        .R(1'b0));
  FDRE \tmp_6_cast_reg_247_reg[9] 
       (.C(ap_clk),
        .CE(x_reg_1050),
        .D(tmp_3_fu_161_p2[6]),
        .Q(tmp_6_cast_reg_247[9]),
        .R(1'b0));
  CARRY4 \tmp_6_cast_reg_247_reg[9]_i_1 
       (.CI(1'b0),
        .CO({\tmp_6_cast_reg_247_reg[9]_i_1_n_0 ,\tmp_6_cast_reg_247_reg[9]_i_1_n_1 ,\tmp_6_cast_reg_247_reg[9]_i_1_n_2 ,\tmp_6_cast_reg_247_reg[9]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\y_reg_94_reg_n_0_[3] }),
        .O({tmp_3_fu_161_p2[6:4],\NLW_tmp_6_cast_reg_247_reg[9]_i_1_O_UNCONNECTED [0]}),
        .S({\^bias_Addr_A [5:3],\tmp_6_cast_reg_247[9]_i_2_n_0 }));
  LUT5 #(
    .INIT(32'hAAAAAA8A)) 
    \tmp_8_reg_260[12]_i_1 
       (.I0(bias_EN_A),
        .I1(x_reg_105[1]),
        .I2(x_reg_105[3]),
        .I3(x_reg_105[2]),
        .I4(x_reg_105[0]),
        .O(tmp_8_reg_2600));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_8_reg_260[3]_i_1 
       (.I0(tmp_6_cast_reg_247[3]),
        .I1(x_reg_105[3]),
        .O(tmp_8_fu_190_p2[3]));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_8_reg_260[6]_i_2 
       (.I0(tmp_6_cast_reg_247[3]),
        .I1(x_reg_105[3]),
        .O(\tmp_8_reg_260[6]_i_2_n_0 ));
  FDRE \tmp_8_reg_260_reg[0] 
       (.C(ap_clk),
        .CE(tmp_8_reg_2600),
        .D(x_reg_105[0]),
        .Q(\^output_r_Addr_A [2]),
        .R(1'b0));
  FDRE \tmp_8_reg_260_reg[10] 
       (.C(ap_clk),
        .CE(tmp_8_reg_2600),
        .D(tmp_8_fu_190_p2[10]),
        .Q(\^output_r_Addr_A [12]),
        .R(1'b0));
  CARRY4 \tmp_8_reg_260_reg[10]_i_1 
       (.CI(\tmp_8_reg_260_reg[6]_i_1_n_0 ),
        .CO({\tmp_8_reg_260_reg[10]_i_1_n_0 ,\tmp_8_reg_260_reg[10]_i_1_n_1 ,\tmp_8_reg_260_reg[10]_i_1_n_2 ,\tmp_8_reg_260_reg[10]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(tmp_8_fu_190_p2[10:7]),
        .S(tmp_6_cast_reg_247[10:7]));
  FDRE \tmp_8_reg_260_reg[11] 
       (.C(ap_clk),
        .CE(tmp_8_reg_2600),
        .D(tmp_8_fu_190_p2[11]),
        .Q(\^output_r_Addr_A [13]),
        .R(1'b0));
  FDRE \tmp_8_reg_260_reg[12] 
       (.C(ap_clk),
        .CE(tmp_8_reg_2600),
        .D(tmp_8_fu_190_p2[12]),
        .Q(\^output_r_Addr_A [14]),
        .R(1'b0));
  CARRY4 \tmp_8_reg_260_reg[12]_i_2 
       (.CI(\tmp_8_reg_260_reg[10]_i_1_n_0 ),
        .CO({\NLW_tmp_8_reg_260_reg[12]_i_2_CO_UNCONNECTED [3:1],\tmp_8_reg_260_reg[12]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_tmp_8_reg_260_reg[12]_i_2_O_UNCONNECTED [3:2],tmp_8_fu_190_p2[12:11]}),
        .S({1'b0,1'b0,tmp_6_cast_reg_247[12:11]}));
  FDRE \tmp_8_reg_260_reg[1] 
       (.C(ap_clk),
        .CE(tmp_8_reg_2600),
        .D(x_reg_105[1]),
        .Q(\^output_r_Addr_A [3]),
        .R(1'b0));
  FDRE \tmp_8_reg_260_reg[2] 
       (.C(ap_clk),
        .CE(tmp_8_reg_2600),
        .D(x_reg_105[2]),
        .Q(\^output_r_Addr_A [4]),
        .R(1'b0));
  FDRE \tmp_8_reg_260_reg[3] 
       (.C(ap_clk),
        .CE(tmp_8_reg_2600),
        .D(tmp_8_fu_190_p2[3]),
        .Q(\^output_r_Addr_A [5]),
        .R(1'b0));
  FDRE \tmp_8_reg_260_reg[4] 
       (.C(ap_clk),
        .CE(tmp_8_reg_2600),
        .D(tmp_8_fu_190_p2[4]),
        .Q(\^output_r_Addr_A [6]),
        .R(1'b0));
  FDRE \tmp_8_reg_260_reg[5] 
       (.C(ap_clk),
        .CE(tmp_8_reg_2600),
        .D(tmp_8_fu_190_p2[5]),
        .Q(\^output_r_Addr_A [7]),
        .R(1'b0));
  FDRE \tmp_8_reg_260_reg[6] 
       (.C(ap_clk),
        .CE(tmp_8_reg_2600),
        .D(tmp_8_fu_190_p2[6]),
        .Q(\^output_r_Addr_A [8]),
        .R(1'b0));
  CARRY4 \tmp_8_reg_260_reg[6]_i_1 
       (.CI(1'b0),
        .CO({\tmp_8_reg_260_reg[6]_i_1_n_0 ,\tmp_8_reg_260_reg[6]_i_1_n_1 ,\tmp_8_reg_260_reg[6]_i_1_n_2 ,\tmp_8_reg_260_reg[6]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,tmp_6_cast_reg_247[3]}),
        .O({tmp_8_fu_190_p2[6:4],\NLW_tmp_8_reg_260_reg[6]_i_1_O_UNCONNECTED [0]}),
        .S({tmp_6_cast_reg_247[6:4],\tmp_8_reg_260[6]_i_2_n_0 }));
  FDRE \tmp_8_reg_260_reg[7] 
       (.C(ap_clk),
        .CE(tmp_8_reg_2600),
        .D(tmp_8_fu_190_p2[7]),
        .Q(\^output_r_Addr_A [9]),
        .R(1'b0));
  FDRE \tmp_8_reg_260_reg[8] 
       (.C(ap_clk),
        .CE(tmp_8_reg_2600),
        .D(tmp_8_fu_190_p2[8]),
        .Q(\^output_r_Addr_A [10]),
        .R(1'b0));
  FDRE \tmp_8_reg_260_reg[9] 
       (.C(ap_clk),
        .CE(tmp_8_reg_2600),
        .D(tmp_8_fu_190_p2[9]),
        .Q(\^output_r_Addr_A [11]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \x_1_reg_255[0]_i_1 
       (.I0(x_reg_105[0]),
        .O(x_1_fu_180_p2[0]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \x_1_reg_255[1]_i_1 
       (.I0(x_reg_105[0]),
        .I1(x_reg_105[1]),
        .O(x_1_fu_180_p2[1]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \x_1_reg_255[2]_i_1 
       (.I0(x_reg_105[0]),
        .I1(x_reg_105[1]),
        .I2(x_reg_105[2]),
        .O(x_1_fu_180_p2[2]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \x_1_reg_255[3]_i_1 
       (.I0(x_reg_105[1]),
        .I1(x_reg_105[0]),
        .I2(x_reg_105[2]),
        .I3(x_reg_105[3]),
        .O(x_1_fu_180_p2[3]));
  FDRE \x_1_reg_255_reg[0] 
       (.C(ap_clk),
        .CE(bias_EN_A),
        .D(x_1_fu_180_p2[0]),
        .Q(x_1_reg_255[0]),
        .R(1'b0));
  FDRE \x_1_reg_255_reg[1] 
       (.C(ap_clk),
        .CE(bias_EN_A),
        .D(x_1_fu_180_p2[1]),
        .Q(x_1_reg_255[1]),
        .R(1'b0));
  FDRE \x_1_reg_255_reg[2] 
       (.C(ap_clk),
        .CE(bias_EN_A),
        .D(x_1_fu_180_p2[2]),
        .Q(x_1_reg_255[2]),
        .R(1'b0));
  FDRE \x_1_reg_255_reg[3] 
       (.C(ap_clk),
        .CE(bias_EN_A),
        .D(x_1_fu_180_p2[3]),
        .Q(x_1_reg_255[3]),
        .R(1'b0));
  LUT5 #(
    .INIT(32'hAAAAAA8A)) 
    \x_reg_105[3]_i_1 
       (.I0(ap_CS_fsm_state3),
        .I1(\y_reg_94_reg_n_0_[1] ),
        .I2(\y_reg_94_reg_n_0_[3] ),
        .I3(\y_reg_94_reg_n_0_[2] ),
        .I4(\y_reg_94_reg_n_0_[0] ),
        .O(x_reg_1050));
  FDRE \x_reg_105_reg[0] 
       (.C(ap_clk),
        .CE(\^output_r_WEN_A ),
        .D(x_1_reg_255[0]),
        .Q(x_reg_105[0]),
        .R(x_reg_1050));
  FDRE \x_reg_105_reg[1] 
       (.C(ap_clk),
        .CE(\^output_r_WEN_A ),
        .D(x_1_reg_255[1]),
        .Q(x_reg_105[1]),
        .R(x_reg_1050));
  FDRE \x_reg_105_reg[2] 
       (.C(ap_clk),
        .CE(\^output_r_WEN_A ),
        .D(x_1_reg_255[2]),
        .Q(x_reg_105[2]),
        .R(x_reg_1050));
  FDRE \x_reg_105_reg[3] 
       (.C(ap_clk),
        .CE(\^output_r_WEN_A ),
        .D(x_1_reg_255[3]),
        .Q(x_reg_105[3]),
        .R(x_reg_1050));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \y_1_reg_242[0]_i_1 
       (.I0(\y_reg_94_reg_n_0_[0] ),
        .O(y_1_fu_151_p2[0]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \y_1_reg_242[1]_i_1 
       (.I0(\y_reg_94_reg_n_0_[0] ),
        .I1(\y_reg_94_reg_n_0_[1] ),
        .O(y_1_fu_151_p2[1]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \y_1_reg_242[2]_i_1 
       (.I0(\y_reg_94_reg_n_0_[0] ),
        .I1(\y_reg_94_reg_n_0_[1] ),
        .I2(\y_reg_94_reg_n_0_[2] ),
        .O(y_1_fu_151_p2[2]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \y_1_reg_242[3]_i_1 
       (.I0(\y_reg_94_reg_n_0_[1] ),
        .I1(\y_reg_94_reg_n_0_[0] ),
        .I2(\y_reg_94_reg_n_0_[2] ),
        .I3(\y_reg_94_reg_n_0_[3] ),
        .O(y_1_fu_151_p2[3]));
  FDRE \y_1_reg_242_reg[0] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(y_1_fu_151_p2[0]),
        .Q(y_1_reg_242[0]),
        .R(1'b0));
  FDRE \y_1_reg_242_reg[1] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(y_1_fu_151_p2[1]),
        .Q(y_1_reg_242[1]),
        .R(1'b0));
  FDRE \y_1_reg_242_reg[2] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(y_1_fu_151_p2[2]),
        .Q(y_1_reg_242[2]),
        .R(1'b0));
  FDRE \y_1_reg_242_reg[3] 
       (.C(ap_clk),
        .CE(ap_CS_fsm_state3),
        .D(y_1_fu_151_p2[3]),
        .Q(y_1_reg_242[3]),
        .R(1'b0));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAA2AAAA)) 
    \y_reg_94[3]_i_1 
       (.I0(y_reg_940),
        .I1(bias_EN_A),
        .I2(x_reg_105[0]),
        .I3(x_reg_105[2]),
        .I4(x_reg_105[3]),
        .I5(x_reg_105[1]),
        .O(y_reg_94));
  LUT5 #(
    .INIT(32'h00040000)) 
    \y_reg_94[3]_i_2 
       (.I0(x_reg_105[1]),
        .I1(x_reg_105[3]),
        .I2(x_reg_105[2]),
        .I3(x_reg_105[0]),
        .I4(bias_EN_A),
        .O(ap_NS_fsm1));
  FDRE \y_reg_94_reg[0] 
       (.C(ap_clk),
        .CE(ap_NS_fsm1),
        .D(y_1_reg_242[0]),
        .Q(\y_reg_94_reg_n_0_[0] ),
        .R(y_reg_94));
  FDRE \y_reg_94_reg[1] 
       (.C(ap_clk),
        .CE(ap_NS_fsm1),
        .D(y_1_reg_242[1]),
        .Q(\y_reg_94_reg_n_0_[1] ),
        .R(y_reg_94));
  FDRE \y_reg_94_reg[2] 
       (.C(ap_clk),
        .CE(ap_NS_fsm1),
        .D(y_1_reg_242[2]),
        .Q(\y_reg_94_reg_n_0_[2] ),
        .R(y_reg_94));
  FDRE \y_reg_94_reg[3] 
       (.C(ap_clk),
        .CE(ap_NS_fsm1),
        .D(y_1_reg_242[3]),
        .Q(\y_reg_94_reg_n_0_[3] ),
        .R(y_reg_94));
endmodule

(* CHECK_LICENSE_TYPE = "zed_Conv2_12x12x20_5x5x40_1_0_1_0,a0_Conv2_12x12x20_5x5x40_1_0,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "HLS" *) 
(* X_CORE_INFO = "a0_Conv2_12x12x20_5x5x40_1_0,Vivado 2018.2" *) (* hls_module = "yes" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (ap_clk,
    ap_rst_n,
    ap_start,
    ap_done,
    ap_idle,
    ap_ready,
    input_r_Clk_A,
    input_r_Rst_A,
    input_r_EN_A,
    input_r_WEN_A,
    input_r_Addr_A,
    input_r_Din_A,
    input_r_Dout_A,
    bias_Clk_A,
    bias_Rst_A,
    bias_EN_A,
    bias_WEN_A,
    bias_Addr_A,
    bias_Din_A,
    bias_Dout_A,
    output_r_Clk_A,
    output_r_Rst_A,
    output_r_EN_A,
    output_r_WEN_A,
    output_r_Addr_A,
    output_r_Din_A,
    output_r_Dout_A);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 ap_clk CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME ap_clk, ASSOCIATED_RESET ap_rst_n, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}}}, FREQ_HZ 100000000, PHASE 0.000, CLK_DOMAIN /clk_wiz_0_clk_out1" *) input ap_clk;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 ap_rst_n RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME ap_rst_n, POLARITY ACTIVE_LOW, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}}}" *) input ap_rst_n;
  (* X_INTERFACE_INFO = "xilinx.com:interface:acc_handshake:1.0 ap_ctrl start" *) input ap_start;
  (* X_INTERFACE_INFO = "xilinx.com:interface:acc_handshake:1.0 ap_ctrl done" *) output ap_done;
  (* X_INTERFACE_INFO = "xilinx.com:interface:acc_handshake:1.0 ap_ctrl idle" *) output ap_idle;
  (* X_INTERFACE_INFO = "xilinx.com:interface:acc_handshake:1.0 ap_ctrl ready" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME ap_ctrl, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {start {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} done {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} idle {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ready {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}}}" *) output ap_ready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 input_r_PORTA CLK" *) output input_r_Clk_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 input_r_PORTA RST" *) output input_r_Rst_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 input_r_PORTA EN" *) output input_r_EN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 input_r_PORTA WE" *) output [3:0]input_r_WEN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 input_r_PORTA ADDR" *) output [31:0]input_r_Addr_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 input_r_PORTA DIN" *) output [31:0]input_r_Din_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 input_r_PORTA DOUT" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME input_r_PORTA, MEM_WIDTH 32, MEM_SIZE 11520, MASTER_TYPE BRAM_CTRL, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {EN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ADDR {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} WE {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 4} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} DIN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}} DOUT {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}}, MEM_ECC NONE" *) input [31:0]input_r_Dout_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 bias_PORTA CLK" *) output bias_Clk_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 bias_PORTA RST" *) output bias_Rst_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 bias_PORTA EN" *) output bias_EN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 bias_PORTA WE" *) output [3:0]bias_WEN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 bias_PORTA ADDR" *) output [31:0]bias_Addr_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 bias_PORTA DIN" *) output [31:0]bias_Din_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 bias_PORTA DOUT" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME bias_PORTA, MEM_WIDTH 32, MEM_SIZE 160, MASTER_TYPE BRAM_CTRL, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {EN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ADDR {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} WE {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 4} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} DIN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}} DOUT {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}}, MEM_ECC NONE" *) input [31:0]bias_Dout_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 output_r_PORTA CLK" *) output output_r_Clk_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 output_r_PORTA RST" *) output output_r_Rst_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 output_r_PORTA EN" *) output output_r_EN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 output_r_PORTA WE" *) output [3:0]output_r_WEN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 output_r_PORTA ADDR" *) output [31:0]output_r_Addr_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 output_r_PORTA DIN" *) output [31:0]output_r_Din_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 output_r_PORTA DOUT" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME output_r_PORTA, MEM_WIDTH 32, MEM_SIZE 10240, MASTER_TYPE BRAM_CTRL, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {EN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ADDR {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} WE {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 4} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} DIN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}} DOUT {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}}, MEM_ECC NONE" *) input [31:0]output_r_Dout_A;

  wire ap_clk;
  wire ap_done;
  wire ap_idle;
  wire ap_ready;
  wire ap_rst_n;
  wire ap_start;
  wire [31:0]bias_Addr_A;
  wire bias_Clk_A;
  wire [31:0]bias_Din_A;
  wire [31:0]bias_Dout_A;
  wire bias_EN_A;
  wire bias_Rst_A;
  wire [3:0]bias_WEN_A;
  wire [31:0]input_r_Addr_A;
  wire input_r_Clk_A;
  wire [31:0]input_r_Din_A;
  wire [31:0]input_r_Dout_A;
  wire input_r_EN_A;
  wire input_r_Rst_A;
  wire [3:0]input_r_WEN_A;
  wire [31:0]output_r_Addr_A;
  wire output_r_Clk_A;
  wire [31:0]output_r_Din_A;
  wire [31:0]output_r_Dout_A;
  wire output_r_EN_A;
  wire output_r_Rst_A;
  wire [3:0]output_r_WEN_A;

  (* SDX_KERNEL = "true" *) 
  (* SDX_KERNEL_SYNTH_INST = "inst" *) 
  (* SDX_KERNEL_TYPE = "hls" *) 
  (* ap_ST_fsm_state1 = "6'b000001" *) 
  (* ap_ST_fsm_state2 = "6'b000010" *) 
  (* ap_ST_fsm_state3 = "6'b000100" *) 
  (* ap_ST_fsm_state4 = "6'b001000" *) 
  (* ap_ST_fsm_state5 = "6'b010000" *) 
  (* ap_ST_fsm_state6 = "6'b100000" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0 inst
       (.ap_clk(ap_clk),
        .ap_done(ap_done),
        .ap_idle(ap_idle),
        .ap_ready(ap_ready),
        .ap_rst_n(ap_rst_n),
        .ap_start(ap_start),
        .bias_Addr_A(bias_Addr_A),
        .bias_Clk_A(bias_Clk_A),
        .bias_Din_A(bias_Din_A),
        .bias_Dout_A(bias_Dout_A),
        .bias_EN_A(bias_EN_A),
        .bias_Rst_A(bias_Rst_A),
        .bias_WEN_A(bias_WEN_A),
        .input_r_Addr_A(input_r_Addr_A),
        .input_r_Clk_A(input_r_Clk_A),
        .input_r_Din_A(input_r_Din_A),
        .input_r_Dout_A(input_r_Dout_A),
        .input_r_EN_A(input_r_EN_A),
        .input_r_Rst_A(input_r_Rst_A),
        .input_r_WEN_A(input_r_WEN_A),
        .output_r_Addr_A(output_r_Addr_A),
        .output_r_Clk_A(output_r_Clk_A),
        .output_r_Din_A(output_r_Din_A),
        .output_r_Dout_A(output_r_Dout_A),
        .output_r_EN_A(output_r_EN_A),
        .output_r_Rst_A(output_r_Rst_A),
        .output_r_WEN_A(output_r_WEN_A));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

endmodule
`endif
