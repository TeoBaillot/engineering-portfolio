// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2018.2 (lin64) Build 2258646 Thu Jun 14 20:02:38 MDT 2018
// Date        : Wed Dec 17 17:18:45 2025
// Host        : PCII-REF running 64-bit Ubuntu 22.04.5 LTS
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ zed_Conv2_12x12x20_5x5x40_1_0_1_0_sim_netlist.v
// Design      : zed_Conv2_12x12x20_5x5x40_1_0_1_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg484-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* ap_ST_fsm_pp0_stage0 = "3'b010" *) (* ap_ST_fsm_state1 = "3'b001" *) (* ap_ST_fsm_state5 = "3'b100" *) 
(* hls_module = "yes" *) 
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0
   (ap_clk,
    ap_rst_n,
    ap_start,
    ap_done,
    ap_idle,
    ap_ready,
    input_r_Addr_A,
    input_r_EN_A,
    input_r_WEN_A,
    input_r_Din_A,
    input_r_Dout_A,
    input_r_Clk_A,
    input_r_Rst_A,
    bias_Addr_A,
    bias_EN_A,
    bias_WEN_A,
    bias_Din_A,
    bias_Dout_A,
    bias_Clk_A,
    bias_Rst_A,
    output_r_Addr_A,
    output_r_EN_A,
    output_r_WEN_A,
    output_r_Din_A,
    output_r_Dout_A,
    output_r_Clk_A,
    output_r_Rst_A);
  input ap_clk;
  input ap_rst_n;
  input ap_start;
  output ap_done;
  output ap_idle;
  output ap_ready;
  output [31:0]input_r_Addr_A;
  output input_r_EN_A;
  output [3:0]input_r_WEN_A;
  output [31:0]input_r_Din_A;
  input [31:0]input_r_Dout_A;
  output input_r_Clk_A;
  output input_r_Rst_A;
  output [31:0]bias_Addr_A;
  output bias_EN_A;
  output [3:0]bias_WEN_A;
  output [31:0]bias_Din_A;
  input [31:0]bias_Dout_A;
  output bias_Clk_A;
  output bias_Rst_A;
  output [31:0]output_r_Addr_A;
  output output_r_EN_A;
  output [3:0]output_r_WEN_A;
  output [31:0]output_r_Din_A;
  input [31:0]output_r_Dout_A;
  output output_r_Clk_A;
  output output_r_Rst_A;

  wire \<const0> ;
  wire \ap_CS_fsm[1]_i_2_n_0 ;
  wire \ap_CS_fsm[2]_i_3_n_0 ;
  wire \ap_CS_fsm[2]_i_4_n_0 ;
  wire ap_CS_fsm_pp0_stage0;
  wire \ap_CS_fsm_reg_n_0_[0] ;
  wire [2:0]ap_NS_fsm;
  wire ap_clk;
  wire ap_done;
  wire ap_enable_reg_pp0_iter0;
  wire ap_enable_reg_pp0_iter0_i_1_n_0;
  wire ap_enable_reg_pp0_iter1_i_1_n_0;
  wire ap_enable_reg_pp0_iter1_reg_n_0;
  wire ap_idle;
  wire [3:0]ap_phi_mux_filter_index_phi_fu_117_p4;
  wire ap_rst_n;
  wire ap_start;
  wire [7:2]\^bias_Addr_A ;
  wire \bias_Addr_A[5]_INST_0_i_1_n_0 ;
  wire \bias_Addr_A[6]_INST_0_i_1_n_0 ;
  wire \bias_Addr_A[7]_INST_0_i_1_n_0 ;
  wire \bias_Addr_A[7]_INST_0_i_4_n_0 ;
  wire \bias_Addr_A[7]_INST_0_i_5_n_0 ;
  wire [31:0]bias_Dout_A;
  wire bias_EN_A;
  wire exitcond_flatten1_fu_157_p2;
  wire exitcond_flatten1_reg_331;
  wire \exitcond_flatten1_reg_331[0]_i_1_n_0 ;
  wire exitcond_flatten1_reg_331_pp0_iter1_reg;
  wire \exitcond_flatten1_reg_331_pp0_iter1_reg[0]_i_1_n_0 ;
  wire \exitcond_flatten1_reg_331_reg_n_0_[0] ;
  wire exitcond_flatten7_fu_175_p2;
  wire filter_index_reg_113;
  wire filter_index_reg_1130;
  wire \filter_index_reg_113_reg_n_0_[0] ;
  wire \filter_index_reg_113_reg_n_0_[1] ;
  wire \filter_index_reg_113_reg_n_0_[2] ;
  wire \filter_index_reg_113_reg_n_0_[3] ;
  wire \filter_index_reg_113_reg_n_0_[4] ;
  wire \filter_index_reg_113_reg_n_0_[5] ;
  wire indvar_flatten1_reg_102;
  wire indvar_flatten1_reg_1020;
  wire \indvar_flatten1_reg_102[0]_i_2_n_0 ;
  wire [11:0]indvar_flatten1_reg_102_reg;
  wire \indvar_flatten1_reg_102_reg[0]_i_1_n_0 ;
  wire \indvar_flatten1_reg_102_reg[0]_i_1_n_1 ;
  wire \indvar_flatten1_reg_102_reg[0]_i_1_n_2 ;
  wire \indvar_flatten1_reg_102_reg[0]_i_1_n_3 ;
  wire \indvar_flatten1_reg_102_reg[0]_i_1_n_4 ;
  wire \indvar_flatten1_reg_102_reg[0]_i_1_n_5 ;
  wire \indvar_flatten1_reg_102_reg[0]_i_1_n_6 ;
  wire \indvar_flatten1_reg_102_reg[0]_i_1_n_7 ;
  wire \indvar_flatten1_reg_102_reg[4]_i_1_n_0 ;
  wire \indvar_flatten1_reg_102_reg[4]_i_1_n_1 ;
  wire \indvar_flatten1_reg_102_reg[4]_i_1_n_2 ;
  wire \indvar_flatten1_reg_102_reg[4]_i_1_n_3 ;
  wire \indvar_flatten1_reg_102_reg[4]_i_1_n_4 ;
  wire \indvar_flatten1_reg_102_reg[4]_i_1_n_5 ;
  wire \indvar_flatten1_reg_102_reg[4]_i_1_n_6 ;
  wire \indvar_flatten1_reg_102_reg[4]_i_1_n_7 ;
  wire \indvar_flatten1_reg_102_reg[8]_i_1_n_1 ;
  wire \indvar_flatten1_reg_102_reg[8]_i_1_n_2 ;
  wire \indvar_flatten1_reg_102_reg[8]_i_1_n_3 ;
  wire \indvar_flatten1_reg_102_reg[8]_i_1_n_4 ;
  wire \indvar_flatten1_reg_102_reg[8]_i_1_n_5 ;
  wire \indvar_flatten1_reg_102_reg[8]_i_1_n_6 ;
  wire \indvar_flatten1_reg_102_reg[8]_i_1_n_7 ;
  wire [7:0]indvar_flatten_next_fu_260_p3;
  wire \indvar_flatten_reg_124[5]_i_2_n_0 ;
  wire \indvar_flatten_reg_124[7]_i_2_n_0 ;
  wire [7:0]indvar_flatten_reg_124_reg__0;
  wire [14:2]\^output_r_Addr_A ;
  wire [30:0]\^output_r_Din_A ;
  wire output_r_EN_A;
  wire output_r_Rst_A;
  wire [0:0]\^output_r_WEN_A ;
  wire p_0_in;
  wire \res_1_reg_377[30]_i_10_n_0 ;
  wire \res_1_reg_377[30]_i_11_n_0 ;
  wire \res_1_reg_377[30]_i_13_n_0 ;
  wire \res_1_reg_377[30]_i_14_n_0 ;
  wire \res_1_reg_377[30]_i_15_n_0 ;
  wire \res_1_reg_377[30]_i_16_n_0 ;
  wire \res_1_reg_377[30]_i_17_n_0 ;
  wire \res_1_reg_377[30]_i_18_n_0 ;
  wire \res_1_reg_377[30]_i_19_n_0 ;
  wire \res_1_reg_377[30]_i_1_n_0 ;
  wire \res_1_reg_377[30]_i_20_n_0 ;
  wire \res_1_reg_377[30]_i_22_n_0 ;
  wire \res_1_reg_377[30]_i_23_n_0 ;
  wire \res_1_reg_377[30]_i_24_n_0 ;
  wire \res_1_reg_377[30]_i_25_n_0 ;
  wire \res_1_reg_377[30]_i_26_n_0 ;
  wire \res_1_reg_377[30]_i_27_n_0 ;
  wire \res_1_reg_377[30]_i_28_n_0 ;
  wire \res_1_reg_377[30]_i_29_n_0 ;
  wire \res_1_reg_377[30]_i_30_n_0 ;
  wire \res_1_reg_377[30]_i_31_n_0 ;
  wire \res_1_reg_377[30]_i_32_n_0 ;
  wire \res_1_reg_377[30]_i_33_n_0 ;
  wire \res_1_reg_377[30]_i_34_n_0 ;
  wire \res_1_reg_377[30]_i_35_n_0 ;
  wire \res_1_reg_377[30]_i_36_n_0 ;
  wire \res_1_reg_377[30]_i_37_n_0 ;
  wire \res_1_reg_377[30]_i_4_n_0 ;
  wire \res_1_reg_377[30]_i_5_n_0 ;
  wire \res_1_reg_377[30]_i_6_n_0 ;
  wire \res_1_reg_377[30]_i_7_n_0 ;
  wire \res_1_reg_377[30]_i_8_n_0 ;
  wire \res_1_reg_377[30]_i_9_n_0 ;
  wire \res_1_reg_377_reg[30]_i_12_n_0 ;
  wire \res_1_reg_377_reg[30]_i_12_n_1 ;
  wire \res_1_reg_377_reg[30]_i_12_n_2 ;
  wire \res_1_reg_377_reg[30]_i_12_n_3 ;
  wire \res_1_reg_377_reg[30]_i_21_n_0 ;
  wire \res_1_reg_377_reg[30]_i_21_n_1 ;
  wire \res_1_reg_377_reg[30]_i_21_n_2 ;
  wire \res_1_reg_377_reg[30]_i_21_n_3 ;
  wire \res_1_reg_377_reg[30]_i_2_n_0 ;
  wire \res_1_reg_377_reg[30]_i_2_n_1 ;
  wire \res_1_reg_377_reg[30]_i_2_n_2 ;
  wire \res_1_reg_377_reg[30]_i_2_n_3 ;
  wire \res_1_reg_377_reg[30]_i_3_n_0 ;
  wire \res_1_reg_377_reg[30]_i_3_n_1 ;
  wire \res_1_reg_377_reg[30]_i_3_n_2 ;
  wire \res_1_reg_377_reg[30]_i_3_n_3 ;
  wire [9:3]tmp_4_fu_282_p2;
  wire [3:0]tmp_5_mid2_fu_240_p3;
  wire [3:0]tmp_5_mid2_reg_351;
  wire \tmp_5_mid2_reg_351[3]_i_3_n_0 ;
  wire \tmp_5_mid2_reg_351[3]_i_6_n_0 ;
  wire [5:0]tmp_mid2_v_reg_340_reg__0;
  wire [12:2]tmp_s_fu_299_p2;
  wire \tmp_s_reg_372[12]_i_6_n_0 ;
  wire \tmp_s_reg_372[5]_i_2_n_0 ;
  wire \tmp_s_reg_372_reg[12]_i_2_n_2 ;
  wire \tmp_s_reg_372_reg[12]_i_2_n_3 ;
  wire \tmp_s_reg_372_reg[5]_i_1_n_0 ;
  wire \tmp_s_reg_372_reg[5]_i_1_n_1 ;
  wire \tmp_s_reg_372_reg[5]_i_1_n_2 ;
  wire \tmp_s_reg_372_reg[5]_i_1_n_3 ;
  wire \tmp_s_reg_372_reg[9]_i_1_n_0 ;
  wire \tmp_s_reg_372_reg[9]_i_1_n_1 ;
  wire \tmp_s_reg_372_reg[9]_i_1_n_2 ;
  wire \tmp_s_reg_372_reg[9]_i_1_n_3 ;
  wire [3:0]x_1_fu_248_p2;
  wire [3:0]x_mid2_fu_232_p3;
  wire [3:0]x_mid2_reg_346;
  wire x_mid2_reg_3460;
  wire [3:0]x_reg_146;
  wire [3:1]y_mid_fu_181_p3;
  wire [3:0]y_reg_135;
  wire [3:3]\NLW_indvar_flatten1_reg_102_reg[8]_i_1_CO_UNCONNECTED ;
  wire [3:0]\NLW_res_1_reg_377_reg[30]_i_12_O_UNCONNECTED ;
  wire [3:0]\NLW_res_1_reg_377_reg[30]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_res_1_reg_377_reg[30]_i_21_O_UNCONNECTED ;
  wire [3:0]\NLW_res_1_reg_377_reg[30]_i_3_O_UNCONNECTED ;
  wire [3:2]\NLW_tmp_s_reg_372_reg[12]_i_2_CO_UNCONNECTED ;
  wire [3:3]\NLW_tmp_s_reg_372_reg[12]_i_2_O_UNCONNECTED ;

  assign ap_ready = ap_done;
  assign bias_Addr_A[31] = \<const0> ;
  assign bias_Addr_A[30] = \<const0> ;
  assign bias_Addr_A[29] = \<const0> ;
  assign bias_Addr_A[28] = \<const0> ;
  assign bias_Addr_A[27] = \<const0> ;
  assign bias_Addr_A[26] = \<const0> ;
  assign bias_Addr_A[25] = \<const0> ;
  assign bias_Addr_A[24] = \<const0> ;
  assign bias_Addr_A[23] = \<const0> ;
  assign bias_Addr_A[22] = \<const0> ;
  assign bias_Addr_A[21] = \<const0> ;
  assign bias_Addr_A[20] = \<const0> ;
  assign bias_Addr_A[19] = \<const0> ;
  assign bias_Addr_A[18] = \<const0> ;
  assign bias_Addr_A[17] = \<const0> ;
  assign bias_Addr_A[16] = \<const0> ;
  assign bias_Addr_A[15] = \<const0> ;
  assign bias_Addr_A[14] = \<const0> ;
  assign bias_Addr_A[13] = \<const0> ;
  assign bias_Addr_A[12] = \<const0> ;
  assign bias_Addr_A[11] = \<const0> ;
  assign bias_Addr_A[10] = \<const0> ;
  assign bias_Addr_A[9] = \<const0> ;
  assign bias_Addr_A[8] = \<const0> ;
  assign bias_Addr_A[7:2] = \^bias_Addr_A [7:2];
  assign bias_Addr_A[1] = \<const0> ;
  assign bias_Addr_A[0] = \<const0> ;
  assign bias_Clk_A = ap_clk;
  assign bias_Din_A[31] = \<const0> ;
  assign bias_Din_A[30] = \<const0> ;
  assign bias_Din_A[29] = \<const0> ;
  assign bias_Din_A[28] = \<const0> ;
  assign bias_Din_A[27] = \<const0> ;
  assign bias_Din_A[26] = \<const0> ;
  assign bias_Din_A[25] = \<const0> ;
  assign bias_Din_A[24] = \<const0> ;
  assign bias_Din_A[23] = \<const0> ;
  assign bias_Din_A[22] = \<const0> ;
  assign bias_Din_A[21] = \<const0> ;
  assign bias_Din_A[20] = \<const0> ;
  assign bias_Din_A[19] = \<const0> ;
  assign bias_Din_A[18] = \<const0> ;
  assign bias_Din_A[17] = \<const0> ;
  assign bias_Din_A[16] = \<const0> ;
  assign bias_Din_A[15] = \<const0> ;
  assign bias_Din_A[14] = \<const0> ;
  assign bias_Din_A[13] = \<const0> ;
  assign bias_Din_A[12] = \<const0> ;
  assign bias_Din_A[11] = \<const0> ;
  assign bias_Din_A[10] = \<const0> ;
  assign bias_Din_A[9] = \<const0> ;
  assign bias_Din_A[8] = \<const0> ;
  assign bias_Din_A[7] = \<const0> ;
  assign bias_Din_A[6] = \<const0> ;
  assign bias_Din_A[5] = \<const0> ;
  assign bias_Din_A[4] = \<const0> ;
  assign bias_Din_A[3] = \<const0> ;
  assign bias_Din_A[2] = \<const0> ;
  assign bias_Din_A[1] = \<const0> ;
  assign bias_Din_A[0] = \<const0> ;
  assign bias_Rst_A = output_r_Rst_A;
  assign bias_WEN_A[3] = \<const0> ;
  assign bias_WEN_A[2] = \<const0> ;
  assign bias_WEN_A[1] = \<const0> ;
  assign bias_WEN_A[0] = \<const0> ;
  assign input_r_Addr_A[31] = \<const0> ;
  assign input_r_Addr_A[30] = \<const0> ;
  assign input_r_Addr_A[29] = \<const0> ;
  assign input_r_Addr_A[28] = \<const0> ;
  assign input_r_Addr_A[27] = \<const0> ;
  assign input_r_Addr_A[26] = \<const0> ;
  assign input_r_Addr_A[25] = \<const0> ;
  assign input_r_Addr_A[24] = \<const0> ;
  assign input_r_Addr_A[23] = \<const0> ;
  assign input_r_Addr_A[22] = \<const0> ;
  assign input_r_Addr_A[21] = \<const0> ;
  assign input_r_Addr_A[20] = \<const0> ;
  assign input_r_Addr_A[19] = \<const0> ;
  assign input_r_Addr_A[18] = \<const0> ;
  assign input_r_Addr_A[17] = \<const0> ;
  assign input_r_Addr_A[16] = \<const0> ;
  assign input_r_Addr_A[15] = \<const0> ;
  assign input_r_Addr_A[14] = \<const0> ;
  assign input_r_Addr_A[13] = \<const0> ;
  assign input_r_Addr_A[12] = \<const0> ;
  assign input_r_Addr_A[11] = \<const0> ;
  assign input_r_Addr_A[10] = \<const0> ;
  assign input_r_Addr_A[9] = \<const0> ;
  assign input_r_Addr_A[8] = \<const0> ;
  assign input_r_Addr_A[7] = \<const0> ;
  assign input_r_Addr_A[6] = \<const0> ;
  assign input_r_Addr_A[5] = \<const0> ;
  assign input_r_Addr_A[4] = \<const0> ;
  assign input_r_Addr_A[3] = \<const0> ;
  assign input_r_Addr_A[2] = \<const0> ;
  assign input_r_Addr_A[1] = \<const0> ;
  assign input_r_Addr_A[0] = \<const0> ;
  assign input_r_Clk_A = ap_clk;
  assign input_r_Din_A[31] = \<const0> ;
  assign input_r_Din_A[30] = \<const0> ;
  assign input_r_Din_A[29] = \<const0> ;
  assign input_r_Din_A[28] = \<const0> ;
  assign input_r_Din_A[27] = \<const0> ;
  assign input_r_Din_A[26] = \<const0> ;
  assign input_r_Din_A[25] = \<const0> ;
  assign input_r_Din_A[24] = \<const0> ;
  assign input_r_Din_A[23] = \<const0> ;
  assign input_r_Din_A[22] = \<const0> ;
  assign input_r_Din_A[21] = \<const0> ;
  assign input_r_Din_A[20] = \<const0> ;
  assign input_r_Din_A[19] = \<const0> ;
  assign input_r_Din_A[18] = \<const0> ;
  assign input_r_Din_A[17] = \<const0> ;
  assign input_r_Din_A[16] = \<const0> ;
  assign input_r_Din_A[15] = \<const0> ;
  assign input_r_Din_A[14] = \<const0> ;
  assign input_r_Din_A[13] = \<const0> ;
  assign input_r_Din_A[12] = \<const0> ;
  assign input_r_Din_A[11] = \<const0> ;
  assign input_r_Din_A[10] = \<const0> ;
  assign input_r_Din_A[9] = \<const0> ;
  assign input_r_Din_A[8] = \<const0> ;
  assign input_r_Din_A[7] = \<const0> ;
  assign input_r_Din_A[6] = \<const0> ;
  assign input_r_Din_A[5] = \<const0> ;
  assign input_r_Din_A[4] = \<const0> ;
  assign input_r_Din_A[3] = \<const0> ;
  assign input_r_Din_A[2] = \<const0> ;
  assign input_r_Din_A[1] = \<const0> ;
  assign input_r_Din_A[0] = \<const0> ;
  assign input_r_EN_A = \<const0> ;
  assign input_r_Rst_A = output_r_Rst_A;
  assign input_r_WEN_A[3] = \<const0> ;
  assign input_r_WEN_A[2] = \<const0> ;
  assign input_r_WEN_A[1] = \<const0> ;
  assign input_r_WEN_A[0] = \<const0> ;
  assign output_r_Addr_A[31] = \<const0> ;
  assign output_r_Addr_A[30] = \<const0> ;
  assign output_r_Addr_A[29] = \<const0> ;
  assign output_r_Addr_A[28] = \<const0> ;
  assign output_r_Addr_A[27] = \<const0> ;
  assign output_r_Addr_A[26] = \<const0> ;
  assign output_r_Addr_A[25] = \<const0> ;
  assign output_r_Addr_A[24] = \<const0> ;
  assign output_r_Addr_A[23] = \<const0> ;
  assign output_r_Addr_A[22] = \<const0> ;
  assign output_r_Addr_A[21] = \<const0> ;
  assign output_r_Addr_A[20] = \<const0> ;
  assign output_r_Addr_A[19] = \<const0> ;
  assign output_r_Addr_A[18] = \<const0> ;
  assign output_r_Addr_A[17] = \<const0> ;
  assign output_r_Addr_A[16] = \<const0> ;
  assign output_r_Addr_A[15] = \<const0> ;
  assign output_r_Addr_A[14:2] = \^output_r_Addr_A [14:2];
  assign output_r_Addr_A[1] = \<const0> ;
  assign output_r_Addr_A[0] = \<const0> ;
  assign output_r_Clk_A = ap_clk;
  assign output_r_Din_A[31] = \<const0> ;
  assign output_r_Din_A[30:0] = \^output_r_Din_A [30:0];
  assign output_r_WEN_A[3] = \^output_r_WEN_A [0];
  assign output_r_WEN_A[2] = \^output_r_WEN_A [0];
  assign output_r_WEN_A[1] = \^output_r_WEN_A [0];
  assign output_r_WEN_A[0] = \^output_r_WEN_A [0];
  GND GND
       (.G(\<const0> ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT4 #(
    .INIT(16'h2333)) 
    \ap_CS_fsm[0]_i_1 
       (.I0(ap_done),
        .I1(ap_CS_fsm_pp0_stage0),
        .I2(ap_start),
        .I3(\ap_CS_fsm_reg_n_0_[0] ),
        .O(ap_NS_fsm[0]));
  LUT6 #(
    .INIT(64'hFCCCFCCCFCDCFCFC)) 
    \ap_CS_fsm[1]_i_1 
       (.I0(exitcond_flatten1_fu_157_p2),
        .I1(\ap_CS_fsm[1]_i_2_n_0 ),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\ap_CS_fsm_reg_n_0_[0] ),
        .I4(ap_enable_reg_pp0_iter0),
        .I5(output_r_EN_A),
        .O(ap_NS_fsm[1]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT4 #(
    .INIT(16'hF888)) 
    \ap_CS_fsm[1]_i_2 
       (.I0(ap_CS_fsm_pp0_stage0),
        .I1(ap_enable_reg_pp0_iter1_reg_n_0),
        .I2(\ap_CS_fsm_reg_n_0_[0] ),
        .I3(ap_start),
        .O(\ap_CS_fsm[1]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'h0F080000)) 
    \ap_CS_fsm[2]_i_1 
       (.I0(exitcond_flatten1_fu_157_p2),
        .I1(ap_enable_reg_pp0_iter0),
        .I2(ap_enable_reg_pp0_iter1_reg_n_0),
        .I3(output_r_EN_A),
        .I4(ap_CS_fsm_pp0_stage0),
        .O(ap_NS_fsm[2]));
  LUT6 #(
    .INIT(64'h0020000000000000)) 
    \ap_CS_fsm[2]_i_2 
       (.I0(\ap_CS_fsm[2]_i_3_n_0 ),
        .I1(indvar_flatten1_reg_102_reg[10]),
        .I2(indvar_flatten1_reg_102_reg[11]),
        .I3(indvar_flatten1_reg_102_reg[8]),
        .I4(indvar_flatten1_reg_102_reg[9]),
        .I5(\ap_CS_fsm[2]_i_4_n_0 ),
        .O(exitcond_flatten1_fu_157_p2));
  LUT4 #(
    .INIT(16'h0001)) 
    \ap_CS_fsm[2]_i_3 
       (.I0(indvar_flatten1_reg_102_reg[7]),
        .I1(indvar_flatten1_reg_102_reg[6]),
        .I2(indvar_flatten1_reg_102_reg[5]),
        .I3(indvar_flatten1_reg_102_reg[4]),
        .O(\ap_CS_fsm[2]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h0001)) 
    \ap_CS_fsm[2]_i_4 
       (.I0(indvar_flatten1_reg_102_reg[1]),
        .I1(indvar_flatten1_reg_102_reg[0]),
        .I2(indvar_flatten1_reg_102_reg[3]),
        .I3(indvar_flatten1_reg_102_reg[2]),
        .O(\ap_CS_fsm[2]_i_4_n_0 ));
  (* FSM_ENCODING = "none" *) 
  FDSE #(
    .INIT(1'b1)) 
    \ap_CS_fsm_reg[0] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[0]),
        .Q(\ap_CS_fsm_reg_n_0_[0] ),
        .S(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[1] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[1]),
        .Q(ap_CS_fsm_pp0_stage0),
        .R(output_r_Rst_A));
  (* FSM_ENCODING = "none" *) 
  FDRE #(
    .INIT(1'b0)) 
    \ap_CS_fsm_reg[2] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_NS_fsm[2]),
        .Q(ap_done),
        .R(output_r_Rst_A));
  LUT6 #(
    .INIT(64'h0000A888A888A888)) 
    ap_enable_reg_pp0_iter0_i_1
       (.I0(ap_rst_n),
        .I1(ap_enable_reg_pp0_iter0),
        .I2(\ap_CS_fsm_reg_n_0_[0] ),
        .I3(ap_start),
        .I4(exitcond_flatten1_fu_157_p2),
        .I5(ap_CS_fsm_pp0_stage0),
        .O(ap_enable_reg_pp0_iter0_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    ap_enable_reg_pp0_iter0_reg
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_enable_reg_pp0_iter0_i_1_n_0),
        .Q(ap_enable_reg_pp0_iter0),
        .R(1'b0));
  LUT3 #(
    .INIT(8'h08)) 
    ap_enable_reg_pp0_iter1_i_1
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_rst_n),
        .I2(exitcond_flatten1_fu_157_p2),
        .O(ap_enable_reg_pp0_iter1_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    ap_enable_reg_pp0_iter1_reg
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_enable_reg_pp0_iter1_i_1_n_0),
        .Q(ap_enable_reg_pp0_iter1_reg_n_0),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    ap_enable_reg_pp0_iter2_reg
       (.C(ap_clk),
        .CE(1'b1),
        .D(ap_enable_reg_pp0_iter1_reg_n_0),
        .Q(output_r_EN_A),
        .R(output_r_Rst_A));
  LUT2 #(
    .INIT(4'h2)) 
    ap_idle_INST_0
       (.I0(\ap_CS_fsm_reg_n_0_[0] ),
        .I1(ap_start),
        .O(ap_idle));
  LUT6 #(
    .INIT(64'h656666666A666666)) 
    \bias_Addr_A[2]_INST_0 
       (.I0(exitcond_flatten7_fu_175_p2),
        .I1(\filter_index_reg_113_reg_n_0_[0] ),
        .I2(\exitcond_flatten1_reg_331_reg_n_0_[0] ),
        .I3(ap_enable_reg_pp0_iter1_reg_n_0),
        .I4(ap_CS_fsm_pp0_stage0),
        .I5(tmp_mid2_v_reg_340_reg__0[0]),
        .O(\^bias_Addr_A [2]));
  LUT6 #(
    .INIT(64'h77775FA088885FA0)) 
    \bias_Addr_A[3]_INST_0 
       (.I0(exitcond_flatten7_fu_175_p2),
        .I1(tmp_mid2_v_reg_340_reg__0[0]),
        .I2(\filter_index_reg_113_reg_n_0_[0] ),
        .I3(\filter_index_reg_113_reg_n_0_[1] ),
        .I4(filter_index_reg_1130),
        .I5(tmp_mid2_v_reg_340_reg__0[1]),
        .O(\^bias_Addr_A [3]));
  LUT6 #(
    .INIT(64'h7F777FFF80888000)) 
    \bias_Addr_A[4]_INST_0 
       (.I0(ap_phi_mux_filter_index_phi_fu_117_p4[0]),
        .I1(exitcond_flatten7_fu_175_p2),
        .I2(tmp_mid2_v_reg_340_reg__0[1]),
        .I3(filter_index_reg_1130),
        .I4(\filter_index_reg_113_reg_n_0_[1] ),
        .I5(ap_phi_mux_filter_index_phi_fu_117_p4[2]),
        .O(\^bias_Addr_A [4]));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \bias_Addr_A[4]_INST_0_i_1 
       (.I0(tmp_mid2_v_reg_340_reg__0[0]),
        .I1(ap_CS_fsm_pp0_stage0),
        .I2(ap_enable_reg_pp0_iter1_reg_n_0),
        .I3(\exitcond_flatten1_reg_331_reg_n_0_[0] ),
        .I4(\filter_index_reg_113_reg_n_0_[0] ),
        .O(ap_phi_mux_filter_index_phi_fu_117_p4[0]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h00100000)) 
    \bias_Addr_A[4]_INST_0_i_2 
       (.I0(indvar_flatten_reg_124_reg__0[4]),
        .I1(indvar_flatten_reg_124_reg__0[5]),
        .I2(indvar_flatten_reg_124_reg__0[6]),
        .I3(indvar_flatten_reg_124_reg__0[7]),
        .I4(\bias_Addr_A[7]_INST_0_i_5_n_0 ),
        .O(exitcond_flatten7_fu_175_p2));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \bias_Addr_A[4]_INST_0_i_3 
       (.I0(tmp_mid2_v_reg_340_reg__0[2]),
        .I1(ap_CS_fsm_pp0_stage0),
        .I2(ap_enable_reg_pp0_iter1_reg_n_0),
        .I3(\exitcond_flatten1_reg_331_reg_n_0_[0] ),
        .I4(\filter_index_reg_113_reg_n_0_[2] ),
        .O(ap_phi_mux_filter_index_phi_fu_117_p4[2]));
  LUT6 #(
    .INIT(64'h77775FA088885FA0)) 
    \bias_Addr_A[5]_INST_0 
       (.I0(\bias_Addr_A[5]_INST_0_i_1_n_0 ),
        .I1(tmp_mid2_v_reg_340_reg__0[2]),
        .I2(\filter_index_reg_113_reg_n_0_[2] ),
        .I3(\filter_index_reg_113_reg_n_0_[3] ),
        .I4(filter_index_reg_1130),
        .I5(tmp_mid2_v_reg_340_reg__0[3]),
        .O(\^bias_Addr_A [5]));
  LUT6 #(
    .INIT(64'hE200000000000000)) 
    \bias_Addr_A[5]_INST_0_i_1 
       (.I0(\filter_index_reg_113_reg_n_0_[1] ),
        .I1(filter_index_reg_1130),
        .I2(tmp_mid2_v_reg_340_reg__0[1]),
        .I3(\bias_Addr_A[7]_INST_0_i_4_n_0 ),
        .I4(\bias_Addr_A[7]_INST_0_i_5_n_0 ),
        .I5(ap_phi_mux_filter_index_phi_fu_117_p4[0]),
        .O(\bias_Addr_A[5]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF5F5F30C0A0AF30C)) 
    \bias_Addr_A[6]_INST_0 
       (.I0(tmp_mid2_v_reg_340_reg__0[3]),
        .I1(\filter_index_reg_113_reg_n_0_[3] ),
        .I2(\bias_Addr_A[6]_INST_0_i_1_n_0 ),
        .I3(\filter_index_reg_113_reg_n_0_[4] ),
        .I4(filter_index_reg_1130),
        .I5(tmp_mid2_v_reg_340_reg__0[4]),
        .O(\^bias_Addr_A [6]));
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    \bias_Addr_A[6]_INST_0_i_1 
       (.I0(ap_phi_mux_filter_index_phi_fu_117_p4[2]),
        .I1(ap_phi_mux_filter_index_phi_fu_117_p4[0]),
        .I2(\bias_Addr_A[7]_INST_0_i_5_n_0 ),
        .I3(\bias_Addr_A[7]_INST_0_i_4_n_0 ),
        .I4(ap_phi_mux_filter_index_phi_fu_117_p4[1]),
        .O(\bias_Addr_A[6]_INST_0_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF5F5F30C0A0AF30C)) 
    \bias_Addr_A[7]_INST_0 
       (.I0(tmp_mid2_v_reg_340_reg__0[4]),
        .I1(\filter_index_reg_113_reg_n_0_[4] ),
        .I2(\bias_Addr_A[7]_INST_0_i_1_n_0 ),
        .I3(\filter_index_reg_113_reg_n_0_[5] ),
        .I4(filter_index_reg_1130),
        .I5(tmp_mid2_v_reg_340_reg__0[5]),
        .O(\^bias_Addr_A [7]));
  LUT6 #(
    .INIT(64'h7FFFFFFFFFFFFFFF)) 
    \bias_Addr_A[7]_INST_0_i_1 
       (.I0(ap_phi_mux_filter_index_phi_fu_117_p4[1]),
        .I1(\bias_Addr_A[7]_INST_0_i_4_n_0 ),
        .I2(\bias_Addr_A[7]_INST_0_i_5_n_0 ),
        .I3(ap_phi_mux_filter_index_phi_fu_117_p4[0]),
        .I4(ap_phi_mux_filter_index_phi_fu_117_p4[2]),
        .I5(ap_phi_mux_filter_index_phi_fu_117_p4[3]),
        .O(\bias_Addr_A[7]_INST_0_i_1_n_0 ));
  LUT3 #(
    .INIT(8'h08)) 
    \bias_Addr_A[7]_INST_0_i_2 
       (.I0(ap_CS_fsm_pp0_stage0),
        .I1(ap_enable_reg_pp0_iter1_reg_n_0),
        .I2(\exitcond_flatten1_reg_331_reg_n_0_[0] ),
        .O(filter_index_reg_1130));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \bias_Addr_A[7]_INST_0_i_3 
       (.I0(tmp_mid2_v_reg_340_reg__0[1]),
        .I1(ap_CS_fsm_pp0_stage0),
        .I2(ap_enable_reg_pp0_iter1_reg_n_0),
        .I3(\exitcond_flatten1_reg_331_reg_n_0_[0] ),
        .I4(\filter_index_reg_113_reg_n_0_[1] ),
        .O(ap_phi_mux_filter_index_phi_fu_117_p4[1]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h0004)) 
    \bias_Addr_A[7]_INST_0_i_4 
       (.I0(indvar_flatten_reg_124_reg__0[7]),
        .I1(indvar_flatten_reg_124_reg__0[6]),
        .I2(indvar_flatten_reg_124_reg__0[5]),
        .I3(indvar_flatten_reg_124_reg__0[4]),
        .O(\bias_Addr_A[7]_INST_0_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    \bias_Addr_A[7]_INST_0_i_5 
       (.I0(indvar_flatten_reg_124_reg__0[1]),
        .I1(indvar_flatten_reg_124_reg__0[0]),
        .I2(indvar_flatten_reg_124_reg__0[3]),
        .I3(indvar_flatten_reg_124_reg__0[2]),
        .O(\bias_Addr_A[7]_INST_0_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    \bias_Addr_A[7]_INST_0_i_6 
       (.I0(tmp_mid2_v_reg_340_reg__0[3]),
        .I1(ap_CS_fsm_pp0_stage0),
        .I2(ap_enable_reg_pp0_iter1_reg_n_0),
        .I3(\exitcond_flatten1_reg_331_reg_n_0_[0] ),
        .I4(\filter_index_reg_113_reg_n_0_[3] ),
        .O(ap_phi_mux_filter_index_phi_fu_117_p4[3]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'h8)) 
    bias_EN_A_INST_0
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(ap_CS_fsm_pp0_stage0),
        .O(bias_EN_A));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \exitcond_flatten1_reg_331[0]_i_1 
       (.I0(exitcond_flatten1_fu_157_p2),
        .I1(ap_CS_fsm_pp0_stage0),
        .I2(\exitcond_flatten1_reg_331_reg_n_0_[0] ),
        .O(\exitcond_flatten1_reg_331[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \exitcond_flatten1_reg_331_pp0_iter1_reg[0]_i_1 
       (.I0(\exitcond_flatten1_reg_331_reg_n_0_[0] ),
        .I1(ap_CS_fsm_pp0_stage0),
        .I2(exitcond_flatten1_reg_331_pp0_iter1_reg),
        .O(\exitcond_flatten1_reg_331_pp0_iter1_reg[0]_i_1_n_0 ));
  FDRE \exitcond_flatten1_reg_331_pp0_iter1_reg_reg[0] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\exitcond_flatten1_reg_331_pp0_iter1_reg[0]_i_1_n_0 ),
        .Q(exitcond_flatten1_reg_331_pp0_iter1_reg),
        .R(1'b0));
  FDRE \exitcond_flatten1_reg_331_reg[0] 
       (.C(ap_clk),
        .CE(1'b1),
        .D(\exitcond_flatten1_reg_331[0]_i_1_n_0 ),
        .Q(\exitcond_flatten1_reg_331_reg_n_0_[0] ),
        .R(1'b0));
  LUT5 #(
    .INIT(32'h80888888)) 
    \filter_index_reg_113[5]_i_1 
       (.I0(\ap_CS_fsm_reg_n_0_[0] ),
        .I1(ap_start),
        .I2(\exitcond_flatten1_reg_331_reg_n_0_[0] ),
        .I3(ap_enable_reg_pp0_iter1_reg_n_0),
        .I4(ap_CS_fsm_pp0_stage0),
        .O(filter_index_reg_113));
  FDRE \filter_index_reg_113_reg[0] 
       (.C(ap_clk),
        .CE(filter_index_reg_1130),
        .D(tmp_mid2_v_reg_340_reg__0[0]),
        .Q(\filter_index_reg_113_reg_n_0_[0] ),
        .R(filter_index_reg_113));
  FDRE \filter_index_reg_113_reg[1] 
       (.C(ap_clk),
        .CE(filter_index_reg_1130),
        .D(tmp_mid2_v_reg_340_reg__0[1]),
        .Q(\filter_index_reg_113_reg_n_0_[1] ),
        .R(filter_index_reg_113));
  FDRE \filter_index_reg_113_reg[2] 
       (.C(ap_clk),
        .CE(filter_index_reg_1130),
        .D(tmp_mid2_v_reg_340_reg__0[2]),
        .Q(\filter_index_reg_113_reg_n_0_[2] ),
        .R(filter_index_reg_113));
  FDRE \filter_index_reg_113_reg[3] 
       (.C(ap_clk),
        .CE(filter_index_reg_1130),
        .D(tmp_mid2_v_reg_340_reg__0[3]),
        .Q(\filter_index_reg_113_reg_n_0_[3] ),
        .R(filter_index_reg_113));
  FDRE \filter_index_reg_113_reg[4] 
       (.C(ap_clk),
        .CE(filter_index_reg_1130),
        .D(tmp_mid2_v_reg_340_reg__0[4]),
        .Q(\filter_index_reg_113_reg_n_0_[4] ),
        .R(filter_index_reg_113));
  FDRE \filter_index_reg_113_reg[5] 
       (.C(ap_clk),
        .CE(filter_index_reg_1130),
        .D(tmp_mid2_v_reg_340_reg__0[5]),
        .Q(\filter_index_reg_113_reg_n_0_[5] ),
        .R(filter_index_reg_113));
  LUT1 #(
    .INIT(2'h1)) 
    \indvar_flatten1_reg_102[0]_i_2 
       (.I0(indvar_flatten1_reg_102_reg[0]),
        .O(\indvar_flatten1_reg_102[0]_i_2_n_0 ));
  FDRE \indvar_flatten1_reg_102_reg[0] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(\indvar_flatten1_reg_102_reg[0]_i_1_n_7 ),
        .Q(indvar_flatten1_reg_102_reg[0]),
        .R(indvar_flatten1_reg_102));
  CARRY4 \indvar_flatten1_reg_102_reg[0]_i_1 
       (.CI(1'b0),
        .CO({\indvar_flatten1_reg_102_reg[0]_i_1_n_0 ,\indvar_flatten1_reg_102_reg[0]_i_1_n_1 ,\indvar_flatten1_reg_102_reg[0]_i_1_n_2 ,\indvar_flatten1_reg_102_reg[0]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\indvar_flatten1_reg_102_reg[0]_i_1_n_4 ,\indvar_flatten1_reg_102_reg[0]_i_1_n_5 ,\indvar_flatten1_reg_102_reg[0]_i_1_n_6 ,\indvar_flatten1_reg_102_reg[0]_i_1_n_7 }),
        .S({indvar_flatten1_reg_102_reg[3:1],\indvar_flatten1_reg_102[0]_i_2_n_0 }));
  FDRE \indvar_flatten1_reg_102_reg[10] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(\indvar_flatten1_reg_102_reg[8]_i_1_n_5 ),
        .Q(indvar_flatten1_reg_102_reg[10]),
        .R(indvar_flatten1_reg_102));
  FDRE \indvar_flatten1_reg_102_reg[11] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(\indvar_flatten1_reg_102_reg[8]_i_1_n_4 ),
        .Q(indvar_flatten1_reg_102_reg[11]),
        .R(indvar_flatten1_reg_102));
  FDRE \indvar_flatten1_reg_102_reg[1] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(\indvar_flatten1_reg_102_reg[0]_i_1_n_6 ),
        .Q(indvar_flatten1_reg_102_reg[1]),
        .R(indvar_flatten1_reg_102));
  FDRE \indvar_flatten1_reg_102_reg[2] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(\indvar_flatten1_reg_102_reg[0]_i_1_n_5 ),
        .Q(indvar_flatten1_reg_102_reg[2]),
        .R(indvar_flatten1_reg_102));
  FDRE \indvar_flatten1_reg_102_reg[3] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(\indvar_flatten1_reg_102_reg[0]_i_1_n_4 ),
        .Q(indvar_flatten1_reg_102_reg[3]),
        .R(indvar_flatten1_reg_102));
  FDRE \indvar_flatten1_reg_102_reg[4] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(\indvar_flatten1_reg_102_reg[4]_i_1_n_7 ),
        .Q(indvar_flatten1_reg_102_reg[4]),
        .R(indvar_flatten1_reg_102));
  CARRY4 \indvar_flatten1_reg_102_reg[4]_i_1 
       (.CI(\indvar_flatten1_reg_102_reg[0]_i_1_n_0 ),
        .CO({\indvar_flatten1_reg_102_reg[4]_i_1_n_0 ,\indvar_flatten1_reg_102_reg[4]_i_1_n_1 ,\indvar_flatten1_reg_102_reg[4]_i_1_n_2 ,\indvar_flatten1_reg_102_reg[4]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\indvar_flatten1_reg_102_reg[4]_i_1_n_4 ,\indvar_flatten1_reg_102_reg[4]_i_1_n_5 ,\indvar_flatten1_reg_102_reg[4]_i_1_n_6 ,\indvar_flatten1_reg_102_reg[4]_i_1_n_7 }),
        .S(indvar_flatten1_reg_102_reg[7:4]));
  FDRE \indvar_flatten1_reg_102_reg[5] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(\indvar_flatten1_reg_102_reg[4]_i_1_n_6 ),
        .Q(indvar_flatten1_reg_102_reg[5]),
        .R(indvar_flatten1_reg_102));
  FDRE \indvar_flatten1_reg_102_reg[6] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(\indvar_flatten1_reg_102_reg[4]_i_1_n_5 ),
        .Q(indvar_flatten1_reg_102_reg[6]),
        .R(indvar_flatten1_reg_102));
  FDRE \indvar_flatten1_reg_102_reg[7] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(\indvar_flatten1_reg_102_reg[4]_i_1_n_4 ),
        .Q(indvar_flatten1_reg_102_reg[7]),
        .R(indvar_flatten1_reg_102));
  FDRE \indvar_flatten1_reg_102_reg[8] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(\indvar_flatten1_reg_102_reg[8]_i_1_n_7 ),
        .Q(indvar_flatten1_reg_102_reg[8]),
        .R(indvar_flatten1_reg_102));
  CARRY4 \indvar_flatten1_reg_102_reg[8]_i_1 
       (.CI(\indvar_flatten1_reg_102_reg[4]_i_1_n_0 ),
        .CO({\NLW_indvar_flatten1_reg_102_reg[8]_i_1_CO_UNCONNECTED [3],\indvar_flatten1_reg_102_reg[8]_i_1_n_1 ,\indvar_flatten1_reg_102_reg[8]_i_1_n_2 ,\indvar_flatten1_reg_102_reg[8]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\indvar_flatten1_reg_102_reg[8]_i_1_n_4 ,\indvar_flatten1_reg_102_reg[8]_i_1_n_5 ,\indvar_flatten1_reg_102_reg[8]_i_1_n_6 ,\indvar_flatten1_reg_102_reg[8]_i_1_n_7 }),
        .S(indvar_flatten1_reg_102_reg[11:8]));
  FDRE \indvar_flatten1_reg_102_reg[9] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(\indvar_flatten1_reg_102_reg[8]_i_1_n_6 ),
        .Q(indvar_flatten1_reg_102_reg[9]),
        .R(indvar_flatten1_reg_102));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \indvar_flatten_reg_124[0]_i_1 
       (.I0(exitcond_flatten7_fu_175_p2),
        .I1(indvar_flatten_reg_124_reg__0[0]),
        .O(indvar_flatten_next_fu_260_p3[0]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'h14)) 
    \indvar_flatten_reg_124[1]_i_1 
       (.I0(exitcond_flatten7_fu_175_p2),
        .I1(indvar_flatten_reg_124_reg__0[0]),
        .I2(indvar_flatten_reg_124_reg__0[1]),
        .O(indvar_flatten_next_fu_260_p3[1]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h1540)) 
    \indvar_flatten_reg_124[2]_i_1 
       (.I0(exitcond_flatten7_fu_175_p2),
        .I1(indvar_flatten_reg_124_reg__0[0]),
        .I2(indvar_flatten_reg_124_reg__0[1]),
        .I3(indvar_flatten_reg_124_reg__0[2]),
        .O(indvar_flatten_next_fu_260_p3[2]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h15554000)) 
    \indvar_flatten_reg_124[3]_i_1 
       (.I0(exitcond_flatten7_fu_175_p2),
        .I1(indvar_flatten_reg_124_reg__0[1]),
        .I2(indvar_flatten_reg_124_reg__0[0]),
        .I3(indvar_flatten_reg_124_reg__0[2]),
        .I4(indvar_flatten_reg_124_reg__0[3]),
        .O(indvar_flatten_next_fu_260_p3[3]));
  LUT6 #(
    .INIT(64'h00007FFF00008000)) 
    \indvar_flatten_reg_124[4]_i_1 
       (.I0(indvar_flatten_reg_124_reg__0[3]),
        .I1(indvar_flatten_reg_124_reg__0[1]),
        .I2(indvar_flatten_reg_124_reg__0[0]),
        .I3(indvar_flatten_reg_124_reg__0[2]),
        .I4(exitcond_flatten7_fu_175_p2),
        .I5(indvar_flatten_reg_124_reg__0[4]),
        .O(indvar_flatten_next_fu_260_p3[4]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'h12)) 
    \indvar_flatten_reg_124[5]_i_1 
       (.I0(\indvar_flatten_reg_124[5]_i_2_n_0 ),
        .I1(exitcond_flatten7_fu_175_p2),
        .I2(indvar_flatten_reg_124_reg__0[5]),
        .O(indvar_flatten_next_fu_260_p3[5]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    \indvar_flatten_reg_124[5]_i_2 
       (.I0(indvar_flatten_reg_124_reg__0[4]),
        .I1(indvar_flatten_reg_124_reg__0[2]),
        .I2(indvar_flatten_reg_124_reg__0[0]),
        .I3(indvar_flatten_reg_124_reg__0[1]),
        .I4(indvar_flatten_reg_124_reg__0[3]),
        .O(\indvar_flatten_reg_124[5]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'h21)) 
    \indvar_flatten_reg_124[6]_i_1 
       (.I0(\indvar_flatten_reg_124[7]_i_2_n_0 ),
        .I1(exitcond_flatten7_fu_175_p2),
        .I2(indvar_flatten_reg_124_reg__0[6]),
        .O(indvar_flatten_next_fu_260_p3[6]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT4 #(
    .INIT(16'h0B04)) 
    \indvar_flatten_reg_124[7]_i_1 
       (.I0(\indvar_flatten_reg_124[7]_i_2_n_0 ),
        .I1(indvar_flatten_reg_124_reg__0[6]),
        .I2(exitcond_flatten7_fu_175_p2),
        .I3(indvar_flatten_reg_124_reg__0[7]),
        .O(indvar_flatten_next_fu_260_p3[7]));
  LUT6 #(
    .INIT(64'h7FFFFFFFFFFFFFFF)) 
    \indvar_flatten_reg_124[7]_i_2 
       (.I0(indvar_flatten_reg_124_reg__0[3]),
        .I1(indvar_flatten_reg_124_reg__0[1]),
        .I2(indvar_flatten_reg_124_reg__0[0]),
        .I3(indvar_flatten_reg_124_reg__0[2]),
        .I4(indvar_flatten_reg_124_reg__0[4]),
        .I5(indvar_flatten_reg_124_reg__0[5]),
        .O(\indvar_flatten_reg_124[7]_i_2_n_0 ));
  FDRE \indvar_flatten_reg_124_reg[0] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(indvar_flatten_next_fu_260_p3[0]),
        .Q(indvar_flatten_reg_124_reg__0[0]),
        .R(indvar_flatten1_reg_102));
  FDRE \indvar_flatten_reg_124_reg[1] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(indvar_flatten_next_fu_260_p3[1]),
        .Q(indvar_flatten_reg_124_reg__0[1]),
        .R(indvar_flatten1_reg_102));
  FDRE \indvar_flatten_reg_124_reg[2] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(indvar_flatten_next_fu_260_p3[2]),
        .Q(indvar_flatten_reg_124_reg__0[2]),
        .R(indvar_flatten1_reg_102));
  FDRE \indvar_flatten_reg_124_reg[3] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(indvar_flatten_next_fu_260_p3[3]),
        .Q(indvar_flatten_reg_124_reg__0[3]),
        .R(indvar_flatten1_reg_102));
  FDRE \indvar_flatten_reg_124_reg[4] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(indvar_flatten_next_fu_260_p3[4]),
        .Q(indvar_flatten_reg_124_reg__0[4]),
        .R(indvar_flatten1_reg_102));
  FDRE \indvar_flatten_reg_124_reg[5] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(indvar_flatten_next_fu_260_p3[5]),
        .Q(indvar_flatten_reg_124_reg__0[5]),
        .R(indvar_flatten1_reg_102));
  FDRE \indvar_flatten_reg_124_reg[6] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(indvar_flatten_next_fu_260_p3[6]),
        .Q(indvar_flatten_reg_124_reg__0[6]),
        .R(indvar_flatten1_reg_102));
  FDRE \indvar_flatten_reg_124_reg[7] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(indvar_flatten_next_fu_260_p3[7]),
        .Q(indvar_flatten_reg_124_reg__0[7]),
        .R(indvar_flatten1_reg_102));
  LUT1 #(
    .INIT(2'h1)) 
    output_r_Rst_A_INST_0
       (.I0(ap_rst_n),
        .O(output_r_Rst_A));
  LUT2 #(
    .INIT(4'h2)) 
    \output_r_WEN_A[0]_INST_0 
       (.I0(output_r_EN_A),
        .I1(exitcond_flatten1_reg_331_pp0_iter1_reg),
        .O(\^output_r_WEN_A ));
  LUT3 #(
    .INIT(8'h04)) 
    \res_1_reg_377[30]_i_1 
       (.I0(\exitcond_flatten1_reg_331_reg_n_0_[0] ),
        .I1(ap_CS_fsm_pp0_stage0),
        .I2(\res_1_reg_377_reg[30]_i_2_n_0 ),
        .O(\res_1_reg_377[30]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_377[30]_i_10 
       (.I0(bias_Dout_A[26]),
        .I1(bias_Dout_A[27]),
        .O(\res_1_reg_377[30]_i_10_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_377[30]_i_11 
       (.I0(bias_Dout_A[24]),
        .I1(bias_Dout_A[25]),
        .O(\res_1_reg_377[30]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_377[30]_i_13 
       (.I0(bias_Dout_A[22]),
        .I1(bias_Dout_A[23]),
        .O(\res_1_reg_377[30]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_377[30]_i_14 
       (.I0(bias_Dout_A[20]),
        .I1(bias_Dout_A[21]),
        .O(\res_1_reg_377[30]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_377[30]_i_15 
       (.I0(bias_Dout_A[18]),
        .I1(bias_Dout_A[19]),
        .O(\res_1_reg_377[30]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_377[30]_i_16 
       (.I0(bias_Dout_A[16]),
        .I1(bias_Dout_A[17]),
        .O(\res_1_reg_377[30]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_377[30]_i_17 
       (.I0(bias_Dout_A[22]),
        .I1(bias_Dout_A[23]),
        .O(\res_1_reg_377[30]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_377[30]_i_18 
       (.I0(bias_Dout_A[20]),
        .I1(bias_Dout_A[21]),
        .O(\res_1_reg_377[30]_i_18_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_377[30]_i_19 
       (.I0(bias_Dout_A[18]),
        .I1(bias_Dout_A[19]),
        .O(\res_1_reg_377[30]_i_19_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_377[30]_i_20 
       (.I0(bias_Dout_A[16]),
        .I1(bias_Dout_A[17]),
        .O(\res_1_reg_377[30]_i_20_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_377[30]_i_22 
       (.I0(bias_Dout_A[14]),
        .I1(bias_Dout_A[15]),
        .O(\res_1_reg_377[30]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_377[30]_i_23 
       (.I0(bias_Dout_A[12]),
        .I1(bias_Dout_A[13]),
        .O(\res_1_reg_377[30]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_377[30]_i_24 
       (.I0(bias_Dout_A[10]),
        .I1(bias_Dout_A[11]),
        .O(\res_1_reg_377[30]_i_24_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_377[30]_i_25 
       (.I0(bias_Dout_A[8]),
        .I1(bias_Dout_A[9]),
        .O(\res_1_reg_377[30]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_377[30]_i_26 
       (.I0(bias_Dout_A[14]),
        .I1(bias_Dout_A[15]),
        .O(\res_1_reg_377[30]_i_26_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_377[30]_i_27 
       (.I0(bias_Dout_A[12]),
        .I1(bias_Dout_A[13]),
        .O(\res_1_reg_377[30]_i_27_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_377[30]_i_28 
       (.I0(bias_Dout_A[10]),
        .I1(bias_Dout_A[11]),
        .O(\res_1_reg_377[30]_i_28_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_377[30]_i_29 
       (.I0(bias_Dout_A[8]),
        .I1(bias_Dout_A[9]),
        .O(\res_1_reg_377[30]_i_29_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_377[30]_i_30 
       (.I0(bias_Dout_A[6]),
        .I1(bias_Dout_A[7]),
        .O(\res_1_reg_377[30]_i_30_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_377[30]_i_31 
       (.I0(bias_Dout_A[4]),
        .I1(bias_Dout_A[5]),
        .O(\res_1_reg_377[30]_i_31_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_377[30]_i_32 
       (.I0(bias_Dout_A[2]),
        .I1(bias_Dout_A[3]),
        .O(\res_1_reg_377[30]_i_32_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_377[30]_i_33 
       (.I0(bias_Dout_A[0]),
        .I1(bias_Dout_A[1]),
        .O(\res_1_reg_377[30]_i_33_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_377[30]_i_34 
       (.I0(bias_Dout_A[6]),
        .I1(bias_Dout_A[7]),
        .O(\res_1_reg_377[30]_i_34_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_377[30]_i_35 
       (.I0(bias_Dout_A[4]),
        .I1(bias_Dout_A[5]),
        .O(\res_1_reg_377[30]_i_35_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_377[30]_i_36 
       (.I0(bias_Dout_A[2]),
        .I1(bias_Dout_A[3]),
        .O(\res_1_reg_377[30]_i_36_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_377[30]_i_37 
       (.I0(bias_Dout_A[0]),
        .I1(bias_Dout_A[1]),
        .O(\res_1_reg_377[30]_i_37_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \res_1_reg_377[30]_i_4 
       (.I0(bias_Dout_A[30]),
        .I1(bias_Dout_A[31]),
        .O(\res_1_reg_377[30]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_377[30]_i_5 
       (.I0(bias_Dout_A[28]),
        .I1(bias_Dout_A[29]),
        .O(\res_1_reg_377[30]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_377[30]_i_6 
       (.I0(bias_Dout_A[26]),
        .I1(bias_Dout_A[27]),
        .O(\res_1_reg_377[30]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \res_1_reg_377[30]_i_7 
       (.I0(bias_Dout_A[24]),
        .I1(bias_Dout_A[25]),
        .O(\res_1_reg_377[30]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_377[30]_i_8 
       (.I0(bias_Dout_A[30]),
        .I1(bias_Dout_A[31]),
        .O(\res_1_reg_377[30]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \res_1_reg_377[30]_i_9 
       (.I0(bias_Dout_A[28]),
        .I1(bias_Dout_A[29]),
        .O(\res_1_reg_377[30]_i_9_n_0 ));
  FDRE \res_1_reg_377_reg[0] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[0]),
        .Q(\^output_r_Din_A [0]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[10] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[10]),
        .Q(\^output_r_Din_A [10]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[11] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[11]),
        .Q(\^output_r_Din_A [11]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[12] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[12]),
        .Q(\^output_r_Din_A [12]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[13] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[13]),
        .Q(\^output_r_Din_A [13]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[14] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[14]),
        .Q(\^output_r_Din_A [14]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[15] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[15]),
        .Q(\^output_r_Din_A [15]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[16] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[16]),
        .Q(\^output_r_Din_A [16]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[17] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[17]),
        .Q(\^output_r_Din_A [17]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[18] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[18]),
        .Q(\^output_r_Din_A [18]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[19] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[19]),
        .Q(\^output_r_Din_A [19]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[1] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[1]),
        .Q(\^output_r_Din_A [1]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[20] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[20]),
        .Q(\^output_r_Din_A [20]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[21] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[21]),
        .Q(\^output_r_Din_A [21]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[22] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[22]),
        .Q(\^output_r_Din_A [22]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[23] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[23]),
        .Q(\^output_r_Din_A [23]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[24] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[24]),
        .Q(\^output_r_Din_A [24]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[25] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[25]),
        .Q(\^output_r_Din_A [25]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[26] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[26]),
        .Q(\^output_r_Din_A [26]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[27] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[27]),
        .Q(\^output_r_Din_A [27]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[28] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[28]),
        .Q(\^output_r_Din_A [28]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[29] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[29]),
        .Q(\^output_r_Din_A [29]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[2] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[2]),
        .Q(\^output_r_Din_A [2]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[30] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[30]),
        .Q(\^output_r_Din_A [30]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  CARRY4 \res_1_reg_377_reg[30]_i_12 
       (.CI(\res_1_reg_377_reg[30]_i_21_n_0 ),
        .CO({\res_1_reg_377_reg[30]_i_12_n_0 ,\res_1_reg_377_reg[30]_i_12_n_1 ,\res_1_reg_377_reg[30]_i_12_n_2 ,\res_1_reg_377_reg[30]_i_12_n_3 }),
        .CYINIT(1'b0),
        .DI({\res_1_reg_377[30]_i_22_n_0 ,\res_1_reg_377[30]_i_23_n_0 ,\res_1_reg_377[30]_i_24_n_0 ,\res_1_reg_377[30]_i_25_n_0 }),
        .O(\NLW_res_1_reg_377_reg[30]_i_12_O_UNCONNECTED [3:0]),
        .S({\res_1_reg_377[30]_i_26_n_0 ,\res_1_reg_377[30]_i_27_n_0 ,\res_1_reg_377[30]_i_28_n_0 ,\res_1_reg_377[30]_i_29_n_0 }));
  CARRY4 \res_1_reg_377_reg[30]_i_2 
       (.CI(\res_1_reg_377_reg[30]_i_3_n_0 ),
        .CO({\res_1_reg_377_reg[30]_i_2_n_0 ,\res_1_reg_377_reg[30]_i_2_n_1 ,\res_1_reg_377_reg[30]_i_2_n_2 ,\res_1_reg_377_reg[30]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\res_1_reg_377[30]_i_4_n_0 ,\res_1_reg_377[30]_i_5_n_0 ,\res_1_reg_377[30]_i_6_n_0 ,\res_1_reg_377[30]_i_7_n_0 }),
        .O(\NLW_res_1_reg_377_reg[30]_i_2_O_UNCONNECTED [3:0]),
        .S({\res_1_reg_377[30]_i_8_n_0 ,\res_1_reg_377[30]_i_9_n_0 ,\res_1_reg_377[30]_i_10_n_0 ,\res_1_reg_377[30]_i_11_n_0 }));
  CARRY4 \res_1_reg_377_reg[30]_i_21 
       (.CI(1'b0),
        .CO({\res_1_reg_377_reg[30]_i_21_n_0 ,\res_1_reg_377_reg[30]_i_21_n_1 ,\res_1_reg_377_reg[30]_i_21_n_2 ,\res_1_reg_377_reg[30]_i_21_n_3 }),
        .CYINIT(1'b0),
        .DI({\res_1_reg_377[30]_i_30_n_0 ,\res_1_reg_377[30]_i_31_n_0 ,\res_1_reg_377[30]_i_32_n_0 ,\res_1_reg_377[30]_i_33_n_0 }),
        .O(\NLW_res_1_reg_377_reg[30]_i_21_O_UNCONNECTED [3:0]),
        .S({\res_1_reg_377[30]_i_34_n_0 ,\res_1_reg_377[30]_i_35_n_0 ,\res_1_reg_377[30]_i_36_n_0 ,\res_1_reg_377[30]_i_37_n_0 }));
  CARRY4 \res_1_reg_377_reg[30]_i_3 
       (.CI(\res_1_reg_377_reg[30]_i_12_n_0 ),
        .CO({\res_1_reg_377_reg[30]_i_3_n_0 ,\res_1_reg_377_reg[30]_i_3_n_1 ,\res_1_reg_377_reg[30]_i_3_n_2 ,\res_1_reg_377_reg[30]_i_3_n_3 }),
        .CYINIT(1'b0),
        .DI({\res_1_reg_377[30]_i_13_n_0 ,\res_1_reg_377[30]_i_14_n_0 ,\res_1_reg_377[30]_i_15_n_0 ,\res_1_reg_377[30]_i_16_n_0 }),
        .O(\NLW_res_1_reg_377_reg[30]_i_3_O_UNCONNECTED [3:0]),
        .S({\res_1_reg_377[30]_i_17_n_0 ,\res_1_reg_377[30]_i_18_n_0 ,\res_1_reg_377[30]_i_19_n_0 ,\res_1_reg_377[30]_i_20_n_0 }));
  FDRE \res_1_reg_377_reg[3] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[3]),
        .Q(\^output_r_Din_A [3]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[4] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[4]),
        .Q(\^output_r_Din_A [4]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[5] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[5]),
        .Q(\^output_r_Din_A [5]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[6] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[6]),
        .Q(\^output_r_Din_A [6]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[7] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[7]),
        .Q(\^output_r_Din_A [7]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[8] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[8]),
        .Q(\^output_r_Din_A [8]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  FDRE \res_1_reg_377_reg[9] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(bias_Dout_A[9]),
        .Q(\^output_r_Din_A [9]),
        .R(\res_1_reg_377[30]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hA5A6A9AA)) 
    \tmp_5_mid2_reg_351[0]_i_1 
       (.I0(p_0_in),
        .I1(filter_index_reg_1130),
        .I2(exitcond_flatten7_fu_175_p2),
        .I3(y_reg_135[0]),
        .I4(tmp_5_mid2_reg_351[0]),
        .O(tmp_5_mid2_fu_240_p3[0]));
  LUT6 #(
    .INIT(64'h0000000200020002)) 
    \tmp_5_mid2_reg_351[0]_i_2 
       (.I0(x_reg_146[3]),
        .I1(x_reg_146[2]),
        .I2(x_reg_146[0]),
        .I3(x_reg_146[1]),
        .I4(\bias_Addr_A[7]_INST_0_i_5_n_0 ),
        .I5(\bias_Addr_A[7]_INST_0_i_4_n_0 ),
        .O(p_0_in));
  LUT5 #(
    .INIT(32'h5A595655)) 
    \tmp_5_mid2_reg_351[1]_i_1 
       (.I0(\tmp_5_mid2_reg_351[3]_i_3_n_0 ),
        .I1(filter_index_reg_1130),
        .I2(exitcond_flatten7_fu_175_p2),
        .I3(y_reg_135[1]),
        .I4(tmp_5_mid2_reg_351[1]),
        .O(tmp_5_mid2_fu_240_p3[1]));
  LUT6 #(
    .INIT(64'hFFFFF5F300000A0C)) 
    \tmp_5_mid2_reg_351[2]_i_1 
       (.I0(tmp_5_mid2_reg_351[1]),
        .I1(y_reg_135[1]),
        .I2(exitcond_flatten7_fu_175_p2),
        .I3(filter_index_reg_1130),
        .I4(\tmp_5_mid2_reg_351[3]_i_3_n_0 ),
        .I5(y_mid_fu_181_p3[2]),
        .O(tmp_5_mid2_fu_240_p3[2]));
  LUT4 #(
    .INIT(16'hDF20)) 
    \tmp_5_mid2_reg_351[3]_i_1 
       (.I0(y_mid_fu_181_p3[2]),
        .I1(\tmp_5_mid2_reg_351[3]_i_3_n_0 ),
        .I2(y_mid_fu_181_p3[1]),
        .I3(y_mid_fu_181_p3[3]),
        .O(tmp_5_mid2_fu_240_p3[3]));
  LUT5 #(
    .INIT(32'h0AAA0CCC)) 
    \tmp_5_mid2_reg_351[3]_i_2 
       (.I0(tmp_5_mid2_reg_351[2]),
        .I1(y_reg_135[2]),
        .I2(\bias_Addr_A[7]_INST_0_i_5_n_0 ),
        .I3(\bias_Addr_A[7]_INST_0_i_4_n_0 ),
        .I4(filter_index_reg_1130),
        .O(y_mid_fu_181_p3[2]));
  LUT6 #(
    .INIT(64'hFF1B1B1BFFFFFFFF)) 
    \tmp_5_mid2_reg_351[3]_i_3 
       (.I0(filter_index_reg_1130),
        .I1(y_reg_135[0]),
        .I2(tmp_5_mid2_reg_351[0]),
        .I3(\bias_Addr_A[7]_INST_0_i_4_n_0 ),
        .I4(\bias_Addr_A[7]_INST_0_i_5_n_0 ),
        .I5(\tmp_5_mid2_reg_351[3]_i_6_n_0 ),
        .O(\tmp_5_mid2_reg_351[3]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h0AAA0CCC)) 
    \tmp_5_mid2_reg_351[3]_i_4 
       (.I0(tmp_5_mid2_reg_351[1]),
        .I1(y_reg_135[1]),
        .I2(\bias_Addr_A[7]_INST_0_i_5_n_0 ),
        .I3(\bias_Addr_A[7]_INST_0_i_4_n_0 ),
        .I4(filter_index_reg_1130),
        .O(y_mid_fu_181_p3[1]));
  LUT5 #(
    .INIT(32'h0AAA0CCC)) 
    \tmp_5_mid2_reg_351[3]_i_5 
       (.I0(tmp_5_mid2_reg_351[3]),
        .I1(y_reg_135[3]),
        .I2(\bias_Addr_A[7]_INST_0_i_5_n_0 ),
        .I3(\bias_Addr_A[7]_INST_0_i_4_n_0 ),
        .I4(filter_index_reg_1130),
        .O(y_mid_fu_181_p3[3]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h0100)) 
    \tmp_5_mid2_reg_351[3]_i_6 
       (.I0(x_reg_146[1]),
        .I1(x_reg_146[0]),
        .I2(x_reg_146[2]),
        .I3(x_reg_146[3]),
        .O(\tmp_5_mid2_reg_351[3]_i_6_n_0 ));
  FDRE \tmp_5_mid2_reg_351_reg[0] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(tmp_5_mid2_fu_240_p3[0]),
        .Q(tmp_5_mid2_reg_351[0]),
        .R(1'b0));
  FDRE \tmp_5_mid2_reg_351_reg[1] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(tmp_5_mid2_fu_240_p3[1]),
        .Q(tmp_5_mid2_reg_351[1]),
        .R(1'b0));
  FDRE \tmp_5_mid2_reg_351_reg[2] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(tmp_5_mid2_fu_240_p3[2]),
        .Q(tmp_5_mid2_reg_351[2]),
        .R(1'b0));
  FDRE \tmp_5_mid2_reg_351_reg[3] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(tmp_5_mid2_fu_240_p3[3]),
        .Q(tmp_5_mid2_reg_351[3]),
        .R(1'b0));
  FDRE \tmp_mid2_v_reg_340_reg[0] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(\^bias_Addr_A [2]),
        .Q(tmp_mid2_v_reg_340_reg__0[0]),
        .R(1'b0));
  FDRE \tmp_mid2_v_reg_340_reg[1] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(\^bias_Addr_A [3]),
        .Q(tmp_mid2_v_reg_340_reg__0[1]),
        .R(1'b0));
  FDRE \tmp_mid2_v_reg_340_reg[2] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(\^bias_Addr_A [4]),
        .Q(tmp_mid2_v_reg_340_reg__0[2]),
        .R(1'b0));
  FDRE \tmp_mid2_v_reg_340_reg[3] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(\^bias_Addr_A [5]),
        .Q(tmp_mid2_v_reg_340_reg__0[3]),
        .R(1'b0));
  FDRE \tmp_mid2_v_reg_340_reg[4] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(\^bias_Addr_A [6]),
        .Q(tmp_mid2_v_reg_340_reg__0[4]),
        .R(1'b0));
  FDRE \tmp_mid2_v_reg_340_reg[5] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(\^bias_Addr_A [7]),
        .Q(tmp_mid2_v_reg_340_reg__0[5]),
        .R(1'b0));
  LUT2 #(
    .INIT(4'h2)) 
    \tmp_s_reg_372[12]_i_1 
       (.I0(ap_CS_fsm_pp0_stage0),
        .I1(\exitcond_flatten1_reg_331_reg_n_0_[0] ),
        .O(exitcond_flatten1_reg_331));
  LUT4 #(
    .INIT(16'h8000)) 
    \tmp_s_reg_372[12]_i_3 
       (.I0(tmp_mid2_v_reg_340_reg__0[3]),
        .I1(tmp_mid2_v_reg_340_reg__0[4]),
        .I2(tmp_mid2_v_reg_340_reg__0[5]),
        .I3(\tmp_s_reg_372[12]_i_6_n_0 ),
        .O(tmp_4_fu_282_p2[9]));
  LUT4 #(
    .INIT(16'h7F80)) 
    \tmp_s_reg_372[12]_i_4 
       (.I0(\tmp_s_reg_372[12]_i_6_n_0 ),
        .I1(tmp_mid2_v_reg_340_reg__0[3]),
        .I2(tmp_mid2_v_reg_340_reg__0[4]),
        .I3(tmp_mid2_v_reg_340_reg__0[5]),
        .O(tmp_4_fu_282_p2[8]));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \tmp_s_reg_372[12]_i_5 
       (.I0(tmp_mid2_v_reg_340_reg__0[3]),
        .I1(tmp_mid2_v_reg_340_reg__0[1]),
        .I2(tmp_5_mid2_reg_351[3]),
        .I3(tmp_mid2_v_reg_340_reg__0[0]),
        .I4(tmp_mid2_v_reg_340_reg__0[2]),
        .I5(tmp_mid2_v_reg_340_reg__0[4]),
        .O(tmp_4_fu_282_p2[7]));
  LUT4 #(
    .INIT(16'h8000)) 
    \tmp_s_reg_372[12]_i_6 
       (.I0(tmp_mid2_v_reg_340_reg__0[1]),
        .I1(tmp_5_mid2_reg_351[3]),
        .I2(tmp_mid2_v_reg_340_reg__0[0]),
        .I3(tmp_mid2_v_reg_340_reg__0[2]),
        .O(\tmp_s_reg_372[12]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_s_reg_372[5]_i_2 
       (.I0(tmp_5_mid2_reg_351[0]),
        .I1(x_mid2_reg_346[3]),
        .O(\tmp_s_reg_372[5]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \tmp_s_reg_372[9]_i_2 
       (.I0(tmp_mid2_v_reg_340_reg__0[2]),
        .I1(tmp_mid2_v_reg_340_reg__0[0]),
        .I2(tmp_5_mid2_reg_351[3]),
        .I3(tmp_mid2_v_reg_340_reg__0[1]),
        .I4(tmp_mid2_v_reg_340_reg__0[3]),
        .O(tmp_4_fu_282_p2[6]));
  LUT4 #(
    .INIT(16'h7F80)) 
    \tmp_s_reg_372[9]_i_3 
       (.I0(tmp_mid2_v_reg_340_reg__0[1]),
        .I1(tmp_5_mid2_reg_351[3]),
        .I2(tmp_mid2_v_reg_340_reg__0[0]),
        .I3(tmp_mid2_v_reg_340_reg__0[2]),
        .O(tmp_4_fu_282_p2[5]));
  LUT3 #(
    .INIT(8'h78)) 
    \tmp_s_reg_372[9]_i_4 
       (.I0(tmp_mid2_v_reg_340_reg__0[0]),
        .I1(tmp_5_mid2_reg_351[3]),
        .I2(tmp_mid2_v_reg_340_reg__0[1]),
        .O(tmp_4_fu_282_p2[4]));
  LUT2 #(
    .INIT(4'h6)) 
    \tmp_s_reg_372[9]_i_5 
       (.I0(tmp_mid2_v_reg_340_reg__0[0]),
        .I1(tmp_5_mid2_reg_351[3]),
        .O(tmp_4_fu_282_p2[3]));
  FDRE \tmp_s_reg_372_reg[0] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(x_mid2_reg_346[0]),
        .Q(\^output_r_Addr_A [2]),
        .R(1'b0));
  FDRE \tmp_s_reg_372_reg[10] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(tmp_s_fu_299_p2[10]),
        .Q(\^output_r_Addr_A [12]),
        .R(1'b0));
  FDRE \tmp_s_reg_372_reg[11] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(tmp_s_fu_299_p2[11]),
        .Q(\^output_r_Addr_A [13]),
        .R(1'b0));
  FDRE \tmp_s_reg_372_reg[12] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(tmp_s_fu_299_p2[12]),
        .Q(\^output_r_Addr_A [14]),
        .R(1'b0));
  CARRY4 \tmp_s_reg_372_reg[12]_i_2 
       (.CI(\tmp_s_reg_372_reg[9]_i_1_n_0 ),
        .CO({\NLW_tmp_s_reg_372_reg[12]_i_2_CO_UNCONNECTED [3:2],\tmp_s_reg_372_reg[12]_i_2_n_2 ,\tmp_s_reg_372_reg[12]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_tmp_s_reg_372_reg[12]_i_2_O_UNCONNECTED [3],tmp_s_fu_299_p2[12:10]}),
        .S({1'b0,tmp_4_fu_282_p2[9:7]}));
  FDRE \tmp_s_reg_372_reg[1] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(x_mid2_reg_346[1]),
        .Q(\^output_r_Addr_A [3]),
        .R(1'b0));
  FDRE \tmp_s_reg_372_reg[2] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(tmp_s_fu_299_p2[2]),
        .Q(\^output_r_Addr_A [4]),
        .R(1'b0));
  FDRE \tmp_s_reg_372_reg[3] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(tmp_s_fu_299_p2[3]),
        .Q(\^output_r_Addr_A [5]),
        .R(1'b0));
  FDRE \tmp_s_reg_372_reg[4] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(tmp_s_fu_299_p2[4]),
        .Q(\^output_r_Addr_A [6]),
        .R(1'b0));
  FDRE \tmp_s_reg_372_reg[5] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(tmp_s_fu_299_p2[5]),
        .Q(\^output_r_Addr_A [7]),
        .R(1'b0));
  CARRY4 \tmp_s_reg_372_reg[5]_i_1 
       (.CI(1'b0),
        .CO({\tmp_s_reg_372_reg[5]_i_1_n_0 ,\tmp_s_reg_372_reg[5]_i_1_n_1 ,\tmp_s_reg_372_reg[5]_i_1_n_2 ,\tmp_s_reg_372_reg[5]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,tmp_5_mid2_reg_351[0],1'b0}),
        .O(tmp_s_fu_299_p2[5:2]),
        .S({tmp_5_mid2_reg_351[2:1],\tmp_s_reg_372[5]_i_2_n_0 ,x_mid2_reg_346[2]}));
  FDRE \tmp_s_reg_372_reg[6] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(tmp_s_fu_299_p2[6]),
        .Q(\^output_r_Addr_A [8]),
        .R(1'b0));
  FDRE \tmp_s_reg_372_reg[7] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(tmp_s_fu_299_p2[7]),
        .Q(\^output_r_Addr_A [9]),
        .R(1'b0));
  FDRE \tmp_s_reg_372_reg[8] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(tmp_s_fu_299_p2[8]),
        .Q(\^output_r_Addr_A [10]),
        .R(1'b0));
  FDRE \tmp_s_reg_372_reg[9] 
       (.C(ap_clk),
        .CE(exitcond_flatten1_reg_331),
        .D(tmp_s_fu_299_p2[9]),
        .Q(\^output_r_Addr_A [11]),
        .R(1'b0));
  CARRY4 \tmp_s_reg_372_reg[9]_i_1 
       (.CI(\tmp_s_reg_372_reg[5]_i_1_n_0 ),
        .CO({\tmp_s_reg_372_reg[9]_i_1_n_0 ,\tmp_s_reg_372_reg[9]_i_1_n_1 ,\tmp_s_reg_372_reg[9]_i_1_n_2 ,\tmp_s_reg_372_reg[9]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(tmp_s_fu_299_p2[9:6]),
        .S(tmp_4_fu_282_p2[6:3]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT2 #(
    .INIT(4'h4)) 
    \x_mid2_reg_346[0]_i_1 
       (.I0(exitcond_flatten7_fu_175_p2),
        .I1(x_reg_146[0]),
        .O(x_mid2_fu_232_p3[0]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT2 #(
    .INIT(4'h4)) 
    \x_mid2_reg_346[1]_i_1 
       (.I0(exitcond_flatten7_fu_175_p2),
        .I1(x_reg_146[1]),
        .O(x_mid2_fu_232_p3[1]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT2 #(
    .INIT(4'h4)) 
    \x_mid2_reg_346[2]_i_1 
       (.I0(exitcond_flatten7_fu_175_p2),
        .I1(x_reg_146[2]),
        .O(x_mid2_fu_232_p3[2]));
  LUT2 #(
    .INIT(4'h2)) 
    \x_mid2_reg_346[3]_i_1 
       (.I0(ap_CS_fsm_pp0_stage0),
        .I1(exitcond_flatten1_fu_157_p2),
        .O(x_mid2_reg_3460));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h55540000)) 
    \x_mid2_reg_346[3]_i_2 
       (.I0(exitcond_flatten7_fu_175_p2),
        .I1(x_reg_146[2]),
        .I2(x_reg_146[0]),
        .I3(x_reg_146[1]),
        .I4(x_reg_146[3]),
        .O(x_mid2_fu_232_p3[3]));
  FDRE \x_mid2_reg_346_reg[0] 
       (.C(ap_clk),
        .CE(x_mid2_reg_3460),
        .D(x_mid2_fu_232_p3[0]),
        .Q(x_mid2_reg_346[0]),
        .R(1'b0));
  FDRE \x_mid2_reg_346_reg[1] 
       (.C(ap_clk),
        .CE(x_mid2_reg_3460),
        .D(x_mid2_fu_232_p3[1]),
        .Q(x_mid2_reg_346[1]),
        .R(1'b0));
  FDRE \x_mid2_reg_346_reg[2] 
       (.C(ap_clk),
        .CE(x_mid2_reg_3460),
        .D(x_mid2_fu_232_p3[2]),
        .Q(x_mid2_reg_346[2]),
        .R(1'b0));
  FDRE \x_mid2_reg_346_reg[3] 
       (.C(ap_clk),
        .CE(x_mid2_reg_3460),
        .D(x_mid2_fu_232_p3[3]),
        .Q(x_mid2_reg_346[3]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT2 #(
    .INIT(4'hD)) 
    \x_reg_146[0]_i_1 
       (.I0(x_reg_146[0]),
        .I1(exitcond_flatten7_fu_175_p2),
        .O(x_1_fu_248_p2[0]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'h06)) 
    \x_reg_146[1]_i_1 
       (.I0(x_reg_146[1]),
        .I1(x_reg_146[0]),
        .I2(exitcond_flatten7_fu_175_p2),
        .O(x_1_fu_248_p2[1]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT4 #(
    .INIT(16'h006A)) 
    \x_reg_146[2]_i_1 
       (.I0(x_reg_146[2]),
        .I1(x_reg_146[1]),
        .I2(x_reg_146[0]),
        .I3(exitcond_flatten7_fu_175_p2),
        .O(x_1_fu_248_p2[2]));
  LUT5 #(
    .INIT(32'hDF000000)) 
    \x_reg_146[3]_i_1 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(exitcond_flatten1_fu_157_p2),
        .I2(ap_CS_fsm_pp0_stage0),
        .I3(\ap_CS_fsm_reg_n_0_[0] ),
        .I4(ap_start),
        .O(indvar_flatten1_reg_102));
  LUT3 #(
    .INIT(8'h20)) 
    \x_reg_146[3]_i_2 
       (.I0(ap_enable_reg_pp0_iter0),
        .I1(exitcond_flatten1_fu_157_p2),
        .I2(ap_CS_fsm_pp0_stage0),
        .O(indvar_flatten1_reg_1020));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h00006AA8)) 
    \x_reg_146[3]_i_3 
       (.I0(x_reg_146[3]),
        .I1(x_reg_146[1]),
        .I2(x_reg_146[0]),
        .I3(x_reg_146[2]),
        .I4(exitcond_flatten7_fu_175_p2),
        .O(x_1_fu_248_p2[3]));
  FDRE \x_reg_146_reg[0] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(x_1_fu_248_p2[0]),
        .Q(x_reg_146[0]),
        .R(indvar_flatten1_reg_102));
  FDRE \x_reg_146_reg[1] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(x_1_fu_248_p2[1]),
        .Q(x_reg_146[1]),
        .R(indvar_flatten1_reg_102));
  FDRE \x_reg_146_reg[2] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(x_1_fu_248_p2[2]),
        .Q(x_reg_146[2]),
        .R(indvar_flatten1_reg_102));
  FDRE \x_reg_146_reg[3] 
       (.C(ap_clk),
        .CE(indvar_flatten1_reg_1020),
        .D(x_1_fu_248_p2[3]),
        .Q(x_reg_146[3]),
        .R(indvar_flatten1_reg_102));
  FDRE \y_reg_135_reg[0] 
       (.C(ap_clk),
        .CE(filter_index_reg_1130),
        .D(tmp_5_mid2_reg_351[0]),
        .Q(y_reg_135[0]),
        .R(filter_index_reg_113));
  FDRE \y_reg_135_reg[1] 
       (.C(ap_clk),
        .CE(filter_index_reg_1130),
        .D(tmp_5_mid2_reg_351[1]),
        .Q(y_reg_135[1]),
        .R(filter_index_reg_113));
  FDRE \y_reg_135_reg[2] 
       (.C(ap_clk),
        .CE(filter_index_reg_1130),
        .D(tmp_5_mid2_reg_351[2]),
        .Q(y_reg_135[2]),
        .R(filter_index_reg_113));
  FDRE \y_reg_135_reg[3] 
       (.C(ap_clk),
        .CE(filter_index_reg_1130),
        .D(tmp_5_mid2_reg_351[3]),
        .Q(y_reg_135[3]),
        .R(filter_index_reg_113));
endmodule

(* CHECK_LICENSE_TYPE = "zed_Conv2_12x12x20_5x5x40_1_0_1_0,a0_Conv2_12x12x20_5x5x40_1_0,{}" *) (* DowngradeIPIdentifiedWarnings = "yes" *) (* IP_DEFINITION_SOURCE = "HLS" *) 
(* X_CORE_INFO = "a0_Conv2_12x12x20_5x5x40_1_0,Vivado 2018.2" *) (* hls_module = "yes" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (ap_clk,
    ap_rst_n,
    ap_start,
    ap_done,
    ap_idle,
    ap_ready,
    input_r_Clk_A,
    input_r_Rst_A,
    input_r_EN_A,
    input_r_WEN_A,
    input_r_Addr_A,
    input_r_Din_A,
    input_r_Dout_A,
    bias_Clk_A,
    bias_Rst_A,
    bias_EN_A,
    bias_WEN_A,
    bias_Addr_A,
    bias_Din_A,
    bias_Dout_A,
    output_r_Clk_A,
    output_r_Rst_A,
    output_r_EN_A,
    output_r_WEN_A,
    output_r_Addr_A,
    output_r_Din_A,
    output_r_Dout_A);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 ap_clk CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME ap_clk, ASSOCIATED_RESET ap_rst_n, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}}}, FREQ_HZ 100000000, PHASE 0.000, CLK_DOMAIN /clk_wiz_0_clk_out1" *) input ap_clk;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 ap_rst_n RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME ap_rst_n, POLARITY ACTIVE_LOW, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}}}" *) input ap_rst_n;
  (* X_INTERFACE_INFO = "xilinx.com:interface:acc_handshake:1.0 ap_ctrl start" *) input ap_start;
  (* X_INTERFACE_INFO = "xilinx.com:interface:acc_handshake:1.0 ap_ctrl done" *) output ap_done;
  (* X_INTERFACE_INFO = "xilinx.com:interface:acc_handshake:1.0 ap_ctrl idle" *) output ap_idle;
  (* X_INTERFACE_INFO = "xilinx.com:interface:acc_handshake:1.0 ap_ctrl ready" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME ap_ctrl, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {start {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} done {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} idle {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ready {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}}}" *) output ap_ready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 input_r_PORTA CLK" *) output input_r_Clk_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 input_r_PORTA RST" *) output input_r_Rst_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 input_r_PORTA EN" *) output input_r_EN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 input_r_PORTA WE" *) output [3:0]input_r_WEN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 input_r_PORTA ADDR" *) output [31:0]input_r_Addr_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 input_r_PORTA DIN" *) output [31:0]input_r_Din_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 input_r_PORTA DOUT" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME input_r_PORTA, MEM_WIDTH 32, MEM_SIZE 11520, MASTER_TYPE BRAM_CTRL, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {EN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ADDR {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} WE {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 4} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} DIN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}} DOUT {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}}, MEM_ECC NONE" *) input [31:0]input_r_Dout_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 bias_PORTA CLK" *) output bias_Clk_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 bias_PORTA RST" *) output bias_Rst_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 bias_PORTA EN" *) output bias_EN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 bias_PORTA WE" *) output [3:0]bias_WEN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 bias_PORTA ADDR" *) output [31:0]bias_Addr_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 bias_PORTA DIN" *) output [31:0]bias_Din_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 bias_PORTA DOUT" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME bias_PORTA, MEM_WIDTH 32, MEM_SIZE 160, MASTER_TYPE BRAM_CTRL, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {EN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ADDR {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} WE {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 4} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} DIN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}} DOUT {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}}, MEM_ECC NONE" *) input [31:0]bias_Dout_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 output_r_PORTA CLK" *) output output_r_Clk_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 output_r_PORTA RST" *) output output_r_Rst_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 output_r_PORTA EN" *) output output_r_EN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 output_r_PORTA WE" *) output [3:0]output_r_WEN_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 output_r_PORTA ADDR" *) output [31:0]output_r_Addr_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 output_r_PORTA DIN" *) output [31:0]output_r_Din_A;
  (* X_INTERFACE_INFO = "xilinx.com:interface:bram:1.0 output_r_PORTA DOUT" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME output_r_PORTA, MEM_WIDTH 32, MEM_SIZE 10240, MASTER_TYPE BRAM_CTRL, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {EN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ADDR {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} WE {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 4} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} DIN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}} DOUT {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}}, MEM_ECC NONE" *) input [31:0]output_r_Dout_A;

  wire ap_clk;
  wire ap_done;
  wire ap_idle;
  wire ap_ready;
  wire ap_rst_n;
  wire ap_start;
  wire [31:0]bias_Addr_A;
  wire bias_Clk_A;
  wire [31:0]bias_Din_A;
  wire [31:0]bias_Dout_A;
  wire bias_EN_A;
  wire bias_Rst_A;
  wire [3:0]bias_WEN_A;
  wire [31:0]input_r_Addr_A;
  wire input_r_Clk_A;
  wire [31:0]input_r_Din_A;
  wire [31:0]input_r_Dout_A;
  wire input_r_EN_A;
  wire input_r_Rst_A;
  wire [3:0]input_r_WEN_A;
  wire [31:0]output_r_Addr_A;
  wire output_r_Clk_A;
  wire [31:0]output_r_Din_A;
  wire [31:0]output_r_Dout_A;
  wire output_r_EN_A;
  wire output_r_Rst_A;
  wire [3:0]output_r_WEN_A;

  (* SDX_KERNEL = "true" *) 
  (* SDX_KERNEL_SYNTH_INST = "inst" *) 
  (* SDX_KERNEL_TYPE = "hls" *) 
  (* ap_ST_fsm_pp0_stage0 = "3'b010" *) 
  (* ap_ST_fsm_state1 = "3'b001" *) 
  (* ap_ST_fsm_state5 = "3'b100" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0 inst
       (.ap_clk(ap_clk),
        .ap_done(ap_done),
        .ap_idle(ap_idle),
        .ap_ready(ap_ready),
        .ap_rst_n(ap_rst_n),
        .ap_start(ap_start),
        .bias_Addr_A(bias_Addr_A),
        .bias_Clk_A(bias_Clk_A),
        .bias_Din_A(bias_Din_A),
        .bias_Dout_A(bias_Dout_A),
        .bias_EN_A(bias_EN_A),
        .bias_Rst_A(bias_Rst_A),
        .bias_WEN_A(bias_WEN_A),
        .input_r_Addr_A(input_r_Addr_A),
        .input_r_Clk_A(input_r_Clk_A),
        .input_r_Din_A(input_r_Din_A),
        .input_r_Dout_A(input_r_Dout_A),
        .input_r_EN_A(input_r_EN_A),
        .input_r_Rst_A(input_r_Rst_A),
        .input_r_WEN_A(input_r_WEN_A),
        .output_r_Addr_A(output_r_Addr_A),
        .output_r_Clk_A(output_r_Clk_A),
        .output_r_Din_A(output_r_Din_A),
        .output_r_Dout_A(output_r_Dout_A),
        .output_r_EN_A(output_r_EN_A),
        .output_r_Rst_A(output_r_Rst_A),
        .output_r_WEN_A(output_r_WEN_A));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

endmodule
`endif
