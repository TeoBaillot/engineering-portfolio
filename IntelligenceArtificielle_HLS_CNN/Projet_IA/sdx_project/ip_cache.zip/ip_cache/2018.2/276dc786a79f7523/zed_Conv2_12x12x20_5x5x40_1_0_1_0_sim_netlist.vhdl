-- Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2018.2 (lin64) Build 2258646 Thu Jun 14 20:02:38 MDT 2018
-- Date        : Wed Dec 17 17:18:45 2025
-- Host        : PCII-REF running 64-bit Ubuntu 22.04.5 LTS
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ zed_Conv2_12x12x20_5x5x40_1_0_1_0_sim_netlist.vhdl
-- Design      : zed_Conv2_12x12x20_5x5x40_1_0_1_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg484-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0 is
  port (
    ap_clk : in STD_LOGIC;
    ap_rst_n : in STD_LOGIC;
    ap_start : in STD_LOGIC;
    ap_done : out STD_LOGIC;
    ap_idle : out STD_LOGIC;
    ap_ready : out STD_LOGIC;
    input_r_Addr_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    input_r_EN_A : out STD_LOGIC;
    input_r_WEN_A : out STD_LOGIC_VECTOR ( 3 downto 0 );
    input_r_Din_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    input_r_Dout_A : in STD_LOGIC_VECTOR ( 31 downto 0 );
    input_r_Clk_A : out STD_LOGIC;
    input_r_Rst_A : out STD_LOGIC;
    bias_Addr_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    bias_EN_A : out STD_LOGIC;
    bias_WEN_A : out STD_LOGIC_VECTOR ( 3 downto 0 );
    bias_Din_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    bias_Dout_A : in STD_LOGIC_VECTOR ( 31 downto 0 );
    bias_Clk_A : out STD_LOGIC;
    bias_Rst_A : out STD_LOGIC;
    output_r_Addr_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    output_r_EN_A : out STD_LOGIC;
    output_r_WEN_A : out STD_LOGIC_VECTOR ( 3 downto 0 );
    output_r_Din_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    output_r_Dout_A : in STD_LOGIC_VECTOR ( 31 downto 0 );
    output_r_Clk_A : out STD_LOGIC;
    output_r_Rst_A : out STD_LOGIC
  );
  attribute ap_ST_fsm_pp0_stage0 : string;
  attribute ap_ST_fsm_pp0_stage0 of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0 : entity is "3'b010";
  attribute ap_ST_fsm_state1 : string;
  attribute ap_ST_fsm_state1 of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0 : entity is "3'b001";
  attribute ap_ST_fsm_state5 : string;
  attribute ap_ST_fsm_state5 of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0 : entity is "3'b100";
  attribute hls_module : string;
  attribute hls_module of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0 : entity is "yes";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0 is
  signal \<const0>\ : STD_LOGIC;
  signal \ap_CS_fsm[1]_i_2_n_0\ : STD_LOGIC;
  signal \ap_CS_fsm[2]_i_3_n_0\ : STD_LOGIC;
  signal \ap_CS_fsm[2]_i_4_n_0\ : STD_LOGIC;
  signal ap_CS_fsm_pp0_stage0 : STD_LOGIC;
  signal \ap_CS_fsm_reg_n_0_[0]\ : STD_LOGIC;
  signal ap_NS_fsm : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \^ap_clk\ : STD_LOGIC;
  signal \^ap_done\ : STD_LOGIC;
  signal ap_enable_reg_pp0_iter0 : STD_LOGIC;
  signal ap_enable_reg_pp0_iter0_i_1_n_0 : STD_LOGIC;
  signal ap_enable_reg_pp0_iter1_i_1_n_0 : STD_LOGIC;
  signal ap_enable_reg_pp0_iter1_reg_n_0 : STD_LOGIC;
  signal ap_phi_mux_filter_index_phi_fu_117_p4 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \^bias_addr_a\ : STD_LOGIC_VECTOR ( 7 downto 2 );
  signal \bias_Addr_A[5]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bias_Addr_A[6]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bias_Addr_A[7]_INST_0_i_1_n_0\ : STD_LOGIC;
  signal \bias_Addr_A[7]_INST_0_i_4_n_0\ : STD_LOGIC;
  signal \bias_Addr_A[7]_INST_0_i_5_n_0\ : STD_LOGIC;
  signal exitcond_flatten1_fu_157_p2 : STD_LOGIC;
  signal exitcond_flatten1_reg_331 : STD_LOGIC;
  signal \exitcond_flatten1_reg_331[0]_i_1_n_0\ : STD_LOGIC;
  signal exitcond_flatten1_reg_331_pp0_iter1_reg : STD_LOGIC;
  signal \exitcond_flatten1_reg_331_pp0_iter1_reg[0]_i_1_n_0\ : STD_LOGIC;
  signal \exitcond_flatten1_reg_331_reg_n_0_[0]\ : STD_LOGIC;
  signal exitcond_flatten7_fu_175_p2 : STD_LOGIC;
  signal filter_index_reg_113 : STD_LOGIC;
  signal filter_index_reg_1130 : STD_LOGIC;
  signal \filter_index_reg_113_reg_n_0_[0]\ : STD_LOGIC;
  signal \filter_index_reg_113_reg_n_0_[1]\ : STD_LOGIC;
  signal \filter_index_reg_113_reg_n_0_[2]\ : STD_LOGIC;
  signal \filter_index_reg_113_reg_n_0_[3]\ : STD_LOGIC;
  signal \filter_index_reg_113_reg_n_0_[4]\ : STD_LOGIC;
  signal \filter_index_reg_113_reg_n_0_[5]\ : STD_LOGIC;
  signal indvar_flatten1_reg_102 : STD_LOGIC;
  signal indvar_flatten1_reg_1020 : STD_LOGIC;
  signal \indvar_flatten1_reg_102[0]_i_2_n_0\ : STD_LOGIC;
  signal indvar_flatten1_reg_102_reg : STD_LOGIC_VECTOR ( 11 downto 0 );
  signal \indvar_flatten1_reg_102_reg[0]_i_1_n_0\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[0]_i_1_n_1\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[0]_i_1_n_2\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[0]_i_1_n_3\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[0]_i_1_n_4\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[0]_i_1_n_5\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[0]_i_1_n_6\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[0]_i_1_n_7\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[4]_i_1_n_0\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[4]_i_1_n_1\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[4]_i_1_n_2\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[4]_i_1_n_3\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[4]_i_1_n_4\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[4]_i_1_n_5\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[4]_i_1_n_6\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[4]_i_1_n_7\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[8]_i_1_n_1\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[8]_i_1_n_2\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[8]_i_1_n_3\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[8]_i_1_n_4\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[8]_i_1_n_5\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[8]_i_1_n_6\ : STD_LOGIC;
  signal \indvar_flatten1_reg_102_reg[8]_i_1_n_7\ : STD_LOGIC;
  signal indvar_flatten_next_fu_260_p3 : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \indvar_flatten_reg_124[5]_i_2_n_0\ : STD_LOGIC;
  signal \indvar_flatten_reg_124[7]_i_2_n_0\ : STD_LOGIC;
  signal \indvar_flatten_reg_124_reg__0\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \^output_r_addr_a\ : STD_LOGIC_VECTOR ( 14 downto 2 );
  signal \^output_r_din_a\ : STD_LOGIC_VECTOR ( 30 downto 0 );
  signal \^output_r_en_a\ : STD_LOGIC;
  signal \^output_r_rst_a\ : STD_LOGIC;
  signal \^output_r_wen_a\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal p_0_in : STD_LOGIC;
  signal \res_1_reg_377[30]_i_10_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_11_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_13_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_14_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_15_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_16_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_17_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_18_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_19_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_1_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_20_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_22_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_23_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_24_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_25_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_26_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_27_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_28_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_29_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_30_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_31_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_32_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_33_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_34_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_35_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_36_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_37_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_4_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_5_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_6_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_7_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_8_n_0\ : STD_LOGIC;
  signal \res_1_reg_377[30]_i_9_n_0\ : STD_LOGIC;
  signal \res_1_reg_377_reg[30]_i_12_n_0\ : STD_LOGIC;
  signal \res_1_reg_377_reg[30]_i_12_n_1\ : STD_LOGIC;
  signal \res_1_reg_377_reg[30]_i_12_n_2\ : STD_LOGIC;
  signal \res_1_reg_377_reg[30]_i_12_n_3\ : STD_LOGIC;
  signal \res_1_reg_377_reg[30]_i_21_n_0\ : STD_LOGIC;
  signal \res_1_reg_377_reg[30]_i_21_n_1\ : STD_LOGIC;
  signal \res_1_reg_377_reg[30]_i_21_n_2\ : STD_LOGIC;
  signal \res_1_reg_377_reg[30]_i_21_n_3\ : STD_LOGIC;
  signal \res_1_reg_377_reg[30]_i_2_n_0\ : STD_LOGIC;
  signal \res_1_reg_377_reg[30]_i_2_n_1\ : STD_LOGIC;
  signal \res_1_reg_377_reg[30]_i_2_n_2\ : STD_LOGIC;
  signal \res_1_reg_377_reg[30]_i_2_n_3\ : STD_LOGIC;
  signal \res_1_reg_377_reg[30]_i_3_n_0\ : STD_LOGIC;
  signal \res_1_reg_377_reg[30]_i_3_n_1\ : STD_LOGIC;
  signal \res_1_reg_377_reg[30]_i_3_n_2\ : STD_LOGIC;
  signal \res_1_reg_377_reg[30]_i_3_n_3\ : STD_LOGIC;
  signal tmp_4_fu_282_p2 : STD_LOGIC_VECTOR ( 9 downto 3 );
  signal tmp_5_mid2_fu_240_p3 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal tmp_5_mid2_reg_351 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \tmp_5_mid2_reg_351[3]_i_3_n_0\ : STD_LOGIC;
  signal \tmp_5_mid2_reg_351[3]_i_6_n_0\ : STD_LOGIC;
  signal \tmp_mid2_v_reg_340_reg__0\ : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal tmp_s_fu_299_p2 : STD_LOGIC_VECTOR ( 12 downto 2 );
  signal \tmp_s_reg_372[12]_i_6_n_0\ : STD_LOGIC;
  signal \tmp_s_reg_372[5]_i_2_n_0\ : STD_LOGIC;
  signal \tmp_s_reg_372_reg[12]_i_2_n_2\ : STD_LOGIC;
  signal \tmp_s_reg_372_reg[12]_i_2_n_3\ : STD_LOGIC;
  signal \tmp_s_reg_372_reg[5]_i_1_n_0\ : STD_LOGIC;
  signal \tmp_s_reg_372_reg[5]_i_1_n_1\ : STD_LOGIC;
  signal \tmp_s_reg_372_reg[5]_i_1_n_2\ : STD_LOGIC;
  signal \tmp_s_reg_372_reg[5]_i_1_n_3\ : STD_LOGIC;
  signal \tmp_s_reg_372_reg[9]_i_1_n_0\ : STD_LOGIC;
  signal \tmp_s_reg_372_reg[9]_i_1_n_1\ : STD_LOGIC;
  signal \tmp_s_reg_372_reg[9]_i_1_n_2\ : STD_LOGIC;
  signal \tmp_s_reg_372_reg[9]_i_1_n_3\ : STD_LOGIC;
  signal x_1_fu_248_p2 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal x_mid2_fu_232_p3 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal x_mid2_reg_346 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal x_mid2_reg_3460 : STD_LOGIC;
  signal x_reg_146 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal y_mid_fu_181_p3 : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal y_reg_135 : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_indvar_flatten1_reg_102_reg[8]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_res_1_reg_377_reg[30]_i_12_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_res_1_reg_377_reg[30]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_res_1_reg_377_reg[30]_i_21_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_res_1_reg_377_reg[30]_i_3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_tmp_s_reg_372_reg[12]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_tmp_s_reg_372_reg[12]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \ap_CS_fsm[0]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \ap_CS_fsm[1]_i_2\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \ap_CS_fsm[2]_i_1\ : label is "soft_lutpair4";
  attribute FSM_ENCODING : string;
  attribute FSM_ENCODING of \ap_CS_fsm_reg[0]\ : label is "none";
  attribute FSM_ENCODING of \ap_CS_fsm_reg[1]\ : label is "none";
  attribute FSM_ENCODING of \ap_CS_fsm_reg[2]\ : label is "none";
  attribute SOFT_HLUTNM of \bias_Addr_A[4]_INST_0_i_2\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \bias_Addr_A[7]_INST_0_i_4\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \bias_Addr_A[7]_INST_0_i_5\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of bias_EN_A_INST_0 : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \exitcond_flatten1_reg_331[0]_i_1\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \exitcond_flatten1_reg_331_pp0_iter1_reg[0]_i_1\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \indvar_flatten_reg_124[0]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \indvar_flatten_reg_124[1]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \indvar_flatten_reg_124[2]_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \indvar_flatten_reg_124[3]_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \indvar_flatten_reg_124[5]_i_1\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \indvar_flatten_reg_124[5]_i_2\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \indvar_flatten_reg_124[6]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \indvar_flatten_reg_124[7]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \tmp_5_mid2_reg_351[3]_i_6\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \x_mid2_reg_346[0]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \x_mid2_reg_346[1]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \x_mid2_reg_346[2]_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \x_mid2_reg_346[3]_i_2\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \x_reg_146[0]_i_1\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \x_reg_146[1]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \x_reg_146[2]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \x_reg_146[3]_i_3\ : label is "soft_lutpair0";
begin
  \^ap_clk\ <= ap_clk;
  ap_done <= \^ap_done\;
  ap_ready <= \^ap_done\;
  bias_Addr_A(31) <= \<const0>\;
  bias_Addr_A(30) <= \<const0>\;
  bias_Addr_A(29) <= \<const0>\;
  bias_Addr_A(28) <= \<const0>\;
  bias_Addr_A(27) <= \<const0>\;
  bias_Addr_A(26) <= \<const0>\;
  bias_Addr_A(25) <= \<const0>\;
  bias_Addr_A(24) <= \<const0>\;
  bias_Addr_A(23) <= \<const0>\;
  bias_Addr_A(22) <= \<const0>\;
  bias_Addr_A(21) <= \<const0>\;
  bias_Addr_A(20) <= \<const0>\;
  bias_Addr_A(19) <= \<const0>\;
  bias_Addr_A(18) <= \<const0>\;
  bias_Addr_A(17) <= \<const0>\;
  bias_Addr_A(16) <= \<const0>\;
  bias_Addr_A(15) <= \<const0>\;
  bias_Addr_A(14) <= \<const0>\;
  bias_Addr_A(13) <= \<const0>\;
  bias_Addr_A(12) <= \<const0>\;
  bias_Addr_A(11) <= \<const0>\;
  bias_Addr_A(10) <= \<const0>\;
  bias_Addr_A(9) <= \<const0>\;
  bias_Addr_A(8) <= \<const0>\;
  bias_Addr_A(7 downto 2) <= \^bias_addr_a\(7 downto 2);
  bias_Addr_A(1) <= \<const0>\;
  bias_Addr_A(0) <= \<const0>\;
  bias_Clk_A <= \^ap_clk\;
  bias_Din_A(31) <= \<const0>\;
  bias_Din_A(30) <= \<const0>\;
  bias_Din_A(29) <= \<const0>\;
  bias_Din_A(28) <= \<const0>\;
  bias_Din_A(27) <= \<const0>\;
  bias_Din_A(26) <= \<const0>\;
  bias_Din_A(25) <= \<const0>\;
  bias_Din_A(24) <= \<const0>\;
  bias_Din_A(23) <= \<const0>\;
  bias_Din_A(22) <= \<const0>\;
  bias_Din_A(21) <= \<const0>\;
  bias_Din_A(20) <= \<const0>\;
  bias_Din_A(19) <= \<const0>\;
  bias_Din_A(18) <= \<const0>\;
  bias_Din_A(17) <= \<const0>\;
  bias_Din_A(16) <= \<const0>\;
  bias_Din_A(15) <= \<const0>\;
  bias_Din_A(14) <= \<const0>\;
  bias_Din_A(13) <= \<const0>\;
  bias_Din_A(12) <= \<const0>\;
  bias_Din_A(11) <= \<const0>\;
  bias_Din_A(10) <= \<const0>\;
  bias_Din_A(9) <= \<const0>\;
  bias_Din_A(8) <= \<const0>\;
  bias_Din_A(7) <= \<const0>\;
  bias_Din_A(6) <= \<const0>\;
  bias_Din_A(5) <= \<const0>\;
  bias_Din_A(4) <= \<const0>\;
  bias_Din_A(3) <= \<const0>\;
  bias_Din_A(2) <= \<const0>\;
  bias_Din_A(1) <= \<const0>\;
  bias_Din_A(0) <= \<const0>\;
  bias_Rst_A <= \^output_r_rst_a\;
  bias_WEN_A(3) <= \<const0>\;
  bias_WEN_A(2) <= \<const0>\;
  bias_WEN_A(1) <= \<const0>\;
  bias_WEN_A(0) <= \<const0>\;
  input_r_Addr_A(31) <= \<const0>\;
  input_r_Addr_A(30) <= \<const0>\;
  input_r_Addr_A(29) <= \<const0>\;
  input_r_Addr_A(28) <= \<const0>\;
  input_r_Addr_A(27) <= \<const0>\;
  input_r_Addr_A(26) <= \<const0>\;
  input_r_Addr_A(25) <= \<const0>\;
  input_r_Addr_A(24) <= \<const0>\;
  input_r_Addr_A(23) <= \<const0>\;
  input_r_Addr_A(22) <= \<const0>\;
  input_r_Addr_A(21) <= \<const0>\;
  input_r_Addr_A(20) <= \<const0>\;
  input_r_Addr_A(19) <= \<const0>\;
  input_r_Addr_A(18) <= \<const0>\;
  input_r_Addr_A(17) <= \<const0>\;
  input_r_Addr_A(16) <= \<const0>\;
  input_r_Addr_A(15) <= \<const0>\;
  input_r_Addr_A(14) <= \<const0>\;
  input_r_Addr_A(13) <= \<const0>\;
  input_r_Addr_A(12) <= \<const0>\;
  input_r_Addr_A(11) <= \<const0>\;
  input_r_Addr_A(10) <= \<const0>\;
  input_r_Addr_A(9) <= \<const0>\;
  input_r_Addr_A(8) <= \<const0>\;
  input_r_Addr_A(7) <= \<const0>\;
  input_r_Addr_A(6) <= \<const0>\;
  input_r_Addr_A(5) <= \<const0>\;
  input_r_Addr_A(4) <= \<const0>\;
  input_r_Addr_A(3) <= \<const0>\;
  input_r_Addr_A(2) <= \<const0>\;
  input_r_Addr_A(1) <= \<const0>\;
  input_r_Addr_A(0) <= \<const0>\;
  input_r_Clk_A <= \^ap_clk\;
  input_r_Din_A(31) <= \<const0>\;
  input_r_Din_A(30) <= \<const0>\;
  input_r_Din_A(29) <= \<const0>\;
  input_r_Din_A(28) <= \<const0>\;
  input_r_Din_A(27) <= \<const0>\;
  input_r_Din_A(26) <= \<const0>\;
  input_r_Din_A(25) <= \<const0>\;
  input_r_Din_A(24) <= \<const0>\;
  input_r_Din_A(23) <= \<const0>\;
  input_r_Din_A(22) <= \<const0>\;
  input_r_Din_A(21) <= \<const0>\;
  input_r_Din_A(20) <= \<const0>\;
  input_r_Din_A(19) <= \<const0>\;
  input_r_Din_A(18) <= \<const0>\;
  input_r_Din_A(17) <= \<const0>\;
  input_r_Din_A(16) <= \<const0>\;
  input_r_Din_A(15) <= \<const0>\;
  input_r_Din_A(14) <= \<const0>\;
  input_r_Din_A(13) <= \<const0>\;
  input_r_Din_A(12) <= \<const0>\;
  input_r_Din_A(11) <= \<const0>\;
  input_r_Din_A(10) <= \<const0>\;
  input_r_Din_A(9) <= \<const0>\;
  input_r_Din_A(8) <= \<const0>\;
  input_r_Din_A(7) <= \<const0>\;
  input_r_Din_A(6) <= \<const0>\;
  input_r_Din_A(5) <= \<const0>\;
  input_r_Din_A(4) <= \<const0>\;
  input_r_Din_A(3) <= \<const0>\;
  input_r_Din_A(2) <= \<const0>\;
  input_r_Din_A(1) <= \<const0>\;
  input_r_Din_A(0) <= \<const0>\;
  input_r_EN_A <= \<const0>\;
  input_r_Rst_A <= \^output_r_rst_a\;
  input_r_WEN_A(3) <= \<const0>\;
  input_r_WEN_A(2) <= \<const0>\;
  input_r_WEN_A(1) <= \<const0>\;
  input_r_WEN_A(0) <= \<const0>\;
  output_r_Addr_A(31) <= \<const0>\;
  output_r_Addr_A(30) <= \<const0>\;
  output_r_Addr_A(29) <= \<const0>\;
  output_r_Addr_A(28) <= \<const0>\;
  output_r_Addr_A(27) <= \<const0>\;
  output_r_Addr_A(26) <= \<const0>\;
  output_r_Addr_A(25) <= \<const0>\;
  output_r_Addr_A(24) <= \<const0>\;
  output_r_Addr_A(23) <= \<const0>\;
  output_r_Addr_A(22) <= \<const0>\;
  output_r_Addr_A(21) <= \<const0>\;
  output_r_Addr_A(20) <= \<const0>\;
  output_r_Addr_A(19) <= \<const0>\;
  output_r_Addr_A(18) <= \<const0>\;
  output_r_Addr_A(17) <= \<const0>\;
  output_r_Addr_A(16) <= \<const0>\;
  output_r_Addr_A(15) <= \<const0>\;
  output_r_Addr_A(14 downto 2) <= \^output_r_addr_a\(14 downto 2);
  output_r_Addr_A(1) <= \<const0>\;
  output_r_Addr_A(0) <= \<const0>\;
  output_r_Clk_A <= \^ap_clk\;
  output_r_Din_A(31) <= \<const0>\;
  output_r_Din_A(30 downto 0) <= \^output_r_din_a\(30 downto 0);
  output_r_EN_A <= \^output_r_en_a\;
  output_r_Rst_A <= \^output_r_rst_a\;
  output_r_WEN_A(3) <= \^output_r_wen_a\(0);
  output_r_WEN_A(2) <= \^output_r_wen_a\(0);
  output_r_WEN_A(1) <= \^output_r_wen_a\(0);
  output_r_WEN_A(0) <= \^output_r_wen_a\(0);
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
\ap_CS_fsm[0]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2333"
    )
        port map (
      I0 => \^ap_done\,
      I1 => ap_CS_fsm_pp0_stage0,
      I2 => ap_start,
      I3 => \ap_CS_fsm_reg_n_0_[0]\,
      O => ap_NS_fsm(0)
    );
\ap_CS_fsm[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FCCCFCCCFCDCFCFC"
    )
        port map (
      I0 => exitcond_flatten1_fu_157_p2,
      I1 => \ap_CS_fsm[1]_i_2_n_0\,
      I2 => ap_CS_fsm_pp0_stage0,
      I3 => \ap_CS_fsm_reg_n_0_[0]\,
      I4 => ap_enable_reg_pp0_iter0,
      I5 => \^output_r_en_a\,
      O => ap_NS_fsm(1)
    );
\ap_CS_fsm[1]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F888"
    )
        port map (
      I0 => ap_CS_fsm_pp0_stage0,
      I1 => ap_enable_reg_pp0_iter1_reg_n_0,
      I2 => \ap_CS_fsm_reg_n_0_[0]\,
      I3 => ap_start,
      O => \ap_CS_fsm[1]_i_2_n_0\
    );
\ap_CS_fsm[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0F080000"
    )
        port map (
      I0 => exitcond_flatten1_fu_157_p2,
      I1 => ap_enable_reg_pp0_iter0,
      I2 => ap_enable_reg_pp0_iter1_reg_n_0,
      I3 => \^output_r_en_a\,
      I4 => ap_CS_fsm_pp0_stage0,
      O => ap_NS_fsm(2)
    );
\ap_CS_fsm[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0020000000000000"
    )
        port map (
      I0 => \ap_CS_fsm[2]_i_3_n_0\,
      I1 => indvar_flatten1_reg_102_reg(10),
      I2 => indvar_flatten1_reg_102_reg(11),
      I3 => indvar_flatten1_reg_102_reg(8),
      I4 => indvar_flatten1_reg_102_reg(9),
      I5 => \ap_CS_fsm[2]_i_4_n_0\,
      O => exitcond_flatten1_fu_157_p2
    );
\ap_CS_fsm[2]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => indvar_flatten1_reg_102_reg(7),
      I1 => indvar_flatten1_reg_102_reg(6),
      I2 => indvar_flatten1_reg_102_reg(5),
      I3 => indvar_flatten1_reg_102_reg(4),
      O => \ap_CS_fsm[2]_i_3_n_0\
    );
\ap_CS_fsm[2]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => indvar_flatten1_reg_102_reg(1),
      I1 => indvar_flatten1_reg_102_reg(0),
      I2 => indvar_flatten1_reg_102_reg(3),
      I3 => indvar_flatten1_reg_102_reg(2),
      O => \ap_CS_fsm[2]_i_4_n_0\
    );
\ap_CS_fsm_reg[0]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => \^ap_clk\,
      CE => '1',
      D => ap_NS_fsm(0),
      Q => \ap_CS_fsm_reg_n_0_[0]\,
      S => \^output_r_rst_a\
    );
\ap_CS_fsm_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => \^ap_clk\,
      CE => '1',
      D => ap_NS_fsm(1),
      Q => ap_CS_fsm_pp0_stage0,
      R => \^output_r_rst_a\
    );
\ap_CS_fsm_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => \^ap_clk\,
      CE => '1',
      D => ap_NS_fsm(2),
      Q => \^ap_done\,
      R => \^output_r_rst_a\
    );
ap_enable_reg_pp0_iter0_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000A888A888A888"
    )
        port map (
      I0 => ap_rst_n,
      I1 => ap_enable_reg_pp0_iter0,
      I2 => \ap_CS_fsm_reg_n_0_[0]\,
      I3 => ap_start,
      I4 => exitcond_flatten1_fu_157_p2,
      I5 => ap_CS_fsm_pp0_stage0,
      O => ap_enable_reg_pp0_iter0_i_1_n_0
    );
ap_enable_reg_pp0_iter0_reg: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => \^ap_clk\,
      CE => '1',
      D => ap_enable_reg_pp0_iter0_i_1_n_0,
      Q => ap_enable_reg_pp0_iter0,
      R => '0'
    );
ap_enable_reg_pp0_iter1_i_1: unisim.vcomponents.LUT3
    generic map(
      INIT => X"08"
    )
        port map (
      I0 => ap_enable_reg_pp0_iter0,
      I1 => ap_rst_n,
      I2 => exitcond_flatten1_fu_157_p2,
      O => ap_enable_reg_pp0_iter1_i_1_n_0
    );
ap_enable_reg_pp0_iter1_reg: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => \^ap_clk\,
      CE => '1',
      D => ap_enable_reg_pp0_iter1_i_1_n_0,
      Q => ap_enable_reg_pp0_iter1_reg_n_0,
      R => '0'
    );
ap_enable_reg_pp0_iter2_reg: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => \^ap_clk\,
      CE => '1',
      D => ap_enable_reg_pp0_iter1_reg_n_0,
      Q => \^output_r_en_a\,
      R => \^output_r_rst_a\
    );
ap_idle_INST_0: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \ap_CS_fsm_reg_n_0_[0]\,
      I1 => ap_start,
      O => ap_idle
    );
\bias_Addr_A[2]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"656666666A666666"
    )
        port map (
      I0 => exitcond_flatten7_fu_175_p2,
      I1 => \filter_index_reg_113_reg_n_0_[0]\,
      I2 => \exitcond_flatten1_reg_331_reg_n_0_[0]\,
      I3 => ap_enable_reg_pp0_iter1_reg_n_0,
      I4 => ap_CS_fsm_pp0_stage0,
      I5 => \tmp_mid2_v_reg_340_reg__0\(0),
      O => \^bias_addr_a\(2)
    );
\bias_Addr_A[3]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"77775FA088885FA0"
    )
        port map (
      I0 => exitcond_flatten7_fu_175_p2,
      I1 => \tmp_mid2_v_reg_340_reg__0\(0),
      I2 => \filter_index_reg_113_reg_n_0_[0]\,
      I3 => \filter_index_reg_113_reg_n_0_[1]\,
      I4 => filter_index_reg_1130,
      I5 => \tmp_mid2_v_reg_340_reg__0\(1),
      O => \^bias_addr_a\(3)
    );
\bias_Addr_A[4]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7F777FFF80888000"
    )
        port map (
      I0 => ap_phi_mux_filter_index_phi_fu_117_p4(0),
      I1 => exitcond_flatten7_fu_175_p2,
      I2 => \tmp_mid2_v_reg_340_reg__0\(1),
      I3 => filter_index_reg_1130,
      I4 => \filter_index_reg_113_reg_n_0_[1]\,
      I5 => ap_phi_mux_filter_index_phi_fu_117_p4(2),
      O => \^bias_addr_a\(4)
    );
\bias_Addr_A[4]_INST_0_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFBF0080"
    )
        port map (
      I0 => \tmp_mid2_v_reg_340_reg__0\(0),
      I1 => ap_CS_fsm_pp0_stage0,
      I2 => ap_enable_reg_pp0_iter1_reg_n_0,
      I3 => \exitcond_flatten1_reg_331_reg_n_0_[0]\,
      I4 => \filter_index_reg_113_reg_n_0_[0]\,
      O => ap_phi_mux_filter_index_phi_fu_117_p4(0)
    );
\bias_Addr_A[4]_INST_0_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00100000"
    )
        port map (
      I0 => \indvar_flatten_reg_124_reg__0\(4),
      I1 => \indvar_flatten_reg_124_reg__0\(5),
      I2 => \indvar_flatten_reg_124_reg__0\(6),
      I3 => \indvar_flatten_reg_124_reg__0\(7),
      I4 => \bias_Addr_A[7]_INST_0_i_5_n_0\,
      O => exitcond_flatten7_fu_175_p2
    );
\bias_Addr_A[4]_INST_0_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFBF0080"
    )
        port map (
      I0 => \tmp_mid2_v_reg_340_reg__0\(2),
      I1 => ap_CS_fsm_pp0_stage0,
      I2 => ap_enable_reg_pp0_iter1_reg_n_0,
      I3 => \exitcond_flatten1_reg_331_reg_n_0_[0]\,
      I4 => \filter_index_reg_113_reg_n_0_[2]\,
      O => ap_phi_mux_filter_index_phi_fu_117_p4(2)
    );
\bias_Addr_A[5]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"77775FA088885FA0"
    )
        port map (
      I0 => \bias_Addr_A[5]_INST_0_i_1_n_0\,
      I1 => \tmp_mid2_v_reg_340_reg__0\(2),
      I2 => \filter_index_reg_113_reg_n_0_[2]\,
      I3 => \filter_index_reg_113_reg_n_0_[3]\,
      I4 => filter_index_reg_1130,
      I5 => \tmp_mid2_v_reg_340_reg__0\(3),
      O => \^bias_addr_a\(5)
    );
\bias_Addr_A[5]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"E200000000000000"
    )
        port map (
      I0 => \filter_index_reg_113_reg_n_0_[1]\,
      I1 => filter_index_reg_1130,
      I2 => \tmp_mid2_v_reg_340_reg__0\(1),
      I3 => \bias_Addr_A[7]_INST_0_i_4_n_0\,
      I4 => \bias_Addr_A[7]_INST_0_i_5_n_0\,
      I5 => ap_phi_mux_filter_index_phi_fu_117_p4(0),
      O => \bias_Addr_A[5]_INST_0_i_1_n_0\
    );
\bias_Addr_A[6]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F5F5F30C0A0AF30C"
    )
        port map (
      I0 => \tmp_mid2_v_reg_340_reg__0\(3),
      I1 => \filter_index_reg_113_reg_n_0_[3]\,
      I2 => \bias_Addr_A[6]_INST_0_i_1_n_0\,
      I3 => \filter_index_reg_113_reg_n_0_[4]\,
      I4 => filter_index_reg_1130,
      I5 => \tmp_mid2_v_reg_340_reg__0\(4),
      O => \^bias_addr_a\(6)
    );
\bias_Addr_A[6]_INST_0_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFFFFFF"
    )
        port map (
      I0 => ap_phi_mux_filter_index_phi_fu_117_p4(2),
      I1 => ap_phi_mux_filter_index_phi_fu_117_p4(0),
      I2 => \bias_Addr_A[7]_INST_0_i_5_n_0\,
      I3 => \bias_Addr_A[7]_INST_0_i_4_n_0\,
      I4 => ap_phi_mux_filter_index_phi_fu_117_p4(1),
      O => \bias_Addr_A[6]_INST_0_i_1_n_0\
    );
\bias_Addr_A[7]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F5F5F30C0A0AF30C"
    )
        port map (
      I0 => \tmp_mid2_v_reg_340_reg__0\(4),
      I1 => \filter_index_reg_113_reg_n_0_[4]\,
      I2 => \bias_Addr_A[7]_INST_0_i_1_n_0\,
      I3 => \filter_index_reg_113_reg_n_0_[5]\,
      I4 => filter_index_reg_1130,
      I5 => \tmp_mid2_v_reg_340_reg__0\(5),
      O => \^bias_addr_a\(7)
    );
\bias_Addr_A[7]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFFFFFFFFFF"
    )
        port map (
      I0 => ap_phi_mux_filter_index_phi_fu_117_p4(1),
      I1 => \bias_Addr_A[7]_INST_0_i_4_n_0\,
      I2 => \bias_Addr_A[7]_INST_0_i_5_n_0\,
      I3 => ap_phi_mux_filter_index_phi_fu_117_p4(0),
      I4 => ap_phi_mux_filter_index_phi_fu_117_p4(2),
      I5 => ap_phi_mux_filter_index_phi_fu_117_p4(3),
      O => \bias_Addr_A[7]_INST_0_i_1_n_0\
    );
\bias_Addr_A[7]_INST_0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"08"
    )
        port map (
      I0 => ap_CS_fsm_pp0_stage0,
      I1 => ap_enable_reg_pp0_iter1_reg_n_0,
      I2 => \exitcond_flatten1_reg_331_reg_n_0_[0]\,
      O => filter_index_reg_1130
    );
\bias_Addr_A[7]_INST_0_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFBF0080"
    )
        port map (
      I0 => \tmp_mid2_v_reg_340_reg__0\(1),
      I1 => ap_CS_fsm_pp0_stage0,
      I2 => ap_enable_reg_pp0_iter1_reg_n_0,
      I3 => \exitcond_flatten1_reg_331_reg_n_0_[0]\,
      I4 => \filter_index_reg_113_reg_n_0_[1]\,
      O => ap_phi_mux_filter_index_phi_fu_117_p4(1)
    );
\bias_Addr_A[7]_INST_0_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0004"
    )
        port map (
      I0 => \indvar_flatten_reg_124_reg__0\(7),
      I1 => \indvar_flatten_reg_124_reg__0\(6),
      I2 => \indvar_flatten_reg_124_reg__0\(5),
      I3 => \indvar_flatten_reg_124_reg__0\(4),
      O => \bias_Addr_A[7]_INST_0_i_4_n_0\
    );
\bias_Addr_A[7]_INST_0_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => \indvar_flatten_reg_124_reg__0\(1),
      I1 => \indvar_flatten_reg_124_reg__0\(0),
      I2 => \indvar_flatten_reg_124_reg__0\(3),
      I3 => \indvar_flatten_reg_124_reg__0\(2),
      O => \bias_Addr_A[7]_INST_0_i_5_n_0\
    );
\bias_Addr_A[7]_INST_0_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFBF0080"
    )
        port map (
      I0 => \tmp_mid2_v_reg_340_reg__0\(3),
      I1 => ap_CS_fsm_pp0_stage0,
      I2 => ap_enable_reg_pp0_iter1_reg_n_0,
      I3 => \exitcond_flatten1_reg_331_reg_n_0_[0]\,
      I4 => \filter_index_reg_113_reg_n_0_[3]\,
      O => ap_phi_mux_filter_index_phi_fu_117_p4(3)
    );
bias_EN_A_INST_0: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => ap_enable_reg_pp0_iter0,
      I1 => ap_CS_fsm_pp0_stage0,
      O => bias_EN_A
    );
\exitcond_flatten1_reg_331[0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => exitcond_flatten1_fu_157_p2,
      I1 => ap_CS_fsm_pp0_stage0,
      I2 => \exitcond_flatten1_reg_331_reg_n_0_[0]\,
      O => \exitcond_flatten1_reg_331[0]_i_1_n_0\
    );
\exitcond_flatten1_reg_331_pp0_iter1_reg[0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \exitcond_flatten1_reg_331_reg_n_0_[0]\,
      I1 => ap_CS_fsm_pp0_stage0,
      I2 => exitcond_flatten1_reg_331_pp0_iter1_reg,
      O => \exitcond_flatten1_reg_331_pp0_iter1_reg[0]_i_1_n_0\
    );
\exitcond_flatten1_reg_331_pp0_iter1_reg_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => '1',
      D => \exitcond_flatten1_reg_331_pp0_iter1_reg[0]_i_1_n_0\,
      Q => exitcond_flatten1_reg_331_pp0_iter1_reg,
      R => '0'
    );
\exitcond_flatten1_reg_331_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => '1',
      D => \exitcond_flatten1_reg_331[0]_i_1_n_0\,
      Q => \exitcond_flatten1_reg_331_reg_n_0_[0]\,
      R => '0'
    );
\filter_index_reg_113[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80888888"
    )
        port map (
      I0 => \ap_CS_fsm_reg_n_0_[0]\,
      I1 => ap_start,
      I2 => \exitcond_flatten1_reg_331_reg_n_0_[0]\,
      I3 => ap_enable_reg_pp0_iter1_reg_n_0,
      I4 => ap_CS_fsm_pp0_stage0,
      O => filter_index_reg_113
    );
\filter_index_reg_113_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => filter_index_reg_1130,
      D => \tmp_mid2_v_reg_340_reg__0\(0),
      Q => \filter_index_reg_113_reg_n_0_[0]\,
      R => filter_index_reg_113
    );
\filter_index_reg_113_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => filter_index_reg_1130,
      D => \tmp_mid2_v_reg_340_reg__0\(1),
      Q => \filter_index_reg_113_reg_n_0_[1]\,
      R => filter_index_reg_113
    );
\filter_index_reg_113_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => filter_index_reg_1130,
      D => \tmp_mid2_v_reg_340_reg__0\(2),
      Q => \filter_index_reg_113_reg_n_0_[2]\,
      R => filter_index_reg_113
    );
\filter_index_reg_113_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => filter_index_reg_1130,
      D => \tmp_mid2_v_reg_340_reg__0\(3),
      Q => \filter_index_reg_113_reg_n_0_[3]\,
      R => filter_index_reg_113
    );
\filter_index_reg_113_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => filter_index_reg_1130,
      D => \tmp_mid2_v_reg_340_reg__0\(4),
      Q => \filter_index_reg_113_reg_n_0_[4]\,
      R => filter_index_reg_113
    );
\filter_index_reg_113_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => filter_index_reg_1130,
      D => \tmp_mid2_v_reg_340_reg__0\(5),
      Q => \filter_index_reg_113_reg_n_0_[5]\,
      R => filter_index_reg_113
    );
\indvar_flatten1_reg_102[0]_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => indvar_flatten1_reg_102_reg(0),
      O => \indvar_flatten1_reg_102[0]_i_2_n_0\
    );
\indvar_flatten1_reg_102_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => \indvar_flatten1_reg_102_reg[0]_i_1_n_7\,
      Q => indvar_flatten1_reg_102_reg(0),
      R => indvar_flatten1_reg_102
    );
\indvar_flatten1_reg_102_reg[0]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \indvar_flatten1_reg_102_reg[0]_i_1_n_0\,
      CO(2) => \indvar_flatten1_reg_102_reg[0]_i_1_n_1\,
      CO(1) => \indvar_flatten1_reg_102_reg[0]_i_1_n_2\,
      CO(0) => \indvar_flatten1_reg_102_reg[0]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0001",
      O(3) => \indvar_flatten1_reg_102_reg[0]_i_1_n_4\,
      O(2) => \indvar_flatten1_reg_102_reg[0]_i_1_n_5\,
      O(1) => \indvar_flatten1_reg_102_reg[0]_i_1_n_6\,
      O(0) => \indvar_flatten1_reg_102_reg[0]_i_1_n_7\,
      S(3 downto 1) => indvar_flatten1_reg_102_reg(3 downto 1),
      S(0) => \indvar_flatten1_reg_102[0]_i_2_n_0\
    );
\indvar_flatten1_reg_102_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => \indvar_flatten1_reg_102_reg[8]_i_1_n_5\,
      Q => indvar_flatten1_reg_102_reg(10),
      R => indvar_flatten1_reg_102
    );
\indvar_flatten1_reg_102_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => \indvar_flatten1_reg_102_reg[8]_i_1_n_4\,
      Q => indvar_flatten1_reg_102_reg(11),
      R => indvar_flatten1_reg_102
    );
\indvar_flatten1_reg_102_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => \indvar_flatten1_reg_102_reg[0]_i_1_n_6\,
      Q => indvar_flatten1_reg_102_reg(1),
      R => indvar_flatten1_reg_102
    );
\indvar_flatten1_reg_102_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => \indvar_flatten1_reg_102_reg[0]_i_1_n_5\,
      Q => indvar_flatten1_reg_102_reg(2),
      R => indvar_flatten1_reg_102
    );
\indvar_flatten1_reg_102_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => \indvar_flatten1_reg_102_reg[0]_i_1_n_4\,
      Q => indvar_flatten1_reg_102_reg(3),
      R => indvar_flatten1_reg_102
    );
\indvar_flatten1_reg_102_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => \indvar_flatten1_reg_102_reg[4]_i_1_n_7\,
      Q => indvar_flatten1_reg_102_reg(4),
      R => indvar_flatten1_reg_102
    );
\indvar_flatten1_reg_102_reg[4]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \indvar_flatten1_reg_102_reg[0]_i_1_n_0\,
      CO(3) => \indvar_flatten1_reg_102_reg[4]_i_1_n_0\,
      CO(2) => \indvar_flatten1_reg_102_reg[4]_i_1_n_1\,
      CO(1) => \indvar_flatten1_reg_102_reg[4]_i_1_n_2\,
      CO(0) => \indvar_flatten1_reg_102_reg[4]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \indvar_flatten1_reg_102_reg[4]_i_1_n_4\,
      O(2) => \indvar_flatten1_reg_102_reg[4]_i_1_n_5\,
      O(1) => \indvar_flatten1_reg_102_reg[4]_i_1_n_6\,
      O(0) => \indvar_flatten1_reg_102_reg[4]_i_1_n_7\,
      S(3 downto 0) => indvar_flatten1_reg_102_reg(7 downto 4)
    );
\indvar_flatten1_reg_102_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => \indvar_flatten1_reg_102_reg[4]_i_1_n_6\,
      Q => indvar_flatten1_reg_102_reg(5),
      R => indvar_flatten1_reg_102
    );
\indvar_flatten1_reg_102_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => \indvar_flatten1_reg_102_reg[4]_i_1_n_5\,
      Q => indvar_flatten1_reg_102_reg(6),
      R => indvar_flatten1_reg_102
    );
\indvar_flatten1_reg_102_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => \indvar_flatten1_reg_102_reg[4]_i_1_n_4\,
      Q => indvar_flatten1_reg_102_reg(7),
      R => indvar_flatten1_reg_102
    );
\indvar_flatten1_reg_102_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => \indvar_flatten1_reg_102_reg[8]_i_1_n_7\,
      Q => indvar_flatten1_reg_102_reg(8),
      R => indvar_flatten1_reg_102
    );
\indvar_flatten1_reg_102_reg[8]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \indvar_flatten1_reg_102_reg[4]_i_1_n_0\,
      CO(3) => \NLW_indvar_flatten1_reg_102_reg[8]_i_1_CO_UNCONNECTED\(3),
      CO(2) => \indvar_flatten1_reg_102_reg[8]_i_1_n_1\,
      CO(1) => \indvar_flatten1_reg_102_reg[8]_i_1_n_2\,
      CO(0) => \indvar_flatten1_reg_102_reg[8]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \indvar_flatten1_reg_102_reg[8]_i_1_n_4\,
      O(2) => \indvar_flatten1_reg_102_reg[8]_i_1_n_5\,
      O(1) => \indvar_flatten1_reg_102_reg[8]_i_1_n_6\,
      O(0) => \indvar_flatten1_reg_102_reg[8]_i_1_n_7\,
      S(3 downto 0) => indvar_flatten1_reg_102_reg(11 downto 8)
    );
\indvar_flatten1_reg_102_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => \indvar_flatten1_reg_102_reg[8]_i_1_n_6\,
      Q => indvar_flatten1_reg_102_reg(9),
      R => indvar_flatten1_reg_102
    );
\indvar_flatten_reg_124[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => exitcond_flatten7_fu_175_p2,
      I1 => \indvar_flatten_reg_124_reg__0\(0),
      O => indvar_flatten_next_fu_260_p3(0)
    );
\indvar_flatten_reg_124[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"14"
    )
        port map (
      I0 => exitcond_flatten7_fu_175_p2,
      I1 => \indvar_flatten_reg_124_reg__0\(0),
      I2 => \indvar_flatten_reg_124_reg__0\(1),
      O => indvar_flatten_next_fu_260_p3(1)
    );
\indvar_flatten_reg_124[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1540"
    )
        port map (
      I0 => exitcond_flatten7_fu_175_p2,
      I1 => \indvar_flatten_reg_124_reg__0\(0),
      I2 => \indvar_flatten_reg_124_reg__0\(1),
      I3 => \indvar_flatten_reg_124_reg__0\(2),
      O => indvar_flatten_next_fu_260_p3(2)
    );
\indvar_flatten_reg_124[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"15554000"
    )
        port map (
      I0 => exitcond_flatten7_fu_175_p2,
      I1 => \indvar_flatten_reg_124_reg__0\(1),
      I2 => \indvar_flatten_reg_124_reg__0\(0),
      I3 => \indvar_flatten_reg_124_reg__0\(2),
      I4 => \indvar_flatten_reg_124_reg__0\(3),
      O => indvar_flatten_next_fu_260_p3(3)
    );
\indvar_flatten_reg_124[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00007FFF00008000"
    )
        port map (
      I0 => \indvar_flatten_reg_124_reg__0\(3),
      I1 => \indvar_flatten_reg_124_reg__0\(1),
      I2 => \indvar_flatten_reg_124_reg__0\(0),
      I3 => \indvar_flatten_reg_124_reg__0\(2),
      I4 => exitcond_flatten7_fu_175_p2,
      I5 => \indvar_flatten_reg_124_reg__0\(4),
      O => indvar_flatten_next_fu_260_p3(4)
    );
\indvar_flatten_reg_124[5]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"12"
    )
        port map (
      I0 => \indvar_flatten_reg_124[5]_i_2_n_0\,
      I1 => exitcond_flatten7_fu_175_p2,
      I2 => \indvar_flatten_reg_124_reg__0\(5),
      O => indvar_flatten_next_fu_260_p3(5)
    );
\indvar_flatten_reg_124[5]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => \indvar_flatten_reg_124_reg__0\(4),
      I1 => \indvar_flatten_reg_124_reg__0\(2),
      I2 => \indvar_flatten_reg_124_reg__0\(0),
      I3 => \indvar_flatten_reg_124_reg__0\(1),
      I4 => \indvar_flatten_reg_124_reg__0\(3),
      O => \indvar_flatten_reg_124[5]_i_2_n_0\
    );
\indvar_flatten_reg_124[6]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"21"
    )
        port map (
      I0 => \indvar_flatten_reg_124[7]_i_2_n_0\,
      I1 => exitcond_flatten7_fu_175_p2,
      I2 => \indvar_flatten_reg_124_reg__0\(6),
      O => indvar_flatten_next_fu_260_p3(6)
    );
\indvar_flatten_reg_124[7]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0B04"
    )
        port map (
      I0 => \indvar_flatten_reg_124[7]_i_2_n_0\,
      I1 => \indvar_flatten_reg_124_reg__0\(6),
      I2 => exitcond_flatten7_fu_175_p2,
      I3 => \indvar_flatten_reg_124_reg__0\(7),
      O => indvar_flatten_next_fu_260_p3(7)
    );
\indvar_flatten_reg_124[7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFFFFFFFFFF"
    )
        port map (
      I0 => \indvar_flatten_reg_124_reg__0\(3),
      I1 => \indvar_flatten_reg_124_reg__0\(1),
      I2 => \indvar_flatten_reg_124_reg__0\(0),
      I3 => \indvar_flatten_reg_124_reg__0\(2),
      I4 => \indvar_flatten_reg_124_reg__0\(4),
      I5 => \indvar_flatten_reg_124_reg__0\(5),
      O => \indvar_flatten_reg_124[7]_i_2_n_0\
    );
\indvar_flatten_reg_124_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => indvar_flatten_next_fu_260_p3(0),
      Q => \indvar_flatten_reg_124_reg__0\(0),
      R => indvar_flatten1_reg_102
    );
\indvar_flatten_reg_124_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => indvar_flatten_next_fu_260_p3(1),
      Q => \indvar_flatten_reg_124_reg__0\(1),
      R => indvar_flatten1_reg_102
    );
\indvar_flatten_reg_124_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => indvar_flatten_next_fu_260_p3(2),
      Q => \indvar_flatten_reg_124_reg__0\(2),
      R => indvar_flatten1_reg_102
    );
\indvar_flatten_reg_124_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => indvar_flatten_next_fu_260_p3(3),
      Q => \indvar_flatten_reg_124_reg__0\(3),
      R => indvar_flatten1_reg_102
    );
\indvar_flatten_reg_124_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => indvar_flatten_next_fu_260_p3(4),
      Q => \indvar_flatten_reg_124_reg__0\(4),
      R => indvar_flatten1_reg_102
    );
\indvar_flatten_reg_124_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => indvar_flatten_next_fu_260_p3(5),
      Q => \indvar_flatten_reg_124_reg__0\(5),
      R => indvar_flatten1_reg_102
    );
\indvar_flatten_reg_124_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => indvar_flatten_next_fu_260_p3(6),
      Q => \indvar_flatten_reg_124_reg__0\(6),
      R => indvar_flatten1_reg_102
    );
\indvar_flatten_reg_124_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => indvar_flatten_next_fu_260_p3(7),
      Q => \indvar_flatten_reg_124_reg__0\(7),
      R => indvar_flatten1_reg_102
    );
output_r_Rst_A_INST_0: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => ap_rst_n,
      O => \^output_r_rst_a\
    );
\output_r_WEN_A[0]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^output_r_en_a\,
      I1 => exitcond_flatten1_reg_331_pp0_iter1_reg,
      O => \^output_r_wen_a\(0)
    );
\res_1_reg_377[30]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => \exitcond_flatten1_reg_331_reg_n_0_[0]\,
      I1 => ap_CS_fsm_pp0_stage0,
      I2 => \res_1_reg_377_reg[30]_i_2_n_0\,
      O => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377[30]_i_10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(26),
      I1 => bias_Dout_A(27),
      O => \res_1_reg_377[30]_i_10_n_0\
    );
\res_1_reg_377[30]_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(24),
      I1 => bias_Dout_A(25),
      O => \res_1_reg_377[30]_i_11_n_0\
    );
\res_1_reg_377[30]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(22),
      I1 => bias_Dout_A(23),
      O => \res_1_reg_377[30]_i_13_n_0\
    );
\res_1_reg_377[30]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(20),
      I1 => bias_Dout_A(21),
      O => \res_1_reg_377[30]_i_14_n_0\
    );
\res_1_reg_377[30]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(18),
      I1 => bias_Dout_A(19),
      O => \res_1_reg_377[30]_i_15_n_0\
    );
\res_1_reg_377[30]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(16),
      I1 => bias_Dout_A(17),
      O => \res_1_reg_377[30]_i_16_n_0\
    );
\res_1_reg_377[30]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(22),
      I1 => bias_Dout_A(23),
      O => \res_1_reg_377[30]_i_17_n_0\
    );
\res_1_reg_377[30]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(20),
      I1 => bias_Dout_A(21),
      O => \res_1_reg_377[30]_i_18_n_0\
    );
\res_1_reg_377[30]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(18),
      I1 => bias_Dout_A(19),
      O => \res_1_reg_377[30]_i_19_n_0\
    );
\res_1_reg_377[30]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(16),
      I1 => bias_Dout_A(17),
      O => \res_1_reg_377[30]_i_20_n_0\
    );
\res_1_reg_377[30]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(14),
      I1 => bias_Dout_A(15),
      O => \res_1_reg_377[30]_i_22_n_0\
    );
\res_1_reg_377[30]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(12),
      I1 => bias_Dout_A(13),
      O => \res_1_reg_377[30]_i_23_n_0\
    );
\res_1_reg_377[30]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(10),
      I1 => bias_Dout_A(11),
      O => \res_1_reg_377[30]_i_24_n_0\
    );
\res_1_reg_377[30]_i_25\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(8),
      I1 => bias_Dout_A(9),
      O => \res_1_reg_377[30]_i_25_n_0\
    );
\res_1_reg_377[30]_i_26\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(14),
      I1 => bias_Dout_A(15),
      O => \res_1_reg_377[30]_i_26_n_0\
    );
\res_1_reg_377[30]_i_27\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(12),
      I1 => bias_Dout_A(13),
      O => \res_1_reg_377[30]_i_27_n_0\
    );
\res_1_reg_377[30]_i_28\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(10),
      I1 => bias_Dout_A(11),
      O => \res_1_reg_377[30]_i_28_n_0\
    );
\res_1_reg_377[30]_i_29\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(8),
      I1 => bias_Dout_A(9),
      O => \res_1_reg_377[30]_i_29_n_0\
    );
\res_1_reg_377[30]_i_30\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(6),
      I1 => bias_Dout_A(7),
      O => \res_1_reg_377[30]_i_30_n_0\
    );
\res_1_reg_377[30]_i_31\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(4),
      I1 => bias_Dout_A(5),
      O => \res_1_reg_377[30]_i_31_n_0\
    );
\res_1_reg_377[30]_i_32\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(2),
      I1 => bias_Dout_A(3),
      O => \res_1_reg_377[30]_i_32_n_0\
    );
\res_1_reg_377[30]_i_33\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(0),
      I1 => bias_Dout_A(1),
      O => \res_1_reg_377[30]_i_33_n_0\
    );
\res_1_reg_377[30]_i_34\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(6),
      I1 => bias_Dout_A(7),
      O => \res_1_reg_377[30]_i_34_n_0\
    );
\res_1_reg_377[30]_i_35\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(4),
      I1 => bias_Dout_A(5),
      O => \res_1_reg_377[30]_i_35_n_0\
    );
\res_1_reg_377[30]_i_36\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(2),
      I1 => bias_Dout_A(3),
      O => \res_1_reg_377[30]_i_36_n_0\
    );
\res_1_reg_377[30]_i_37\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(0),
      I1 => bias_Dout_A(1),
      O => \res_1_reg_377[30]_i_37_n_0\
    );
\res_1_reg_377[30]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => bias_Dout_A(30),
      I1 => bias_Dout_A(31),
      O => \res_1_reg_377[30]_i_4_n_0\
    );
\res_1_reg_377[30]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(28),
      I1 => bias_Dout_A(29),
      O => \res_1_reg_377[30]_i_5_n_0\
    );
\res_1_reg_377[30]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(26),
      I1 => bias_Dout_A(27),
      O => \res_1_reg_377[30]_i_6_n_0\
    );
\res_1_reg_377[30]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => bias_Dout_A(24),
      I1 => bias_Dout_A(25),
      O => \res_1_reg_377[30]_i_7_n_0\
    );
\res_1_reg_377[30]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(30),
      I1 => bias_Dout_A(31),
      O => \res_1_reg_377[30]_i_8_n_0\
    );
\res_1_reg_377[30]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => bias_Dout_A(28),
      I1 => bias_Dout_A(29),
      O => \res_1_reg_377[30]_i_9_n_0\
    );
\res_1_reg_377_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(0),
      Q => \^output_r_din_a\(0),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(10),
      Q => \^output_r_din_a\(10),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(11),
      Q => \^output_r_din_a\(11),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(12),
      Q => \^output_r_din_a\(12),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(13),
      Q => \^output_r_din_a\(13),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(14),
      Q => \^output_r_din_a\(14),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(15),
      Q => \^output_r_din_a\(15),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(16),
      Q => \^output_r_din_a\(16),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(17),
      Q => \^output_r_din_a\(17),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(18),
      Q => \^output_r_din_a\(18),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(19),
      Q => \^output_r_din_a\(19),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(1),
      Q => \^output_r_din_a\(1),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(20),
      Q => \^output_r_din_a\(20),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(21),
      Q => \^output_r_din_a\(21),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(22),
      Q => \^output_r_din_a\(22),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(23),
      Q => \^output_r_din_a\(23),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(24),
      Q => \^output_r_din_a\(24),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(25),
      Q => \^output_r_din_a\(25),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(26),
      Q => \^output_r_din_a\(26),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(27),
      Q => \^output_r_din_a\(27),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(28),
      Q => \^output_r_din_a\(28),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(29),
      Q => \^output_r_din_a\(29),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(2),
      Q => \^output_r_din_a\(2),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(30),
      Q => \^output_r_din_a\(30),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[30]_i_12\: unisim.vcomponents.CARRY4
     port map (
      CI => \res_1_reg_377_reg[30]_i_21_n_0\,
      CO(3) => \res_1_reg_377_reg[30]_i_12_n_0\,
      CO(2) => \res_1_reg_377_reg[30]_i_12_n_1\,
      CO(1) => \res_1_reg_377_reg[30]_i_12_n_2\,
      CO(0) => \res_1_reg_377_reg[30]_i_12_n_3\,
      CYINIT => '0',
      DI(3) => \res_1_reg_377[30]_i_22_n_0\,
      DI(2) => \res_1_reg_377[30]_i_23_n_0\,
      DI(1) => \res_1_reg_377[30]_i_24_n_0\,
      DI(0) => \res_1_reg_377[30]_i_25_n_0\,
      O(3 downto 0) => \NLW_res_1_reg_377_reg[30]_i_12_O_UNCONNECTED\(3 downto 0),
      S(3) => \res_1_reg_377[30]_i_26_n_0\,
      S(2) => \res_1_reg_377[30]_i_27_n_0\,
      S(1) => \res_1_reg_377[30]_i_28_n_0\,
      S(0) => \res_1_reg_377[30]_i_29_n_0\
    );
\res_1_reg_377_reg[30]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \res_1_reg_377_reg[30]_i_3_n_0\,
      CO(3) => \res_1_reg_377_reg[30]_i_2_n_0\,
      CO(2) => \res_1_reg_377_reg[30]_i_2_n_1\,
      CO(1) => \res_1_reg_377_reg[30]_i_2_n_2\,
      CO(0) => \res_1_reg_377_reg[30]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \res_1_reg_377[30]_i_4_n_0\,
      DI(2) => \res_1_reg_377[30]_i_5_n_0\,
      DI(1) => \res_1_reg_377[30]_i_6_n_0\,
      DI(0) => \res_1_reg_377[30]_i_7_n_0\,
      O(3 downto 0) => \NLW_res_1_reg_377_reg[30]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \res_1_reg_377[30]_i_8_n_0\,
      S(2) => \res_1_reg_377[30]_i_9_n_0\,
      S(1) => \res_1_reg_377[30]_i_10_n_0\,
      S(0) => \res_1_reg_377[30]_i_11_n_0\
    );
\res_1_reg_377_reg[30]_i_21\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \res_1_reg_377_reg[30]_i_21_n_0\,
      CO(2) => \res_1_reg_377_reg[30]_i_21_n_1\,
      CO(1) => \res_1_reg_377_reg[30]_i_21_n_2\,
      CO(0) => \res_1_reg_377_reg[30]_i_21_n_3\,
      CYINIT => '0',
      DI(3) => \res_1_reg_377[30]_i_30_n_0\,
      DI(2) => \res_1_reg_377[30]_i_31_n_0\,
      DI(1) => \res_1_reg_377[30]_i_32_n_0\,
      DI(0) => \res_1_reg_377[30]_i_33_n_0\,
      O(3 downto 0) => \NLW_res_1_reg_377_reg[30]_i_21_O_UNCONNECTED\(3 downto 0),
      S(3) => \res_1_reg_377[30]_i_34_n_0\,
      S(2) => \res_1_reg_377[30]_i_35_n_0\,
      S(1) => \res_1_reg_377[30]_i_36_n_0\,
      S(0) => \res_1_reg_377[30]_i_37_n_0\
    );
\res_1_reg_377_reg[30]_i_3\: unisim.vcomponents.CARRY4
     port map (
      CI => \res_1_reg_377_reg[30]_i_12_n_0\,
      CO(3) => \res_1_reg_377_reg[30]_i_3_n_0\,
      CO(2) => \res_1_reg_377_reg[30]_i_3_n_1\,
      CO(1) => \res_1_reg_377_reg[30]_i_3_n_2\,
      CO(0) => \res_1_reg_377_reg[30]_i_3_n_3\,
      CYINIT => '0',
      DI(3) => \res_1_reg_377[30]_i_13_n_0\,
      DI(2) => \res_1_reg_377[30]_i_14_n_0\,
      DI(1) => \res_1_reg_377[30]_i_15_n_0\,
      DI(0) => \res_1_reg_377[30]_i_16_n_0\,
      O(3 downto 0) => \NLW_res_1_reg_377_reg[30]_i_3_O_UNCONNECTED\(3 downto 0),
      S(3) => \res_1_reg_377[30]_i_17_n_0\,
      S(2) => \res_1_reg_377[30]_i_18_n_0\,
      S(1) => \res_1_reg_377[30]_i_19_n_0\,
      S(0) => \res_1_reg_377[30]_i_20_n_0\
    );
\res_1_reg_377_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(3),
      Q => \^output_r_din_a\(3),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(4),
      Q => \^output_r_din_a\(4),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(5),
      Q => \^output_r_din_a\(5),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(6),
      Q => \^output_r_din_a\(6),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(7),
      Q => \^output_r_din_a\(7),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(8),
      Q => \^output_r_din_a\(8),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\res_1_reg_377_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => bias_Dout_A(9),
      Q => \^output_r_din_a\(9),
      R => \res_1_reg_377[30]_i_1_n_0\
    );
\tmp_5_mid2_reg_351[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A5A6A9AA"
    )
        port map (
      I0 => p_0_in,
      I1 => filter_index_reg_1130,
      I2 => exitcond_flatten7_fu_175_p2,
      I3 => y_reg_135(0),
      I4 => tmp_5_mid2_reg_351(0),
      O => tmp_5_mid2_fu_240_p3(0)
    );
\tmp_5_mid2_reg_351[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000200020002"
    )
        port map (
      I0 => x_reg_146(3),
      I1 => x_reg_146(2),
      I2 => x_reg_146(0),
      I3 => x_reg_146(1),
      I4 => \bias_Addr_A[7]_INST_0_i_5_n_0\,
      I5 => \bias_Addr_A[7]_INST_0_i_4_n_0\,
      O => p_0_in
    );
\tmp_5_mid2_reg_351[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"5A595655"
    )
        port map (
      I0 => \tmp_5_mid2_reg_351[3]_i_3_n_0\,
      I1 => filter_index_reg_1130,
      I2 => exitcond_flatten7_fu_175_p2,
      I3 => y_reg_135(1),
      I4 => tmp_5_mid2_reg_351(1),
      O => tmp_5_mid2_fu_240_p3(1)
    );
\tmp_5_mid2_reg_351[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF5F300000A0C"
    )
        port map (
      I0 => tmp_5_mid2_reg_351(1),
      I1 => y_reg_135(1),
      I2 => exitcond_flatten7_fu_175_p2,
      I3 => filter_index_reg_1130,
      I4 => \tmp_5_mid2_reg_351[3]_i_3_n_0\,
      I5 => y_mid_fu_181_p3(2),
      O => tmp_5_mid2_fu_240_p3(2)
    );
\tmp_5_mid2_reg_351[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"DF20"
    )
        port map (
      I0 => y_mid_fu_181_p3(2),
      I1 => \tmp_5_mid2_reg_351[3]_i_3_n_0\,
      I2 => y_mid_fu_181_p3(1),
      I3 => y_mid_fu_181_p3(3),
      O => tmp_5_mid2_fu_240_p3(3)
    );
\tmp_5_mid2_reg_351[3]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0AAA0CCC"
    )
        port map (
      I0 => tmp_5_mid2_reg_351(2),
      I1 => y_reg_135(2),
      I2 => \bias_Addr_A[7]_INST_0_i_5_n_0\,
      I3 => \bias_Addr_A[7]_INST_0_i_4_n_0\,
      I4 => filter_index_reg_1130,
      O => y_mid_fu_181_p3(2)
    );
\tmp_5_mid2_reg_351[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF1B1B1BFFFFFFFF"
    )
        port map (
      I0 => filter_index_reg_1130,
      I1 => y_reg_135(0),
      I2 => tmp_5_mid2_reg_351(0),
      I3 => \bias_Addr_A[7]_INST_0_i_4_n_0\,
      I4 => \bias_Addr_A[7]_INST_0_i_5_n_0\,
      I5 => \tmp_5_mid2_reg_351[3]_i_6_n_0\,
      O => \tmp_5_mid2_reg_351[3]_i_3_n_0\
    );
\tmp_5_mid2_reg_351[3]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0AAA0CCC"
    )
        port map (
      I0 => tmp_5_mid2_reg_351(1),
      I1 => y_reg_135(1),
      I2 => \bias_Addr_A[7]_INST_0_i_5_n_0\,
      I3 => \bias_Addr_A[7]_INST_0_i_4_n_0\,
      I4 => filter_index_reg_1130,
      O => y_mid_fu_181_p3(1)
    );
\tmp_5_mid2_reg_351[3]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0AAA0CCC"
    )
        port map (
      I0 => tmp_5_mid2_reg_351(3),
      I1 => y_reg_135(3),
      I2 => \bias_Addr_A[7]_INST_0_i_5_n_0\,
      I3 => \bias_Addr_A[7]_INST_0_i_4_n_0\,
      I4 => filter_index_reg_1130,
      O => y_mid_fu_181_p3(3)
    );
\tmp_5_mid2_reg_351[3]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0100"
    )
        port map (
      I0 => x_reg_146(1),
      I1 => x_reg_146(0),
      I2 => x_reg_146(2),
      I3 => x_reg_146(3),
      O => \tmp_5_mid2_reg_351[3]_i_6_n_0\
    );
\tmp_5_mid2_reg_351_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => tmp_5_mid2_fu_240_p3(0),
      Q => tmp_5_mid2_reg_351(0),
      R => '0'
    );
\tmp_5_mid2_reg_351_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => tmp_5_mid2_fu_240_p3(1),
      Q => tmp_5_mid2_reg_351(1),
      R => '0'
    );
\tmp_5_mid2_reg_351_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => tmp_5_mid2_fu_240_p3(2),
      Q => tmp_5_mid2_reg_351(2),
      R => '0'
    );
\tmp_5_mid2_reg_351_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => tmp_5_mid2_fu_240_p3(3),
      Q => tmp_5_mid2_reg_351(3),
      R => '0'
    );
\tmp_mid2_v_reg_340_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => \^bias_addr_a\(2),
      Q => \tmp_mid2_v_reg_340_reg__0\(0),
      R => '0'
    );
\tmp_mid2_v_reg_340_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => \^bias_addr_a\(3),
      Q => \tmp_mid2_v_reg_340_reg__0\(1),
      R => '0'
    );
\tmp_mid2_v_reg_340_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => \^bias_addr_a\(4),
      Q => \tmp_mid2_v_reg_340_reg__0\(2),
      R => '0'
    );
\tmp_mid2_v_reg_340_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => \^bias_addr_a\(5),
      Q => \tmp_mid2_v_reg_340_reg__0\(3),
      R => '0'
    );
\tmp_mid2_v_reg_340_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => \^bias_addr_a\(6),
      Q => \tmp_mid2_v_reg_340_reg__0\(4),
      R => '0'
    );
\tmp_mid2_v_reg_340_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => \^bias_addr_a\(7),
      Q => \tmp_mid2_v_reg_340_reg__0\(5),
      R => '0'
    );
\tmp_s_reg_372[12]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => ap_CS_fsm_pp0_stage0,
      I1 => \exitcond_flatten1_reg_331_reg_n_0_[0]\,
      O => exitcond_flatten1_reg_331
    );
\tmp_s_reg_372[12]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => \tmp_mid2_v_reg_340_reg__0\(3),
      I1 => \tmp_mid2_v_reg_340_reg__0\(4),
      I2 => \tmp_mid2_v_reg_340_reg__0\(5),
      I3 => \tmp_s_reg_372[12]_i_6_n_0\,
      O => tmp_4_fu_282_p2(9)
    );
\tmp_s_reg_372[12]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => \tmp_s_reg_372[12]_i_6_n_0\,
      I1 => \tmp_mid2_v_reg_340_reg__0\(3),
      I2 => \tmp_mid2_v_reg_340_reg__0\(4),
      I3 => \tmp_mid2_v_reg_340_reg__0\(5),
      O => tmp_4_fu_282_p2(8)
    );
\tmp_s_reg_372[12]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFF80000000"
    )
        port map (
      I0 => \tmp_mid2_v_reg_340_reg__0\(3),
      I1 => \tmp_mid2_v_reg_340_reg__0\(1),
      I2 => tmp_5_mid2_reg_351(3),
      I3 => \tmp_mid2_v_reg_340_reg__0\(0),
      I4 => \tmp_mid2_v_reg_340_reg__0\(2),
      I5 => \tmp_mid2_v_reg_340_reg__0\(4),
      O => tmp_4_fu_282_p2(7)
    );
\tmp_s_reg_372[12]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => \tmp_mid2_v_reg_340_reg__0\(1),
      I1 => tmp_5_mid2_reg_351(3),
      I2 => \tmp_mid2_v_reg_340_reg__0\(0),
      I3 => \tmp_mid2_v_reg_340_reg__0\(2),
      O => \tmp_s_reg_372[12]_i_6_n_0\
    );
\tmp_s_reg_372[5]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => tmp_5_mid2_reg_351(0),
      I1 => x_mid2_reg_346(3),
      O => \tmp_s_reg_372[5]_i_2_n_0\
    );
\tmp_s_reg_372[9]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF8000"
    )
        port map (
      I0 => \tmp_mid2_v_reg_340_reg__0\(2),
      I1 => \tmp_mid2_v_reg_340_reg__0\(0),
      I2 => tmp_5_mid2_reg_351(3),
      I3 => \tmp_mid2_v_reg_340_reg__0\(1),
      I4 => \tmp_mid2_v_reg_340_reg__0\(3),
      O => tmp_4_fu_282_p2(6)
    );
\tmp_s_reg_372[9]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => \tmp_mid2_v_reg_340_reg__0\(1),
      I1 => tmp_5_mid2_reg_351(3),
      I2 => \tmp_mid2_v_reg_340_reg__0\(0),
      I3 => \tmp_mid2_v_reg_340_reg__0\(2),
      O => tmp_4_fu_282_p2(5)
    );
\tmp_s_reg_372[9]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \tmp_mid2_v_reg_340_reg__0\(0),
      I1 => tmp_5_mid2_reg_351(3),
      I2 => \tmp_mid2_v_reg_340_reg__0\(1),
      O => tmp_4_fu_282_p2(4)
    );
\tmp_s_reg_372[9]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \tmp_mid2_v_reg_340_reg__0\(0),
      I1 => tmp_5_mid2_reg_351(3),
      O => tmp_4_fu_282_p2(3)
    );
\tmp_s_reg_372_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => x_mid2_reg_346(0),
      Q => \^output_r_addr_a\(2),
      R => '0'
    );
\tmp_s_reg_372_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => tmp_s_fu_299_p2(10),
      Q => \^output_r_addr_a\(12),
      R => '0'
    );
\tmp_s_reg_372_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => tmp_s_fu_299_p2(11),
      Q => \^output_r_addr_a\(13),
      R => '0'
    );
\tmp_s_reg_372_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => tmp_s_fu_299_p2(12),
      Q => \^output_r_addr_a\(14),
      R => '0'
    );
\tmp_s_reg_372_reg[12]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \tmp_s_reg_372_reg[9]_i_1_n_0\,
      CO(3 downto 2) => \NLW_tmp_s_reg_372_reg[12]_i_2_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \tmp_s_reg_372_reg[12]_i_2_n_2\,
      CO(0) => \tmp_s_reg_372_reg[12]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \NLW_tmp_s_reg_372_reg[12]_i_2_O_UNCONNECTED\(3),
      O(2 downto 0) => tmp_s_fu_299_p2(12 downto 10),
      S(3) => '0',
      S(2 downto 0) => tmp_4_fu_282_p2(9 downto 7)
    );
\tmp_s_reg_372_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => x_mid2_reg_346(1),
      Q => \^output_r_addr_a\(3),
      R => '0'
    );
\tmp_s_reg_372_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => tmp_s_fu_299_p2(2),
      Q => \^output_r_addr_a\(4),
      R => '0'
    );
\tmp_s_reg_372_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => tmp_s_fu_299_p2(3),
      Q => \^output_r_addr_a\(5),
      R => '0'
    );
\tmp_s_reg_372_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => tmp_s_fu_299_p2(4),
      Q => \^output_r_addr_a\(6),
      R => '0'
    );
\tmp_s_reg_372_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => tmp_s_fu_299_p2(5),
      Q => \^output_r_addr_a\(7),
      R => '0'
    );
\tmp_s_reg_372_reg[5]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \tmp_s_reg_372_reg[5]_i_1_n_0\,
      CO(2) => \tmp_s_reg_372_reg[5]_i_1_n_1\,
      CO(1) => \tmp_s_reg_372_reg[5]_i_1_n_2\,
      CO(0) => \tmp_s_reg_372_reg[5]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => tmp_5_mid2_reg_351(0),
      DI(0) => '0',
      O(3 downto 0) => tmp_s_fu_299_p2(5 downto 2),
      S(3 downto 2) => tmp_5_mid2_reg_351(2 downto 1),
      S(1) => \tmp_s_reg_372[5]_i_2_n_0\,
      S(0) => x_mid2_reg_346(2)
    );
\tmp_s_reg_372_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => tmp_s_fu_299_p2(6),
      Q => \^output_r_addr_a\(8),
      R => '0'
    );
\tmp_s_reg_372_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => tmp_s_fu_299_p2(7),
      Q => \^output_r_addr_a\(9),
      R => '0'
    );
\tmp_s_reg_372_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => tmp_s_fu_299_p2(8),
      Q => \^output_r_addr_a\(10),
      R => '0'
    );
\tmp_s_reg_372_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => exitcond_flatten1_reg_331,
      D => tmp_s_fu_299_p2(9),
      Q => \^output_r_addr_a\(11),
      R => '0'
    );
\tmp_s_reg_372_reg[9]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \tmp_s_reg_372_reg[5]_i_1_n_0\,
      CO(3) => \tmp_s_reg_372_reg[9]_i_1_n_0\,
      CO(2) => \tmp_s_reg_372_reg[9]_i_1_n_1\,
      CO(1) => \tmp_s_reg_372_reg[9]_i_1_n_2\,
      CO(0) => \tmp_s_reg_372_reg[9]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => tmp_s_fu_299_p2(9 downto 6),
      S(3 downto 0) => tmp_4_fu_282_p2(6 downto 3)
    );
\x_mid2_reg_346[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"4"
    )
        port map (
      I0 => exitcond_flatten7_fu_175_p2,
      I1 => x_reg_146(0),
      O => x_mid2_fu_232_p3(0)
    );
\x_mid2_reg_346[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"4"
    )
        port map (
      I0 => exitcond_flatten7_fu_175_p2,
      I1 => x_reg_146(1),
      O => x_mid2_fu_232_p3(1)
    );
\x_mid2_reg_346[2]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"4"
    )
        port map (
      I0 => exitcond_flatten7_fu_175_p2,
      I1 => x_reg_146(2),
      O => x_mid2_fu_232_p3(2)
    );
\x_mid2_reg_346[3]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => ap_CS_fsm_pp0_stage0,
      I1 => exitcond_flatten1_fu_157_p2,
      O => x_mid2_reg_3460
    );
\x_mid2_reg_346[3]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55540000"
    )
        port map (
      I0 => exitcond_flatten7_fu_175_p2,
      I1 => x_reg_146(2),
      I2 => x_reg_146(0),
      I3 => x_reg_146(1),
      I4 => x_reg_146(3),
      O => x_mid2_fu_232_p3(3)
    );
\x_mid2_reg_346_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => x_mid2_reg_3460,
      D => x_mid2_fu_232_p3(0),
      Q => x_mid2_reg_346(0),
      R => '0'
    );
\x_mid2_reg_346_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => x_mid2_reg_3460,
      D => x_mid2_fu_232_p3(1),
      Q => x_mid2_reg_346(1),
      R => '0'
    );
\x_mid2_reg_346_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => x_mid2_reg_3460,
      D => x_mid2_fu_232_p3(2),
      Q => x_mid2_reg_346(2),
      R => '0'
    );
\x_mid2_reg_346_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => x_mid2_reg_3460,
      D => x_mid2_fu_232_p3(3),
      Q => x_mid2_reg_346(3),
      R => '0'
    );
\x_reg_146[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"D"
    )
        port map (
      I0 => x_reg_146(0),
      I1 => exitcond_flatten7_fu_175_p2,
      O => x_1_fu_248_p2(0)
    );
\x_reg_146[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"06"
    )
        port map (
      I0 => x_reg_146(1),
      I1 => x_reg_146(0),
      I2 => exitcond_flatten7_fu_175_p2,
      O => x_1_fu_248_p2(1)
    );
\x_reg_146[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"006A"
    )
        port map (
      I0 => x_reg_146(2),
      I1 => x_reg_146(1),
      I2 => x_reg_146(0),
      I3 => exitcond_flatten7_fu_175_p2,
      O => x_1_fu_248_p2(2)
    );
\x_reg_146[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"DF000000"
    )
        port map (
      I0 => ap_enable_reg_pp0_iter0,
      I1 => exitcond_flatten1_fu_157_p2,
      I2 => ap_CS_fsm_pp0_stage0,
      I3 => \ap_CS_fsm_reg_n_0_[0]\,
      I4 => ap_start,
      O => indvar_flatten1_reg_102
    );
\x_reg_146[3]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"20"
    )
        port map (
      I0 => ap_enable_reg_pp0_iter0,
      I1 => exitcond_flatten1_fu_157_p2,
      I2 => ap_CS_fsm_pp0_stage0,
      O => indvar_flatten1_reg_1020
    );
\x_reg_146[3]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00006AA8"
    )
        port map (
      I0 => x_reg_146(3),
      I1 => x_reg_146(1),
      I2 => x_reg_146(0),
      I3 => x_reg_146(2),
      I4 => exitcond_flatten7_fu_175_p2,
      O => x_1_fu_248_p2(3)
    );
\x_reg_146_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => x_1_fu_248_p2(0),
      Q => x_reg_146(0),
      R => indvar_flatten1_reg_102
    );
\x_reg_146_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => x_1_fu_248_p2(1),
      Q => x_reg_146(1),
      R => indvar_flatten1_reg_102
    );
\x_reg_146_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => x_1_fu_248_p2(2),
      Q => x_reg_146(2),
      R => indvar_flatten1_reg_102
    );
\x_reg_146_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => indvar_flatten1_reg_1020,
      D => x_1_fu_248_p2(3),
      Q => x_reg_146(3),
      R => indvar_flatten1_reg_102
    );
\y_reg_135_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => filter_index_reg_1130,
      D => tmp_5_mid2_reg_351(0),
      Q => y_reg_135(0),
      R => filter_index_reg_113
    );
\y_reg_135_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => filter_index_reg_1130,
      D => tmp_5_mid2_reg_351(1),
      Q => y_reg_135(1),
      R => filter_index_reg_113
    );
\y_reg_135_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => filter_index_reg_1130,
      D => tmp_5_mid2_reg_351(2),
      Q => y_reg_135(2),
      R => filter_index_reg_113
    );
\y_reg_135_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => \^ap_clk\,
      CE => filter_index_reg_1130,
      D => tmp_5_mid2_reg_351(3),
      Q => y_reg_135(3),
      R => filter_index_reg_113
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    ap_clk : in STD_LOGIC;
    ap_rst_n : in STD_LOGIC;
    ap_start : in STD_LOGIC;
    ap_done : out STD_LOGIC;
    ap_idle : out STD_LOGIC;
    ap_ready : out STD_LOGIC;
    input_r_Clk_A : out STD_LOGIC;
    input_r_Rst_A : out STD_LOGIC;
    input_r_EN_A : out STD_LOGIC;
    input_r_WEN_A : out STD_LOGIC_VECTOR ( 3 downto 0 );
    input_r_Addr_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    input_r_Din_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    input_r_Dout_A : in STD_LOGIC_VECTOR ( 31 downto 0 );
    bias_Clk_A : out STD_LOGIC;
    bias_Rst_A : out STD_LOGIC;
    bias_EN_A : out STD_LOGIC;
    bias_WEN_A : out STD_LOGIC_VECTOR ( 3 downto 0 );
    bias_Addr_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    bias_Din_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    bias_Dout_A : in STD_LOGIC_VECTOR ( 31 downto 0 );
    output_r_Clk_A : out STD_LOGIC;
    output_r_Rst_A : out STD_LOGIC;
    output_r_EN_A : out STD_LOGIC;
    output_r_WEN_A : out STD_LOGIC_VECTOR ( 3 downto 0 );
    output_r_Addr_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    output_r_Din_A : out STD_LOGIC_VECTOR ( 31 downto 0 );
    output_r_Dout_A : in STD_LOGIC_VECTOR ( 31 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "zed_Conv2_12x12x20_5x5x40_1_0_1_0,a0_Conv2_12x12x20_5x5x40_1_0,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "HLS";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "a0_Conv2_12x12x20_5x5x40_1_0,Vivado 2018.2";
  attribute hls_module : string;
  attribute hls_module of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  attribute SDX_KERNEL : string;
  attribute SDX_KERNEL of inst : label is "true";
  attribute SDX_KERNEL_SYNTH_INST : string;
  attribute SDX_KERNEL_SYNTH_INST of inst : label is "inst";
  attribute SDX_KERNEL_TYPE : string;
  attribute SDX_KERNEL_TYPE of inst : label is "hls";
  attribute ap_ST_fsm_pp0_stage0 : string;
  attribute ap_ST_fsm_pp0_stage0 of inst : label is "3'b010";
  attribute ap_ST_fsm_state1 : string;
  attribute ap_ST_fsm_state1 of inst : label is "3'b001";
  attribute ap_ST_fsm_state5 : string;
  attribute ap_ST_fsm_state5 of inst : label is "3'b100";
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of ap_clk : signal is "xilinx.com:signal:clock:1.0 ap_clk CLK";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of ap_clk : signal is "XIL_INTERFACENAME ap_clk, ASSOCIATED_RESET ap_rst_n, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}}}, FREQ_HZ 100000000, PHASE 0.000, CLK_DOMAIN /clk_wiz_0_clk_out1";
  attribute X_INTERFACE_INFO of ap_done : signal is "xilinx.com:interface:acc_handshake:1.0 ap_ctrl done";
  attribute X_INTERFACE_INFO of ap_idle : signal is "xilinx.com:interface:acc_handshake:1.0 ap_ctrl idle";
  attribute X_INTERFACE_INFO of ap_ready : signal is "xilinx.com:interface:acc_handshake:1.0 ap_ctrl ready";
  attribute X_INTERFACE_PARAMETER of ap_ready : signal is "XIL_INTERFACENAME ap_ctrl, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {start {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} done {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} idle {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ready {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}}}";
  attribute X_INTERFACE_INFO of ap_rst_n : signal is "xilinx.com:signal:reset:1.0 ap_rst_n RST";
  attribute X_INTERFACE_PARAMETER of ap_rst_n : signal is "XIL_INTERFACENAME ap_rst_n, POLARITY ACTIVE_LOW, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}}}";
  attribute X_INTERFACE_INFO of ap_start : signal is "xilinx.com:interface:acc_handshake:1.0 ap_ctrl start";
  attribute X_INTERFACE_INFO of bias_Clk_A : signal is "xilinx.com:interface:bram:1.0 bias_PORTA CLK";
  attribute X_INTERFACE_INFO of bias_EN_A : signal is "xilinx.com:interface:bram:1.0 bias_PORTA EN";
  attribute X_INTERFACE_INFO of bias_Rst_A : signal is "xilinx.com:interface:bram:1.0 bias_PORTA RST";
  attribute X_INTERFACE_INFO of input_r_Clk_A : signal is "xilinx.com:interface:bram:1.0 input_r_PORTA CLK";
  attribute X_INTERFACE_INFO of input_r_EN_A : signal is "xilinx.com:interface:bram:1.0 input_r_PORTA EN";
  attribute X_INTERFACE_INFO of input_r_Rst_A : signal is "xilinx.com:interface:bram:1.0 input_r_PORTA RST";
  attribute X_INTERFACE_INFO of output_r_Clk_A : signal is "xilinx.com:interface:bram:1.0 output_r_PORTA CLK";
  attribute X_INTERFACE_INFO of output_r_EN_A : signal is "xilinx.com:interface:bram:1.0 output_r_PORTA EN";
  attribute X_INTERFACE_INFO of output_r_Rst_A : signal is "xilinx.com:interface:bram:1.0 output_r_PORTA RST";
  attribute X_INTERFACE_INFO of bias_Addr_A : signal is "xilinx.com:interface:bram:1.0 bias_PORTA ADDR";
  attribute X_INTERFACE_INFO of bias_Din_A : signal is "xilinx.com:interface:bram:1.0 bias_PORTA DIN";
  attribute X_INTERFACE_INFO of bias_Dout_A : signal is "xilinx.com:interface:bram:1.0 bias_PORTA DOUT";
  attribute X_INTERFACE_PARAMETER of bias_Dout_A : signal is "XIL_INTERFACENAME bias_PORTA, MEM_WIDTH 32, MEM_SIZE 160, MASTER_TYPE BRAM_CTRL, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {EN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ADDR {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} WE {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 4} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} DIN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}} DOUT {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}}, MEM_ECC NONE";
  attribute X_INTERFACE_INFO of bias_WEN_A : signal is "xilinx.com:interface:bram:1.0 bias_PORTA WE";
  attribute X_INTERFACE_INFO of input_r_Addr_A : signal is "xilinx.com:interface:bram:1.0 input_r_PORTA ADDR";
  attribute X_INTERFACE_INFO of input_r_Din_A : signal is "xilinx.com:interface:bram:1.0 input_r_PORTA DIN";
  attribute X_INTERFACE_INFO of input_r_Dout_A : signal is "xilinx.com:interface:bram:1.0 input_r_PORTA DOUT";
  attribute X_INTERFACE_PARAMETER of input_r_Dout_A : signal is "XIL_INTERFACENAME input_r_PORTA, MEM_WIDTH 32, MEM_SIZE 11520, MASTER_TYPE BRAM_CTRL, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {EN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ADDR {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} WE {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 4} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} DIN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}} DOUT {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}}, MEM_ECC NONE";
  attribute X_INTERFACE_INFO of input_r_WEN_A : signal is "xilinx.com:interface:bram:1.0 input_r_PORTA WE";
  attribute X_INTERFACE_INFO of output_r_Addr_A : signal is "xilinx.com:interface:bram:1.0 output_r_PORTA ADDR";
  attribute X_INTERFACE_INFO of output_r_Din_A : signal is "xilinx.com:interface:bram:1.0 output_r_PORTA DIN";
  attribute X_INTERFACE_INFO of output_r_Dout_A : signal is "xilinx.com:interface:bram:1.0 output_r_PORTA DOUT";
  attribute X_INTERFACE_PARAMETER of output_r_Dout_A : signal is "XIL_INTERFACENAME output_r_PORTA, MEM_WIDTH 32, MEM_SIZE 10240, MASTER_TYPE BRAM_CTRL, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {EN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} CLK {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} RST {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 1} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0}}} ADDR {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} WE {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 4} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} DIN {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}} DOUT {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}}, MEM_ECC NONE";
  attribute X_INTERFACE_INFO of output_r_WEN_A : signal is "xilinx.com:interface:bram:1.0 output_r_PORTA WE";
begin
inst: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_a0_Conv2_12x12x20_5x5x40_1_0
     port map (
      ap_clk => ap_clk,
      ap_done => ap_done,
      ap_idle => ap_idle,
      ap_ready => ap_ready,
      ap_rst_n => ap_rst_n,
      ap_start => ap_start,
      bias_Addr_A(31 downto 0) => bias_Addr_A(31 downto 0),
      bias_Clk_A => bias_Clk_A,
      bias_Din_A(31 downto 0) => bias_Din_A(31 downto 0),
      bias_Dout_A(31 downto 0) => bias_Dout_A(31 downto 0),
      bias_EN_A => bias_EN_A,
      bias_Rst_A => bias_Rst_A,
      bias_WEN_A(3 downto 0) => bias_WEN_A(3 downto 0),
      input_r_Addr_A(31 downto 0) => input_r_Addr_A(31 downto 0),
      input_r_Clk_A => input_r_Clk_A,
      input_r_Din_A(31 downto 0) => input_r_Din_A(31 downto 0),
      input_r_Dout_A(31 downto 0) => input_r_Dout_A(31 downto 0),
      input_r_EN_A => input_r_EN_A,
      input_r_Rst_A => input_r_Rst_A,
      input_r_WEN_A(3 downto 0) => input_r_WEN_A(3 downto 0),
      output_r_Addr_A(31 downto 0) => output_r_Addr_A(31 downto 0),
      output_r_Clk_A => output_r_Clk_A,
      output_r_Din_A(31 downto 0) => output_r_Din_A(31 downto 0),
      output_r_Dout_A(31 downto 0) => output_r_Dout_A(31 downto 0),
      output_r_EN_A => output_r_EN_A,
      output_r_Rst_A => output_r_Rst_A,
      output_r_WEN_A(3 downto 0) => output_r_WEN_A(3 downto 0)
    );
end STRUCTURE;
