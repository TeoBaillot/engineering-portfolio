// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2018.2 (lin64) Build 2258646 Thu Jun 14 20:02:38 MDT 2018
// Date        : Wed Dec 17 17:09:03 2025
// Host        : PCII-REF running 64-bit Ubuntu 22.04.5 LTS
// Command     : write_verilog -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ zed_Conv1_28x28x1_5x5x20_1_0_1_0_stub.v
// Design      : zed_Conv1_28x28x1_5x5x20_1_0_1_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7z020clg484-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "a0_Conv1_28x28x1_5x5x20_1_0,Vivado 2018.2" *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix(ap_clk, ap_rst_n, ap_start, ap_done, ap_idle, 
  ap_ready, input_r_Clk_A, input_r_Rst_A, input_r_EN_A, input_r_WEN_A, input_r_Addr_A, 
  input_r_Din_A, input_r_Dout_A, kernel_Clk_A, kernel_Rst_A, kernel_EN_A, kernel_WEN_A, 
  kernel_Addr_A, kernel_Din_A, kernel_Dout_A, bias_Clk_A, bias_Rst_A, bias_EN_A, bias_WEN_A, 
  bias_Addr_A, bias_Din_A, bias_Dout_A, output_r_Clk_A, output_r_Rst_A, output_r_EN_A, 
  output_r_WEN_A, output_r_Addr_A, output_r_Din_A, output_r_Dout_A)
/* synthesis syn_black_box black_box_pad_pin="ap_clk,ap_rst_n,ap_start,ap_done,ap_idle,ap_ready,input_r_Clk_A,input_r_Rst_A,input_r_EN_A,input_r_WEN_A[3:0],input_r_Addr_A[31:0],input_r_Din_A[31:0],input_r_Dout_A[31:0],kernel_Clk_A,kernel_Rst_A,kernel_EN_A,kernel_WEN_A[3:0],kernel_Addr_A[31:0],kernel_Din_A[31:0],kernel_Dout_A[31:0],bias_Clk_A,bias_Rst_A,bias_EN_A,bias_WEN_A[3:0],bias_Addr_A[31:0],bias_Din_A[31:0],bias_Dout_A[31:0],output_r_Clk_A,output_r_Rst_A,output_r_EN_A,output_r_WEN_A[3:0],output_r_Addr_A[31:0],output_r_Din_A[31:0],output_r_Dout_A[31:0]" */;
  input ap_clk;
  input ap_rst_n;
  input ap_start;
  output ap_done;
  output ap_idle;
  output ap_ready;
  output input_r_Clk_A;
  output input_r_Rst_A;
  output input_r_EN_A;
  output [3:0]input_r_WEN_A;
  output [31:0]input_r_Addr_A;
  output [31:0]input_r_Din_A;
  input [31:0]input_r_Dout_A;
  output kernel_Clk_A;
  output kernel_Rst_A;
  output kernel_EN_A;
  output [3:0]kernel_WEN_A;
  output [31:0]kernel_Addr_A;
  output [31:0]kernel_Din_A;
  input [31:0]kernel_Dout_A;
  output bias_Clk_A;
  output bias_Rst_A;
  output bias_EN_A;
  output [3:0]bias_WEN_A;
  output [31:0]bias_Addr_A;
  output [31:0]bias_Din_A;
  input [31:0]bias_Dout_A;
  output output_r_Clk_A;
  output output_r_Rst_A;
  output output_r_EN_A;
  output [3:0]output_r_WEN_A;
  output [31:0]output_r_Addr_A;
  output [31:0]output_r_Din_A;
  input [31:0]output_r_Dout_A;
endmodule
