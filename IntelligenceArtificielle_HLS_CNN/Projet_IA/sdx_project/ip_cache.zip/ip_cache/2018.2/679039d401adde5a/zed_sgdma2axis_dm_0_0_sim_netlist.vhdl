-- Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2018.2 (lin64) Build 2258646 Thu Jun 14 20:02:38 MDT 2018
-- Date        : Wed Dec 17 13:25:05 2025
-- Host        : PCII-REF running 64-bit Ubuntu 22.04.5 LTS
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ zed_sgdma2axis_dm_0_0_sim_netlist.vhdl
-- Design      : zed_sgdma2axis_dm_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7z020clg484-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_sgdma2axis_ic is
  port (
    ctrl_tready : out STD_LOGIC;
    axis_tdest : out STD_LOGIC_VECTOR ( 3 downto 0 );
    data_tready : out STD_LOGIC;
    axis_tvalid : out STD_LOGIC;
    ctrl_tvalid : in STD_LOGIC;
    arstn : in STD_LOGIC;
    clk : in STD_LOGIC;
    ctrl_tdata : in STD_LOGIC_VECTOR ( 3 downto 0 );
    ctrl_tlast : in STD_LOGIC;
    axis_tready : in STD_LOGIC;
    data_tvalid : in STD_LOGIC;
    data_tlast : in STD_LOGIC
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_sgdma2axis_ic;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_sgdma2axis_ic is
  signal count : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal count1 : STD_LOGIC;
  signal \count[0]_i_1_n_0\ : STD_LOGIC;
  signal \count[1]_i_1_n_0\ : STD_LOGIC;
  signal \count[2]_i_1_n_0\ : STD_LOGIC;
  signal \^ctrl_tready\ : STD_LOGIC;
  signal p_0_in : STD_LOGIC;
  signal state : STD_LOGIC;
  signal state00_out : STD_LOGIC;
  signal state_i_1_n_0 : STD_LOGIC;
  signal \tdest[3]_i_2_n_0\ : STD_LOGIC;
  signal tready_i_1_n_0 : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of axis_tvalid_INST_0 : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \count[2]_i_2\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of data_tready_INST_0 : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of tready_i_1 : label is "soft_lutpair0";
begin
  ctrl_tready <= \^ctrl_tready\;
axis_tvalid_INST_0: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => data_tvalid,
      I1 => state,
      O => axis_tvalid
    );
\count[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"006A0000"
    )
        port map (
      I0 => count(0),
      I1 => ctrl_tvalid,
      I2 => \^ctrl_tready\,
      I3 => state,
      I4 => arstn,
      O => \count[0]_i_1_n_0\
    );
\count[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"006A00AA00000000"
    )
        port map (
      I0 => count(1),
      I1 => ctrl_tvalid,
      I2 => \^ctrl_tready\,
      I3 => state,
      I4 => count(0),
      I5 => arstn,
      O => \count[1]_i_1_n_0\
    );
\count[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"060A0A0A00000000"
    )
        port map (
      I0 => count(2),
      I1 => count1,
      I2 => state,
      I3 => count(1),
      I4 => count(0),
      I5 => arstn,
      O => \count[2]_i_1_n_0\
    );
\count[2]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => ctrl_tvalid,
      I1 => \^ctrl_tready\,
      O => count1
    );
\count_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \count[0]_i_1_n_0\,
      Q => count(0),
      R => '0'
    );
\count_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \count[1]_i_1_n_0\,
      Q => count(1),
      R => '0'
    );
\count_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \count[2]_i_1_n_0\,
      Q => count(2),
      R => '0'
    );
data_tready_INST_0: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => axis_tready,
      I1 => state,
      O => data_tready
    );
state_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2EEEEEEE00000000"
    )
        port map (
      I0 => state00_out,
      I1 => state,
      I2 => data_tvalid,
      I3 => axis_tready,
      I4 => data_tlast,
      I5 => arstn,
      O => state_i_1_n_0
    );
state_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => ctrl_tlast,
      I1 => ctrl_tvalid,
      O => state00_out
    );
state_reg: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => state_i_1_n_0,
      Q => state,
      R => '0'
    );
\tdest[3]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => arstn,
      O => p_0_in
    );
\tdest[3]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000008"
    )
        port map (
      I0 => ctrl_tvalid,
      I1 => count(1),
      I2 => count(2),
      I3 => count(0),
      I4 => state,
      O => \tdest[3]_i_2_n_0\
    );
\tdest_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \tdest[3]_i_2_n_0\,
      D => ctrl_tdata(0),
      Q => axis_tdest(0),
      R => p_0_in
    );
\tdest_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \tdest[3]_i_2_n_0\,
      D => ctrl_tdata(1),
      Q => axis_tdest(1),
      R => p_0_in
    );
\tdest_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \tdest[3]_i_2_n_0\,
      D => ctrl_tdata(2),
      Q => axis_tdest(2),
      R => p_0_in
    );
\tdest_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \tdest[3]_i_2_n_0\,
      D => ctrl_tdata(3),
      Q => axis_tdest(3),
      R => p_0_in
    );
tready_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"88880CCC"
    )
        port map (
      I0 => \^ctrl_tready\,
      I1 => arstn,
      I2 => ctrl_tvalid,
      I3 => ctrl_tlast,
      I4 => state,
      O => tready_i_1_n_0
    );
tready_reg: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => tready_i_1_n_0,
      Q => \^ctrl_tready\,
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    clk : in STD_LOGIC;
    arstn : in STD_LOGIC;
    data_tdata : in STD_LOGIC_VECTOR ( 63 downto 0 );
    data_tvalid : in STD_LOGIC;
    data_tlast : in STD_LOGIC;
    data_tready : out STD_LOGIC;
    data_tkeep : in STD_LOGIC_VECTOR ( 7 downto 0 );
    ctrl_tdata : in STD_LOGIC_VECTOR ( 31 downto 0 );
    ctrl_tvalid : in STD_LOGIC;
    ctrl_tlast : in STD_LOGIC;
    ctrl_tready : out STD_LOGIC;
    ctrl_tkeep : in STD_LOGIC_VECTOR ( 3 downto 0 );
    axis_tdata : out STD_LOGIC_VECTOR ( 63 downto 0 );
    axis_tvalid : out STD_LOGIC;
    axis_tlast : out STD_LOGIC;
    axis_tready : in STD_LOGIC;
    axis_tkeep : out STD_LOGIC_VECTOR ( 7 downto 0 );
    axis_tdest : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "zed_sgdma2axis_dm_0_0,sgdma2axis_ic,{}";
  attribute DowngradeIPIdentifiedWarnings : string;
  attribute DowngradeIPIdentifiedWarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute IP_DEFINITION_SOURCE : string;
  attribute IP_DEFINITION_SOURCE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "package_project";
  attribute X_CORE_INFO : string;
  attribute X_CORE_INFO of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "sgdma2axis_ic,Vivado 2018.2";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  signal \^data_tdata\ : STD_LOGIC_VECTOR ( 63 downto 0 );
  signal \^data_tkeep\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \^data_tlast\ : STD_LOGIC;
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of arstn : signal is "xilinx.com:signal:reset:1.0 arstn RST";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of arstn : signal is "XIL_INTERFACENAME arstn, POLARITY ACTIVE_LOW";
  attribute X_INTERFACE_INFO of axis_tlast : signal is "xilinx.com:interface:axis:1.0 M_AXIS_DATA TLAST";
  attribute X_INTERFACE_INFO of axis_tready : signal is "xilinx.com:interface:axis:1.0 M_AXIS_DATA TREADY";
  attribute X_INTERFACE_INFO of axis_tvalid : signal is "xilinx.com:interface:axis:1.0 M_AXIS_DATA TVALID";
  attribute X_INTERFACE_INFO of clk : signal is "xilinx.com:signal:clock:1.0 clk CLK";
  attribute X_INTERFACE_PARAMETER of clk : signal is "XIL_INTERFACENAME clk, ASSOCIATED_BUSIF S_AXIS_DATA:S_AXIS_CTRL:M_AXIS_DATA, ASSOCIATED_RESET arstn, FREQ_HZ 100000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1";
  attribute X_INTERFACE_INFO of ctrl_tlast : signal is "xilinx.com:interface:axis:1.0 S_AXIS_CTRL TLAST";
  attribute X_INTERFACE_INFO of ctrl_tready : signal is "xilinx.com:interface:axis:1.0 S_AXIS_CTRL TREADY";
  attribute X_INTERFACE_INFO of ctrl_tvalid : signal is "xilinx.com:interface:axis:1.0 S_AXIS_CTRL TVALID";
  attribute X_INTERFACE_INFO of data_tlast : signal is "xilinx.com:interface:axis:1.0 S_AXIS_DATA TLAST";
  attribute X_INTERFACE_INFO of data_tready : signal is "xilinx.com:interface:axis:1.0 S_AXIS_DATA TREADY";
  attribute X_INTERFACE_INFO of data_tvalid : signal is "xilinx.com:interface:axis:1.0 S_AXIS_DATA TVALID";
  attribute X_INTERFACE_INFO of axis_tdata : signal is "xilinx.com:interface:axis:1.0 M_AXIS_DATA TDATA";
  attribute X_INTERFACE_INFO of axis_tdest : signal is "xilinx.com:interface:axis:1.0 M_AXIS_DATA TDEST";
  attribute X_INTERFACE_PARAMETER of axis_tdest : signal is "XIL_INTERFACENAME M_AXIS_DATA, TDATA_NUM_BYTES 8, TDEST_WIDTH 4, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 1, HAS_TLAST 1, FREQ_HZ 100000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, LAYERED_METADATA undef";
  attribute X_INTERFACE_INFO of axis_tkeep : signal is "xilinx.com:interface:axis:1.0 M_AXIS_DATA TKEEP";
  attribute X_INTERFACE_INFO of ctrl_tdata : signal is "xilinx.com:interface:axis:1.0 S_AXIS_CTRL TDATA";
  attribute X_INTERFACE_INFO of ctrl_tkeep : signal is "xilinx.com:interface:axis:1.0 S_AXIS_CTRL TKEEP";
  attribute X_INTERFACE_PARAMETER of ctrl_tkeep : signal is "XIL_INTERFACENAME S_AXIS_CTRL, TDATA_NUM_BYTES 4, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 1, HAS_TLAST 1, FREQ_HZ 100000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, LAYERED_METADATA undef";
  attribute X_INTERFACE_INFO of data_tdata : signal is "xilinx.com:interface:axis:1.0 S_AXIS_DATA TDATA";
  attribute X_INTERFACE_INFO of data_tkeep : signal is "xilinx.com:interface:axis:1.0 S_AXIS_DATA TKEEP";
  attribute X_INTERFACE_PARAMETER of data_tkeep : signal is "XIL_INTERFACENAME S_AXIS_DATA, TDATA_NUM_BYTES 8, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 1, HAS_TLAST 1, FREQ_HZ 100000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, LAYERED_METADATA undef";
begin
  \^data_tdata\(63 downto 0) <= data_tdata(63 downto 0);
  \^data_tkeep\(7 downto 0) <= data_tkeep(7 downto 0);
  \^data_tlast\ <= data_tlast;
  axis_tdata(63 downto 0) <= \^data_tdata\(63 downto 0);
  axis_tkeep(7 downto 0) <= \^data_tkeep\(7 downto 0);
  axis_tlast <= \^data_tlast\;
inst: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_sgdma2axis_ic
     port map (
      arstn => arstn,
      axis_tdest(3 downto 0) => axis_tdest(3 downto 0),
      axis_tready => axis_tready,
      axis_tvalid => axis_tvalid,
      clk => clk,
      ctrl_tdata(3 downto 0) => ctrl_tdata(3 downto 0),
      ctrl_tlast => ctrl_tlast,
      ctrl_tready => ctrl_tready,
      ctrl_tvalid => ctrl_tvalid,
      data_tlast => \^data_tlast\,
      data_tready => data_tready,
      data_tvalid => data_tvalid
    );
end STRUCTURE;
